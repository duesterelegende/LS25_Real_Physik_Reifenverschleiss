--[[
    FS25_Reifenverschleiss
    Diagnostic TEST 0.1.0.76

    Purpose of this build:
      - validate the proven Lights & Symbol HUD chassis recognition approach
      - separate normal wheels from GIANTS Crawler objects
      - expose physical axle/wheel structure for diagnostics
      - expose crawler objects individually
      - collect distance, speed, slip, tire type, contact, load and crawler data
      - test tire wear is calculated and stored only in the independent own-wear model
      - NO tire deformation or tire-pressure dependency
      - NO changes to vehicle physics
      - TEST0.1.0.44 adds the first physically based load/width/radius wear model.

    The diagnostic layer and test wear formula remain deliberately conservative and traceable.
]]

-- RELEASE: suppress development/diagnostic print output only.
-- Functional code paths remain identical to TEST2_3_136.
local function print(...)
end

ReifenVerschleissDiagnostic = {}

local RV = ReifenVerschleissDiagnostic

-- Explicitly excluded third-party vehicle with incompatible custom tire shader/UV layout.
local function rvIsExplicitlyExcludedVehicle(vehicle)
    if vehicle == nil then return false end
    local config = string.lower(tostring(vehicle.configFileName or vehicle.xmlFileName or ""))
    config = string.gsub(config, "\\", "/")
    return string.find(config, "/fs25_johndeere_7r_2020/", 1, true) ~= nil
end

function RV.isVehicleExcluded(vehicle)
    return rvIsExplicitlyExcludedVehicle(vehicle)
end
RV.DIAGNOSTIC_DISPLAY_ENABLED = true
RV.VERSION = "1.2.1.0"

RV.LOG_INTERVAL_MS = 1000
RV.DEBUG_DISTANCE_M = 0
RV.DEBUG_TIME_MS = 0

-- Wear model uses the proven 100 km reference.
RV.WEAR_REFERENCE_DISTANCE_M = 100000
RV.WEAR_MAX = 1

-- Physical-load test model (REALISTIC BASELINE, NOT GAME-TUNED YET).
-- The later FS25 game scaling must remain separate from these physical inputs.
RV.PHYSICS_REFERENCE_LOAD_T = 2.5       -- nominal tire-load reference
RV.PHYSICS_REFERENCE_WIDTH_M = 0.60     -- nominal tire-width reference
RV.PHYSICS_REFERENCE_RADIUS_M = 0.75    -- nominal tire-radius reference
RV.PHYSICS_LOAD_EXPONENT = 0.75
RV.PHYSICS_WIDTH_EXPONENT = 0.50
RV.PHYSICS_RADIUS_EXPONENT = 0.35
RV.totalEffectiveWearDistanceM = 0
RV.lastSpeedKmh = 0
RV.lastVehicleForMotion = nil

RV.currentVehicle = nil
-- Vehicles that were explicitly handed over to an automated driver remain
-- eligible for wear processing after the player leaves the cab.
local aiTrackedVehicles = {}

-- TEST0.2.2.78: independent per-vehicle wear activity. This is deliberately
-- separate from currentVehicle/activeVehicle so changing the player's vehicle
-- cannot remove an already running AD/CP/GIANTS-AI vehicle from wear processing.
local activeWearVehicles = setmetatable({}, {__mode = "k"})

-- TEST0.2.2.77: experimental activeVehicle hold. The existing diagnostic
-- currentVehicle is retained when the HUD clears its controlled vehicle while
-- the same vehicle is still moving or has an automated driver. No GIANTS
-- controlledVehicle field is modified.
local activeVehicleHeld = false
local aiWearAccumulatorMs = 0
RV.manifest = nil
RV.lastLogTime = -math.huge
RV.lastDisplayTime = 0
RV.vehicleSerial = 0

local manifestCache = setmetatable({}, {__mode = "k"})

-- Persistent per-vehicle wear state. The calculation belongs to the
-- relevant player-owned vehicle, not to the currently entered vehicle.
-- Vehicles owned by other farms/players and unowned/AI mission vehicles are
-- deliberately excluded from wear processing.
local vehicleWearStates = setmetatable({}, {__mode = "k"})

-- OWN-WEAR persistence is stored directly inside each GIANTS vehicles.xml
-- vehicle node. The pending table is keyed by the concrete vehicle object, so
-- save/load does not need a parallel sidecar file or a second identity mapping.
local pendingSavedWearStates = setmetatable({}, {__mode = "k"})
local capturedVehicleWearSavegame = setmetatable({}, {__mode = "k"})
local lastVehicleScanTime = -math.huge
local ownedMotorizedVehicleCache = {}
local ownedAttachedImplementCache = {}
RV.VEHICLE_SCAN_INTERVAL_MS = 1000
-- TEST0.2.2.89: automated-driver wear tracker cadence.
-- AI vehicles are sampled from world position every 300 ms; the player
-- controlled vehicle keeps the proven normal update cadence.
RV.AI_WEAR_UPDATE_INTERVAL_MS = 300
RV.SAVE_SCHEMA_VERSION = 14
RV.DEBUG_FORMULA = false
RV.DEBUG_SAVE_VERIFY = false
RV.DEBUG_MAX_WHEELS_PER_LOG = 64

-- TEST0.2.2.01: non-invasive physics-hook probe.
-- This does NOT apply a traction/wear malus. It only proves whether the
-- already installed Wheels.updateWheelFriction callback reaches our code.
RV.DEBUG_HOOK_PROBE_ENABLED = false
RV.DEBUG_HOOK_PROBE_MAX_PER_WHEEL = 5
RV.DEBUG_HOOK_PROBE_COUNTS = setmetatable({}, {__mode = "k"})

-- TEST0.2.2.08: native WheelPhysics friction reference probe.
-- TEST0.2.2.12 applies a wear-dependent target to coeff*frictionScale; frictionScale itself remains untouched.
-- It only records the values immediately before/after the native GIANTS
-- updateFriction/updateTireFriction path.
RV.DEBUG_WHEEL_PHYSICS_HOOK_ACTIVE = false
RV.DEBUG_WHEEL_PHYSICS_HOOK_CALLS = 0
RV.DEBUG_WHEEL_PHYSICS_LAST_WHEEL = "?"
RV.DEBUG_WHEEL_PHYSICS_LAST_COEFF_BEFORE = nil
RV.DEBUG_WHEEL_PHYSICS_LAST_COEFF_AFTER = nil
RV.DEBUG_WHEEL_PHYSICS_LAST_SCALE_BEFORE = nil
RV.DEBUG_WHEEL_PHYSICS_LAST_SCALE_AFTER = nil
RV.DEBUG_WHEEL_PHYSICS_LAST_APPLIED = nil
RV.DEBUG_WHEEL_PHYSICS_LAST_RAW_SLIP = nil
RV.DEBUG_WHEEL_PHYSICS_LAST_GROUND_TYPE = nil
RV.DEBUG_WHEEL_PHYSICS_LAST_CONTACT = nil
-- TEST0.2.2.13: keep friction diagnostics separated per physical vehicle object.
RV.DEBUG_WHEEL_PHYSICS_OBJECTS = setmetatable({}, {__mode = "k"})

local function rvGetObjectType(vehicle)
    if vehicle == nil then return "UNKNOWN" end
    if vehicle.getAttacherVehicle ~= nil then
        local ok, parent = pcall(vehicle.getAttacherVehicle, vehicle)
        if ok and parent ~= nil then return "ATTACHED IMPLEMENT/TRAILER" end
    end
    return "VEHICLE"
end

local function rvGetObjectLabel(vehicle)
    if vehicle == nil then return "UNKNOWN" end
    return tostring(vehicle.configFileName or vehicle.xmlFileName or vehicle.typeName or "UNKNOWN")
end

local function rvGetObjectDiag(vehicle)
    if vehicle == nil then return nil end
    local d = RV.DEBUG_WHEEL_PHYSICS_OBJECTS[vehicle]
    if d == nil then
        d = {objectType = rvGetObjectType(vehicle), label = rvGetObjectLabel(vehicle), calls = 0, lastWheel = "?", before = nil, after = nil, applied = nil, rawSlip = nil}
        RV.DEBUG_WHEEL_PHYSICS_OBJECTS[vehicle] = d
    else
        d.objectType = rvGetObjectType(vehicle)
        d.label = rvGetObjectLabel(vehicle)
    end
    return d
end
RV.DEBUG_WHEEL_PHYSICS_MAX_LOG = 32

local function rvGetPhysicsRawSlip(physics)
    if physics == nil or physics.wheelShape == nil or physics.wheelShape == 0 then return nil end
    local wheel = physics.wheel
    if wheel == nil or wheel.node == nil or getWheelShapeSlip == nil then return nil end
    local ok, longSlip = pcall(getWheelShapeSlip, wheel.node, physics.wheelShape)
    if ok and type(longSlip) == "number" and longSlip == longSlip then return longSlip end
    return nil
end

function ReifenVerschleissDiagnostic.probeWheelPhysicsBefore(physics, stage)
    if physics == nil then return end
    RV.DEBUG_WHEEL_PHYSICS_HOOK_ACTIVE = false
    RV.DEBUG_WHEEL_PHYSICS_HOOK_CALLS = (RV.DEBUG_WHEEL_PHYSICS_HOOK_CALLS or 0) + 1
    local wheel = physics.wheel
    local wi = wheel ~= nil and wheel.wheelIndex or "?"
    local coeff = physics.tireGroundFrictionCoeff
    local scale = physics.frictionScale
    local rawSlip = rvGetPhysicsRawSlip(physics)
    RV.DEBUG_WHEEL_PHYSICS_LAST_WHEEL = tostring(wi)
    RV.DEBUG_WHEEL_PHYSICS_LAST_COEFF_BEFORE = coeff
    RV.DEBUG_WHEEL_PHYSICS_LAST_SCALE_BEFORE = scale
    RV.DEBUG_WHEEL_PHYSICS_LAST_RAW_SLIP = rawSlip
    RV.DEBUG_WHEEL_PHYSICS_LAST_GROUND_TYPE = physics.densityType
    RV.DEBUG_WHEEL_PHYSICS_LAST_CONTACT = physics.contact
    local objectDiag = rvGetObjectDiag(wheel ~= nil and wheel.vehicle or nil)
    if objectDiag ~= nil then
        objectDiag.calls = objectDiag.calls + 1
        objectDiag.lastWheel = tostring(wi)
        objectDiag.before = coeff
        objectDiag.rawSlip = rawSlip
    end
    if RV.DEBUG_WHEEL_PHYSICS_HOOK_CALLS <= RV.DEBUG_WHEEL_PHYSICS_MAX_LOG then
        print(string.format("[ReifenVerschleiss][NATIVE-FRICTION-REF] %s BEFORE W%s coeff=%s frictionScale=%s applied=%s dirty=%s rawSlip=%s groundType=%s contact=%s",
            tostring(stage or "?"), tostring(wi),
            coeff ~= nil and string.format("%.6f", coeff) or "nil",
            scale ~= nil and string.format("%.6f", scale) or "nil",
            (type(coeff)=="number" and type(scale)=="number") and string.format("%.6f", coeff*scale) or "nil",
            tostring(physics.isFrictionDirty), rawSlip ~= nil and string.format("%.2f%%", rawSlip*100) or "nil", tostring(physics.densityType), tostring(physics.contact)))
    end
end

function ReifenVerschleissDiagnostic.probeWheelPhysicsAfter(physics, stage)
    if physics == nil then return end
    RV.DEBUG_WHEEL_PHYSICS_HOOK_ACTIVE = false
    local coeff = physics.tireGroundFrictionCoeff
    local scale = physics.frictionScale
    local applied = (type(coeff)=="number" and type(scale)=="number") and coeff*scale or nil
    RV.DEBUG_WHEEL_PHYSICS_LAST_COEFF_AFTER = coeff
    RV.DEBUG_WHEEL_PHYSICS_LAST_SCALE_AFTER = scale
    RV.DEBUG_WHEEL_PHYSICS_LAST_APPLIED = applied
    local objectDiag = rvGetObjectDiag(physics.wheel ~= nil and physics.wheel.vehicle or nil)
    if objectDiag ~= nil then
        objectDiag.lastWheel = tostring(RV.DEBUG_WHEEL_PHYSICS_LAST_WHEEL or "?")
        objectDiag.after = coeff
        objectDiag.applied = applied
    end
    if RV.DEBUG_WHEEL_PHYSICS_HOOK_CALLS <= RV.DEBUG_WHEEL_PHYSICS_MAX_LOG then
        print(string.format("[ReifenVerschleiss][NATIVE-FRICTION-REF] %s AFTER W%s coeff=%s frictionScale=%s applied=%s dirty=%s",
            tostring(stage or "?"), tostring(RV.DEBUG_WHEEL_PHYSICS_LAST_WHEEL or "?"),
            coeff ~= nil and string.format("%.6f", coeff) or "nil",
            scale ~= nil and string.format("%.6f", scale) or "nil",
            applied ~= nil and string.format("%.6f", applied) or "nil",
            tostring(physics.isFrictionDirty)))
    end
end

-- Backward-compatible names retained for the existing HUD/diagnostic code.
-- TEST0.2.2.14: native-GIANTS-scaled wear -> applied friction target curve.
-- The proven 1.80 reference curve is scaled to the native GIANTS frictionScale
-- for the current wheel. From 90% wear onward the absolute end curve is fixed
-- at 0.55 -> 0.40 -> 0.30 for every native start value.
function ReifenVerschleissDiagnostic.getWearAppliedTarget(vehicle, wheel)
    if vehicle == nil or wheel == nil then
        return nil, nil
    end

    local wear = ReifenVerschleissDiagnostic.getWheelWearValue(vehicle, wheel)
    if type(wear) ~= "number" then
        return nil, nil
    end
    wear = math.clamp(wear, 0, 1)
    local pct = wear * 100

    local function lerp(a, b, t)
        return a + (b - a) * math.clamp(t, 0, 1)
    end

    -- Use the native GIANTS frictionScale as the individual 0% reference.
    -- This keeps the complete 1.80 reference curve proportional through 75%.
    local nativeStart = nil
    if wheel.physics ~= nil and type(wheel.physics.frictionScale) == "number" then
        nativeStart = wheel.physics.frictionScale
    elseif wheel.wheelPhysics ~= nil and type(wheel.wheelPhysics.frictionScale) == "number" then
        nativeStart = wheel.wheelPhysics.frictionScale
    end

    if type(nativeStart) ~= "number" or nativeStart <= 0 then
        return nil, pct
    end

    local scale = nativeStart / 1.80
    local applied
    if pct <= 15 then
        applied = 1.80 * scale
    elseif pct <= 25 then
        applied = lerp(1.80, 1.60, (pct - 15) / 10) * scale
    elseif pct <= 40 then
        applied = lerp(1.60, 1.40, (pct - 25) / 15) * scale
    elseif pct <= 60 then
        applied = lerp(1.40, 1.20, (pct - 40) / 20) * scale
    elseif pct <= 75 then
        applied = lerp(1.20, 1.00, (pct - 60) / 15) * scale
    elseif pct <= 90 then
        -- 75% keeps the scaled 1.00 reference point; 90% MUST reach 0.55
        -- absolute, regardless of the native starting value.
        local start75 = 1.00 * scale
        applied = lerp(start75, 0.55, (pct - 75) / 15)
    elseif pct <= 95 then
        applied = lerp(0.55, 0.40, (pct - 90) / 5)
    else
        applied = lerp(0.40, 0.30, (pct - 95) / 5)
    end

    return applied, pct
end

function ReifenVerschleissDiagnostic.probeWheelPhysicsFriction(physics)
    ReifenVerschleissDiagnostic.probeWheelPhysicsBefore(physics, "updateFriction")
end

function ReifenVerschleissDiagnostic.probeWheelPhysicsApplied(physics)
    ReifenVerschleissDiagnostic.probeWheelPhysicsAfter(physics, "updateTireFriction")
end

local function getVehicleWearState(vehicle)
    if vehicle == nil then
        return nil
    end

    local state = vehicleWearStates[vehicle]
    if state == nil then
        state = {
            wear = {},
            wheelWear = {},
            trackWear = {},
            totalEffectiveWearDistanceM = 0,
            lastSpeedKmh = 0,
            debugDistanceM = 0,
            gpsDistanceM = 0,
            gpsLastX = nil,
            gpsLastY = nil,
            gpsLastZ = nil,
            debugTimeMs = 0,
            initialized = false,
            ready = false,
            readySince = 0,
            lastReadyLog = false,
            totalDistanceWear = 0,
            totalSlipWear = 0,
            totalTimeWear = 0,
            totalWear = 0,
            timeWearMoveConfirmSec = 0,
            timeWearWindowSec = 0,
            timeWearWindowDistanceM = 0,
            timeWearRatePointsPerHourAt1000 = 7.5,
            timeWearWindowAvgSpeedKmh = 0,
            timeWearHarvestBoostActive = false,
            lastWheelCount = 0,
            loadedFromSavegame = false,
            debugStep = 0,
            debugLastDistanceWear = {},
            debugLastSlipWear = {},
            debugLastTotalWear = {},
            debugLastLoggedDistanceWear = {},
            debugLastLoggedSlipWear = {},
            debugLastLoggedTotalWear = {},
            slipDisplayReady = false,
            slipDisplayLast = {},
            slipDisplayRotation = {},
            slipDisplayBlocked = true
        }
        vehicleWearStates[vehicle] = state
    end

    return state
end


local function safeNumber(value, fallback)
    if type(value) == "number" and value == value and math.abs(value) < math.huge then
        return value
    end
    return fallback
end

local function updateGpsDistance(state, object)
    if state == nil or object == nil or object.rootNode == nil or getWorldTranslation == nil then
        return 0
    end

    local x, y, z = getWorldTranslation(object.rootNode)
    x, y, z = safeNumber(x, nil), safeNumber(y, nil), safeNumber(z, nil)
    if x == nil or y == nil or z == nil then
        return 0
    end

    local delta = 0
    if state.gpsLastX ~= nil and state.gpsLastY ~= nil and state.gpsLastZ ~= nil then
        local dx = x - state.gpsLastX
        local dy = y - state.gpsLastY
        local dz = z - state.gpsLastZ
        delta = math.sqrt(dx * dx + dy * dy + dz * dz)
        -- Ignore implausible teleport/spawn jumps in the diagnostic GPS counter.
        if delta > 25 then
            delta = 0
        end
    end

    state.gpsLastX, state.gpsLastY, state.gpsLastZ = x, y, z
    state.gpsDistanceM = safeNumber(state.gpsDistanceM, 0) + math.max(0, delta)
    return delta
end

local function getWheelIndexKey(wheel, fallbackIndex)
    if wheel ~= nil and wheel.wheelIndex ~= nil then
        return wheel.wheelIndex
    end
    return fallbackIndex
end

local function isCrawlerTire(wheel)
    if wheel == nil or WheelsUtil == nil or WheelsUtil.getTireType == nil then
        return false
    end

    local crawlerType = WheelsUtil.getTireType("crawler")
    return crawlerType ~= nil and wheel.tireType == crawlerType
end

-- Resolve the GIANTS tire type name before any snow-profile code uses it.
-- This must be declared before getSnowProfile(): local Lua functions are
-- lexical, so a later local declaration is not visible to earlier functions.
local function getTireName(wheel)
    if wheel == nil then
        return "UNKNOWN"
    end

    -- Primary GIANTS source: tireType is an index into WheelsUtil.tireTypes.
    if WheelsUtil ~= nil and wheel.tireType ~= nil then
        if WheelsUtil.getTireTypeName ~= nil then
            local ok, name = pcall(WheelsUtil.getTireTypeName, wheel.tireType)
            if ok and name ~= nil and tostring(name) ~= "unknown" then
                return tostring(name)
            end
        end

        if WheelsUtil.tireTypes ~= nil and WheelsUtil.tireTypes[wheel.tireType] ~= nil then
            local name = WheelsUtil.tireTypes[wheel.tireType].name
            if name ~= nil then
                return tostring(name)
            end
        end
    end

    -- Some modded/crawler wheel objects expose the tire name on the wheel itself.
    if wheel.tireTypeName ~= nil then
        return tostring(wheel.tireTypeName)
    end
    if wheel.name ~= nil then
        return tostring(wheel.name)
    end

    return "UNKNOWN"
end

-- Same drivetrain traversal principle used by the proven HUD:
-- recursively resolve motorized differentials into wheel indices.
local function getTractionWheels(vehicle)
    local traction = {}
    local specMotorized = vehicle ~= nil and vehicle.spec_motorized or nil

    if specMotorized ~= nil and specMotorized.differentials ~= nil then
        local diffs = specMotorized.differentials
        local visited = {}

        local function visitDiff(index)
            if index == nil or visited[index] then
                return
            end

            visited[index] = true
            local diff = diffs[index]
            if diff == nil then
                return
            end

            if diff.diffIndex1IsWheel then
                traction[diff.diffIndex1] = true
            else
                visitDiff(diff.diffIndex1)
            end

            if diff.diffIndex2IsWheel then
                traction[diff.diffIndex2] = true
            else
                visitDiff(diff.diffIndex2)
            end
        end

        for index, _ in pairs(diffs) do
            visitDiff(index)
        end
    end

    return traction
end

local function addUnique(list, seen, wheel)
    if wheel ~= nil and not seen[wheel] then
        seen[wheel] = true
        list[#list + 1] = wheel
    end
end

local function getCrawlerMembers(vehicle, crawler, allWheels)
    local members = {}
    local seen = {}

    if crawler ~= nil and crawler.wheels ~= nil then
        for _, wheelData in pairs(crawler.wheels) do
            local wheel = wheelData ~= nil and wheelData.wheel or nil
            addUnique(members, seen, wheel)
        end
    end

    if crawler ~= nil and crawler.wheelNodes ~= nil then
        for _, node in pairs(crawler.wheelNodes) do
            if node ~= nil then
                for _, wheel in pairs(allWheels or {}) do
                    if wheel ~= nil and (wheel.repr == node or wheel.driveNode == node or wheel.linkNode == node) then
                        addUnique(members, seen, wheel)
                    end
                end
            end
        end
    end

    if crawler ~= nil and crawler.wheelIndices ~= nil then
        for _, index in pairs(crawler.wheelIndices) do
            local wheel = allWheels[index]
            addUnique(members, seen, wheel)
        end
    end

    -- Defensive recovery for runtimes exposing only a single reference wheel.
    if #members == 1 and crawler ~= nil and crawler.wheelIndices == nil and crawler.wheelNodes == nil then
        local reference = members[1]
        local referenceIndex = reference ~= nil and reference.wheelIndex or nil

        if referenceIndex ~= nil then
            local sideSign = crawler.isLeft == true and -1 or 1

            if crawler.linkNode ~= nil and vehicle ~= nil and vehicle.rootNode ~= nil then
                local ok, x = pcall(localToLocal, crawler.linkNode, vehicle.rootNode, 0, 0, 0)
                if ok and x ~= nil and math.abs(x) > 0.02 then
                    sideSign = x < 0 and -1 or 1
                end
            end

            local i = referenceIndex + 1
            while allWheels[i] ~= nil do
                local candidate = allWheels[i]
                if candidate.repr == nil then
                    break
                end

                local ok, x = pcall(localToLocal, candidate.repr, vehicle.rootNode, 0, 0, 0)
                if not ok or x == nil or x * sideSign <= 0.02 then
                    break
                end

                addUnique(members, seen, candidate)
                i = i + 1
            end
        end
    end

    -- Last-resort geometric recovery only when the Crawler object supplied no
    -- wheel membership at all. This is intentionally not a normal path.
    if #members == 0 and crawler ~= nil then
        local sideSign = crawler.isLeft == true and -1 or 1
        local candidates = {}

        for _, wheel in pairs(allWheels or {}) do
            if wheel ~= nil and wheel.repr ~= nil and isCrawlerTire(wheel) then
                local ok, x, _, z = pcall(localToLocal, wheel.repr, vehicle.rootNode, 0, 0, 0)
                if ok and x ~= nil and z ~= nil and x * sideSign > 0.02 then
                    candidates[#candidates + 1] = {wheel = wheel, z = z}
                end
            end
        end

        table.sort(candidates, function(a, b)
            return (a.z or 0) > (b.z or 0)
        end)

        for _, candidate in ipairs(candidates) do
            addUnique(members, seen, candidate.wheel)
        end
    end

    return members
end

local function getWheelLocalPosition(vehicle, wheel)
    if vehicle == nil or vehicle.rootNode == nil or wheel == nil or wheel.repr == nil then
        return nil, nil, nil
    end

    local ok, x, y, z = pcall(localToLocal, wheel.repr, vehicle.rootNode, 0, 0, 0)
    if ok then
        return x, y, z
    end

    return nil, nil, nil
end

local function getCrawlerLocalPosition(vehicle, crawler)
    if vehicle == nil or vehicle.rootNode == nil or crawler == nil or crawler.linkNode == nil then
        return nil, nil, nil
    end

    local ok, x, y, z = pcall(localToLocal, crawler.linkNode, vehicle.rootNode, 0, 0, 0)
    if ok then
        return x, y, z
    end

    return nil, nil, nil
end

-- ============================================================================
-- Fahrwerkstyp-Erkennung
--
-- Ziel: Nicht nur "Crawler" erkennen, sondern das konkrete Fahrwerk anhand
-- seiner tatsächlich vorhandenen GIANTS-Struktur eindeutig gruppieren.
-- Ein unbekanntes Strukturmuster wird während der Laufzeit automatisch als
-- neuer Fahrwerkstyp angelegt. Es ist deshalb keine manuelle Liste für jedes
-- neue Fahrzeug erforderlich.
--
-- Die Bezeichnung basiert NICHT allein auf dem Fahrzeugnamen. Entscheidend
-- sind Crawler-/Radanzahl, Seitenlage, Radpositionen, Radabmessungen und die
-- vorhandenen Crawler-Knoten. Der Fahrzeugname dient nur als lesbarer Hinweis.
-- ============================================================================
RV.CHASSIS_TYPE_REGISTRY = RV.CHASSIS_TYPE_REGISTRY or {}
RV.CHASSIS_TYPE_BY_SIGNATURE = RV.CHASSIS_TYPE_BY_SIGNATURE or {}
RV.NEXT_CHASSIS_TYPE_ID = RV.NEXT_CHASSIS_TYPE_ID or 1

local function rvRound(value, decimals)
    if type(value) ~= "number" then return 0 end
    local factor = 10 ^ (decimals or 3)
    return math.floor(value * factor + 0.5) / factor
end

local function rvNodeName(node)
    if node == nil then return "-" end
    if getName ~= nil then
        local ok, name = pcall(getName, node)
        if ok and name ~= nil and tostring(name) ~= "" then
            return tostring(name)
        end
    end
    return "NODE"
end

local function rvVehicleHint(vehicle)
    local raw = tostring(vehicle ~= nil and (vehicle.configFileName or vehicle.xmlFileName or vehicle.typeName or "") or "")
    local name = string.lower(raw)
    local brand = "UNKNOWN"
    if string.find(name, "johndeere", 1, true) or string.find(name, "john_deere", 1, true) or string.find(name, "john deere", 1, true) then
        brand = "JOHN_DEERE"
    elseif string.find(name, "newholland", 1, true) or string.find(name, "new_holland", 1, true) or string.find(name, "new holland", 1, true) then
        brand = "NEW_HOLLAND"
    elseif string.find(name, "caseih", 1, true) or string.find(name, "case_ih", 1, true) or string.find(name, "caseih", 1, true) then
        brand = "CASE_IH"
    elseif string.find(name, "case", 1, true) then
        brand = "CASE"
    elseif string.find(name, "fendt", 1, true) then
        brand = "FENDT"
    elseif string.find(name, "claas", 1, true) then
        brand = "CLAAS"
    elseif string.find(name, "ropa", 1, true) then
        brand = "ROPA"
    elseif string.find(name, "leitwolf", 1, true) then
        brand = "LEITWOLF"
    elseif string.find(name, "jf", 1, true) then
        brand = "JF"
    end
    return brand
end

local function rvChassisFamily(vehicle, manifest)
    if manifest ~= nil and (manifest.crawlerCount or 0) > 0 then
        return "CRAWLER"
    end
    local name = string.lower(tostring(vehicle ~= nil and (vehicle.configFileName or vehicle.xmlFileName or vehicle.typeName or "") or ""))
    if string.find(name, "harvester", 1, true) or string.find(name, "combine", 1, true) or string.find(name, "ernter", 1, true) then
        return "HARVESTER"
    end
    if string.find(name, "tractor", 1, true) or string.find(name, "traktor", 1, true) then
        return "TRACTOR"
    end
    return "WHEEL"
end

local function rvGetStableWheelRadius(wheel)
    if wheel == nil then return 0 end
    local physics = wheel.physics
    local candidates = {
        wheel.rvT9OriginalRadius,
        wheel.radiusOriginal,
        physics ~= nil and physics.radiusOriginal or nil,
        wheel.radius,
        physics ~= nil and physics.radius or nil
    }
    for _, value in ipairs(candidates) do
        if type(value) == "number" and value > 0 then
            return value
        end
    end
    return 0
end

local function rvGetStableWheelWidth(wheel)
    if wheel == nil then return 0 end
    local physics = wheel.physics
    local candidates = {
        wheel.width,
        physics ~= nil and physics.width or nil
    }
    for _, value in ipairs(candidates) do
        if type(value) == "number" and value > 0 then
            return value
        end
    end
    return 0
end

local function rvMakeWheelSignature(vehicle, wheel, driven)
    local wx, wy, wz = getWheelLocalPosition(vehicle, wheel)
    return string.format(
        "W@%.3f,%.3f,%.3f:r%.3f:w%.3f:d%d:c%d",
        rvRound(wx,3), rvRound(wy,3), rvRound(wz,3),
        rvRound(rvGetStableWheelRadius(wheel),3),
        rvRound(rvGetStableWheelWidth(wheel),3),
        driven and 1 or 0,
        isCrawlerTire(wheel) and 1 or 0
    )
end

local function rvMakeCrawlerSignature(vehicle, crawler, members)
    local parts = {}
    local x, y, z = getCrawlerLocalPosition(vehicle, crawler)
    parts[#parts + 1] = "C"
    parts[#parts + 1] = crawler.isLeft == true and "L" or "R"
    parts[#parts + 1] = string.format("N%d", #members)
    parts[#parts + 1] = string.format("P%.3f,%.3f,%.3f", rvRound(x,3), rvRound(y,3), rvRound(z,3))

    local wheelParts = {}
    for _, wheel in ipairs(members) do
        local wx, wy, wz = getWheelLocalPosition(vehicle, wheel)
        wheelParts[#wheelParts + 1] = string.format(
            "W@%.3f,%.3f,%.3f:r%.3f:w%.3f",
            rvRound(wx,3), rvRound(wy,3), rvRound(wz,3),
            rvRound(rvGetStableWheelRadius(wheel),3),
            rvRound(rvGetStableWheelWidth(wheel),3)
        )
    end
    table.sort(wheelParts)
    for _, value in ipairs(wheelParts) do
        parts[#parts + 1] = value
    end
    return table.concat(parts, "|")
end

local function rvMakeRunningGearSignature(vehicle, manifest)
    local parts = {}
    local traction = getTractionWheels(vehicle)

    for _, crawler in ipairs(manifest.crawlers or {}) do
        parts[#parts + 1] = rvMakeCrawlerSignature(vehicle, crawler.crawler, crawler.wheels)
    end

    local normalWheels = {}
    for _, unit in ipairs(manifest.wheelUnits or {}) do
        for _, wheel in ipairs(unit.wheels or {}) do
            normalWheels[#normalWheels + 1] = rvMakeWheelSignature(
                vehicle, wheel, traction[wheel.wheelIndex] == true
            )
        end
    end
    table.sort(normalWheels)
    for _, value in ipairs(normalWheels) do
        parts[#parts + 1] = value
    end

    return table.concat(parts, "||")
end

local function rvRegisterChassisType(vehicle, manifest)
    local family = rvChassisFamily(vehicle, manifest)
    local brand = rvVehicleHint(vehicle)
    local signature = string.format(
        "C=%d|W=%d|A=%d|%s",
        manifest.crawlerCount or 0,
        manifest.totalWheelCount or 0,
        manifest.axleCount or 0,
        rvMakeRunningGearSignature(vehicle, manifest)
    )

    local existing = RV.CHASSIS_TYPE_BY_SIGNATURE[signature]
    if existing ~= nil then
        return existing, RV.CHASSIS_TYPE_REGISTRY[existing]
    end

    local id = string.format("FW-%03d", RV.NEXT_CHASSIS_TYPE_ID)
    RV.NEXT_CHASSIS_TYPE_ID = RV.NEXT_CHASSIS_TYPE_ID + 1
    local entry = {
        id = id,
        family = family,
        brand = brand,
        signature = signature,
        vehicleHint = tostring(vehicle ~= nil and (vehicle.configFileName or vehicle.xmlFileName or vehicle.typeName or "UNKNOWN") or "UNKNOWN"),
        crawlerCount = manifest.crawlerCount or 0,
        wheelCount = manifest.totalWheelCount or 0,
        axleCount = manifest.axleCount or 0
    }
    RV.CHASSIS_TYPE_BY_SIGNATURE[signature] = id
    RV.CHASSIS_TYPE_REGISTRY[id] = entry

    print(string.format(
        "[ReifenVerschleiss][CHASSIS] NEW %s | family=%s | brand=%s | crawlers=%d | wheels=%d | axles=%d | hint=%s",
        id, family, brand, entry.crawlerCount, entry.wheelCount, entry.axleCount, entry.vehicleHint
    ))
    print(string.format("[ReifenVerschleiss][CHASSIS-SIGNATURE] %s %s", id, signature))
    return id, entry
end

local function rvGetChassisTypeLabel(entry)
    if entry == nil then return "FW-??? | UNKNOWN" end
    return string.format("%s | %s | %s", entry.id, entry.family, entry.brand)
end

local function classifyCrawler(vehicle, crawler)
    -- Known special case from the project analysis:
    -- Leitwolf uses an external/shared crawler definition whose material is
    -- not safely available from the vehicle package itself.
    local name = ""
    if vehicle ~= nil then
        name = tostring(vehicle.configFileName or vehicle.xmlFileName or vehicle.typeName or "")
        name = string.lower(name)
    end

    if string.find(name, "leitwolf", 1, true) ~= nil then
        return "CRAWLER_STEEL", "SPECIAL_LEITWOLF"
    end
    if string.find(name, "raptor", 1, true) ~= nil then
        return "CRAWLER_STEEL", "SPECIAL_RAPTOR_METAL"
    end
    if string.find(name, "a8800mr", 1, true) ~= nil
        or string.find(name, "jacto_hover_500", 1, true) ~= nil
        or string.find(name, "hover_500", 1, true) ~= nil
        or string.find(name, "hover500", 1, true) ~= nil then
        return "CRAWLER_STEEL", "SPECIAL_A8800MR_STEEL"
    end

    -- Project simplification:
    -- one realistic rubber track category for normal GIANTS crawler vehicles;
    -- Leitwolf is the known steel-chain special case.
    return "RUBBER_TRACK", "GENERIC_CRAWLER_DEFAULT"
end

local function getTerrainSnowInfo(wheel)
    -- FS25: use the actual wheel-shape contact point first. The wheel repr is
    -- not guaranteed to be the point that touches the terrain.
    local mission = g_currentMission
    local terrainId = mission ~= nil and mission.terrainDetailHeightId or nil
    if terrainId == nil or wheel == nil or wheel.node == nil or wheel.physics == nil then
        return nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
    end

    local snowIndex = nil
    local snowSystem = mission ~= nil and mission.snowSystem or nil
    if snowSystem ~= nil and type(snowSystem.snowHeightTypeIndex) == "number" then
        snowIndex = snowSystem.snowHeightTypeIndex
    elseif mission ~= nil and mission.environment ~= nil and type(mission.environment.snowHeightTypeIndex) == "number" then
        snowIndex = mission.environment.snowHeightTypeIndex
    end

    local wx, wy, wz
    local contactSkin = nil
    local gotContactPoint = false
    if getWheelShapeContactPointVector ~= nil and wheel.physics.wheelShape ~= nil then
        local ok, cx, cy, cz, skin = pcall(getWheelShapeContactPointVector, wheel.node, wheel.physics.wheelShape)
        if ok and type(cx) == "number" and type(cy) == "number" and type(cz) == "number" then
            local okWorld, x, y, z = pcall(localToWorld, wheel.node, cx, cy, cz)
            if okWorld then
                wx, wy, wz = x, y, z
                contactSkin = skin
                gotContactPoint = true
            end
        end
    end

    if not gotContactPoint then
        local okPos, x, y, z = pcall(getWorldTranslation, wheel.repr)
        if not okPos then
            return snowIndex, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
        end
        local radius = type(wheel.physics.radius) == "number" and wheel.physics.radius or 0
        wx, wy, wz = x, y - radius, z
    end

    local density = nil
    local typeIndex = nil
    local states = nil
    local channels = nil
    local densityHeight = nil
    local densityDelta = nil
    local terrainHeight = nil
    local heightTypeIndex = nil
    local heightTypeName = nil
    local densityHeightBits = nil
    local nativeHeightTypeChannels = nil
    local nativeHeightTypeCandidates = {}
    local densityTypeIndex = nil
    local densityStateBits = nil

    -- IMPORTANT: this follows the native GIANTS wheel snow-contact logic.
    -- Wheels:updateWheelContact() reads the raw terrainDetailHeight density
    -- value and extracts the height type from the low height-type channels:
    --
    --   densityBits = getDensityAtWorldPos(terrainDetailHeightId, wx, wy, wz)
    --   heightType = bitAND(densityBits, 2^numChannels - 1)
    --   hasSnowContact = heightType == snowHeightTypeIndex
    --
    -- Do NOT use getDensityTypeIndexAtWorldPos() here. That function does not
    -- represent the packed terrain height-type field used by the basegame
    -- snow-contact test.
    if getDensityAtWorldPos ~= nil then
        local ok, value = pcall(getDensityAtWorldPos, terrainId, wx, wy, wz)
        if ok and type(value) == "number" then
            density = value
            densityHeightBits = value
        end
    end

    if densityHeightBits ~= nil then
        -- TEST0.1.0.30: The raw terrainDetailHeight value observed in the
        -- previous channel test is packed with the terrain height-type in
        -- the lower 6 bits. Example from the real log: raw=106 -> 106 & 63 = 42,
        -- while the SnowSystem reports snowHeightTypeIndex=42. The exposed
        -- manager value reported 7, but using all 7 bits reproduced raw=106
        -- and therefore could never match the actual snow type 42.
        -- Use the verified 6-bit height-type field for the Snow decision.
        local numChannels = 6
        nativeHeightTypeChannels = numChannels
        heightTypeIndex = bitAND(densityHeightBits, 2^numChannels - 1)
        typeIndex = heightTypeIndex

        -- Diagnostic channel sweep. This is deliberately read-only and is
        -- used to identify which low bit-channel width reproduces the native
        -- height-type index. No candidate is used for the actual Snow state.
        for n = 1, 10 do
            nativeHeightTypeCandidates[n] = bitAND(densityHeightBits, 2^n - 1)
        end
    end

    if getDensityTypeIndexAtWorldPos ~= nil then
        local ok, value = pcall(getDensityTypeIndexAtWorldPos, terrainId, wx, wy, wz)
        if ok and type(value) == "number" then
            densityTypeIndex = value
        end
    end
    if getDensityStatesAtWorldPos ~= nil then
        local ok, value = pcall(getDensityStatesAtWorldPos, terrainId, wx, wy, wz)
        if ok and type(value) == "number" then
            densityStateBits = value
            states = value
        end
    end
    if getTerrainDetailNumChannels ~= nil then
        local ok, value = pcall(getTerrainDetailNumChannels, terrainId)
        if ok and type(value) == "number" then channels = value end
    end
    if getDensityHeightAtWorldPos ~= nil then
        local ok, h, delta = pcall(getDensityHeightAtWorldPos, terrainId, wx, wy, wz)
        if ok then
            if type(h) == "number" then densityHeight = h end
            if type(delta) == "number" then densityDelta = delta end
        end
    end
    if getTerrainHeightAtWorldPos ~= nil and mission.terrainRootNode ~= nil then
        local ok, h = pcall(getTerrainHeightAtWorldPos, mission.terrainRootNode, wx, wy, wz)
        if ok and type(h) == "number" then terrainHeight = h end
    end

    -- This descriptor is useful as a separate comparison value.
    -- IMPORTANT: never overwrite the native packed heightTypeIndex with desc.index.
    -- In the previous build that masked the actual low-channel value (e.g. 42)
    -- with the descriptor index (e.g. 106), which made the Snow comparison fail.
    local descriptorHeightTypeIndex = nil
    if DensityMapHeightUtil ~= nil and DensityMapHeightUtil.getHeightTypeDescAtWorldPos ~= nil then
        local ok, desc = pcall(DensityMapHeightUtil.getHeightTypeDescAtWorldPos, wx, wy, wz, 0.05)
        if ok and type(desc) == "table" then
            if type(desc.index) == "number" then descriptorHeightTypeIndex = desc.index end
            heightTypeName = desc.name or desc.fillTypeName or desc.title
        end
    end

    local snowFound = false
    local method = "NONE"

    -- Native FS25 snow-contact test. This is the decisive result for lying
    -- snow at the wheel contact point. It is independent of snowfall state
    -- and does not require getSnowHeightAtArea().
    if snowIndex ~= nil and heightTypeIndex ~= nil and heightTypeIndex == snowIndex then
        snowFound = true
        method = "NATIVE_HEIGHT_TYPE"
    elseif snowSystem ~= nil and snowSystem.isEnabled == true and densityDelta ~= nil and densityDelta > 0.015 then
        -- Secondary fallback for a raised terrain-height layer when the snow
        -- type descriptor is temporarily unavailable.
        snowFound = true
        method = "HEIGHT_DELTA"
    end

    return snowIndex, snowFound, typeIndex, density, states, channels, 1,
        densityHeight, densityDelta, terrainHeight, heightTypeIndex, heightTypeName, contactSkin, method,
        nativeHeightTypeChannels, nativeHeightTypeCandidates, densityTypeIndex, densityStateBits, descriptorHeightTypeIndex
end

-- Own snow model: deliberately conservative and close to the normal game range.
-- These are relative gameplay factors, not manufacturer test values.
local SNOW_PROFILES = {
    -- These are ONLY our additional snow modifiers. GIANTS' native
    -- frictionCoeffsSnow remains the base value and is never replaced.
    STREET      = {slip = 1.16, grip = 0.86, wear = 1.06},
    OFFROAD     = {slip = 1.075, grip = 0.93, wear = 1.04},
    MUD         = {slip = 1.03, grip = 0.97, wear = 1.02},
    RUBBER_TRACK= {slip = 1.01, grip = 0.99, wear = 1.01},
    STEEL_TRACK = {slip = 1.00, grip = 1.00, wear = 1.00},
    CHAIN       = {slip = 0.98, grip = 1.02, wear = 0.99},
    DEFAULT     = {slip = 1.00, grip = 1.00, wear = 1.00}
}

local function getSnowProfile(wheel)
    local name = getTireName(wheel):upper()
    if string.find(name, "CHAIN", 1, true) or string.find(name, "KETTE", 1, true) then
        return "CHAIN", SNOW_PROFILES.CHAIN
    end

    if isCrawlerTire(wheel) then
        if string.find(name, "STEEL", 1, true) or string.find(name, "LEITWOLF", 1, true) then
            return "STEEL_TRACK", SNOW_PROFILES.STEEL_TRACK
        end
        return "RUBBER_TRACK", SNOW_PROFILES.RUBBER_TRACK
    end

    if string.find(name, "MUD", 1, true) then
        return "MUD", SNOW_PROFILES.MUD
    end

    -- Many real FS25 tire configuration names do not contain the literal
    -- word OFFROAD. For example, the verified log contains "Conti CrossTrac HD3".
    -- CrossTrac is an all-terrain/off-road tractor tire and must therefore not
    -- fall through to DEFAULT. Keep this classification name-based and local
    -- to the tire profile; do not alter GIANTS' native friction values.
    local offroadTokens = {
        "OFFROAD", "OFF-ROAD", "CROSSTRAC", "ALLTERRAIN", "ALL-TERRAIN",
        "AGRO", "AGRICULT", "TRACTOR", "FIELD", "TERRAIN", "FIELDFORCE",
        "MULTITERRA", "MULTI-TERRA", "SOIL", "RIB", "LUG"
    }
    for _, token in ipairs(offroadTokens) do
        if string.find(name, token, 1, true) then
            return "OFFROAD", SNOW_PROFILES.OFFROAD
        end
    end

    if string.find(name, "STREET", 1, true)
        or string.find(name, "ROAD", 1, true)
        or string.find(name, "HIGHWAY", 1, true)
        or string.find(name, "ASPHALT", 1, true) then
        return "STREET", SNOW_PROFILES.STREET
    end

    -- Unknown names remain neutral instead of silently receiving the OFFROAD
    -- modifier. This prevents an unrecognised tire from changing traction.
    return "DEFAULT", SNOW_PROFILES.DEFAULT
end

local function getWheelWearRunningGearType(wheel)
    if wheel == nil then return "OFFROAD" end
    if isCrawlerTire(wheel) then
        local profileName = getSnowProfile(wheel)
        if profileName == "STEEL_TRACK" or profileName == "CHAIN" then
            return "STEEL_TRACK"
        end
        return "RUBBER_TRACK"
    end

    local profileName = getSnowProfile(wheel)
    if profileName == "STREET" then
        return "STREET"
    end
    return "OFFROAD"
end

local function getWheelContactWorldPosition(wheel)
    if wheel == nil or wheel.node == nil or wheel.physics == nil then
        return nil, nil, nil
    end

    if getWheelShapeContactPointVector ~= nil and wheel.physics.wheelShape ~= nil then
        local ok, cx, cy, cz = pcall(getWheelShapeContactPointVector, wheel.node, wheel.physics.wheelShape)
        if ok and type(cx) == "number" and type(cy) == "number" and type(cz) == "number" then
            local okWorld, x, y, z = pcall(localToWorld, wheel.node, cx, cy, cz)
            if okWorld and type(x) == "number" and type(y) == "number" and type(z) == "number" then
                return x, y, z
            end
        end
    end

    local repr = wheel.repr
    if repr ~= nil then
        local okPos, x, y, z = pcall(getWorldTranslation, repr)
        if okPos and type(x) == "number" and type(y) == "number" and type(z) == "number" then
            local radius = type(wheel.physics.radius) == "number" and wheel.physics.radius or 0
            return x, y - radius, z
        end
    end

    return nil, nil, nil
end

-- Own snow environment:
-- IMPORTANT: snowfall and lying snow are separate states.
-- GIANTS exposes the actual accumulated snow height through
-- snowSystem:getSnowHeightAtArea(x1,z1,x2,z2,x3,z3). This is the value used
-- by basegame code to decide whether an area is covered by snow.
-- The current snowfall rate is only an additional temporary factor.
local function getOwnSnowEnvironment(wheel)
    local mission = g_currentMission
    local snowSystem = mission ~= nil and mission.snowSystem or nil
    local env = mission ~= nil and mission.environment or nil
    local weather = env ~= nil and env.weather or nil

    if snowSystem == nil then
        return 0, 0, 0, 0, "OFF"
    end

    local snowfall = 0
    for _, obj in ipairs({snowSystem, weather}) do
        if obj ~= nil then
            for _, key in ipairs({"snowfallScale", "snowFallScale", "snowScale", "snowIntensity", "snowfallIntensity"}) do
                local v = obj[key]
                if type(v) == "number" then
                    snowfall = math.max(snowfall, math.clamp(v, 0, 1))
                end
            end
        end
    end

    local temp = 0
    if weather ~= nil then
        for _, key in ipairs({"temperature", "currentTemperature", "temperatureCelsius"}) do
            local v = weather[key]
            if type(v) == "number" then
                temp = v
                break
            end
        end
    end

    -- Actual accumulated snow at the wheel contact area.
    -- This is intentionally independent of current snowfall.
    local snowHeight = 0
    local snowHeightMethod = "NONE"
    local areaQueryAvailable = false
    local areaQuerySucceeded = false
    local globalSnowHeight = 0
    if type(snowSystem.height) == "number" and snowSystem.height == snowSystem.height then
        globalSnowHeight = math.max(0, snowSystem.height)
    end

    -- Use the same triangle convention used by GIANTS basegame code:
    -- getSnowHeightAtArea(x,z, x+0.1,z+0.1, x+0.1,z).
    -- The query works in world X/Z only; the Y coordinate is intentionally not
    -- part of this API. First use the real physics contact point, then the wheel
    -- representation as a robust fallback if the contact point is not available.
    local x, y, z = getWheelContactWorldPosition(wheel)
    local candidates = {}
    if x ~= nil and z ~= nil then
        candidates[#candidates + 1] = {x=x, z=z, method="AREA_CONTACT"}
    end

    if wheel ~= nil and wheel.repr ~= nil then
        local okPos, rx, ry, rz = pcall(getWorldTranslation, wheel.repr)
        if okPos and type(rx) == "number" and type(rz) == "number" then
            local duplicate = x ~= nil and math.abs(rx-x) < 0.001 and math.abs(rz-z) < 0.001
            if not duplicate then
                candidates[#candidates + 1] = {x=rx, z=rz, method="AREA_REPR"}
            end
        end
    end

    if snowSystem.getSnowHeightAtArea ~= nil then
        areaQueryAvailable = true
        for _, c in ipairs(candidates) do
            local ok, h = pcall(snowSystem.getSnowHeightAtArea, snowSystem,
                c.x, c.z,
                c.x + 0.10, c.z + 0.10,
                c.x + 0.10, c.z)
            if ok and type(h) == "number" and h == h then
                areaQuerySucceeded = true
                if h > snowHeight then
                    snowHeight = math.max(0, h)
                    snowHeightMethod = c.method
                end
            end
            if snowHeight > 0 then
                break
            end
        end
    end

    -- Only use the global SnowSystem height when the per-area API is unavailable
    -- or could not be called. A successful area result of 0 is authoritative:
    -- this prevents globally lying snow from falsely being applied to a locally
    -- cleared road/area.
    if not areaQueryAvailable or not areaQuerySucceeded then
        for _, obj in ipairs({snowSystem, env}) do
            if obj ~= nil then
                for _, key in ipairs({"height", "snowHeight", "snowDepth", "currentSnowHeight", "snowLayerHeight"}) do
                    local v = obj[key]
                    if type(v) == "number" and v == v and v > snowHeight then
                        snowHeight = math.max(0, v)
                        snowHeightMethod = "GLOBAL_" .. key
                    end
                end
            end
        end
    end

    -- 0.20 m is the full-strength reference height for the own model.
    local heightFactor = math.clamp(snowHeight / 0.20, 0, 1)

    -- Snowfall alone may create a small temporary effect, but it must NEVER
    -- replace the accumulated-snow test. Once snowfall stops, heightFactor
    -- remains active as long as snow is still lying on the ground.
    local snowfallFactor = snowfall
    if snowfall > 0 then
        snowfallFactor = math.max(snowfallFactor, 0.35 + snowfall * 0.65)
    end

    if temp > 1 then
        snowfallFactor = 0
    end

    local target = math.max(heightFactor, snowfallFactor)
    local state
    if heightFactor > 0.02 then
        state = "LYING"
    elseif snowfallFactor > 0.02 then
        state = "FALLING"
    else
        state = "NONE"
    end

    return math.clamp(target, 0, 1), snowfall, temp, snowHeight, state, snowHeightMethod, globalSnowHeight
end

-- Returns the already verified own-Snow traction modifier without running
-- the full diagnostic/environment query. This is used only by the physics hook.
local function getOwnSnowPhysicsModifier(wheel)
    if wheel == nil then
        return 1, 0, "DEFAULT", 1, 1
    end

    -- GIANTS updates hasSnowContact from the terrain height type. This remains
    -- valid after snowfall has stopped because it represents lying snow.
    local snowActive = wheel.hasSnowContact == true

    -- Keep our verified native height-type test as a fallback. This avoids
    -- depending exclusively on a visual/physics flag on unusual wheel objects.
    if not snowActive then
        local ok, _, terrainSnow = pcall(getTerrainSnowInfo, wheel)
        if ok and terrainSnow == true then
            snowActive = true
        end
    end

    if not snowActive then
        return 1, 0, "NONE", 1, 1
    end

    local profileName, profile = getSnowProfile(wheel)
    local gripFactor = safeNumber(profile.grip, 1)
    local slipFactor = safeNumber(profile.slip, 1)
    local wearFactor = safeNumber(profile.wear, 1)

    return gripFactor, 1, profileName, slipFactor, wearFactor
end

-- Apply the own Snow traction factor after GIANTS has calculated its native
-- tire-ground friction. The native snow friction remains intact; our factor
-- is deliberately conservative and only reduces the resulting grip on snow.
-- This naturally increases slip without inventing a separate wheel-slip force.
function ReifenVerschleissDiagnostic.applySnowFriction(wheel)
    if wheel == nil or type(wheel.tireGroundFrictionCoeff) ~= "number" then
        return false
    end

    -- TEST0.2.2.01: hook probe only. No friction value is changed here.
    if RV.DEBUG_HOOK_PROBE_ENABLED then
        local count = RV.DEBUG_HOOK_PROBE_COUNTS[wheel] or 0
        if count < RV.DEBUG_HOOK_PROBE_MAX_PER_WHEEL then
            count = count + 1
            RV.DEBUG_HOOK_PROBE_COUNTS[wheel] = count
            local vehicle = wheel.vehicle
            local wheelIndex = wheel.wheelIndex ~= nil and tostring(wheel.wheelIndex) or "?"
            local rawSlip = 0
            if getWheelSlip ~= nil then
                rawSlip = safeNumber(getWheelSlip(wheel, vehicle), 0)
            end
            print(string.format(
                "[ReifenVerschleiss][HOOK-PROBE] ENTER n=%d wheel=W%s vehicle=%s tireFriction=%.6f rawSlip=%.2f%%",
                count,
                wheelIndex,
                tostring(vehicle ~= nil and (vehicle.configFileName or vehicle.uniqueId or vehicle) or "?"),
                safeNumber(wheel.tireGroundFrictionCoeff, 0),
                rawSlip
            ))
        end
    end

    local gripFactor, active, profileName, slipFactor, wearFactor = getOwnSnowPhysicsModifier(wheel)

    -- IMPORTANT: never leave a previous Snow modifier on the wheel.
    -- updateWheelFriction may be called again after leaving snow; the normal
    -- GIANTS coefficient must remain untouched on ROAD/HARD/MUD/etc.
    if active ~= 1 then
        local currentCoeff = wheel.tireGroundFrictionCoeff
        local previousFactor = safeNumber(wheel.reifenVerschleissAppliedGripFactor, 1)
        local previousCoeff = safeNumber(wheel.reifenVerschleissAppliedCoeff, nil)
        if previousFactor ~= 1 and previousCoeff ~= nil and math.abs(currentCoeff - previousCoeff) <= 0.000001 then
            wheel.tireGroundFrictionCoeff = currentCoeff / previousFactor
            if wheel.vehicle ~= nil and wheel.vehicle.setWheelTireFrictionDirty ~= nil then
                pcall(wheel.vehicle.setWheelTireFrictionDirty, wheel.vehicle, wheel)
            end
        end
        wheel.reifenVerschleissSnowActive = false
        wheel.reifenVerschleissSnowProfile = "NONE"
        wheel.reifenVerschleissSnowGripFactor = 1
        wheel.reifenVerschleissSnowSlipFactor = 1
        wheel.reifenVerschleissSnowWearFactor = 1
        wheel.reifenVerschleissAppliedGripFactor = 1
        wheel.reifenVerschleissAppliedCoeff = nil
        return false
    end

    -- GIANTS calculates tireGroundFrictionCoeff first, including its own
    -- frictionCoeffsSnow. Never multiply an already modified value again.
    -- If the current value is still our previously applied value, recover the
    -- native coefficient first. If GIANTS has already recalculated it, use the
    -- current value untouched as the native base.
    local currentCoeff = wheel.tireGroundFrictionCoeff
    local previousFactor = safeNumber(wheel.reifenVerschleissAppliedGripFactor, 1)
    local previousCoeff = safeNumber(wheel.reifenVerschleissAppliedCoeff, nil)
    local nativeCoeff = currentCoeff

    if previousFactor ~= 1 and previousCoeff ~= nil and math.abs(currentCoeff - previousCoeff) <= 0.000001 then
        nativeCoeff = currentCoeff / previousFactor
    end

    local modifiedCoeff = nativeCoeff * gripFactor
    if math.abs(modifiedCoeff - currentCoeff) > 0.000001 then
        wheel.tireGroundFrictionCoeff = modifiedCoeff
        if wheel.vehicle ~= nil and wheel.vehicle.setWheelTireFrictionDirty ~= nil then
            pcall(wheel.vehicle.setWheelTireFrictionDirty, wheel.vehicle, wheel)
        end
    end

    wheel.reifenVerschleissSnowActive = true
    wheel.reifenVerschleissSnowProfile = profileName
    wheel.reifenVerschleissSnowGripFactor = gripFactor
    wheel.reifenVerschleissSnowSlipFactor = slipFactor
    wheel.reifenVerschleissSnowWearFactor = wearFactor
    wheel.reifenVerschleissAppliedGripFactor = gripFactor
    wheel.reifenVerschleissAppliedCoeff = modifiedCoeff
    return true
end

local function getWheelGroundInfo(wheel)
    if wheel == nil or wheel.physics == nil then
        return nil, nil, nil, nil, nil, nil, nil, nil
    end

    local p = wheel.physics
    local contact = p.contact

    -- IMPORTANT: use the same native classification inputs as GIANTS Wheels.
    -- FS25 WheelsUtil.getGroundType() is defined as:
    --   FIELD when isField is true
    --   ROAD when isRoad is true OR depth < 0.1
    --   HARD for depth 0.1..0.8
    --   SOFT for depth > 0.8
    -- GIANTS derives isRoad from (contact ~= WHEEL_GROUND_CONTACT).
    local isField = wheel.densityType ~= nil and wheel.densityType ~= 0
    local isRoad = false
    if Wheels ~= nil and Wheels.WHEEL_GROUND_CONTACT ~= nil and contact ~= nil then
        isRoad = contact ~= Wheels.WHEEL_GROUND_CONTACT
    elseif Vehicle ~= nil and Vehicle.WHEEL_GROUND_CONTACT ~= nil and contact ~= nil then
        isRoad = contact ~= Vehicle.WHEEL_GROUND_CONTACT
    elseif WheelContactType ~= nil and WheelContactType.GROUND ~= nil and contact ~= nil then
        isRoad = contact ~= WheelContactType.GROUND
    end

    local groundDepth = nil
    if wheel.lastColor ~= nil and type(wheel.lastColor[4]) == "number" then
        groundDepth = wheel.lastColor[4]
    elseif p.getGroundAttributes ~= nil then
        local ok, _, _, _, depth = pcall(p.getGroundAttributes, p)
        if ok and type(depth) == "number" then
            groundDepth = depth
        end
    end
    groundDepth = safeNumber(groundDepth, 0)

    local groundType = nil
    if WheelsUtil ~= nil and WheelsUtil.getGroundType ~= nil then
        local okGround, value = pcall(WheelsUtil.getGroundType, isField, isRoad, groundDepth)
        if okGround then
            groundType = value
        end
    end

    -- Native wheel contact status is kept separate from isRoad/groundType.
    local hasGroundContact = false
    if p.hasGroundContact ~= nil then
        hasGroundContact = p.hasGroundContact == true
    elseif wheel.hasGroundContact ~= nil then
        hasGroundContact = wheel.hasGroundContact == true
    elseif Vehicle ~= nil and Vehicle.WHEEL_GROUND_CONTACT ~= nil then
        hasGroundContact = contact == Vehicle.WHEEL_GROUND_CONTACT
            or (Vehicle.WHEEL_GROUND_HEIGHT_CONTACT ~= nil and contact == Vehicle.WHEEL_GROUND_HEIGHT_CONTACT)
    end

    -- FS25 can report terrain/height contact as a numeric contact value (for
    -- example contact=4) instead of WHEEL_GROUND_CONTACT. If WheelsUtil has
    -- already resolved a valid terrain ground type and a contact exists, this
    -- is still real wheel-ground contact. This is essential for SOFT terrain
    -- and prevents slip/wear from being limited to ROAD/HARD.
    if not hasGroundContact and contact ~= nil and groundType ~= nil and WheelsUtil ~= nil then
        local validTerrain = groundType == WheelsUtil.GROUND_FIELD
            or groundType == WheelsUtil.GROUND_ROAD
            or groundType == WheelsUtil.GROUND_HARD_TERRAIN
            or groundType == WheelsUtil.GROUND_SOFT_TERRAIN
        if validTerrain then
            hasGroundContact = true
        end
    end

    -- Wetness: official GIANTS ground wetness is authoritative. Rainfall stays
    -- separate and is never substituted for a valid native 0.0.
    local wetScale = nil
    local rainScale = 0
    local timeSinceLastRain = nil
    local temperature = nil
    if g_currentMission ~= nil and g_currentMission.environment ~= nil then
        local weather = g_currentMission.environment.weather
        if weather ~= nil then
            if weather.getGroundWetness ~= nil then
                local okWet, value = pcall(weather.getGroundWetness, weather)
                if okWet and type(value) == "number" and value == value then
                    wetScale = math.clamp(value, 0, 1)
                end
            end
            if weather.getRainFallScale ~= nil then
                local okRain, value = pcall(weather.getRainFallScale, weather)
                if okRain and type(value) == "number" and value == value then
                    rainScale = math.clamp(value, 0, 1)
                end
            end
            if weather.getTimeSinceLastRain ~= nil then
                local okTime, value = pcall(weather.getTimeSinceLastRain, weather)
                if okTime and type(value) == "number" and value == value then
                    timeSinceLastRain = value
                end
            end
            if weather.getCurrentTemperature ~= nil then
                local okTemp, value = pcall(weather.getCurrentTemperature, weather)
                if okTemp and type(value) == "number" and value == value then
                    temperature = value
                end
            end
        end
    end

    local wetSource = "NATIVE_GROUND_WETNESS"
    if wetScale == nil then
        wetScale = rainScale
        wetSource = "RAIN_FALLBACK"
    end

    -- Native snow contact/scale. Lying snow is additionally verified against
    -- the terrainDetailHeight height-type used by the base game.
    local hasSnowContact = nil
    if wheel.hasSnowContact ~= nil then
        hasSnowContact = wheel.hasSnowContact == true
    elseif p.hasSnowContact ~= nil then
        hasSnowContact = p.hasSnowContact == true
    end

    local nativeSnowScale = nil
    if type(p.snowScale) == "number" then
        nativeSnowScale = math.clamp(p.snowScale, 0, 1)
    elseif type(wheel.snowScale) == "number" then
        nativeSnowScale = math.clamp(wheel.snowScale, 0, 1)
    elseif hasSnowContact ~= nil then
        nativeSnowScale = hasSnowContact and 1 or 0
    end
    nativeSnowScale = safeNumber(nativeSnowScale, 0)

    local ownSnow, snowfall, ownTemperature, snowHeight, ownSnowState, snowHeightMethod, globalSnowHeight = getOwnSnowEnvironment(wheel)
    if temperature == nil then
        temperature = ownTemperature
    end

    local terrainSnowIndex, terrainSnow, terrainTypeIndex, terrainDensity, terrainStates, terrainChannels, terrainSnowSamples, densityHeight, densityDelta, terrainHeight, heightTypeIndex, heightTypeName, contactSkin, snowMethod, nativeHeightTypeChannels, nativeHeightTypeCandidates, densityTypeIndex, densityStateBits, descriptorHeightTypeIndex = getTerrainSnowInfo(wheel)
    if terrainSnow == true then
        ownSnow = 1
        ownSnowState = "LYING"
        if snowHeight <= 0 then
            snowHeightMethod = "NATIVE_HEIGHT_TYPE"
        end
    end

    -- A true terrain "mud" state is not exposed by WheelsUtil as a separate
    -- ground type. Do not confuse the native tireType "mud" with muddy ground:
    -- GIANTS uses "mud" as a valid/default tire type for wheels. We derive MUD
    -- only from native SOFT terrain + native wetness. The 0.2 threshold is the
    -- same threshold GIANTS uses for wet ground particle state.
    local isMudTerrain = false
    if groundType ~= nil and WheelsUtil ~= nil and WheelsUtil.GROUND_SOFT_TERRAIN ~= nil then
        isMudTerrain = groundType == WheelsUtil.GROUND_SOFT_TERRAIN and wetScale > 0.2 and ownSnow < 0.5
    end

    -- Native GIANTS tire type and current native tire-ground friction.
    local nativeTireType = getTireName(wheel)
    local nativeTireFriction = nil
    if WheelsUtil ~= nil and WheelsUtil.getTireFriction ~= nil
        and wheel.tireType ~= nil and groundType ~= nil then
        local okFriction, value = pcall(
            WheelsUtil.getTireFriction,
            wheel.tireType,
            groundType,
            wetScale,
            nativeSnowScale
        )
        if okFriction and type(value) == "number" and value == value then
            nativeTireFriction = value
        end
    end

    return groundType, wetScale, ownSnow, contact, groundDepth, hasSnowContact, isField, isRoad, terrainSnowIndex, terrainSnow, terrainTypeIndex, terrainDensity, terrainStates, terrainChannels, terrainSnowSamples, densityHeight, densityDelta, terrainHeight, heightTypeIndex, heightTypeName, contactSkin, snowMethod, nativeSnowScale, snowfall, temperature, snowHeight, ownSnowState, snowHeightMethod, globalSnowHeight, nativeTireType, nativeTireFriction, hasGroundContact, isMudTerrain, rainScale, timeSinceLastRain, wetSource, nativeHeightTypeChannels, nativeHeightTypeCandidates, densityTypeIndex, densityStateBits, descriptorHeightTypeIndex
end
local function getWheelSlip(wheel, vehicle)
    if wheel == nil or wheel.physics == nil or wheel.node == nil or wheel.physics.wheelShape == nil then
        return nil
    end

    local ok, slip = pcall(getWheelShapeSlip, wheel.node, wheel.physics.wheelShape)
    if ok and type(slip) == "number" and math.abs(slip) < math.huge then
        return math.abs(slip) * 100
    end

    return nil
end

local function isWheelPhysicallyRotating(wheel)
    if wheel == nil or wheel.physics == nil or wheel.node == nil or wheel.physics.wheelShape == nil then
        return false
    end

    if getWheelShapeAxleSpeed == nil then
        return false
    end

    local ok, angular = pcall(getWheelShapeAxleSpeed, wheel.node, wheel.physics.wheelShape)
    if not ok or type(angular) ~= "number" or angular ~= angular or math.abs(angular) >= math.huge then
        return false
    end

    local radius = safeNumber(wheel.physics.radius, 0)
    return math.abs(angular) * math.max(radius, 0) > 0.05
end


local function getWheelLoad(wheel)
    if wheel == nil or wheel.physics == nil or wheel.physics.getTireLoad == nil then
        return nil
    end

    local ok, load = pcall(wheel.physics.getTireLoad, wheel.physics)
    if ok and type(load) == "number" and math.abs(load) < math.huge then
        return load
    end

    return nil
end

local function getWheelDiameter(wheel)
    if wheel == nil or wheel.physics == nil then
        return nil
    end
    local radius = safeNumber(wheel.physics.radius, nil)
    if radius == nil then
        return nil
    end
    return radius * 2
end

local function getWheelWidth(wheel)
    if wheel == nil or wheel.physics == nil then
        return nil
    end

    local width = safeNumber(wheel.physics.width, nil)
    if width ~= nil and width > 0 then
        return width
    end

    width = safeNumber(wheel.physics.wheelShapeWidth, nil)
    if width ~= nil and width > 0 then
        return width
    end

    return nil
end

local function getWheelRestLoad(wheel)
    if wheel == nil or wheel.physics == nil then
        return nil
    end

    local restLoad = safeNumber(wheel.physics.restLoad, nil)
    if restLoad ~= nil and restLoad > 0 then
        return restLoad
    end

    return nil
end

local function getWheelPhysicalFactors(load, width, radius)
    local loadT = math.max(0.01, safeNumber(load, RV.PHYSICS_REFERENCE_LOAD_T))
    local widthM = math.max(0.01, safeNumber(width, RV.PHYSICS_REFERENCE_WIDTH_M))
    local radiusM = math.max(0.05, safeNumber(radius, RV.PHYSICS_REFERENCE_RADIUS_M))

    -- Neutral reference: 2.5 t tire load, 600 mm width, 750 mm radius.
    -- Load is sub-linear; narrower tires carry the same load over a smaller
    -- footprint; smaller radius means slightly more tread stress per distance.
    local loadFactor = math.pow(loadT / RV.PHYSICS_REFERENCE_LOAD_T, RV.PHYSICS_LOAD_EXPONENT)
    local widthFactor = math.pow(RV.PHYSICS_REFERENCE_WIDTH_M / widthM, RV.PHYSICS_WIDTH_EXPONENT)
    local radiusFactor = math.pow(RV.PHYSICS_REFERENCE_RADIUS_M / radiusM, RV.PHYSICS_RADIUS_EXPONENT)

    return loadFactor, widthFactor, radiusFactor, loadFactor * widthFactor * radiusFactor
end

local function getVehicleSpeedKmh(vehicle)
    if vehicle == nil then
        return 0
    end

    -- lastSpeedReal is the normal physics source. When an external AI driver
    -- owns the vehicle after the player leaves it, some AI/control paths can
    -- temporarily expose no useful lastSpeedReal value to a mod update.
    -- GIANTS' getLastSpeed() is the public kph accessor and remains valid for
    -- AI-controlled vehicles. Manual driving therefore keeps the exact same
    -- primary path; the fallback is only used when lastSpeedReal is zero.
    local speedReal = math.abs(safeNumber(vehicle.lastSpeedReal, 0))
    if speedReal > 0.000001 then
        return speedReal * 1000 * 3.6
    end

    if vehicle.getLastSpeed ~= nil then
        local ok, speedKmh = pcall(vehicle.getLastSpeed, vehicle, false)
        if ok and type(speedKmh) == "number" then
            return math.abs(speedKmh)
        end
    end

    return 0
end

local function getVehicleMotionDistanceM(vehicle, dtSec)
    if vehicle == nil then
        return 0
    end

    local lastMovedDistance = math.abs(safeNumber(vehicle.lastMovedDistance, 0))
    if lastMovedDistance > 0.000001 then
        return lastMovedDistance
    end

    return math.abs(safeNumber(vehicle.lastSpeedReal, 0)) * 1000 * dtSec
end

local function getVehicleIsAIActive(vehicle)
    if vehicle == nil then
        return false
    end

    -- Prefer GIANTS' own AI state when exposed by the runtime.
    if vehicle.getIsAIActive ~= nil then
        local ok, active = pcall(vehicle.getIsAIActive, vehicle)
        if ok and active == true then
            return true
        end
    end

    -- Generic fallback for vehicle types exposing the AI specialization state.
    local spec = vehicle.spec_aiVehicle
    if spec ~= nil then
        if spec.isActive == true or spec.active == true or spec.isRunning == true then
            return true
        end
    end

    return false
end

local function getPlayerFarmId()
    local mission = g_currentMission
    if mission == nil or mission.getFarmId == nil then
        return nil
    end

    local ok, farmId = pcall(mission.getFarmId, mission)
    if ok and type(farmId) == "number" and farmId ~= FarmManager.SPECTATOR_FARM_ID then
        return farmId
    end

    return nil
end

local function getVehiclePropertyStateSafe(vehicle)
    if vehicle == nil then return nil end
    if vehicle.getPropertyState ~= nil then
        local ok, value = pcall(vehicle.getPropertyState, vehicle)
        if ok then return value end
    end
    return vehicle.propertyState
end

local function getVehicleOwnerFarmIdSafe(vehicle)
    if vehicle == nil then return nil end
    if vehicle.getOwnerFarmId ~= nil then
        local ok, value = pcall(vehicle.getOwnerFarmId, vehicle)
        if ok and type(value) == "number" then return value end
    end
    if type(vehicle.ownerFarmId) == "number" then
        return vehicle.ownerFarmId
    end
    return nil
end

local function isMissionVehicleState(vehicle, propertyState)
    if VehiclePropertyState ~= nil and VehiclePropertyState.MISSION ~= nil
        and propertyState == VehiclePropertyState.MISSION then
        return true
    end
    -- GIANTS writes activeMissionId for mission-bound vehicles. Keep this as
    -- a second, explicit guard so a mission vehicle can never enter OWN-WEAR
    -- even when a mod temporarily exposes an unexpected property state.
    return vehicle ~= nil and vehicle.activeMissionId ~= nil
end

local function hasMissionVehicleInAttacherChain(vehicle)
    if vehicle == nil then return false end
    local current = vehicle
    local visited = {}
    for _ = 1, 16 do
        if current == nil or visited[current] then break end
        visited[current] = true
        local propertyState = getVehiclePropertyStateSafe(current)
        if isMissionVehicleState(current, propertyState) then
            return true
        end
        if type(current.getAttacherVehicle) ~= "function" then break end
        local ok, parent = pcall(current.getAttacherVehicle, current)
        if not ok or parent == nil then break end
        current = parent
    end
    return false
end

local function isRelevantPlayerVehicle(vehicle)
    if vehicle == nil or rvIsExplicitlyExcludedVehicle(vehicle) then
        return false
    end

    local playerFarmId = getPlayerFarmId()
    if playerFarmId == nil then
        return false
    end

    local ownerFarmId = getVehicleOwnerFarmIdSafe(vehicle)
    if ownerFarmId == nil or ownerFarmId ~= playerFarmId then
        return false
    end

    local propertyState = getVehiclePropertyStateSafe(vehicle)
    if isMissionVehicleState(vehicle, propertyState) then
        return false
    end

    -- TEST2.3.136: mission-provided trailers/implements can expose OWNED/LEASED
    -- and the player's farm id even though their towing root is mission-bound.
    -- Walk the attacher chain and fail closed when any parent/root belongs to
    -- an active mission. This fixes mission trailers accumulating DIST/SLIP/TIME.
    if hasMissionVehicleInAttacherChain(vehicle) then
        return false
    end

    -- Runtime OWN-WEAR is restricted to the current player's farm. GIANTS'
    -- normal shop flow uses OWNED for purchases and LEASED for leased/rented
    -- farm vehicles. Unknown states are not accepted here: fail closed rather
    -- than accidentally evaluating map/shop/foreign objects.
    if VehiclePropertyState ~= nil then
        local owned = VehiclePropertyState.OWNED
        local leased = VehiclePropertyState.LEASED
        if propertyState ~= owned and propertyState ~= leased then
            return false
        end
    end

    return true
end

-- TEST0.2.2.28: explicit AI/driver-assistance recognition.
-- Courseplay and AutoDrive control player-owned vehicles; their wear must use
-- the exact same movement/wear calculation as manual driving. This helper only
-- identifies the active driver source. It does not change the wear formula.
local function getAutomatedDriverSource(vehicle)
    if vehicle == nil then
        return nil
    end

    -- Courseplay exposes getIsCpActive() on its root vehicle.
    local root = vehicle.getRootVehicle ~= nil and vehicle:getRootVehicle() or vehicle
    if root ~= nil and root.getIsCpActive ~= nil then
        local ok, active = pcall(root.getIsCpActive, root)
        if ok and active == true then
            return "COURSEPLAY"
        end
    end

    -- AutoDrive keeps its active state in vehicle.ad.stateModule.
    if root ~= nil and root.ad ~= nil and root.ad.stateModule ~= nil
            and root.ad.stateModule.isActive ~= nil then
        local ok, active = pcall(root.ad.stateModule.isActive, root.ad.stateModule)
        if ok and active == true then
            return "AUTODRIVE"
        end
    end

    -- GIANTS helper / AI worker.
    if root ~= nil and root.getIsAIActive ~= nil then
        local ok, active = pcall(root.getIsAIActive, root)
        if ok and active == true then
            return "GIANTS_AI"
        end
    end

    return nil
end

local function getIsMotorizedObject(vehicle)
    if vehicle == nil or vehicle.getIsMotorized == nil then
        return false
    end
    local ok, motorized = pcall(vehicle.getIsMotorized, vehicle)
    return ok and motorized == true
end

local function getAttacherVehicleSafe(vehicle)
    if vehicle == nil or vehicle.getAttacherVehicle == nil then
        return nil
    end
    local ok, parent = pcall(vehicle.getAttacherVehicle, vehicle)
    if ok then
        return parent
    end
    return nil
end

-- Resolve the moving motorized root for an attached trailer/implement. This is
-- only a motion reference; the wear state and wheel manifest remain attached
-- to the trailer/implement object itself.
local function getMotorizedMotionRoot(vehicle)
    local current = vehicle
    local visited = {}
    for _ = 1, 16 do
        if current == nil or visited[current] then
            return nil
        end
        visited[current] = true
        if getIsMotorizedObject(current) then
            return current
        end
        current = getAttacherVehicleSafe(current)
    end
    return nil
end

local function refreshOwnedMotorizedVehicleCache(now)
    if now - lastVehicleScanTime < RV.VEHICLE_SCAN_INTERVAL_MS then
        return
    end

    lastVehicleScanTime = now
    table.clear(ownedMotorizedVehicleCache)
    table.clear(ownedAttachedImplementCache)

    local mission = g_currentMission
    if mission == nil or mission.vehicles == nil then
        return
    end

    -- Ownership is the first broad filter. Motorized objects enter the existing
    -- vehicle path. Non-motorized objects are considered only when they are
    -- actually attached to a moving motorized root and have a wheel manifest.
    for _, vehicle in pairs(mission.vehicles) do
        if isRelevantPlayerVehicle(vehicle) then
            if getIsMotorizedObject(vehicle) then
                ownedMotorizedVehicleCache[#ownedMotorizedVehicleCache + 1] = vehicle
            else
                local parent = getAttacherVehicleSafe(vehicle)
                local root = getMotorizedMotionRoot(vehicle)
                if parent ~= nil and root ~= nil then
                    ownedAttachedImplementCache[#ownedAttachedImplementCache + 1] = vehicle
                end
            end
        end
    end
end

local function getMovingMissionVehicles()
    local result = {}
    local now = g_currentMission ~= nil and safeNumber(g_currentMission.time, 0) or 0
    refreshOwnedMotorizedVehicleCache(now)

    for _, vehicle in ipairs(ownedMotorizedVehicleCache) do
        local speedKmh = getVehicleSpeedKmh(vehicle)
        local aiSource = getAutomatedDriverSource(vehicle)

        -- TEST0.2.2.78: activity is tracked per vehicle, not per
        -- currentVehicle. Once a player-owned vehicle has entered the wear
        -- processing set because it is moving, player-controlled, or driven
        -- by AD/CP/GIANTS-AI, changing to another vehicle must not remove it.
        if aiSource ~= nil then
            aiTrackedVehicles[vehicle] = aiSource
            activeWearVehicles[vehicle] = true
        elseif speedKmh > 0.05 or vehicle == RV.currentVehicle then
            activeWearVehicles[vehicle] = true
        elseif speedKmh <= 0.05 and vehicle ~= RV.currentVehicle then
            -- No driver, no movement, no current player control: this vehicle
            -- no longer needs a live wear update. Its persistent wear state
            -- remains in vehicleWearStates.
            aiTrackedVehicles[vehicle] = nil
            activeWearVehicles[vehicle] = nil
        end

        if activeWearVehicles[vehicle] == true then
            result[#result + 1] = vehicle
        end
    end

    return result
end

local function getMovingAttachedImplements()
    local result = {}
    for _, implement in ipairs(ownedAttachedImplementCache) do
        local root = getMotorizedMotionRoot(implement)
        if root ~= nil then
            local speedKmh = getVehicleSpeedKmh(root)
            if speedKmh > 0.05 then
                result[#result + 1] = {object = implement, root = root, speedKmh = speedKmh}
            end
        end
    end
    return result
end

RV.getMovingAttachedImplements = getMovingAttachedImplements

-- TEST0.2.2.21: HUD recognition must not depend on movement.
-- Wear processing still uses getMovingAttachedImplements(); this display path
-- lists currently attached objects even while the combination is stationary.
local function getAttachedImplementsForDisplay(vehicleOverride)
    local result = {}
    local seen = {}
    local function addObject(object, root)
        if object == nil or seen[object] then return end
        if object == RV.currentVehicle then return end
        local parent = getAttacherVehicleSafe(object)
        local motionRoot = root or getMotorizedMotionRoot(object)
        if parent == nil and motionRoot == nil then return end
        seen[object] = true
        local speedKmh = motionRoot ~= nil and getVehicleSpeedKmh(motionRoot) or 0
        result[#result + 1] = {object = object, root = motionRoot, speedKmh = speedKmh}
    end

    -- Primary source: the currently controlled vehicle's native attachment list.
    local current = vehicleOverride or RV.currentVehicle
    if current ~= nil and current.getAttachedImplements ~= nil then
        local ok, list = pcall(current.getAttachedImplements, current)
        if ok and type(list) == "table" then
            for _, item in pairs(list) do
                local object = item
                if type(item) == "table" then
                    object = item.object or item.implement or item.vehicle or item.attachedVehicle
                end
                addObject(object, current)
            end
        end
    end

    -- Fallback: already maintained attached-object cache. Unlike the movement
    -- function, this deliberately does not require root speed > 0.05 km/h.
    refreshOwnedMotorizedVehicleCache(g_currentMission ~= nil and safeNumber(g_currentMission.time, 0) or 0)
    for _, object in ipairs(ownedAttachedImplementCache) do
        addObject(object, getMotorizedMotionRoot(object))
    end

    return result
end
RV.getAttachedImplementsForDisplay = getAttachedImplementsForDisplay

-- Public authoritative read bridge for the HUD. The HUD must pass the exact
-- vehicle it is displaying; never substitute RV.currentVehicle here.
function RV:getOwnWearPercentForHUD(vehicle)
    if vehicle == nil then return nil end
    if type(self.getVehicleWearPercent) == "function" then
        local ok, value = pcall(self.getVehicleWearPercent, vehicle)
        if ok and type(value) == "number" then
            return math.max(0, math.min(100, value))
        end
    end
    return nil
end


local function getVehicleMass(vehicle)
    if vehicle == nil then
        return nil
    end

    if vehicle.getTotalMass ~= nil then
        -- Same first mass query as EnhancedVehicle HUD:
        -- self.vehicle:getTotalMass(true)
        local ok, mass = pcall(vehicle.getTotalMass, vehicle, true)
        if ok and type(mass) == "number" then
            return mass
        end
    end

    if vehicle.getMass ~= nil then
        local ok, mass = pcall(vehicle.getMass, vehicle)
        if ok and type(mass) == "number" then
            return mass
        end
    end

    return nil
end

local function buildManifest(vehicle)
    local manifest = {
        wheels = {},
        wheelUnits = {},
        crawlers = {},
        axleUnits = {},
        totalWheelCount = 0,
        normalWheelCount = 0,
        crawlerWheelCount = 0,
        axleCount = 0,
        crawlerCount = 0
    }

    if vehicle == nil or vehicle.spec_wheels == nil or vehicle.spec_wheels.wheels == nil then
        return manifest
    end

    local allWheels = vehicle.spec_wheels.wheels
    local assignedCrawler = {}

    -- ================================================================
    -- Phase 1: resolve Crawler objects first.
    -- This is the same structural principle as the proven HUD:
    -- Crawler wheels are removed from the normal wheel pool.
    -- ================================================================
    if vehicle.spec_crawlers ~= nil and vehicle.spec_crawlers.crawlers ~= nil then
        for crawlerIndex, crawler in ipairs(vehicle.spec_crawlers.crawlers) do
            local members = getCrawlerMembers(vehicle, crawler, allWheels)
            local x, y, z = getCrawlerLocalPosition(vehicle, crawler)
            -- TEST0.1.0.52: resolve crawler type defensively inline.
            -- The previous diagnostic build could fail here in the live runtime
            -- although the helper existed in source. Do not let the temporary
            -- load test depend on that optional classifier.
            local crawlerType, typeSource = "RUBBER_TRACK", "GENERIC_CRAWLER_DEFAULT"
            local vehicleName = string.lower(tostring(vehicle.configFileName or vehicle.xmlFileName or vehicle.typeName or ""))
            if string.find(vehicleName, "leitwolf", 1, true) ~= nil then
                crawlerType, typeSource = "CRAWLER_STEEL", "SPECIAL_LEITWOLF"
            end

            local unit = {
                index = crawlerIndex,
                side = crawler.isLeft == true and "LEFT" or "RIGHT",
                crawler = crawler,
                wheels = members,
                wheelCount = #members,
                x = x,
                y = y,
                z = z,
                type = crawlerType,
                typeSource = typeSource,
                movedDistance = safeNumber(crawler.movedDistance, 0)
            }

            for _, wheel in ipairs(members) do
                assignedCrawler[wheel] = true
                if wheel.wheelIndex ~= nil then
                    assignedCrawler[wheel.wheelIndex] = true
                end
            end

            manifest.crawlers[#manifest.crawlers + 1] = unit
        end
    end

    -- Phase 2: normal wheels only.
    local normalEntries = {}
    for index, wheel in pairs(allWheels) do
        local isCrawler = assignedCrawler[wheel] or assignedCrawler[index]
        if not isCrawler and wheel ~= nil and wheel.wheelIndex ~= nil then
            isCrawler = assignedCrawler[wheel.wheelIndex]
        end

        if not isCrawler and isCrawlerTire(wheel) then
            isCrawler = true
        end

        if not isCrawler and wheel ~= nil and wheel.repr ~= nil then
            local _, _, z = getWheelLocalPosition(vehicle, wheel)
            if z ~= nil then
                normalEntries[#normalEntries + 1] = {
                    wheel = wheel,
                    index = index,
                    z = z
                }
            end
        end
    end

    table.sort(normalEntries, function(a, b)
        return (a.z or 0) > (b.z or 0)
    end)

    -- First use explicit GIANTS WheelAxle links.
    local normalByObject = {}
    for _, entry in ipairs(normalEntries) do
        normalByObject[entry.wheel] = entry
    end

    local consumed = {}
    local wheelAxles = vehicle.wheelAxles
    if wheelAxles == nil and vehicle.spec_wheels ~= nil then
        wheelAxles = vehicle.spec_wheels.wheelAxles
    end

    if wheelAxles ~= nil then
        for _, axle in pairs(wheelAxles) do
            local w1, w2 = axle.wheel1, axle.wheel2
            local e1, e2 = normalByObject[w1], normalByObject[w2]

            if e1 ~= nil and e2 ~= nil then
                local unit = {
                    index = #manifest.wheelUnits + 1,
                    kind = "WHEEL_AXLE",
                    wheels = {w1, w2},
                    z = ((e1.z or 0) + (e2.z or 0)) * 0.5
                }

                manifest.wheelUnits[#manifest.wheelUnits + 1] = unit
                consumed[e1] = true
                consumed[e2] = true
            end
        end
    end

    -- Remaining wheels are grouped by longitudinal position using the same
    -- wheel-size-derived tolerance principle as the proven HUD.
    local remaining = {}
    for _, entry in ipairs(normalEntries) do
        if not consumed[entry] then
            remaining[#remaining + 1] = entry
        end
    end

    for _, entry in ipairs(remaining) do
        local wheel = entry.wheel
        local radius = wheel.physics ~= nil and safeNumber(wheel.physics.radius, 0.4) or 0.4

        local best = nil
        local bestDistance = math.huge

        for _, unit in ipairs(manifest.wheelUnits) do
            if unit.kind == "WHEEL_PLANE" then
                local distance = math.abs((unit.z or 0) - entry.z)
                local meanRadius = unit.meanRadius or radius
                local tolerance = math.max(0.08, 0.25 * ((meanRadius + radius) * 0.5))

                if distance <= tolerance and distance < bestDistance then
                    best = unit
                    bestDistance = distance
                end
            end
        end

        if best == nil then
            best = {
                index = #manifest.wheelUnits + 1,
                kind = "WHEEL_PLANE",
                wheels = {},
                z = entry.z,
                meanRadius = radius
            }
            manifest.wheelUnits[#manifest.wheelUnits + 1] = best
        end

        best.wheels[#best.wheels + 1] = wheel
        local count = #best.wheels
        best.z = best.z + ((entry.z - best.z) / count)
        best.meanRadius = best.meanRadius + ((radius - best.meanRadius) / count)
    end

    table.sort(manifest.wheelUnits, function(a, b)
        return (a.z or 0) > (b.z or 0)
    end)

    -- Normalize axle indices after sorting.
    for index, unit in ipairs(manifest.wheelUnits) do
        unit.index = index
    end

    -- Build a complete physical unit list for diagnostics.
    for _, unit in ipairs(manifest.wheelUnits) do
        for _, wheel in ipairs(unit.wheels) do
            manifest.wheels[#manifest.wheels + 1] = wheel
        end
    end

    for _, crawler in ipairs(manifest.crawlers) do
        for _, wheel in ipairs(crawler.wheels) do
            manifest.wheels[#manifest.wheels + 1] = wheel
        end
    end

    manifest.totalWheelCount = #manifest.wheels
    manifest.normalWheelCount = #manifest.wheels - 0

    for _, crawler in ipairs(manifest.crawlers) do
        manifest.crawlerWheelCount = manifest.crawlerWheelCount + #crawler.wheels
    end

    manifest.normalWheelCount = manifest.totalWheelCount - manifest.crawlerWheelCount
    manifest.crawlerCount = #manifest.crawlers
    manifest.axleCount = #manifest.wheelUnits

    -- A simple normalized axle list used only for diagnostics.
    for _, unit in ipairs(manifest.wheelUnits) do
        manifest.axleUnits[#manifest.axleUnits + 1] = unit
    end

    -- Assign one stable structural chassis type to the complete running gear.
    -- The first sighting creates a new type automatically; later vehicles with
    -- the identical structural signature reuse the same type.
    local chassisTypeId, chassisTypeEntry = rvRegisterChassisType(vehicle, manifest)
    manifest.chassisTypeId = chassisTypeId
    manifest.chassisType = chassisTypeEntry

    for _, crawlerUnit in ipairs(manifest.crawlers) do
        crawlerUnit.chassisTypeId = chassisTypeId
        crawlerUnit.chassisType = chassisTypeEntry
    end

    return manifest
end

local function getOrBuildManifest(vehicle)
    local cached = manifestCache[vehicle]
    if cached ~= nil then
        return cached
    end

    local ok, manifest = pcall(buildManifest, vehicle)
    if not ok or manifest == nil then
        print(string.format("[ReifenVerschleiss][DIAG] buildManifest runtime error: %s", tostring(manifest)))
        return nil
    end
    manifestCache[vehicle] = manifest
    return manifest
end

-- ============================================================================
-- REIFENVERSCHLEISS-ERKENNUNG
-- Independent from the chassis/axis/slip recognition. Crawler wheels are
-- physical reference wheels for the chassis/slip path, but are NOT tire-wear
-- objects. A crawler itself is one wear object (the actual band).
-- ============================================================================
local function buildTireWearManifest(vehicle)
    local result = {wheels = {}, tracks = {}, wheelCount = 0, trackCount = 0, totalWearObjectCount = 0}
    if vehicle == nil or vehicle.spec_wheels == nil or vehicle.spec_wheels.wheels == nil then
        return result
    end

    local vehicleName = string.lower(tostring(vehicle.configFileName or vehicle.xmlFileName or vehicle.typeName or ""))
    local isHoverWearSpecial = string.find(vehicleName, "jacto_hover_500", 1, true) ~= nil
        or string.find(vehicleName, "hover_500", 1, true) ~= nil
        or string.find(vehicleName, "hover500", 1, true) ~= nil

    local allWheels = vehicle.spec_wheels.wheels
    local crawlerAssigned = {}

    if vehicle.spec_crawlers ~= nil and vehicle.spec_crawlers.crawlers ~= nil then
        for crawlerIndex, crawler in ipairs(vehicle.spec_crawlers.crawlers) do
            local members = getCrawlerMembers(vehicle, crawler, allWheels)
            for _, wheel in ipairs(members) do
                crawlerAssigned[wheel] = true
                if wheel.wheelIndex ~= nil then crawlerAssigned[wheel.wheelIndex] = true end
            end
            local x, y, z = getCrawlerLocalPosition(vehicle, crawler)
            local side = crawler.isLeft == true and "LEFT" or "RIGHT"
            local signature = rvMakeCrawlerSignature(vehicle, crawler, members)
            local crawlerType = classifyCrawler(vehicle, crawler)
            local wearRunningGearType = crawlerType == "CRAWLER_STEEL" and "STEEL_TRACK" or "RUBBER_TRACK"
            result.tracks[#result.tracks + 1] = {
                index = crawlerIndex, side = side, crawler = crawler,
                referenceWheels = members, wheelCount = #members,
                wearRunningGearType = wearRunningGearType,
                leitwolfRollerFallback = string.find(vehicleName, "leitwolf", 1, true) ~= nil,
                x = x, y = y, z = z, signature = signature,
                key = string.format("TRACK|%s|%s", side, signature)
            }
        end
    end

    local hoverSkippedHelperWheels = 0
    for _, wheel in pairs(allWheels) do
        local isCrawler = crawlerAssigned[wheel] or (wheel ~= nil and crawlerAssigned[wheel.wheelIndex])
        if not isCrawler and wheel ~= nil and wheel.wheelIndex ~= nil and not isCrawlerTire(wheel) then
            -- TEST2.3.112 Hover special path: the mod exposes five tiny 0.085 m
            -- technical/helper wheels (W5-W9). They never represent the visible
            -- crawler tyre/track and diluted the vehicle OWN-WEAR average to ~30%
            -- although both actual crawler tracks were already at 100%. For Hover
            -- only, the two crawler tracks are therefore the authoritative wear objects.
            if isHoverWearSpecial then
                hoverSkippedHelperWheels = hoverSkippedHelperWheels + 1
            else
                result.wheels[#result.wheels + 1] = wheel
            end
        end
    end
    if isHoverWearSpecial and hoverSkippedHelperWheels > 0 then
        print(string.format(
            "[ReifenVerschleiss][HOVER-WEAR113] excludedHelperWheels=%d authoritativeTracks=%d vehicle=%s",
            hoverSkippedHelperWheels, #result.tracks, tostring(vehicle.configFileName or vehicle.typeName or "UNKNOWN")
        ))
    end

    table.sort(result.wheels, function(a,b) return (a.wheelIndex or 0) < (b.wheelIndex or 0) end)
    table.sort(result.tracks, function(a,b) return (a.index or 0) < (b.index or 0) end)
    result.wheelCount = #result.wheels
    result.trackCount = #result.tracks
    result.totalWearObjectCount = result.wheelCount + result.trackCount
    return result
end

local function getOrBuildTireWearManifest(vehicle)
    local manifest = getOrBuildManifest(vehicle)
    if manifest.tireWearManifest == nil then
        manifest.tireWearManifest = buildTireWearManifest(vehicle)
        print(string.format(
            "[ReifenVerschleiss][REIFENVERSCHLEISS-ERKENNUNG] vehicle=%s wheels=%d tracks=%d wearObjects=%d",
            tostring(vehicle.configFileName or vehicle.typeName or "UNKNOWN"),
            manifest.tireWearManifest.wheelCount, manifest.tireWearManifest.trackCount,
            manifest.tireWearManifest.totalWearObjectCount
        ))
        for _, track in ipairs(manifest.tireWearManifest.tracks) do
            print(string.format(
                "[ReifenVerschleiss][REIFENVERSCHLEISS-TRACK] index=%d side=%s refs=%d pos=(%.3f,%.3f,%.3f) key=%s",
                track.index, track.side, track.wheelCount, safeNumber(track.x,0), safeNumber(track.y,0), safeNumber(track.z,0), track.key
            ))
        end
    end
    return manifest.tireWearManifest
end

local getDiagnosticSlip

local function primitiveValue(v)
    local t = type(v)
    if t == "string" or t == "number" or t == "boolean" then
        return tostring(v)
    end
    if v == nil then
        return "nil"
    end
    return "<" .. t .. ">"
end

-- TEST0.2.0.93: runtime drivetrain root + topology diagnostic for the MacDon M1240.
-- Diagnostic only: no values are written back and no existing drivetrain logic
-- is changed. The purpose is to see exactly what GIANTS exposes at runtime.
local function printMacDonDriveTopology(vehicle)
    local name = tostring(vehicle ~= nil and (vehicle.configFileName or vehicle.xmlFileName or vehicle.typeName or "") or "")
    local lowerName = string.lower(name)
    if string.find(lowerName, "m1240", 1, true) == nil and string.find(lowerName, "macdon", 1, true) == nil then
        return
    end

    print("[ReifenVerschleiss][MACDON-DRIVE-DIAG] ===== BEGIN RUNTIME DRIVE TOPOLOGY =====")
    print(string.format("[ReifenVerschleiss][MACDON-DRIVE-DIAG] vehicle=%s", name))

    local wheels = vehicle ~= nil and vehicle.spec_wheels ~= nil and vehicle.spec_wheels.wheels or nil
    if wheels == nil then
        print("[ReifenVerschleiss][MACDON-DRIVE-DIAG] spec_wheels.wheels=nil")
    else
        for i, wheel in pairs(wheels) do
            if wheel ~= nil then
                local wi = wheel.wheelIndex ~= nil and tostring(wheel.wheelIndex) or tostring(i)
                local dm = wheel.driveMode ~= nil and tostring(wheel.driveMode) or "nil"
                local driveNode = wheel.driveNode ~= nil and tostring(wheel.driveNode) or "nil"
                local linkNode = wheel.linkNode ~= nil and tostring(wheel.linkNode) or "nil"
                local axle = wheel.wheelAxle ~= nil and tostring(wheel.wheelAxle) or "nil"
                local motor = wheel.isMotorized ~= nil and tostring(wheel.isMotorized) or "nil"
                print(string.format(
                    "[ReifenVerschleiss][MACDON-DRIVE-DIAG] W%02s driveMode=%s wheelAxle=%s isMotorized=%s driveNode=%s linkNode=%s",
                    wi, dm, axle, motor, driveNode, linkNode
                ))

                local keys = {}
                for k, v in pairs(wheel) do
                    local kt = type(k)
                    local vt = type(v)
                    if kt == "string" and (vt == "string" or vt == "number" or vt == "boolean") then
                        keys[#keys + 1] = string.format("%s=%s", k, primitiveValue(v))
                    end
                end
                table.sort(keys)
                if #keys > 0 then
                    print(string.format("[ReifenVerschleiss][MACDON-DRIVE-DIAG] W%02s primitive=%s", wi, table.concat(keys, " | ")))
                end
            end
        end
    end

    local specMotorized = vehicle ~= nil and vehicle.spec_motorized or nil

    -- TEST0.2.0.93: expose the actual GIANTS Motorized root and motor object.
    -- GIANTS attaches every loaded differential to spec.motorizedNode in
    -- Motorized:addToPhysics(); we log the runtime objects so the MacDon
    -- topology can be verified without changing drivetrain behavior.
    if specMotorized == nil then
        print("[ReifenVerschleiss][MACDON-DRIVE-DIAG] spec_motorized=nil")
    else
        print(string.format(
            "[ReifenVerschleiss][MACDON-DRIVE-DIAG] MOTOR-ROOT motorizedNode=%s motor=%s motorState=%s motorRotSpeed=%s differentialRotSpeed=%s gearRatio=%s",
            tostring(specMotorized.motorizedNode), tostring(specMotorized.motor),
            tostring(specMotorized.motorState),
            tostring(specMotorized.motor ~= nil and specMotorized.motor.motorRotSpeed or nil),
            tostring(specMotorized.motor ~= nil and specMotorized.motor.differentialRotSpeed or nil),
            tostring(specMotorized.motor ~= nil and specMotorized.motor.gearRatio or nil)
        ))

        local function logPrimitiveTable(tag, tbl)
            if tbl == nil then
                return
            end
            local keys = {}
            for k, v in pairs(tbl) do
                local kt, vt = type(k), type(v)
                if kt == "string" and (vt == "string" or vt == "number" or vt == "boolean") then
                    keys[#keys + 1] = string.format("%s=%s", k, primitiveValue(v))
                end
            end
            table.sort(keys)
            if #keys > 0 then
                print(string.format("[ReifenVerschleiss][MACDON-DRIVE-DIAG] %s %s", tag, table.concat(keys, " | ")))
            end
        end

        logPrimitiveTable("MOTOR primitive=", specMotorized.motor)
        logPrimitiveTable("MOTOR-SPEC primitive=", specMotorized)
    end

    local diffs = specMotorized ~= nil and specMotorized.differentials or nil
    if diffs == nil then
        print("[ReifenVerschleiss][MACDON-DRIVE-DIAG] spec_motorized.differentials=nil")
    else
        for index, diff in pairs(diffs) do
            if diff ~= nil then
                print(string.format(
                    "[ReifenVerschleiss][MACDON-DRIVE-DIAG] DIFF[%s] diffIndex1=%s diffIndex1IsWheel=%s diffIndex2=%s diffIndex2IsWheel=%s",
                    tostring(index), tostring(diff.diffIndex1), tostring(diff.diffIndex1IsWheel), tostring(diff.diffIndex2), tostring(diff.diffIndex2IsWheel)
                ))
                local keys = {}
                for k, v in pairs(diff) do
                    local kt = type(k)
                    local vt = type(v)
                    if kt == "string" and (vt == "string" or vt == "number" or vt == "boolean") then
                        keys[#keys + 1] = string.format("%s=%s", k, primitiveValue(v))
                    end
                end
                table.sort(keys)
                if #keys > 0 then
                    print(string.format("[ReifenVerschleiss][MACDON-DRIVE-DIAG] DIFF[%s] primitive=%s", tostring(index), table.concat(keys, " | ")))
                end
            end
        end
    end

    local wheelAxles = vehicle ~= nil and vehicle.wheelAxles or nil
    if wheelAxles == nil and vehicle ~= nil and vehicle.spec_wheels ~= nil then
        wheelAxles = vehicle.spec_wheels.wheelAxles
    end
    if wheelAxles == nil then
        print("[ReifenVerschleiss][MACDON-DRIVE-DIAG] wheelAxles=nil")
    else
        for index, axle in pairs(wheelAxles) do
            if axle ~= nil then
                print(string.format(
                    "[ReifenVerschleiss][MACDON-DRIVE-DIAG] AXLE[%s] wheel1=%s wheel2=%s",
                    tostring(index), tostring(axle.wheel1 ~= nil and axle.wheel1.wheelIndex or nil), tostring(axle.wheel2 ~= nil and axle.wheel2.wheelIndex or nil)
                ))
                local keys = {}
                for k, v in pairs(axle) do
                    local kt = type(k)
                    local vt = type(v)
                    if kt == "string" and (vt == "string" or vt == "number" or vt == "boolean") then
                        keys[#keys + 1] = string.format("%s=%s", k, primitiveValue(v))
                    end
                end
                table.sort(keys)
                if #keys > 0 then
                    print(string.format("[ReifenVerschleiss][MACDON-DRIVE-DIAG] AXLE[%s] primitive=%s", tostring(index), table.concat(keys, " | ")))
                end
            end
        end
    end

    print("[ReifenVerschleiss][MACDON-DRIVE-DIAG] ===== END RUNTIME DRIVE TOPOLOGY =====")
end

local function wheelDiagnostic(wheel, vehicle)
    local groundType, wetScale, snowScale, contact, groundDepth, hasSnowContact, isField, isRoad, terrainSnowIndex, terrainSnow, terrainTypeIndex, terrainDensity, terrainStates, terrainChannels, terrainSnowSamples, densityHeight, densityDelta, terrainHeight, heightTypeIndex, heightTypeName, contactSkin, snowMethod, nativeSnowScale, snowfall, temperature, snowHeight, ownSnowState, snowHeightMethod, globalSnowHeight, nativeTireType, nativeTireFriction, hasGroundContact, isMudTerrain, rainScale, timeSinceLastRain, wetSource, nativeHeightTypeChannels, nativeHeightTypeCandidates, densityTypeIndex, densityStateBits, descriptorHeightTypeIndex = getWheelGroundInfo(wheel)
    local load = getWheelLoad(wheel)
    local rawSlip = getWheelSlip(wheel, vehicle)
    local vehicleState = getVehicleWearState(vehicle)
    local slip, wheelRotation, slipStartupBlocked = getDiagnosticSlip(vehicle, wheel, vehicleState, hasGroundContact)
    local width = getWheelWidth(wheel)
    local restLoad = getWheelRestLoad(wheel)
    local radius = wheel.physics ~= nil and safeNumber(wheel.physics.radius, nil) or nil
    local loadFactor, widthFactor, radiusFactor, physicalFactor = getWheelPhysicalFactors(load, width, radius)

    local x, y, z = getWheelLocalPosition(vehicle, wheel)

    return {
        index = wheel.wheelIndex,
        driveMode = wheel.driveMode,
        wheelAxle = wheel.wheelAxle,
        isMotorized = wheel.isMotorized,
        tire = getTireName(wheel),
        nativeTireType = nativeTireType,
        nativeTireFriction = nativeTireFriction,
        crawler = isCrawlerTire(wheel),
        wearRunningGearType = getWheelWearRunningGearType(wheel),
        driven = getTractionWheels(vehicle)[wheel.wheelIndex] == true,
        load = load,
        restLoad = restLoad,
        slip = slip,
        rawSlip = rawSlip,
        wheelRotation = wheelRotation,
        slipStartupBlocked = slipStartupBlocked,
        width = width,
        loadFactor = loadFactor,
        widthFactor = widthFactor,
        radiusFactor = radiusFactor,
        physicalFactor = physicalFactor,
        contact = contact,
        hasGroundContact = hasGroundContact,
        groundType = groundType,
        isMudTerrain = isMudTerrain,
        wetScale = wetScale,
        rainScale = rainScale,
        timeSinceLastRain = timeSinceLastRain,
        wetSource = wetSource,
        snowScale = snowScale,
        nativeSnowScale = nativeSnowScale,
        snowfall = snowfall,
        snowTemperature = temperature,
        snowHeight = snowHeight,
        ownSnowState = ownSnowState,
        snowHeightMethod = snowHeightMethod,
        globalSnowHeight = globalSnowHeight,
        snowProfile = profileName,
        ownSnowSlipFactor = ownSnowSlipFactor,
        ownSnowGripFactor = ownSnowGripFactor,
        ownSnowWearFactor = ownSnowWearFactor,
        groundDepth = groundDepth,
        hasSnowContact = hasSnowContact,
        isField = isField,
        isRoad = isRoad,
        terrainSnowIndex = terrainSnowIndex,
        terrainSnow = terrainSnow,
        terrainTypeIndex = terrainTypeIndex,
        terrainDensity = terrainDensity,
        terrainStates = terrainStates,
        terrainChannels = terrainChannels,
        terrainSnowSamples = terrainSnowSamples,
        densityHeight = densityHeight,
        densityDelta = densityDelta,
        terrainHeight = terrainHeight,
        heightTypeIndex = heightTypeIndex,
        heightTypeName = heightTypeName,
        nativeHeightTypeChannels = nativeHeightTypeChannels,
        nativeHeightTypeCandidates = nativeHeightTypeCandidates,
        densityTypeIndex = densityTypeIndex,
        densityStateBits = densityStateBits,
        descriptorHeightTypeIndex = descriptorHeightTypeIndex,
        contactSkin = contactSkin,
        snowMethod = snowMethod,
        radius = radius,
        diameter = getWheelDiameter(wheel),
        x = x,
        y = y,
        z = z
    }
end

local function groundName(value)
    if value == nil then return "?" end
    if WheelsUtil ~= nil then
        if value == WheelsUtil.GROUND_ROAD then return "ROAD" end
        if value == WheelsUtil.GROUND_FIELD then return "FIELD" end
        if value == WheelsUtil.GROUND_HARD_TERRAIN then return "HARD" end
        if value == WheelsUtil.GROUND_SOFT_TERRAIN then return "SOFT" end
    end
    return tostring(value)
end

local function contactName(value)
    if value == nil then return "?" end

    if Vehicle ~= nil then
        if value == Vehicle.WHEEL_NO_CONTACT then return "NONE" end
        if value == Vehicle.WHEEL_GROUND_CONTACT then return "GROUND" end
        if value == Vehicle.WHEEL_GROUND_HEIGHT_CONTACT then return "GROUND_HEIGHT" end
        if value == Vehicle.WHEEL_OBJ_CONTACT then return "OBJECT" end
    end

    if WheelContactType ~= nil then
        if WheelContactType.NONE ~= nil and value == WheelContactType.NONE then return "NONE" end
        if WheelContactType.GROUND ~= nil and value == WheelContactType.GROUND then return "GROUND" end
        if WheelContactType.OBJECT ~= nil and value == WheelContactType.OBJECT then return "OBJECT" end
    end

    return tostring(value)
end


-- ============================================================================
-- REALISTIC WEAR MODEL
-- ============================================================================
-- REALISTIC WEAR MODEL
--
-- The model deliberately keeps the two requested wear channels independent:
--
--   DISTANCE WEAR = driven distance + wheel load + ground + wetness/weather
--   SLIP WEAR     = slip distance + wheel load + ground + wetness/weather
--
-- No global "vehicle mass -> wear" multiplier is used. Attached mass therefore
-- influences the tire only through the actual dynamic wheel load measured by
-- GIANTS. This prevents double counting the trailer/implement mass.
--
-- The numerical coefficients below are conservative model coefficients, not
-- claimed laboratory constants. They are kept in one place so they can be
-- calibrated against the collected FS25 test logs without changing the data
-- pipeline.
-- ============================================================================
RV.WEAR_REFERENCE_DISTANCE_M = 100000       -- 100 km = 1.0 base wear; price reference is separate
RV.WEAR_MAX = 1
RV.WEAR_LOAD_EXPONENT = 1.25
RV.WEAR_LOAD_MIN_FACTOR = 0.50
RV.WEAR_LOAD_MAX_FACTOR = 3.00
RV.WEAR_SLIP_REFERENCE = 0.10               -- 10 % slip
RV.WEAR_SLIP_EXPONENT = 1.50
RV.WEAR_SLIP_COEFFICIENT = 0.20
RV.WEAR_SLIP_MIN_PERCENT = 1.0
RV.WEAR_SLIP_MAX_PERCENT = 100.0

-- TEST2.3.136: movement-time wear, calibrated at the agreed 1000 km reference.
-- TIME-WEAR is field-only: road and generic off-road/hard/soft terrain never
-- receive TIME-WEAR. Confirmed movement on a real field adds 7.5 points/hour.
-- After 30 seconds of confirmed active field movement, <=50 m (<=6 km/h avg)
-- raises TIME-WEAR smoothly up to 20 points/hour at 2 km/h. A non-tractor
-- carrier with an active front harvest attachment receives +5 points/hour.
RV.TIME_WEAR_MIN_SPEED_KMH = 2.0
RV.TIME_WEAR_CONFIRM_SEC = 2.0
RV.TIME_WEAR_WINDOW_SEC = 30.0
RV.TIME_WEAR_WINDOW_DISTANCE_M = 50.0
RV.TIME_WEAR_LOW_POINTS_PER_H_AT_1000 = 7.5
RV.TIME_WEAR_SLOW_MAX_POINTS_PER_H_AT_1000 = 20.0
RV.TIME_WEAR_HARVEST_BONUS_POINTS_PER_H_AT_1000 = 5.0
RV.TIME_WEAR_REFERENCE_KM = 1000.0

-- TEST0.2.0.107: selectable target tire/running-gear lifetime.
-- The proven 100 km wear calibration remains the fixed base. The selected
-- reference scales the complete wear rate without changing the underlying
-- DIST-WEAR / SLIP-WEAR model.
local function rvGetWearReferenceRateFactor()
    if RPReferenceSettings ~= nil and RPReferenceSettings.getWearReferenceRateFactor ~= nil then
        local ok, factor = pcall(RPReferenceSettings.getWearReferenceRateFactor)
        if ok and type(factor) == "number" and factor > 0 and factor < math.huge then
            return factor
        end
    end
    return 1.0
end

-- TEST2.3.94: running-gear-specific OWN-WEAR ground matrix.
-- Order/meaning agreed for the wear model:
--   STREET      = road/highway tire
--   OFFROAD     = tractor/agricultural/off-road tire
--   RUBBER_TRACK= rubber crawler/band
--   STEEL_TRACK = metal/steel crawler chain
-- SOFT/MUD remain at the proven .93 base values for all four types.
RV.GROUND_DISTANCE_FACTORS = {
    STREET       = {ROAD=1.00, FIELD=1.15, HARD=1.05, SOFT=0.90, MUD=0.90},
    OFFROAD      = {ROAD=1.10, FIELD=1.05, HARD=1.10, SOFT=0.90, MUD=0.90},
    RUBBER_TRACK = {ROAD=1.20, FIELD=1.00, HARD=1.05, SOFT=0.90, MUD=0.90},
    STEEL_TRACK  = {ROAD=1.50, FIELD=0.90, HARD=1.00, SOFT=0.90, MUD=0.90}
}

RV.GROUND_SLIP_FACTORS = {
    STREET       = {ROAD=1.20, FIELD=1.50, HARD=1.10, SOFT=0.75, MUD=0.75},
    OFFROAD      = {ROAD=1.30, FIELD=1.10, HARD=1.20, SOFT=0.75, MUD=0.75},
    RUBBER_TRACK = {ROAD=1.45, FIELD=1.00, HARD=1.35, SOFT=0.75, MUD=0.75},
    STEEL_TRACK  = {ROAD=1.60, FIELD=0.90, HARD=1.10, SOFT=0.75, MUD=0.75}
}

-- Weather is a REPLACEMENT state, never a stacked multiplier:
-- dry -> wet -> active rain -> snow. Only the strongest current state applies.
RV.WEATHER_WET_FACTOR = 0.80
RV.WEATHER_RAIN_FACTOR = 0.70
RV.WEATHER_SNOW_FACTOR = 0.60

local function clampFinite(value, minValue, maxValue, fallback)
    value = safeNumber(value, fallback)
    if value == nil then
        value = fallback
    end
    return math.clamp(value, minValue, maxValue)
end

local function getGroundWearClass(d)
    if d == nil then
        return "ROAD"
    end
    if d.isField == true then
        return "FIELD"
    end
    if d.isMudTerrain == true then
        return "MUD"
    end

    local name = string.upper(tostring(groundName(d.groundType) or ""))
    if string.find(name, "SOFT", 1, true) ~= nil then
        return "SOFT"
    end
    if string.find(name, "HARD", 1, true) ~= nil then
        return "HARD"
    end
    if string.find(name, "ROAD", 1, true) ~= nil then
        return "ROAD"
    end
    return "HARD"
end

local function rvGetSelectedReferenceKm()
    if RPReferenceSettings ~= nil and RPReferenceSettings.getReferenceKm ~= nil then
        local ok, km = pcall(RPReferenceSettings.getReferenceKm)
        if ok and type(km) == "number" and km > 0 and km < math.huge then
            return km
        end
    end
    return RV.TIME_WEAR_REFERENCE_KM
end

local function rvTimeWearNormalizedPerHour(pointsPerHourAt1000)
    local selectedKm = math.max(1, rvGetSelectedReferenceKm())
    local scaledPoints = safeNumber(pointsPerHourAt1000, 0) * (RV.TIME_WEAR_REFERENCE_KM / selectedKm)
    return scaledPoints / 1000.0
end

local function rvIsTractorByStoreCategory(vehicle)
    if vehicle == nil or g_storeManager == nil or g_storeManager.getItemByXMLFilename == nil then return false end
    local filename = vehicle.configFileName
    if filename == nil then return false end
    local ok, item = pcall(g_storeManager.getItemByXMLFilename, g_storeManager, filename)
    if not ok or item == nil then return false end
    for _, name in ipairs(item.categoryNames or {}) do
        local lower = string.lower(tostring(name or ""))
        if string.find(lower, "tractor", 1, true) ~= nil then
            return true
        end
    end
    return false
end

local function rvIsHarvestAttachmentObject(object)
    if object == nil then return false end
    return object.spec_cutter ~= nil
        or object.spec_pickup ~= nil
        or object.spec_fruitPreparer ~= nil
        or object.spec_vineCutter ~= nil
        or object.spec_extendedCombine ~= nil
end

local function rvIsTurnedOnSafe(object)
    if object == nil then return false end
    if type(object.getIsTurnedOn) == "function" then
        local ok, value = pcall(object.getIsTurnedOn, object)
        if ok and value == true then return true end
    end
    local spec = object.spec_turnOnVehicle
    return spec ~= nil and spec.isTurnedOn == true
end

local function rvIsFrontAttachment(carrier, object)
    if carrier == nil or object == nil or carrier.rootNode == nil or object.rootNode == nil or localToLocal == nil then
        return false
    end
    local ok, _, _, z = pcall(localToLocal, object.rootNode, carrier.rootNode, 0, 0, 0)
    return ok and type(z) == "number" and z > 0.25
end

local function rvHasActiveFrontHarvestAttachment(vehicle)
    if vehicle == nil or rvIsTractorByStoreCategory(vehicle) then return false end
    if type(vehicle.getAttachedImplements) ~= "function" then return false end
    local ok, implements = pcall(vehicle.getAttachedImplements, vehicle)
    if not ok or type(implements) ~= "table" then return false end
    for _, implement in pairs(implements) do
        local object = implement ~= nil and implement.object or nil
        if object ~= nil and rvIsFrontAttachment(vehicle, object) and rvIsHarvestAttachmentObject(object) then
            -- Many GIANTS cutters/pickups are driven by the carrier's Combine/TurnOnVehicle
            -- state instead of exposing their own independent turned-on state. Accept either
            -- side so a rotating/activated header is detected without requiring crop processing.
            if rvIsTurnedOnSafe(object) or rvIsTurnedOnSafe(vehicle) then
                return true
            end
        end
    end
    return false
end

local function rvWearManifestIsOnField(manifest)
    if manifest == nil then return false end
    local wearManifest = manifest.tireWearManifest
    if wearManifest == nil then return false end

    -- Use the same native field signal already used by the wheel diagnostics:
    -- wheel.densityType ~= 0. A single real wear wheel/reference wheel on the
    -- field is sufficient for the object to be treated as active field work.
    for _, wheel in ipairs(wearManifest.wheels or {}) do
        if wheel ~= nil and wheel.densityType ~= nil and wheel.densityType ~= 0 then
            return true
        end
    end
    for _, track in ipairs(wearManifest.tracks or {}) do
        for _, wheel in ipairs(track.referenceWheels or {}) do
            if wheel ~= nil and wheel.densityType ~= nil and wheel.densityType ~= 0 then
                return true
            end
        end
    end
    return false
end

local function rvUpdateTimeWearContext(vehicle, vehicleState, distanceM, speedKmh, dtSec, passiveImplement, manifest)
    local context = {active=false, ratePointsPerHourAt1000=RV.TIME_WEAR_LOW_POINTS_PER_H_AT_1000, avgSpeedKmh=0, harvestBoost=false, isField=false}
    if vehicleState == nil or dtSec <= 0 then return context end

    local isField = rvWearManifestIsOnField(manifest)
    context.isField = isField
    if not isField then
        -- TIME-WEAR is intentionally field-only. Leaving the field also resets
        -- the movement confirmation/window so road/off-road travel cannot prime
        -- a later slow-work factor before the wheels actually re-enter a field.
        vehicleState.timeWearMoveConfirmSec = 0
        vehicleState.timeWearWindowSec = 0
        vehicleState.timeWearWindowDistanceM = 0
        vehicleState.timeWearWindowAvgSpeedKmh = 0
        vehicleState.timeWearRatePointsPerHourAt1000 = RV.TIME_WEAR_LOW_POINTS_PER_H_AT_1000
        vehicleState.timeWearHarvestBoostActive = false
        return context
    end

    local speed = math.abs(safeNumber(speedKmh, 0))
    local moved = math.max(0, safeNumber(distanceM, 0))
    if speed >= RV.TIME_WEAR_MIN_SPEED_KMH then
        vehicleState.timeWearMoveConfirmSec = safeNumber(vehicleState.timeWearMoveConfirmSec, 0) + dtSec
    else
        vehicleState.timeWearMoveConfirmSec = 0
    end

    if safeNumber(vehicleState.timeWearMoveConfirmSec, 0) < RV.TIME_WEAR_CONFIRM_SEC then
        return context
    end

    context.active = true
    vehicleState.timeWearWindowSec = safeNumber(vehicleState.timeWearWindowSec, 0) + dtSec
    vehicleState.timeWearWindowDistanceM = safeNumber(vehicleState.timeWearWindowDistanceM, 0) + moved

    if vehicleState.timeWearWindowSec >= RV.TIME_WEAR_WINDOW_SEC then
        local avgSpeed = vehicleState.timeWearWindowSec > 0
            and (vehicleState.timeWearWindowDistanceM / vehicleState.timeWearWindowSec) * 3.6
            or 0
        vehicleState.timeWearWindowAvgSpeedKmh = avgSpeed

        local rate = RV.TIME_WEAR_LOW_POINTS_PER_H_AT_1000
        if vehicleState.timeWearWindowDistanceM <= RV.TIME_WEAR_WINDOW_DISTANCE_M then
            local alpha = math.clamp((6.0 - avgSpeed) / (6.0 - RV.TIME_WEAR_MIN_SPEED_KMH), 0, 1)
            rate = RV.TIME_WEAR_LOW_POINTS_PER_H_AT_1000
                + (RV.TIME_WEAR_SLOW_MAX_POINTS_PER_H_AT_1000 - RV.TIME_WEAR_LOW_POINTS_PER_H_AT_1000) * alpha
        end
        vehicleState.timeWearRatePointsPerHourAt1000 = rate
        vehicleState.timeWearWindowSec = 0
        vehicleState.timeWearWindowDistanceM = 0
    end

    context.ratePointsPerHourAt1000 = safeNumber(vehicleState.timeWearRatePointsPerHourAt1000, RV.TIME_WEAR_LOW_POINTS_PER_H_AT_1000)
    context.avgSpeedKmh = safeNumber(vehicleState.timeWearWindowAvgSpeedKmh, speed)
    if passiveImplement ~= true and rvHasActiveFrontHarvestAttachment(vehicle) then
        context.harvestBoost = true
        context.ratePointsPerHourAt1000 = context.ratePointsPerHourAt1000 + RV.TIME_WEAR_HARVEST_BONUS_POINTS_PER_H_AT_1000
    end
    vehicleState.timeWearHarvestBoostActive = context.harvestBoost
    return context
end

local function getLoadFactor(d)
    local load = safeNumber(d ~= nil and d.load or nil, nil)
    local reference = safeNumber(d ~= nil and d.restLoad or nil, nil)

    if load == nil or reference == nil or load <= 0 or reference <= 0 then
        return 1.0
    end

    local ratio = load / reference
    return clampFinite(math.pow(math.max(0.01, ratio), RV.WEAR_LOAD_EXPONENT),
        RV.WEAR_LOAD_MIN_FACTOR, RV.WEAR_LOAD_MAX_FACTOR, 1.0)
end

local function getWearRunningGearType(d)
    local t = d ~= nil and tostring(d.wearRunningGearType or "") or ""
    if t == "STREET" or t == "OFFROAD" or t == "RUBBER_TRACK" or t == "STEEL_TRACK" then
        return t
    end
    -- Normal wheels that are not explicitly road tires belong to the
    -- tractor/off-road class. This keeps unknown agricultural tire names out
    -- of the road-tire penalty class.
    return "OFFROAD"
end

local function getWeatherWearFactor(d, runningGearType, groundClass)
    if d == nil then return 1.0, "DRY" end

    -- Priority is intentional and exclusive: snow replaces rain, rain replaces
    -- wetness. No double multiplication of wet+rain+snow is allowed.
    if d.terrainSnow == true or safeNumber(d.snowScale, 0) > 0.5 then
        return RV.WEATHER_SNOW_FACTOR, "SNOW"
    end

    local rain = clampFinite(d.rainScale, 0, 1, 0)
    if rain > 0.001 then
        -- Steel/metal crawler chains on ROAD do not receive the weather wear
        -- reduction from rain; agreed factor stays 1.0.
        if runningGearType == "STEEL_TRACK" and groundClass == "ROAD" then
            return 1.0, "RAIN_STEEL_ROAD"
        end
        return RV.WEATHER_RAIN_FACTOR, "RAIN"
    end

    local wet = clampFinite(d.wetScale, 0, 1, 0)
    if wet > 0.001 then
        -- Same rule for merely wet asphalt with a metal/steel crawler chain.
        if runningGearType == "STEEL_TRACK" and groundClass == "ROAD" then
            return 1.0, "WET_STEEL_ROAD"
        end
        return RV.WEATHER_WET_FACTOR, "WET"
    end

    return 1.0, "DRY"
end

local function getDistanceGroundFactor(d)
    local class = getGroundWearClass(d)
    local runningGearType = getWearRunningGearType(d)
    local tableForType = RV.GROUND_DISTANCE_FACTORS[runningGearType] or RV.GROUND_DISTANCE_FACTORS.OFFROAD
    local base = tableForType[class] or 1.0
    local weatherFactor, weatherClass = getWeatherWearFactor(d, runningGearType, class)
    local factor = base * weatherFactor

    return clampFinite(factor, 0.40, 1.60, 1.0), class, runningGearType, weatherClass
end

local function getSlipGroundFactor(d)
    local class = getGroundWearClass(d)
    local runningGearType = getWearRunningGearType(d)
    local tableForType = RV.GROUND_SLIP_FACTORS[runningGearType] or RV.GROUND_SLIP_FACTORS.OFFROAD
    local base = tableForType[class] or 1.0
    local weatherFactor, weatherClass = getWeatherWearFactor(d, runningGearType, class)
    local factor = base * weatherFactor

    return clampFinite(factor, 0.40, 1.80, 1.0), class, runningGearType, weatherClass
end

local function getSlipIntensity(slipPercent)
    local slip = clampFinite(slipPercent, 0, RV.WEAR_SLIP_MAX_PERCENT, 0) / 100
    if slip < RV.WEAR_SLIP_MIN_PERCENT / 100 then
        return 0
    end

    local normalized = slip / RV.WEAR_SLIP_REFERENCE
    return RV.WEAR_SLIP_COEFFICIENT * math.pow(normalized, RV.WEAR_SLIP_EXPONENT)
end

local function getWearKey(wheel)
    if wheel == nil then
        return nil
    end

    -- Persistenz-/HUD-kritisch: der Radschlüssel muss über Save/Load exakt
    -- dieselbe Tabellenform besitzen. Frühere TEST2.3.78-80 Stände speicherten
    -- numerische wheelIndex-Schlüssel als XML-String und luden sie als String
    -- zurück; getWheelWearState() suchte später aber wieder mit der Zahl.
    -- Ergebnis: Diagnose-/Save-Werte konnten vorhanden sein, während nach
    -- Reload neue 0-Werte unter einem zweiten Schlüssel entstanden. Ab 2_3_81
    -- ist der Schlüssel IMMER ein String.
    if wheel.wheelIndex ~= nil then
        return tostring(wheel.wheelIndex)
    end

    return tostring(wheel)
end

local function getWheelWearState(vehicleState, wheel)
    if vehicleState==nil or wheel==nil then return nil end
    local key=getWearKey(wheel); if key==nil then return nil end
    vehicleState.wheelWear=vehicleState.wheelWear or {}
    local state=vehicleState.wheelWear[key]

    -- Migration für bereits im laufenden Spiel angelegte alte numeric keys.
    -- Nicht kopieren, sondern verschieben, damit es keine Doppelzustände gibt.
    if state == nil and wheel.wheelIndex ~= nil then
        local numericKey = tonumber(wheel.wheelIndex)
        if numericKey ~= nil and vehicleState.wheelWear[numericKey] ~= nil then
            state = vehicleState.wheelWear[numericKey]
            vehicleState.wheelWear[numericKey] = nil
            vehicleState.wheelWear[key] = state
        end
    end

    if state==nil then
        state={value=0,distanceWear=0,slipWear=0,timeWear=0,effectiveDistanceM=0,slipDistanceM=0,lastSlip=0,lastSlipWearPointsPerSecond=0,lastGroundClass="UNKNOWN",lastDistanceFactor=1,lastSlipFactor=1,lastLoadFactor=1,initialized=false,lastDistanceInputM=0,lastDtSec=0,lastSpeedKmh=0,lastLoadInput=0,lastRestLoadInput=0,lastSlipInput=0,debugExpectedDistanceWear=0,debugExpectedSlipWear=0,debugInputDistanceM=0,debugDtSec=0}
        vehicleState.wheelWear[key]=state
    end
    state.value=math.clamp(safeNumber(state.distanceWear,0)+safeNumber(state.slipWear,0)+safeNumber(state.timeWear,0),0,RV.WEAR_MAX)
    return state
end

local function getTrackWearState(vehicleState, track)
    if vehicleState == nil or track == nil then return nil end
    vehicleState.trackWear = vehicleState.trackWear or {}
    local key = track.key or string.format("TRACK|%s|%d", tostring(track.side or "?"), tonumber(track.index) or 0)
    local state = vehicleState.trackWear[key]
    if state == nil then
        state = {
            value = 0,
            distanceWear = 0, slipWear = 0, timeWear = 0, effectiveDistanceM = 0, slipDistanceM = 0,
            lastSlip = 0, lastSlipWearPointsPerSecond = 0,
            lastGroundClass = "UNKNOWN", lastDistanceFactor = 1, lastSlipFactor = 1, lastLoadFactor = 1,
            lastDistanceInputM = 0, lastDtSec = 0, lastSpeedKmh = 0, lastLoadInput = 0,
            lastRestLoadInput = 0, lastSlipInput = 0, debugExpectedDistanceWear = 0,
            debugExpectedSlipWear = 0, debugInputDistanceM = 0, debugDtSec = 0,
            lastCrawlerMovedDistance = nil, initialized = false
        }
        vehicleState.trackWear[key] = state
    end
    state.value = math.clamp(
        safeNumber(state.distanceWear, 0) + safeNumber(state.slipWear, 0) + safeNumber(state.timeWear, 0),
        0, RV.WEAR_MAX
    )
    return state
end

local function getWearSlipTestPointsPerSecond(slip)
    -- FUNCTION TEST ONLY: deliberately visible values to prove that pure
    -- wheel spin produces wear even when vehicle distance is ~0.
    -- Values are wear-points per second on the 0..1000 test scale.
    local s = math.max(0, safeNumber(slip, 0))
    if s < 5 then return 0.00 end
    if s < 10 then return 0.05 end
    if s < 20 then return 0.15 end
    if s < 30 then return 0.30 end
    if s < 40 then return 0.50 end
    if s < 60 then return 0.80 end
    if s < 80 then return 1.20 end
    return 1.50
end

local function isMotorStartPhase(vehicle)
    -- Use the same GIANTS motor-start timing that the proven HUD logic uses.
    -- During this phase wheel-slip values may contain initialization peaks;
    -- absolutely no wear is allowed to pass this gate.
    if vehicle == nil or vehicle.spec_motorized == nil then
        return false, 0, 0
    end

    local spec = vehicle.spec_motorized
    local state = spec.motorState
    local motorStateStarting = MotorState ~= nil and MotorState.STARTING ~= nil and state == MotorState.STARTING

    local startTime = safeNumber(spec.motorStartTime, 0)
    local startDuration = safeNumber(spec.motorStartDuration, 0)

    if motorStateStarting then
        return true, math.max(0, startDuration), 0
    end

    if startTime > 0 and startDuration > 0 and g_time ~= nil then
        local elapsed = g_time - startTime
        if elapsed >= 0 and elapsed < startDuration then
            return true, startDuration, elapsed
        end
    end

    return false, startDuration, 0
end

local function isMotorRunning(vehicle)
    if vehicle == nil then
        return false
    end

    if vehicle.getIsMotorStarted ~= nil then
        local ok, started = pcall(vehicle.getIsMotorStarted, vehicle)
        if ok then
            return started == true
        end
    end

    local spec = vehicle.spec_motorized
    if spec == nil then
        return false
    end

    local state = spec.motorState
    if MotorState ~= nil then
        if MotorState.STARTING ~= nil and state == MotorState.STARTING then
            return false
        end
        if MotorState.STOPPED ~= nil and state == MotorState.STOPPED then
            return false
        end
        if MotorState.OFF ~= nil and state == MotorState.OFF then
            return false
        end
    end

    return state ~= nil
end


local function isWearGroundContact(contact)
    -- Wear requires real ground contact. A freely spinning wheel in the air
    -- may report very high slip, but that must never create tire wear.
    if contact == nil then
        return false
    end

    if Vehicle ~= nil then
        if Vehicle.WHEEL_GROUND_CONTACT ~= nil and contact == Vehicle.WHEEL_GROUND_CONTACT then
            return true
        end
        if Vehicle.WHEEL_GROUND_HEIGHT_CONTACT ~= nil and contact == Vehicle.WHEEL_GROUND_HEIGHT_CONTACT then
            return true
        end
    end

    if WheelContactType ~= nil and WheelContactType.GROUND ~= nil and contact == WheelContactType.GROUND then
        return true
    end

    return false
end

getDiagnosticSlip = function(vehicle, wheel, vehicleState, hasGroundContact)
    local rawSlip = getWheelSlip(wheel, vehicle)
    if rawSlip == nil then
        return 0, false, true
    end

    local startupBlocked = isMotorStartPhase(vehicle)
    local rotating = isWheelPhysicallyRotating(wheel)
    local groundContact = hasGroundContact == true

    -- True standstill/raw-slip gate:
    -- After READY, inertia/braking slip must remain valid while the vehicle is
    -- still moving, even with zero throttle and completely locked wheels.
    -- Only discard a remaining GIANTS raw-slip value when ALL standstill
    -- conditions are true at the same time: no vehicle movement, no physical
    -- wheel/crawler rotation and no drive input. This restores the confirmed
    -- braking/inertia-slip behavior while still blocking the stale ~20%
    -- raw-slip value at a real standstill.
    local speedKmh = getVehicleSpeedKmh(vehicle)
    local driveInput = 0
    local spec = vehicle ~= nil and vehicle.spec_drivable or nil
    if spec ~= nil and spec.lastInputValues ~= nil then
        driveInput = safeNumber(spec.lastInputValues.axisAccelerate, 0)
    end
    local vehicleStopped = math.abs(safeNumber(speedKmh, 0)) <= 0.05
    local noDriveInput = math.abs(driveInput) <= 0.02
    if vehicleStopped and noDriveInput and not rotating then
        return 0, false, startupBlocked
    end
    if hasGroundContact == nil then
        local _, _, _, contact = getWheelGroundInfo(wheel)
        groundContact = isWearGroundContact(contact)
    end

    -- Startup/READY protection remains, but wheel rotation is deliberately NOT
    -- a permanent prerequisite. Once the vehicle is READY, moving and grounded
    -- wheels are eligible for slip evaluation even when the wheel rotation is
    -- very low or zero. This covers braking, wheel lock and heavy steering
    -- inertia instead of misclassifying them as 0% slip.
    if startupBlocked or vehicleState == nil or vehicleState.ready ~= true or not groundContact then
        return 0, rotating, startupBlocked
    end

    return rawSlip, rotating, false
end

local function updateVehicleWearReady(vehicle, vehicleState, dtSec)
    if vehicleState == nil then
        return false, true
    end

    local startPhase = isMotorStartPhase(vehicle)
    local motorRunning = isMotorRunning(vehicle)

    if startPhase or not motorRunning then
        vehicleState.ready = false
        vehicleState.readySince = 0
        return false, startPhase
    end

    -- First valid post-start sample is only used to establish the READY state.
    -- No wear is generated on that sample. This mirrors the proven HUD chain:
    -- raw physics values may exist, but calculations remain blocked until READY.
    if vehicleState.ready ~= true then
        vehicleState.ready = true
        vehicleState.readySince = safeNumber(g_time, 0)
        if ReifenVerschleissWegfahrsperre ~= nil and ReifenVerschleissWegfahrsperre.setReady ~= nil then
            ReifenVerschleissWegfahrsperre.setReady(vehicle)
        end
        return false, false
    end

    return true, false
end

-- ============================================================================
-- WEAR RESET / OWN WEAR
-- TEST0.2.0.26: reset path remains unchanged; visual refresh is handled by RVV.
-- Native workshop actions are independent of the custom wear calculation.
-- The custom reset clears only the mod-owned DIST-/SLIP-/TOTAL-Wear state.
-- ============================================================================
local function resetVehicleWearState(vehicle, reason)
    if vehicle == nil or not isRelevantPlayerVehicle(vehicle) then
        return false
    end

    local state = getVehicleWearState(vehicle)
    if state == nil then
        return false
    end

    state.totalDistanceWear = 0
    state.totalSlipWear = 0
    state.totalTimeWear = 0
    state.totalWear = 0
    state.totalEffectiveWearDistanceM = 0
    state.debugDistanceM = 0
    state.debugTimeMs = 0
    state.debugStep = 0
    state.ready = false
    state.readySince = 0
    state.timeWearMoveConfirmSec = 0
    state.timeWearWindowSec = 0
    state.timeWearWindowDistanceM = 0
    state.timeWearRatePointsPerHourAt1000 = RV.TIME_WEAR_LOW_POINTS_PER_H_AT_1000
    state.timeWearWindowAvgSpeedKmh = 0
    state.timeWearHarvestBoostActive = false
    state.lastReadyLog = false
    state.slipDisplayReady = false
    state.slipDisplayLast = {}
    state.slipDisplayRotation = {}
    state.slipDisplayBlocked = true
    state.debugLastDistanceWear = {}
    state.debugLastSlipWear = {}
    state.debugLastTotalWear = {}
    state.debugLastLoggedDistanceWear = {}
    state.debugLastLoggedSlipWear = {}

    for _, wheelState in pairs(state.wheelWear or {}) do
        wheelState.value = 0
        wheelState.distanceWear = 0
        wheelState.slipWear = 0
        wheelState.timeWear = 0
        wheelState.effectiveDistanceM = 0
        wheelState.slipDistanceM = 0
        wheelState.lastSlip = 0
        wheelState.lastSlipWearPointsPerSecond = 0
        wheelState.lastGroundClass = "RESET"
        wheelState.lastDistanceFactor = 1
        wheelState.lastSlipFactor = 1
        wheelState.lastLoadFactor = 1
        wheelState.lastDistanceInputM = 0
        wheelState.lastDtSec = 0
        wheelState.lastSpeedKmh = 0
        wheelState.lastLoadInput = 0
        wheelState.lastRestLoadInput = 0
        wheelState.lastSlipInput = 0
        wheelState.debugExpectedDistanceWear = 0
        wheelState.debugExpectedSlipWear = 0
        wheelState.debugInputDistanceM = 0
        wheelState.debugDtSec = 0
        wheelState.initialized = false
    end

    for _, trackState in pairs(state.trackWear or {}) do
        trackState.value = 0
        trackState.distanceWear = 0
        trackState.slipWear = 0
        trackState.timeWear = 0
        trackState.effectiveDistanceM = 0
        trackState.slipDistanceM = 0
        trackState.lastSlip = 0
        trackState.lastSlipWearPointsPerSecond = 0
        trackState.lastGroundClass = "RESET"
        trackState.lastDistanceFactor = 1
        trackState.lastSlipFactor = 1
        trackState.lastLoadFactor = 1
        trackState.lastCrawlerMovedDistance = nil
        trackState.initialized = false
    end

    if ReifenVerschleissVisual ~= nil and ReifenVerschleissVisual.resetVehicleWearVisuals ~= nil then
        local ok, err = pcall(ReifenVerschleissVisual.resetVehicleWearVisuals, vehicle)
        if not ok then
            print(string.format("[ReifenVerschleiss][RESET] visual reset failed: %s", tostring(err)))
        end
    end

    print(string.format(
        "[ReifenVerschleiss][RESET] vehicle=%s reason=%s | OWN-WEAR reset to 0",
        tostring(vehicle.configFileName or vehicle.typeName or "UNKNOWN"),
        tostring(reason or "manual")
    ))
    return true
end

function ReifenVerschleissDiagnostic:onVehicleRepaired(vehicle)
    if vehicle ~= nil then
        self:resetVehicleWear(vehicle, "WORKSHOP-REPAIR")
    end
end

function ReifenVerschleissDiagnostic:onVehicleRepainted(vehicle)
    if vehicle ~= nil then
        self:resetVehicleWear(vehicle, "WORKSHOP-REPAINT")
    end
end

function ReifenVerschleissDiagnostic.resetVehicleCustomWearState(vehicle, reason)
    if vehicle == nil or not isRelevantPlayerVehicle(vehicle) then
        return false
    end

    local state = getVehicleWearState(vehicle)
    if state == nil then
        return false
    end

    -- Client-side mirror of the authoritative workshop reset.  The custom
    -- per-wheel wear is not a GIANTS network field, so the receiving client
    -- must clear its local wheel states as well.  Do NOT touch native GIANTS
    -- Wear here; the server event already owns that operation.
    state.workshopReplacementReset = true
    state.totalDistanceWear = 0
    state.totalSlipWear = 0
    state.totalTimeWear = 0
    state.totalWear = 0
    state.totalEffectiveWearDistanceM = 0
    state.debugDistanceM = 0
    state.debugTimeMs = 0
    state.debugStep = 0
    state.ready = false
    state.readySince = 0
    state.timeWearMoveConfirmSec = 0
    state.timeWearWindowSec = 0
    state.timeWearWindowDistanceM = 0
    state.timeWearRatePointsPerHourAt1000 = RV.TIME_WEAR_LOW_POINTS_PER_H_AT_1000
    state.timeWearWindowAvgSpeedKmh = 0
    state.timeWearHarvestBoostActive = false
    state.lastReadyLog = false
    state.slipDisplayReady = false
    state.slipDisplayLast = {}
    state.slipDisplayRotation = {}
    state.slipDisplayBlocked = true
    state.debugLastDistanceWear = {}
    state.debugLastSlipWear = {}
    state.debugLastTotalWear = {}
    state.debugLastLoggedDistanceWear = {}
    state.debugLastLoggedSlipWear = {}

    for _, wheelState in pairs(state.wheelWear or {}) do
        wheelState.value = 0
        wheelState.distanceWear = 0
        wheelState.slipWear = 0
        wheelState.timeWear = 0
        wheelState.effectiveDistanceM = 0
        wheelState.slipDistanceM = 0
        wheelState.lastSlip = 0
        wheelState.lastSlipWearPointsPerSecond = 0
        wheelState.lastGroundClass = "RESET"
        wheelState.lastDistanceFactor = 1
        wheelState.lastSlipFactor = 1
        wheelState.lastLoadFactor = 1
        wheelState.lastDistanceInputM = 0
        wheelState.lastDtSec = 0
        wheelState.lastSpeedKmh = 0
        wheelState.lastLoadInput = 0
        wheelState.lastRestLoadInput = 0
        wheelState.lastSlipInput = 0
        wheelState.debugExpectedDistanceWear = 0
        wheelState.debugExpectedSlipWear = 0
        wheelState.debugInputDistanceM = 0
        wheelState.debugDtSec = 0
        wheelState.initialized = false
    end

    for _, trackState in pairs(state.trackWear or {}) do
        trackState.value=0; trackState.forceZeroWear=true
        trackState.distanceWear=0; trackState.slipWear=0; trackState.timeWear=0; trackState.effectiveDistanceM=0; trackState.slipDistanceM=0
        trackState.lastSlip=0; trackState.lastSlipWearPointsPerSecond=0
        trackState.lastCrawlerMovedDistance=nil; trackState.initialized=false
        trackState.rollerWear=0; trackState.rollerDistanceM=0
    end

    print(string.format(
        "[ReifenVerschleiss][RESET-CLIENT-STATE] vehicle=%s reason=%s own wheel states cleared=0",
        tostring(vehicle.configFileName or vehicle.typeName or "UNKNOWN"),
        tostring(reason or "manual")
    ))
    return true
end

-- Public read-only bridge for the visual layer. It returns the track's own
-- tire-wear value, never the internal crawler-wheel states.
function ReifenVerschleissDiagnostic.getCrawlerWearValue(vehicle, crawler)
    if vehicle == nil or crawler == nil then
        return 0
    end

    -- IMPORTANT: This bridge is for the TRACK VISUAL only.
    -- The shader expects only the own track wear (0=new -> 1=fully worn).
    -- Use only mod-owned DIST-WEAR + SLIP-WEAR + TIME-WEAR.
    local wm = getOrBuildTireWearManifest(vehicle)
    local state = getVehicleWearState(vehicle)

    for _, track in ipairs(wm.tracks or {}) do
        if track.crawler == crawler then
            local st = getTrackWearState(state, track)
            if st ~= nil then
                local ownWear = safeNumber(st.distanceWear, 0) + safeNumber(st.slipWear, 0) + safeNumber(st.timeWear, 0)
                return math.clamp(ownWear, 0, RV.WEAR_MAX)
            end
        end
    end

    return 0
end

function ReifenVerschleissDiagnostic.hasOwnWearObjects(vehicle)
    if vehicle == nil then return false end
    local wearManifest = getOrBuildTireWearManifest(vehicle)
    if wearManifest == nil then return false end
    -- Use the dedicated tire-wear manifest. The chassis manifest uses
    -- totalWheelCount/crawlerCount; the tire-wear manifest uses wheelCount/trackCount.
    return (safeNumber(wearManifest.wheelCount, 0) + safeNumber(wearManifest.trackCount, 0)) > 0
end

function ReifenVerschleissDiagnostic.getVehicleWearPercent(vehicle)
    local wear01 = ReifenVerschleissDiagnostic.getOwnWear01ForHUD(vehicle)
    return wear01 ~= nil and wear01 * 100 or 0
end

function ReifenVerschleissDiagnostic.getWheelWearValue(vehicle, wheel)
    if vehicle == nil or wheel == nil then
        return nil
    end

    local vehicleState = getVehicleWearState(vehicle)
    local state = getWheelWearState(vehicleState, wheel)
    if state == nil then
        return nil
    end

    return math.clamp(safeNumber(state.value, 0), 0, RV.WEAR_MAX)
end

-- ============================================================================
-- TEST0.2.0.69: explicit drive-state gates for wear generation.
--
-- DIST-WEAR is allowed only when the vehicle really travels AND the wheel/
-- crawler reference wheel is physically rotating.
-- SLIP-WEAR is independent from vehicle travel: it may occur at 0 km/h when
-- the driver applies throttle, the wheel/crawler reference wheel rotates and
-- the wheel has real ground contact. This covers a vehicle pushing against an
-- obstacle without allowing stationary engine/physics noise to create wear.
-- ============================================================================
local RV_WEAR_MOVEMENT_EPSILON_M = 0.0005
local RV_WEAR_SPEED_EPSILON_KMH = 0.05
local RV_WEAR_DRIVE_INPUT_EPSILON = 0.02

local function getDriveInput(vehicle)
    if vehicle == nil then
        return 0
    end

    local spec = vehicle.spec_drivable
    if spec ~= nil and spec.lastInputValues ~= nil then
        local input = safeNumber(spec.lastInputValues.axisAccelerate, nil)
        if input ~= nil and math.abs(input) > 0.001 then
            return input
        end
    end

    -- Some FS25 drive states do not keep axisAccelerate populated every frame.
    -- In that case use the current forward/reverse drive axis as the throttle
    -- intent fallback. This is still a drive command, not wheel speed.
    if spec ~= nil then
        local axisForward = safeNumber(spec.axisForward, nil)
        if axisForward ~= nil and math.abs(axisForward) > 0.001 then
            return axisForward
        end
    end

    return 0
end

local function getWheelRotationState(wheel)
    return isWheelPhysicallyRotating(wheel)
end

local function getTrackRotationState(track)
    if track == nil then
        return false
    end

    for _, wheel in ipairs(track.referenceWheels or {}) do
        if getWheelRotationState(wheel) then
            return true
        end
    end

    return false
end

local function getWearDriveGates(vehicle, distanceM, speedKmh, rotating)
    local driveInput = getDriveInput(vehicle)
    local hasMovement = math.max(0, safeNumber(distanceM, 0)) > RV_WEAR_MOVEMENT_EPSILON_M
        and math.abs(safeNumber(speedKmh, 0)) > RV_WEAR_SPEED_EPSILON_KMH
    local hasRotation = rotating == true

    return {
        driveInput = driveInput,
        hasMovement = hasMovement,
        hasRotation = hasRotation,
        -- Distance wear still requires actual vehicle movement and a valid
        -- wheel-rotation signal. This remains the anti-startup/standstill gate.
        allowDistanceWear = hasMovement and hasRotation,
        -- Slip is different: after READY, a grounded wheel may slip whenever
        -- the vehicle is actually moving. Do NOT require throttle or wheel
        -- rotation here. This allows braking, steering/trailing inertia and
        -- wheel lock to become valid slip situations.
        allowSlipWear = hasMovement
    }
end

local function updateWheelWear(wheel, vehicle, vehicleState, distanceM, speedKmh, dtSec, driveGates, passiveImplement, timeContext)
    if wheel == nil or dtSec <= 0 or vehicleState == nil then
        return nil
    end

    local state = getWheelWearState(vehicleState, wheel)
    if state == nil then
        return nil
    end

    local d = wheelDiagnostic(wheel, vehicle)
    if d.hasGroundContact ~= true then
        state.lastSlip = safeNumber(d.slip, 0)
        state.lastSlipWearPointsPerSecond = 0
        return state
    end

    local loadFactor = getLoadFactor(d)
    local distanceGroundFactor, distanceClass, runningGearType, distanceWeatherClass = getDistanceGroundFactor(d)
    local slipGroundFactor, slipClass, _, slipWeatherClass = getSlipGroundFactor(d)
    local rotating = getWheelRotationState(wheel)
    -- wheelDiagnostic() already uses the GIANTS wheel-shape axle-speed API.
    -- Prefer that same confirmed physical rotation result when available.
    if d.wheelRotation == true then
        rotating = true
    end
    driveGates = driveGates or getWearDriveGates(vehicle, distanceM, speedKmh, rotating)
    if passiveImplement == true then
        -- PASSIVE TRAILER/IMPLEMENT PATH:
        -- UYT's documented wear model is based on traveled ground distance, not
        -- on whether a passive wheel reports a driven-wheel axle rotation.
        -- GIANTS can expose valid trailer wheels while getWheelShapeAxleSpeed()
        -- remains zero/non-useful for them. That made our additional rotation
        -- gate suppress all DIST-WEAR on passive wheels.
        --
        -- Passive wheels are never allowed to create SLIP-WEAR, but distance
        -- wear is allowed when the attached combination actually moves.
        driveGates.allowDistanceWear = math.max(0, safeNumber(distanceM, 0)) > RV_WEAR_MOVEMENT_EPSILON_M
            and math.abs(safeNumber(speedKmh, 0)) > RV_WEAR_SPEED_EPSILON_KMH
        driveGates.allowSlipWear = false
        driveGates.driveInput = 0
    end

    -- Distance channel: real vehicle movement AND physical wheel rotation are
    -- both required. This blocks tiny lastSpeedReal/physics residuals while
    -- the vehicle is standing still. Slip uses a separate movement/contact gate.
    local baseDistanceWear = driveGates.allowDistanceWear
        and (math.max(0, distanceM) / RV.WEAR_REFERENCE_DISTANCE_M)
        or 0
    local wearReferenceRateFactor = rvGetWearReferenceRateFactor()
    local distanceIncrement = baseDistanceWear * loadFactor * distanceGroundFactor * wearReferenceRateFactor

    -- Slip channel: convert the actual wheel slip into a physically meaningful
    -- slip-distance contribution. A stationary wheel with slip=100% is not
    -- treated as an arbitrary 100 km/h event; its slip wear is limited by the
    -- actual ground-relative movement. For normal rolling slip this becomes
    -- proportional to travelled distance.
    local slip = clampFinite(d.slip, 0, RV.WEAR_SLIP_MAX_PERCENT, 0) / 100
    local slipDistanceM = math.max(0, distanceM) * slip
    local slipIntensity = getSlipIntensity(d.slip)
    local slipIncrement = 0

    if slipIntensity > 0 and driveGates.allowSlipWear then
        slipIncrement = (slipDistanceM / RV.WEAR_REFERENCE_DISTANCE_M)
            * loadFactor
            * slipGroundFactor
            * slipIntensity
            * wearReferenceRateFactor

        -- A driven wheel can generate slip wear even at 0 km/h (for example
        -- against an obstacle). The stationary time term is therefore kept,
        -- but is now protected by the explicit throttle + rotation gate.
        if distanceM <= RV_WEAR_MOVEMENT_EPSILON_M and speedKmh <= RV_WEAR_SPEED_EPSILON_KMH then
            local stationaryIntensity = math.min(slipIntensity, 0.75)
            slipIncrement = (stationaryIntensity * dtSec) / 3600
                * loadFactor
                * slipGroundFactor
                * wearReferenceRateFactor
        end
    end

    local timeIncrement = 0
    if timeContext ~= nil and timeContext.active == true and distanceClass ~= "ROAD" then
        timeIncrement = rvTimeWearNormalizedPerHour(timeContext.ratePointsPerHourAt1000) * (dtSec / 3600)
    end

    state.distanceWear = math.clamp(state.distanceWear + distanceIncrement, 0, RV.WEAR_MAX)
    state.slipWear = math.clamp(state.slipWear + slipIncrement, 0, RV.WEAR_MAX)
    state.timeWear = math.clamp(safeNumber(state.timeWear, 0) + timeIncrement, 0, RV.WEAR_MAX)
    state.effectiveDistanceM = state.effectiveDistanceM
        + distanceIncrement * RV.WEAR_REFERENCE_DISTANCE_M
    state.slipDistanceM = state.slipDistanceM + slipDistanceM
    state.value = math.clamp(state.distanceWear + state.slipWear + safeNumber(state.timeWear, 0), 0, RV.WEAR_MAX)
    state.lastSlip = safeNumber(d.slip, 0)
    state.lastSlipWearPointsPerSecond = slipIncrement / dtSec * 1000
    state.lastTimeWearPointsPerHour = timeContext ~= nil and safeNumber(timeContext.ratePointsPerHourAt1000, 0) or 0
    state.lastGroundClass = distanceClass or slipClass or "UNKNOWN"
    state.lastWearRunningGearType = runningGearType or "UNKNOWN"
    state.lastWeatherClass = distanceWeatherClass or slipWeatherClass or "DRY"
    state.lastDistanceFactor = distanceGroundFactor
    state.lastSlipFactor = slipGroundFactor
    state.lastLoadFactor = loadFactor
    state.lastDistanceInputM = math.max(0, distanceM)
    state.lastDtSec = dtSec
    state.lastSpeedKmh = speedKmh
    state.lastLoadInput = safeNumber(d.load, 0)
    state.lastRestLoadInput = safeNumber(d.restLoad, 0)
    state.lastSlipInput = safeNumber(d.slip, 0)
    state.lastDriveInput = safeNumber(driveGates.driveInput, 0)
    state.lastWheelRotation = rotating == true
    state.allowDistanceWear = driveGates.allowDistanceWear == true
    state.allowSlipWear = driveGates.allowSlipWear == true
    state.debugExpectedDistanceWear = safeNumber(state.debugExpectedDistanceWear, 0) + distanceIncrement
    state.debugExpectedSlipWear = safeNumber(state.debugExpectedSlipWear, 0) + slipIncrement
    state.debugInputDistanceM = safeNumber(state.debugInputDistanceM, 0) + math.max(0, distanceM)
    state.debugDtSec = safeNumber(state.debugDtSec, 0) + dtSec
    state.initialized = true

    return state
end

local getAverageWear
local getAverageEffectiveWearDistance

-- TEST2.3.97: crawler roller wear. The existing crawler/running-gear
-- recognition remains authoritative. This second stage only classifies the
-- rotating parts INSIDE an already recognised crawler. GIANTS exposes these
-- parts as crawler.rotatingParts with node/radius/speedScale. The largest
-- rotating part is treated as drive/idler sprocket and excluded; smaller
-- rotating parts are the rubber-coated road rollers. If the structure is
-- ambiguous (fewer than two radii or no clear size difference), roller wear
-- stays data-only and no visual node is guessed.
RV.ROLLER_LIFETIME_FACTOR_MIN = 1.70
RV.ROLLER_LIFETIME_FACTOR_MAX = 2.50

local function rvEnsureRollerState(state)
    if state == nil then return nil end
    if safeNumber(state.rollerLifetimeFactor, 0) <= 0 then
        local r = math.random()
        state.rollerLifetimeFactor = RV.ROLLER_LIFETIME_FACTOR_MIN + r * (RV.ROLLER_LIFETIME_FACTOR_MAX - RV.ROLLER_LIFETIME_FACTOR_MIN)
    end
    state.rollerWear = clampFinite(state.rollerWear, 0, RV.WEAR_MAX, 0)
    state.rollerDistanceM = math.max(0, safeNumber(state.rollerDistanceM, 0))
    return state
end

local function rvClassifyCrawlerRollers(track)
    if track == nil or track.crawler == nil then return nil end
    if track.rollerClassification ~= nil then return track.rollerClassification end
    local parts = track.crawler.rotatingParts
    local result = {rollers={}, excluded={}, confident=false, reason="NO_ROTATING_PARTS"}
    if type(parts) ~= "table" or #parts < 2 then
        if track.leitwolfRollerFallback == true
            and type(track.referenceWheels) == "table"
            and #track.referenceWheels > 0 then
            result.reason = "SPECIAL_LEITWOLF_REFERENCE_WHEELS"
            for index, wheel in ipairs(track.referenceWheels) do
                table.insert(result.rollers, {
                    index = index,
                    node = wheel ~= nil and (wheel.node or wheel.driveNode or wheel.repr) or nil,
                    radius = safeNumber(wheel ~= nil and wheel.radius or nil, 0),
                    referenceWheel = wheel
                })
            end
            result.confident = #result.rollers > 0
            track.rollerClassification = result
            if result.confident and track.rollerClassificationLogged ~= true then
                track.rollerClassificationLogged = true
                print(string.format(
                    "[ReifenVerschleiss][ROLLER-DETECT] track=%s side=%s rollers=%d excluded=0 method=%s",
                    tostring(track.key or track.index or "?"), tostring(track.side or "?"),
                    #result.rollers, result.reason))
            end
            return result
        end
        track.rollerClassification = result
        return result
    end
    local maxRadius, minRadius = 0, math.huge
    for _, part in ipairs(parts) do
        local radius = safeNumber(part ~= nil and part.radius or nil, 0)
        if radius > 0 then maxRadius=math.max(maxRadius,radius); minRadius=math.min(minRadius,radius) end
    end
    if maxRadius <= 0 or minRadius == math.huge or maxRadius < minRadius * 1.20 then
        result.reason="AMBIGUOUS_RADII"
        track.rollerClassification=result
        return result
    end
    -- Exclude every part in the largest-radius sprocket/idler class. This is
    -- safer than assuming a fixed XML index and works for left/right variants.
    local sprocketThreshold = maxRadius * 0.90
    for index, part in ipairs(parts) do
        local radius=safeNumber(part ~= nil and part.radius or nil,0)
        local entry={index=index,node=part ~= nil and part.node or nil,radius=radius}
        if radius > 0 and radius < sprocketThreshold then
            table.insert(result.rollers,entry)
        else
            table.insert(result.excluded,entry)
        end
    end
    result.confident=#result.rollers>0 and #result.excluded>0
    result.reason=result.confident and "RADIUS_GROUP" or "NO_SAFE_GROUP"
    track.rollerClassification=result
    if result.confident and track.rollerClassificationLogged ~= true then
        track.rollerClassificationLogged=true
        print(string.format("[ReifenVerschleiss][ROLLER-DETECT] track=%s side=%s rollers=%d excluded=%d maxRadius=%.3f method=%s",
            tostring(track.key or track.index or "?"), tostring(track.side or "?"), #result.rollers, #result.excluded, maxRadius, result.reason))
    end
    return result
end

local function rvUpdateRollerWear(track, state, trackDistanceM, driveGates)
    state=rvEnsureRollerState(state)
    if state == nil then return end
    local classification=rvClassifyCrawlerRollers(track)
    state.rollerDetected = classification ~= nil and classification.confident == true
    state.rollerCount = classification ~= nil and #classification.rollers or 0
    -- Pure mileage only: no ground, slip, load, wetness, rain, snow or speed
    -- factor. The global lifetime reference still scales kilometres exactly as
    -- it does for the rest of the selected wear lifetime setting.
    if driveGates ~= nil and driveGates.allowDistanceWear == true and trackDistanceM > 0 then
        local factor=math.max(RV.ROLLER_LIFETIME_FACTOR_MIN, safeNumber(state.rollerLifetimeFactor,RV.ROLLER_LIFETIME_FACTOR_MIN))
        local inc=(trackDistanceM / RV.WEAR_REFERENCE_DISTANCE_M) * rvGetWearReferenceRateFactor() / factor
        state.rollerWear=math.clamp(state.rollerWear+inc,0,RV.WEAR_MAX)
        state.rollerDistanceM=state.rollerDistanceM+trackDistanceM
    end
end

local function updateTrackWear(track, vehicle, vehicleState, distanceM, speedKmh, dtSec, driveGates, passiveImplement, timeContext)
    if track == nil or vehicleState == nil or dtSec <= 0 then return nil end
    local state = getTrackWearState(vehicleState, track)
    if state == nil then return nil end

    local sumLoad, sumRest, sumSlip, count = 0, 0, 0, 0
    for _, wheel in ipairs(track.referenceWheels or {}) do
        local d = wheelDiagnostic(wheel, vehicle)
        if d ~= nil and d.hasGroundContact == true then
            sumLoad = sumLoad + safeNumber(d.load,0)
            sumRest = sumRest + safeNumber(d.restLoad,0)
            sumSlip = sumSlip + safeNumber(d.slip,0)
            count = count + 1
        end
    end
    if count == 0 then
        state.lastSlip = 0; state.lastSlipWearPointsPerSecond = 0
        return state
    end

    local d = {
        load = sumLoad/count, restLoad = sumRest/count, slip = sumSlip/count,
        groundType = nil, isField = false, isMudTerrain = false, wetScale = 0, rainScale = 0,
        snowScale = 0, terrainSnow = false
    }
    -- Ground/weather class is taken from the first valid reference wheel. The
    -- crawler members are on the same track and therefore share the contact
    -- environment; this avoids inventing a new terrain API for tracks.
    for _, wheel in ipairs(track.referenceWheels or {}) do
        local wd = wheelDiagnostic(wheel, vehicle)
        if wd ~= nil and wd.hasGroundContact == true then
            for k,v in pairs(wd) do d[k] = v end
            d.load = sumLoad/count; d.restLoad = sumRest/count; d.slip = sumSlip/count
            -- The track itself is the wear object. Its own crawler type must
            -- override the reference wheel's generic crawler tire type.
            d.wearRunningGearType = track.wearRunningGearType or "RUBBER_TRACK"
            break
        end
    end

    local loadFactor = getLoadFactor(d)
    local distanceGroundFactor, distanceClass, runningGearType, distanceWeatherClass = getDistanceGroundFactor(d)
    local slipGroundFactor, slipClass, _, slipWeatherClass = getSlipGroundFactor(d)
    local rotating = getTrackRotationState(track)
    driveGates = driveGates or getWearDriveGates(vehicle, distanceM, speedKmh, rotating)
    if passiveImplement == true then
        driveGates.allowSlipWear = false
        driveGates.driveInput = 0
    end
    -- Prefer the GIANTS crawler movedDistance only when it actually advances.
    -- Some crawler implementations expose the field but leave it at zero; in
    -- that case a permanent zero delta would disable track wear. Fall back to
    -- the same vehicle travel distance used by the proven wheel path.
    local trackDistanceM = math.max(0, safeNumber(distanceM,0))
    local moved = track.crawler ~= nil and tonumber(track.crawler.movedDistance) or nil
    if moved ~= nil then
        if state.lastCrawlerMovedDistance ~= nil then
            local delta = moved - state.lastCrawlerMovedDistance
            if delta > 0.001 then
                trackDistanceM = delta
            end
        end
        state.lastCrawlerMovedDistance = moved
    end

    local wearReferenceRateFactor = rvGetWearReferenceRateFactor()
    local distanceIncrement = driveGates.allowDistanceWear
        and ((trackDistanceM / RV.WEAR_REFERENCE_DISTANCE_M) * loadFactor * distanceGroundFactor * wearReferenceRateFactor)
        or 0
    local slip = clampFinite(d.slip,0,RV.WEAR_SLIP_MAX_PERCENT,0)/100
    local slipDistanceM = trackDistanceM * slip
    local intensity = getSlipIntensity(d.slip)
    local slipIncrement = 0
    if intensity > 0 and driveGates.allowSlipWear then
        slipIncrement = (slipDistanceM / RV.WEAR_REFERENCE_DISTANCE_M) * loadFactor * slipGroundFactor * intensity * wearReferenceRateFactor
        if trackDistanceM <= RV_WEAR_MOVEMENT_EPSILON_M and speedKmh <= RV_WEAR_SPEED_EPSILON_KMH then
            slipIncrement = (math.min(intensity,0.75)*dtSec)/3600 * loadFactor * slipGroundFactor * wearReferenceRateFactor
        end
    end

    local timeIncrement = 0
    if timeContext ~= nil and timeContext.active == true and distanceClass ~= "ROAD" then
        timeIncrement = rvTimeWearNormalizedPerHour(timeContext.ratePointsPerHourAt1000) * (dtSec / 3600)
    end
    state.distanceWear = math.clamp(state.distanceWear+distanceIncrement,0,RV.WEAR_MAX)
    state.slipWear = math.clamp(state.slipWear+slipIncrement,0,RV.WEAR_MAX)
    state.timeWear = math.clamp(safeNumber(state.timeWear,0)+timeIncrement,0,RV.WEAR_MAX)
    state.effectiveDistanceM = state.effectiveDistanceM + distanceIncrement*RV.WEAR_REFERENCE_DISTANCE_M
    state.slipDistanceM = state.slipDistanceM + slipDistanceM
    state.value = math.clamp(state.distanceWear+state.slipWear+safeNumber(state.timeWear,0),0,RV.WEAR_MAX)
    state.lastSlip = safeNumber(d.slip,0); state.lastSlipWearPointsPerSecond = slipIncrement/dtSec*1000; state.lastTimeWearPointsPerHour = timeContext ~= nil and safeNumber(timeContext.ratePointsPerHourAt1000,0) or 0
    state.lastGroundClass = distanceClass or slipClass or "UNKNOWN"; state.lastWearRunningGearType = runningGearType or "UNKNOWN"; state.lastWeatherClass = distanceWeatherClass or slipWeatherClass or "DRY"; state.lastDistanceFactor = distanceGroundFactor
    state.lastSlipFactor = slipGroundFactor; state.lastLoadFactor = loadFactor; state.lastDistanceInputM = trackDistanceM
    state.lastDriveInput = safeNumber(driveGates.driveInput, 0)
    state.lastWheelRotation = rotating == true
    state.allowDistanceWear = driveGates.allowDistanceWear == true
    state.allowSlipWear = driveGates.allowSlipWear == true
    state.lastDtSec = dtSec; state.lastSpeedKmh = speedKmh; state.lastLoadInput = safeNumber(d.load,0); state.lastRestLoadInput = safeNumber(d.restLoad,0); state.lastSlipInput = safeNumber(d.slip,0)
    state.debugExpectedDistanceWear = safeNumber(state.debugExpectedDistanceWear,0)+distanceIncrement
    state.debugExpectedSlipWear = safeNumber(state.debugExpectedSlipWear,0)+slipIncrement
    state.debugInputDistanceM = safeNumber(state.debugInputDistanceM,0)+trackDistanceM
    state.debugDtSec = safeNumber(state.debugDtSec,0)+dtSec; state.initialized = true
    rvUpdateRollerWear(track, state, trackDistanceM, driveGates)
    return state
end

local function getWearManifest(manifest)
    return manifest ~= nil and manifest.tireWearManifest or {wheels={}, tracks={}, wheelCount=0, trackCount=0, totalWearObjectCount=0}
end

local function updateWear(vehicle, manifest, distanceM, speedKmh, dtSec, vehicleState, passiveImplement)
    if dtSec <= 0 or manifest == nil or vehicleState == nil then
        return
    end

    local ready = true
    if passiveImplement ~= true then
        ready = updateVehicleWearReady(vehicle, vehicleState, dtSec)
        if not ready then
            return
        end
    end

    local timeContext = rvUpdateTimeWearContext(vehicle, vehicleState, distanceM, speedKmh, dtSec, passiveImplement, manifest)
    local wheelCount = 0
    local totalDistanceIncrement = 0
    local totalSlipIncrement = 0
    local totalTimeIncrement = 0

    local function processWheel(wheel)
        local before = getWheelWearState(vehicleState, wheel)
        local oldDistance = before ~= nil and before.distanceWear or 0
        local oldSlip = before ~= nil and before.slipWear or 0
        local oldTime = before ~= nil and safeNumber(before.timeWear, 0) or 0
        local state = updateWheelWear(wheel, vehicle, vehicleState, distanceM, speedKmh, dtSec, nil, passiveImplement, timeContext)
        if state ~= nil then
            wheelCount = wheelCount + 1
            totalDistanceIncrement = totalDistanceIncrement + math.max(0, state.distanceWear - oldDistance)
            totalSlipIncrement = totalSlipIncrement + math.max(0, state.slipWear - oldSlip)
            totalTimeIncrement = totalTimeIncrement + math.max(0, safeNumber(state.timeWear,0) - oldTime)
        end
    end

    local wearManifest = getWearManifest(manifest)
    for _, wheel in ipairs(wearManifest.wheels or {}) do processWheel(wheel) end
    for _, track in ipairs(wearManifest.tracks or {}) do
        local before = getTrackWearState(vehicleState, track)
        local oldDistance = before ~= nil and before.distanceWear or 0
        local oldSlip = before ~= nil and before.slipWear or 0
        local oldTime = before ~= nil and safeNumber(before.timeWear,0) or 0
        local st = updateTrackWear(track, vehicle, vehicleState, distanceM, speedKmh, dtSec, nil, passiveImplement, timeContext)
        if st ~= nil then
            wheelCount = wheelCount + 1
            totalDistanceIncrement = totalDistanceIncrement + math.max(0, st.distanceWear-oldDistance)
            totalSlipIncrement = totalSlipIncrement + math.max(0, st.slipWear-oldSlip)
            totalTimeIncrement = totalTimeIncrement + math.max(0, safeNumber(st.timeWear,0)-oldTime)
        end
    end

    vehicleState.totalDistanceWear = math.max(0, safeNumber(vehicleState.totalDistanceWear, 0) + totalDistanceIncrement)
    vehicleState.totalSlipWear = math.max(0, safeNumber(vehicleState.totalSlipWear, 0) + totalSlipIncrement)
    vehicleState.totalTimeWear = math.max(0, safeNumber(vehicleState.totalTimeWear, 0) + totalTimeIncrement)
    vehicleState.totalWear = getAverageWear(manifest, vehicleState)
    vehicleState.totalEffectiveWearDistanceM = getAverageEffectiveWearDistance(manifest, vehicleState)
    vehicleState.lastWheelCount = wheelCount
end

local function getAverageWearComponents(manifest, vehicleState)
    local distanceSum, slipSum, timeSum, count = 0, 0, 0, 0
    if manifest == nil or vehicleState == nil then return 0,0,0,0 end
    local function addWheel(wheel)
        local st = getWheelWearState(vehicleState,wheel)
        if st ~= nil then distanceSum=distanceSum+safeNumber(st.distanceWear,0); slipSum=slipSum+safeNumber(st.slipWear,0); timeSum=timeSum+safeNumber(st.timeWear,0); count=count+1 end
    end
    local wm=getWearManifest(manifest)
    for _,wheel in ipairs(wm.wheels or {}) do addWheel(wheel) end
    for _,track in ipairs(wm.tracks or {}) do
        local st=getTrackWearState(vehicleState,track)
        if st ~= nil then distanceSum=distanceSum+safeNumber(st.distanceWear,0); slipSum=slipSum+safeNumber(st.slipWear,0); timeSum=timeSum+safeNumber(st.timeWear,0); count=count+1 end
    end
    return count>0 and distanceSum/count or 0, count>0 and slipSum/count or 0, count>0 and timeSum/count or 0, count
end

getAverageEffectiveWearDistance = function(manifest, vehicleState)
    local sum,count=0,0
    if manifest==nil or vehicleState==nil then return 0 end
    local wm=getWearManifest(manifest)
    for _,wheel in ipairs(wm.wheels or {}) do local st=getWheelWearState(vehicleState,wheel); if st~=nil then sum=sum+safeNumber(st.effectiveDistanceM,0); count=count+1 end end
    for _,track in ipairs(wm.tracks or {}) do local st=getTrackWearState(vehicleState,track); if st~=nil then sum=sum+safeNumber(st.effectiveDistanceM,0); count=count+1 end end
    return count>0 and sum/count or 0
end

getAverageWear = function(manifest, vehicleState)
    local sum,count=0,0
    if manifest==nil or vehicleState==nil then return 0 end
    local function add(st)
        if st~=nil then sum=sum+math.clamp(safeNumber(st.distanceWear,0)+safeNumber(st.slipWear,0)+safeNumber(st.timeWear,0),0,RV.WEAR_MAX); count=count+1 end
    end
    local wm=getWearManifest(manifest)
    for _,wheel in ipairs(wm.wheels or {}) do add(getWheelWearState(vehicleState,wheel)) end
    for _,track in ipairs(wm.tracks or {}) do add(getTrackWearState(vehicleState,track)) end
    return count>0 and sum/count or 0
end

local function getAverageOwnWear(manifest, vehicleState)
    local sum,count=0,0
    if manifest==nil or vehicleState==nil then return 0 end
    local wm=getWearManifest(manifest)
    for _,wheel in ipairs(wm.wheels or {}) do local st=getWheelWearState(vehicleState,wheel); if st~=nil then sum=sum+math.clamp(safeNumber(st.distanceWear,0)+safeNumber(st.slipWear,0)+safeNumber(st.timeWear,0),0,RV.WEAR_MAX); count=count+1 end end
    for _,track in ipairs(wm.tracks or {}) do local st=getTrackWearState(vehicleState,track); if st~=nil then sum=sum+math.clamp(safeNumber(st.distanceWear,0)+safeNumber(st.slipWear,0)+safeNumber(st.timeWear,0),0,RV.WEAR_MAX); count=count+1 end end
    return count>0 and sum/count or 0
end

-- TEST2.3.128:
-- IMPORTANT LUA SCOPE FIX.
-- This workshop block must live AFTER all local helper definitions it calls.
-- In .127 it was placed too early, so rvClassifyCrawlerRollers,
-- rvEnsureRollerState and getAverageOwnWear resolved as nil at runtime.
local function rvWorkshopResetRollers(vehicle,state)
    local wm=getOrBuildTireWearManifest(vehicle)
    if wm==nil then return 0 end
    local n=0
    for _,track in ipairs(wm.tracks or {}) do
        local st=getTrackWearState(state,track)
        local c=rvClassifyCrawlerRollers(track)
        if st~=nil then
            rvEnsureRollerState(st)
            local detected = c~=nil and c.confident==true and #(c.rollers or {})>0
            if detected or safeNumber(st.rollerCount,0)>0 or st.rollerDetected==true then
                local before=safeNumber(st.rollerWear,0)
                st.rollerWear=0
                st.rollerDistanceM=0
                st.rollerDetected=detected or st.rollerDetected==true
                st.rollerCount=detected and #(c.rollers or {}) or math.max(0,math.floor(safeNumber(st.rollerCount,0)))
                n=n+math.max(1,st.rollerCount)
                print(string.format(
                    "[ReifenVerschleiss][WORKSHOP129][ROLLER-RESET] track=%s before=%.3f after=%.3f rollers=%d detected=%s",
                    tostring(track.key or track.index or "?"),
                    before,safeNumber(st.rollerWear,0),st.rollerCount,tostring(detected)))
            end
        end
    end
    return n
end

local function rvWorkshopResetWheels(vehicle,state)
    local wm=getOrBuildTireWearManifest(vehicle)
    if wm==nil then return 0 end
    local n=0
    for _,wheel in ipairs(wm.wheels or {}) do
        local st=getWheelWearState(state,wheel)
        if st~=nil then
            local before=safeNumber(st.distanceWear,0)+safeNumber(st.slipWear,0)+safeNumber(st.timeWear,0)
            st.value=0
            st.distanceWear=0
            st.slipWear=0
            st.timeWear=0
            st.effectiveDistanceM=0
            st.slipDistanceM=0
            st.lastSlip=0
            st.lastSlipWearPointsPerSecond=0
            st.lastGroundClass="WORKSHOP-WHEEL-RESET"
            st.lastDistanceFactor=1
            st.lastSlipFactor=1
            st.lastLoadFactor=1
            st.lastDistanceInputM=0
            st.lastDtSec=0
            st.lastSpeedKmh=0
            st.lastLoadInput=0
            st.lastRestLoadInput=0
            st.lastSlipInput=0
            st.debugExpectedDistanceWear=0
            st.debugExpectedSlipWear=0
            st.debugInputDistanceM=0
            st.debugDtSec=0
            st.initialized=false
            n=n+1
            print(string.format(
                "[ReifenVerschleiss][WORKSHOP129][WHEEL-RESET] wheel=%s before=%.3f after=0",
                tostring(wheel.key or wheel.index or wheel.wheelIndex or "?"),before))
        end
    end
    return n
end

local function rvWorkshopResetTracks(vehicle,state)
    local wm=getOrBuildTireWearManifest(vehicle); if wm==nil then return 0 end
    local n=0
    for _,track in ipairs(wm.tracks or {}) do
        local st=getTrackWearState(state,track)
        if st~=nil then
            st.value=0; st.distanceWear=0; st.slipWear=0; st.timeWear=0
            st.effectiveDistanceM=0; st.slipDistanceM=0
            st.lastSlip=0; st.lastSlipWearPointsPerSecond=0
            st.lastCrawlerMovedDistance=nil; st.initialized=false; n=n+1
        end
    end
    return n
end

function ReifenVerschleissDiagnostic.resetRunningGearWorkshop(vehicle,mode,reason)
    if vehicle==nil or not isRelevantPlayerVehicle(vehicle) then return false end
    local state=getVehicleWearState(vehicle); if state==nil then return false end
    mode=tostring(mode or "ALL")
    if mode=="ALL" then
        local ok=resetVehicleWearState(vehicle,reason or "RP-WORKSHOP-ALL")
        if ok~=true then return false end
        state=getVehicleWearState(vehicle); rvWorkshopResetRollers(vehicle,state)
        return true
    end
    local n=0
    if mode=="WHEELS" then
        n=rvWorkshopResetWheels(vehicle,state)
    elseif mode=="ROLLERS" then
        n=rvWorkshopResetRollers(vehicle,state)
    elseif mode=="TRACKS" then
        n=rvWorkshopResetTracks(vehicle,state)
    end
    if n<=0 then return false end
    local manifest=getOrBuildManifest(vehicle)
    if manifest~=nil then
        manifest.tireWearManifest=getOrBuildTireWearManifest(vehicle)
        state.totalWear=math.clamp(getAverageOwnWear(manifest,state),0,RV.WEAR_MAX)
    end
    if (mode=="TRACKS" or mode=="WHEELS") and ReifenVerschleissVisual~=nil
        and ReifenVerschleissVisual.refreshVehicleWearVisualsImmediate~=nil then
        -- Refresh from the remaining OWN-WEAR states. This resets the selected
        -- component visually while preserving the untouched component states.
        pcall(ReifenVerschleissVisual.refreshVehicleWearVisualsImmediate,vehicle)
    end
    if ReifenVerschleissDiagnostic.publishHudSnapshot~=nil then
        pcall(ReifenVerschleissDiagnostic.publishHudSnapshot)
    end
    print(string.format("[ReifenVerschleiss][WORKSHOP129] reset mode=%s count=%d",mode,n))
    return true
end

function ReifenVerschleissDiagnostic.resetVehicleWear(vehicle, reason)
    return resetVehicleWearState(vehicle, reason)
end



-- ============================================================================
-- OWN-WEAR SAVEGAME PERSISTENCE (vehicles.xml, no sidecar)
--
-- The data is written into the exact GIANTS vehicle node that already belongs
-- to the concrete vehicle/trailer/implement. This removes the former
-- tempsavegame/sidecar timing problem and also removes the need to match a
-- second file back to a vehicle by runtime ids.
-- ============================================================================
local RV_SAVE_BASE_SUFFIX = ".reifenVerschleiss"

local function readSavedWearStateFromVehicleSavegame(savegame)
    if savegame == nil or savegame.xmlFile == nil or savegame.key == nil then
        return nil
    end

    local xmlFile = savegame.xmlFile
    local baseKey = savegame.key .. RV_SAVE_BASE_SUFFIX
    if not xmlFile:hasProperty(baseKey) then
        return nil
    end

    local saved = {
        totalDistanceWear = xmlFile:getValue(baseKey .. "#totalDistanceWear", 0),
        totalSlipWear = xmlFile:getValue(baseKey .. "#totalSlipWear", 0),
        totalTimeWear = xmlFile:getValue(baseKey .. "#totalTimeWear", 0),
        totalWear = xmlFile:getValue(baseKey .. "#totalWear", 0),
        debugDistanceM = xmlFile:getValue(baseKey .. "#debugDistanceM", 0),
        debugTimeMs = xmlFile:getValue(baseKey .. "#debugTimeMs", 0),
        totalEffectiveWearDistanceM = xmlFile:getValue(baseKey .. "#totalEffectiveWearDistanceM", 0),
        wheels = {},
        tracks = {},
        tracksByIndex = {},
        trackList = {}
    }

    for _, wheelKey in xmlFile:iterator(baseKey .. ".wheel") do
        local key = xmlFile:getValue(wheelKey .. "#key")
        if key ~= nil then
            saved.wheels[tostring(key)] = {
                distanceWear = xmlFile:getValue(wheelKey .. "#distanceWear", 0),
                slipWear = xmlFile:getValue(wheelKey .. "#slipWear", 0),
                timeWear = xmlFile:getValue(wheelKey .. "#timeWear", 0),
                effectiveDistanceM = xmlFile:getValue(wheelKey .. "#effectiveDistanceM", 0),
                slipDistanceM = xmlFile:getValue(wheelKey .. "#slipDistanceM", 0),
                lastSlip = xmlFile:getValue(wheelKey .. "#lastSlip", 0),
                lastSlipWearPointsPerSecond = xmlFile:getValue(wheelKey .. "#lastSlipWearPointsPerSecond", 0),
                lastGroundClass = xmlFile:getValue(wheelKey .. "#lastGroundClass", "UNKNOWN"),
                lastDistanceFactor = xmlFile:getValue(wheelKey .. "#lastDistanceFactor", 1),
                lastSlipFactor = xmlFile:getValue(wheelKey .. "#lastSlipFactor", 1),
                lastLoadFactor = xmlFile:getValue(wheelKey .. "#lastLoadFactor", 1)
            }
        end
    end

    local trackSequence = 0
    for _, trackKey in xmlFile:iterator(baseKey .. ".track") do
        trackSequence = trackSequence + 1
        local key = xmlFile:getValue(trackKey .. "#key")
        local savedIndex = xmlFile:getValue(trackKey .. "#index")
        local entry = {
            index = savedIndex,
            side = xmlFile:getValue(trackKey .. "#side"),
            distanceWear = xmlFile:getValue(trackKey .. "#distanceWear", 0),
            slipWear = xmlFile:getValue(trackKey .. "#slipWear", 0),
            timeWear = xmlFile:getValue(trackKey .. "#timeWear", 0),
            effectiveDistanceM = xmlFile:getValue(trackKey .. "#effectiveDistanceM", 0),
            slipDistanceM = xmlFile:getValue(trackKey .. "#slipDistanceM", 0),
            lastSlip = xmlFile:getValue(trackKey .. "#lastSlip", 0),
            lastSlipWearPointsPerSecond = xmlFile:getValue(trackKey .. "#lastSlipWearPointsPerSecond", 0),
            lastGroundClass = xmlFile:getValue(trackKey .. "#lastGroundClass", "UNKNOWN"),
            lastDistanceFactor = xmlFile:getValue(trackKey .. "#lastDistanceFactor", 1),
            lastSlipFactor = xmlFile:getValue(trackKey .. "#lastSlipFactor", 1),
            rollerWear = xmlFile:getValue(trackKey .. "#rollerWear", 0),
            rollerLifetimeFactor = xmlFile:getValue(trackKey .. "#rollerLifetimeFactor", 0),
            rollerDistanceM = xmlFile:getValue(trackKey .. "#rollerDistanceM", 0),
            lastLoadFactor = xmlFile:getValue(trackKey .. "#lastLoadFactor", 1)
        }
        if key ~= nil then
            saved.tracks[tostring(key)] = entry
        end
        if type(savedIndex) == "number" then
            saved.tracksByIndex[math.floor(savedIndex)] = entry
        end
        saved.trackList[trackSequence] = entry
    end

    return saved
end

function ReifenVerschleissDiagnostic.captureVehicleWearSavegame(vehicle, savegame)
    if vehicle == nil then return end
    capturedVehicleWearSavegame[vehicle] = true
    pendingSavedWearStates[vehicle] = readSavedWearStateFromVehicleSavegame(savegame)
end

local function applyPendingSavedState(vehicle, state)
    if vehicle == nil or state == nil or state.loadedFromSavegame then return false end

    -- The persistence specialization captures the concrete vehicle savegame
    -- node during its native onLoad(savegame) event. Never finalize before
    -- that native specialization callback has run.
    if capturedVehicleWearSavegame[vehicle] ~= true then
        return false
    end

    local saved = pendingSavedWearStates[vehicle]
    if saved == nil then
        state.loadedFromSavegame = true
        return true
    end

    state.totalDistanceWear = clampFinite(saved.totalDistanceWear, 0, RV.WEAR_MAX * 10, 0)
    state.totalSlipWear = clampFinite(saved.totalSlipWear, 0, RV.WEAR_MAX * 10, 0)
    state.totalTimeWear = clampFinite(saved.totalTimeWear, 0, RV.WEAR_MAX * 10, 0)
    state.totalWear = clampFinite(saved.totalWear, 0, RV.WEAR_MAX, 0)
    state.debugDistanceM = math.max(0, safeNumber(saved.debugDistanceM, 0))
    state.debugTimeMs = math.max(0, safeNumber(saved.debugTimeMs, 0))
    state.totalEffectiveWearDistanceM = math.max(0, safeNumber(saved.totalEffectiveWearDistanceM, 0))

    state.wheelWear = {}
    for wheelKey, savedWheel in pairs(saved.wheels or {}) do
        local d = clampFinite(savedWheel.distanceWear, 0, RV.WEAR_MAX, 0)
        local sl = clampFinite(savedWheel.slipWear, 0, RV.WEAR_MAX, 0)
        local tw = clampFinite(savedWheel.timeWear, 0, RV.WEAR_MAX, 0)
        state.wheelWear[tostring(wheelKey)] = {
            value = math.clamp(d + sl + tw, 0, RV.WEAR_MAX),
            distanceWear = d, slipWear = sl, timeWear = tw,
            effectiveDistanceM = math.max(0, safeNumber(savedWheel.effectiveDistanceM, 0)),
            slipDistanceM = math.max(0, safeNumber(savedWheel.slipDistanceM, 0)),
            lastSlip = clampFinite(savedWheel.lastSlip, 0, 100, 0),
            lastSlipWearPointsPerSecond = math.max(0, safeNumber(savedWheel.lastSlipWearPointsPerSecond, 0)),
            lastGroundClass = tostring(savedWheel.lastGroundClass or "UNKNOWN"),
            lastDistanceFactor = safeNumber(savedWheel.lastDistanceFactor, 1),
            lastSlipFactor = safeNumber(savedWheel.lastSlipFactor, 1),
            lastLoadFactor = safeNumber(savedWheel.lastLoadFactor, 1),
            initialized = true
        }
    end

    -- Tracks are the persistence unit for both rubber crawlers and metal/steel
    -- crawler running gear. Runtime track.key contains geometry/position data
    -- and is deliberately NOT used as the persistent identity anymore because
    -- those positions can differ after a reload. Persistence maps by the
    -- stable crawler order/index from spec_crawlers.crawlers. For savegames
    -- created by TEST2.3.90, where #index did not exist yet, the XML sequence
    -- is used as a compatibility fallback.
    state.trackWear = {}
    local currentWearManifest = getOrBuildTireWearManifest(vehicle)
    for sequence, track in ipairs((currentWearManifest and currentWearManifest.tracks) or {}) do
        local currentIndex = math.floor(safeNumber(track.index, sequence))
        local savedTrack = (saved.tracksByIndex or {})[currentIndex]
        if savedTrack == nil and track.key ~= nil then
            savedTrack = (saved.tracks or {})[tostring(track.key)]
        end
        if savedTrack == nil then
            savedTrack = (saved.trackList or {})[sequence]
        end

        if savedTrack ~= nil then
            local d = clampFinite(savedTrack.distanceWear, 0, RV.WEAR_MAX, 0)
            local sl = clampFinite(savedTrack.slipWear, 0, RV.WEAR_MAX, 0)
            local tw = clampFinite(savedTrack.timeWear, 0, RV.WEAR_MAX, 0)
            local runtimeKey = track.key or string.format("TRACK|%s|%d", tostring(track.side or "?"), currentIndex)
            state.trackWear[runtimeKey] = {
                value = math.clamp(d + sl + tw, 0, RV.WEAR_MAX),
                distanceWear = d, slipWear = sl, timeWear = tw,
                effectiveDistanceM = math.max(0, safeNumber(savedTrack.effectiveDistanceM, 0)),
                slipDistanceM = math.max(0, safeNumber(savedTrack.slipDistanceM, 0)),
                lastSlip = clampFinite(savedTrack.lastSlip, 0, 100, 0),
                lastSlipWearPointsPerSecond = math.max(0, safeNumber(savedTrack.lastSlipWearPointsPerSecond, 0)),
                lastGroundClass = tostring(savedTrack.lastGroundClass or "UNKNOWN"),
                lastDistanceFactor = safeNumber(savedTrack.lastDistanceFactor, 1),
                lastSlipFactor = safeNumber(savedTrack.lastSlipFactor, 1),
                lastLoadFactor = safeNumber(savedTrack.lastLoadFactor, 1),
                rollerWear = clampFinite(savedTrack.rollerWear, 0, RV.WEAR_MAX, 0),
                rollerLifetimeFactor = clampFinite(savedTrack.rollerLifetimeFactor, RV.ROLLER_LIFETIME_FACTOR_MIN, RV.ROLLER_LIFETIME_FACTOR_MAX, 0),
                rollerDistanceM = math.max(0, safeNumber(savedTrack.rollerDistanceM, 0)),
                lastCrawlerMovedDistance = nil,
                initialized = true
            }
        end
    end

    pendingSavedWearStates[vehicle] = nil
    state.loadedFromSavegame = true

    local wheelCount, trackCount = 0, 0
    for _ in pairs(saved.wheels or {}) do wheelCount = wheelCount + 1 end
    for _ in pairs(saved.tracks or {}) do trackCount = trackCount + 1 end
    print(string.format(
        "[ReifenVerschleiss][SAVE] restored vehicle=%s total=%.4f distance=%.4f slip=%.4f time=%.4f wheels=%d tracks=%d",
        tostring(vehicle.configFileName or vehicle.typeName or "UNKNOWN"),
        state.totalWear, state.totalDistanceWear, state.totalSlipWear, state.totalTimeWear, wheelCount, trackCount
    ))
    return true
end

local function writeWearStateValues(xmlFile, key, st)
    xmlFile:setValue(key .. "#distanceWear", safeNumber(st.distanceWear, 0))
    xmlFile:setValue(key .. "#slipWear", safeNumber(st.slipWear, 0))
    xmlFile:setValue(key .. "#timeWear", safeNumber(st.timeWear, 0))
    xmlFile:setValue(key .. "#totalWear", math.clamp(safeNumber(st.distanceWear, 0) + safeNumber(st.slipWear, 0) + safeNumber(st.timeWear, 0), 0, RV.WEAR_MAX))
    xmlFile:setValue(key .. "#effectiveDistanceM", safeNumber(st.effectiveDistanceM, 0))
    xmlFile:setValue(key .. "#slipDistanceM", safeNumber(st.slipDistanceM, 0))
    xmlFile:setValue(key .. "#lastSlip", safeNumber(st.lastSlip, 0))
    xmlFile:setValue(key .. "#lastSlipWearPointsPerSecond", safeNumber(st.lastSlipWearPointsPerSecond, 0))
    xmlFile:setValue(key .. "#lastGroundClass", tostring(st.lastGroundClass or "UNKNOWN"))
    xmlFile:setValue(key .. "#lastDistanceFactor", safeNumber(st.lastDistanceFactor, 1))
    xmlFile:setValue(key .. "#lastSlipFactor", safeNumber(st.lastSlipFactor, 1))
    xmlFile:setValue(key .. "#lastLoadFactor", safeNumber(st.lastLoadFactor, 1))
end

local function isOwnedFarmVehicleForPersistence(vehicle)
    if vehicle == nil or vehicle.isDeleted == true or vehicle.isDeleting == true then
        return false, "INVALID"
    end
    if rvIsExplicitlyExcludedVehicle(vehicle) then
        return false, "EXCLUDED_INCOMPATIBLE"
    end

    -- Persist only vehicles that are demonstrably assigned to the CURRENT
    -- player's farm. This is the primary ownership proof and mirrors GIANTS'
    -- own garage/selling-point ownership check (ownerFarmId == playerFarmId).
    -- The test happens before any wear manifest/state is built, so foreign/map
    -- vehicles are not evaluated by the OWN-WEAR persistence code.
    local playerFarmId = getPlayerFarmId()
    if type(playerFarmId) ~= "number" then
        return false, "NO_PLAYER_FARM"
    end

    local ownerFarmId = getVehicleOwnerFarmIdSafe(vehicle)
    if type(ownerFarmId) ~= "number" or ownerFarmId ~= playerFarmId then
        return false, "FOREIGN_OR_UNOWNED_FARM"
    end

    local propertyState = getVehiclePropertyStateSafe(vehicle)
    if isMissionVehicleState(vehicle, propertyState) then
        return false, "MISSION"
    end
    if hasMissionVehicleInAttacherChain(vehicle) then
        return false, "MISSION_ATTACHER_CHAIN"
    end

    -- GIANTS BuyVehicleData uses OWNED for purchases and LEASED for normal
    -- leased/rented farm vehicles. Both are part of the user's farm fleet and
    -- therefore must persist. Everything else fails closed.
    if VehiclePropertyState ~= nil then
        local ownedState = VehiclePropertyState.OWNED
        local leasedState = VehiclePropertyState.LEASED
        if propertyState == ownedState then
            return true, string.format("OWNED_FARM_%d", ownerFarmId)
        end
        if propertyState == leasedState then
            return true, string.format("LEASED_FARM_%d", ownerFarmId)
        end
        return false, string.format("UNSUPPORTED_PROPERTY_STATE_%s", tostring(propertyState))
    end

    -- Defensive fallback for an environment where the enum is unavailable:
    -- exact farm ownership is still known, but mission-bound objects were
    -- already rejected above.
    return true, string.format("FARM_%d", ownerFarmId)
end

function ReifenVerschleissDiagnostic.saveVehicleWearToSavegame(vehicle, xmlFile, vehicleKey)
    if vehicle == nil or xmlFile == nil or vehicleKey == nil then return end

    local persist, persistReason = isOwnedFarmVehicleForPersistence(vehicle)
    if not persist then
        if RV.DEBUG_SAVE == true then
            print(string.format(
                "[ReifenVerschleiss][SAVE] specialization skip vehicle=%s reason=%s key=%s",
                tostring(vehicle.configFileName or vehicle.typeName or "UNKNOWN"),
                tostring(persistReason), tostring(vehicleKey)
            ))
        end
        return
    end

    local wearManifest = getOrBuildTireWearManifest(vehicle)
    if wearManifest == nil or safeNumber(wearManifest.totalWearObjectCount, 0) <= 0 then
        return
    end

    local state = getVehicleWearState(vehicle)
    if state == nil then return end
    applyPendingSavedState(vehicle, state)

    local manifest = getOrBuildManifest(vehicle)
    if manifest == nil then return end
    manifest.tireWearManifest = wearManifest
    state.totalWear = getAverageOwnWear(manifest, state)
    state.totalEffectiveWearDistanceM = getAverageEffectiveWearDistance(manifest, state)

    local baseKey = vehicleKey .. RV_SAVE_BASE_SUFFIX
    xmlFile:setValue(baseKey .. "#version", RV.SAVE_SCHEMA_VERSION)
    xmlFile:setValue(baseKey .. "#totalDistanceWear", safeNumber(state.totalDistanceWear, 0))
    xmlFile:setValue(baseKey .. "#totalSlipWear", safeNumber(state.totalSlipWear, 0))
    xmlFile:setValue(baseKey .. "#totalTimeWear", safeNumber(state.totalTimeWear, 0))
    xmlFile:setValue(baseKey .. "#totalWear", safeNumber(state.totalWear, 0))
    xmlFile:setValue(baseKey .. "#debugDistanceM", safeNumber(state.debugDistanceM, 0))
    xmlFile:setValue(baseKey .. "#debugTimeMs", safeNumber(state.debugTimeMs, 0))
    xmlFile:setValue(baseKey .. "#totalEffectiveWearDistanceM", safeNumber(state.totalEffectiveWearDistanceM, 0))

    -- Save in manifest order, not hash-table order. Every concrete wheel gets
    -- exactly one record with its runtime/persistence key.
    local wheelCount = 0
    for _, wheel in ipairs(wearManifest.wheels or {}) do
        local st = getWheelWearState(state, wheel)
        local wearKey = getWearKey(wheel)
        if st ~= nil and wearKey ~= nil then
            local key = string.format("%s.wheel(%d)", baseKey, wheelCount)
            xmlFile:setValue(key .. "#key", tostring(wearKey))
            writeWearStateValues(xmlFile, key, st)
            wheelCount = wheelCount + 1
        end
    end

    -- Rubber tracks and metal/steel crawler running gear are both represented
    -- by the track entries of the tire-wear manifest and are persisted here.
    local trackCount = 0
    for sequence, track in ipairs(wearManifest.tracks or {}) do
        local st = getTrackWearState(state, track)
        if st ~= nil then
            local stableIndex = math.floor(safeNumber(track.index, sequence))
            local key = string.format("%s.track(%d)", baseKey, trackCount)
            xmlFile:setValue(key .. "#key", string.format("TRACK_INDEX|%d", stableIndex))
            xmlFile:setValue(key .. "#index", stableIndex)
            xmlFile:setValue(key .. "#side", tostring(track.side or "UNKNOWN"))
            writeWearStateValues(xmlFile, key, st)
            rvEnsureRollerState(st)
            xmlFile:setValue(key .. "#rollerWear", safeNumber(st.rollerWear, 0))
            xmlFile:setValue(key .. "#rollerLifetimeFactor", safeNumber(st.rollerLifetimeFactor, 0))
            xmlFile:setValue(key .. "#rollerDistanceM", safeNumber(st.rollerDistanceM, 0))
            trackCount = trackCount + 1
        end
    end

    print(string.format(
        "[ReifenVerschleiss][SAVE] specialization wrote vehicle=%s wear=%.4f wheels=%d tracks=%d key=%s owner=%s",
        tostring(vehicle.configFileName or vehicle.typeName or "UNKNOWN"),
        state.totalWear, wheelCount, trackCount, tostring(vehicleKey), tostring(persistReason)
    ))
end

function ReifenVerschleissDiagnostic.applyCapturedVehicleWearSavegame(vehicle)
    if vehicle == nil then return false end
    local state = getVehicleWearState(vehicle)
    if state == nil then return false end
    return applyPendingSavedState(vehicle, state)
end

-- ============================================================================
-- DIRECT HUD PUBLICATION
-- ============================================================================
local function rvWriteHudSnapshot(target, valid, wear01, attachedCount, attachedWear01)
    if target == nil then return end
    target._FS25_RV_OWN_WEAR_VALID = valid == true
    target._FS25_RV_OWN_WEAR01 = math.clamp(safeNumber(wear01, 0), 0, RV.WEAR_MAX)
    target._FS25_RV_ATTACHED_WEAR_COUNT = math.max(0, math.floor(safeNumber(attachedCount, 0)))
    target._FS25_RV_ATTACHED_WEAR01 = math.clamp(safeNumber(attachedWear01, 0), 0, RV.WEAR_MAX)
end

-- TEST2.3.119: read-only running-gear HUD bridge.
-- This never changes wear. It only publishes the already existing OWN-WEAR
-- states so Lights Symbol HUD can render tire / rubber-track / steel-track
-- symbols in the same slot. For track and roller groups the HIGHEST value
-- is deliberately used: one critically worn component must never disappear
-- inside an average.
local function rvGetWheelOnlyHudState(vehicle)
    local result = {valid=false, wear01=0, count=0}
    if vehicle == nil then return result end
    local wm = getOrBuildTireWearManifest(vehicle)
    local state = getVehicleWearState(vehicle)
    if wm == nil or state == nil then return result end
    applyPendingSavedState(vehicle, state)

    for _, wheel in ipairs(wm.wheels or {}) do
        local st = getWheelWearState(state, wheel)
        if st ~= nil then
            result.valid = true
            result.count = result.count + 1
            result.wear01 = math.max(result.wear01, math.clamp(
                safeNumber(st.distanceWear,0) + safeNumber(st.slipWear,0) + safeNumber(st.timeWear,0),
                0, RV.WEAR_MAX))
        end
    end
    return result
end

local function rvGetRunningGearHudState(vehicle)
    local result = {
        kind = "TIRE",
        trackValid = false,
        trackWear01 = 0,
        rollerValid = false,
        rollerWear01 = 0
    }
    if vehicle == nil then return result end

    local wearManifest = getOrBuildTireWearManifest(vehicle)
    if wearManifest == nil or wearManifest.tracks == nil or #wearManifest.tracks <= 0 then
        return result
    end

    local state = getVehicleWearState(vehicle)
    if state == nil then return result end
    applyPendingSavedState(vehicle, state)

    result.kind = "RUBBER_TRACK"
    result.trackValid = true

    for _, track in ipairs(wearManifest.tracks) do
        if track.wearRunningGearType == "STEEL_TRACK" then
            result.kind = "STEEL_TRACK"
        end

        local trackState = getTrackWearState(state, track)
        if trackState ~= nil then
            local ownTrackWear = math.clamp(
                safeNumber(trackState.distanceWear, 0) + safeNumber(trackState.slipWear, 0) + safeNumber(trackState.timeWear, 0),
                0, RV.WEAR_MAX
            )
            result.trackWear01 = math.max(result.trackWear01, ownTrackWear)

            rvEnsureRollerState(trackState)
            local classification = rvClassifyCrawlerRollers(track)
            if classification ~= nil
                and classification.confident == true
                and classification.rollers ~= nil
                and #classification.rollers > 0 then
                result.rollerValid = true
                result.rollerWear01 = math.max(
                    result.rollerWear01,
                    math.clamp(safeNumber(trackState.rollerWear, 0), 0, RV.WEAR_MAX)
                )
            end
        end
    end

    return result
end

local function rvWriteWheelHudSnapshot(target, prefix, ws)
    if target == nil or ws == nil then return end
    prefix = prefix or "_FS25_RV"
    target[prefix .. "_WHEEL_WEAR_VALID"] = ws.valid == true
    target[prefix .. "_WHEEL_WEAR01"] = math.clamp(safeNumber(ws.wear01,0),0,RV.WEAR_MAX)
    target[prefix .. "_WHEEL_COUNT"] = math.max(0,math.floor(safeNumber(ws.count,0)))
end

local function rvWriteRunningGearHudSnapshot(target, prefix, rg)
    if target == nil or rg == nil then return end
    prefix = prefix or "_FS25_RV"
    target[prefix .. "_RUNNING_GEAR_KIND"] = tostring(rg.kind or "TIRE")
    target[prefix .. "_TRACK_WEAR_VALID"] = rg.trackValid == true
    target[prefix .. "_TRACK_WEAR01"] = math.clamp(safeNumber(rg.trackWear01, 0), 0, RV.WEAR_MAX)
    target[prefix .. "_ROLLER_WEAR_VALID"] = rg.rollerValid == true
    target[prefix .. "_ROLLER_WEAR01"] = math.clamp(safeNumber(rg.rollerWear01, 0), 0, RV.WEAR_MAX)
end

local function rvPublishHudSnapshot(self)
    local vehicle = self ~= nil and self.currentVehicle or nil
    if vehicle == nil then return end

    local state = getVehicleWearState(vehicle)
    local manifest = getOrBuildManifest(vehicle)
    local wearManifest = getOrBuildTireWearManifest(vehicle)
    local valid = state ~= nil and manifest ~= nil and wearManifest ~= nil
        and safeNumber(wearManifest.totalWearObjectCount, 0) > 0
    local wear01 = 0

    if valid then
        applyPendingSavedState(vehicle, state)
        manifest.tireWearManifest = wearManifest
        wear01 = math.clamp(getAverageOwnWear(manifest, state), 0, RV.WEAR_MAX)
        state.totalWear = wear01
    end

    local runningGear = rvGetRunningGearHudState(vehicle)
    local wheelHudState = rvGetWheelOnlyHudState(vehicle)

    local attachedCount = 0
    local attachedWear01 = 0
    local attachedRunningGear = {
        kind = "TIRE",
        trackValid = false,
        trackWear01 = 0,
        rollerValid = false,
        rollerWear01 = 0
    }

    for _, entry in ipairs(getAttachedImplementsForDisplay(vehicle)) do
        local object = entry ~= nil and entry.object or nil
        if object ~= nil and object ~= vehicle then
            local objectWearManifest = getOrBuildTireWearManifest(object)
            if objectWearManifest ~= nil and safeNumber(objectWearManifest.totalWearObjectCount, 0) > 0 then
                local objectState = getVehicleWearState(object)
                local objectManifest = getOrBuildManifest(object)
                if objectState ~= nil and objectManifest ~= nil then
                    applyPendingSavedState(object, objectState)
                    objectManifest.tireWearManifest = objectWearManifest
                    local objectWear01 = math.clamp(getAverageOwnWear(objectManifest, objectState), 0, RV.WEAR_MAX)
                    objectState.totalWear = objectWear01
                    attachedCount = attachedCount + 1
                    attachedWear01 = math.max(attachedWear01, objectWear01)

                    local objectRg = rvGetRunningGearHudState(object)
                    if objectRg.kind ~= "TIRE" then
                        if objectRg.kind == "STEEL_TRACK" then
                            attachedRunningGear.kind = "STEEL_TRACK"
                        elseif attachedRunningGear.kind == "TIRE" then
                            attachedRunningGear.kind = "RUBBER_TRACK"
                        end
                        attachedRunningGear.trackValid = attachedRunningGear.trackValid or objectRg.trackValid
                        attachedRunningGear.trackWear01 = math.max(attachedRunningGear.trackWear01, objectRg.trackWear01)
                        if objectRg.rollerValid then
                            attachedRunningGear.rollerValid = true
                            attachedRunningGear.rollerWear01 = math.max(attachedRunningGear.rollerWear01, objectRg.rollerWear01)
                        end
                    end
                end
            end
        end
    end

    rvWriteHudSnapshot(vehicle, valid, wear01, attachedCount, attachedWear01)
    rvWriteRunningGearHudSnapshot(vehicle, "_FS25_RV", runningGear)
    rvWriteWheelHudSnapshot(vehicle, "_FS25_RV", wheelHudState)
    rvWriteRunningGearHudSnapshot(vehicle, "_FS25_RV_ATTACHED", attachedRunningGear)

    local root = nil
    if type(vehicle.getRootVehicle) == "function" then
        local ok, value = pcall(vehicle.getRootVehicle, vehicle)
        if ok then root = value end
    elseif vehicle.rootVehicle ~= nil then
        root = vehicle.rootVehicle
    end
    if root ~= nil and root ~= vehicle then
        rvWriteHudSnapshot(root, valid, wear01, attachedCount, attachedWear01)
        rvWriteRunningGearHudSnapshot(root, "_FS25_RV", runningGear)
        rvWriteWheelHudSnapshot(root, "_FS25_RV", wheelHudState)
        rvWriteRunningGearHudSnapshot(root, "_FS25_RV_ATTACHED", attachedRunningGear)
    end

    local signature = string.format(
        "%s|%.6f|%s|%.6f|%.6f|%d|%.6f|%s|%.6f|%.6f",
        tostring(valid), wear01,
        tostring(runningGear.kind), runningGear.trackWear01, runningGear.rollerWear01,
        attachedCount, attachedWear01,
        tostring(attachedRunningGear.kind), attachedRunningGear.trackWear01, attachedRunningGear.rollerWear01
    )
    if self._rvHudSnapshotSignature ~= signature then
        print(string.format(
            "[ReifenVerschleiss][HUD-PUBLISH119] vehicle=%s valid=%s wear=%.2f%% kind=%s track=%.2f%% roller=%s/%.2f%% attached=%d attachedWear=%.2f%% attachedKind=%s",
            tostring(vehicle.configFileName or vehicle.typeName or "UNKNOWN"),
            tostring(valid), wear01 * 100,
            tostring(runningGear.kind), runningGear.trackWear01 * 100,
            tostring(runningGear.rollerValid), runningGear.rollerWear01 * 100,
            attachedCount, attachedWear01 * 100, tostring(attachedRunningGear.kind)
        ))
        self._rvHudSnapshotSignature = signature
    end
end

function ReifenVerschleissDiagnostic.publishHudSnapshot()
    rvPublishHudSnapshot(ReifenVerschleissDiagnostic)
end

-- TEST2.3.101: read-only roller wear bridge for the existing AutoDrive
-- cruise-cap hook. Only confidently detected RUBBER_TRACK crawlers qualify.
-- STEEL_TRACK is deliberately excluded.
function ReifenVerschleissDiagnostic.getRubberTrackRollerWear01ForSpeedMalus(vehicle)
    if vehicle == nil then return nil end
    local wearManifest = getOrBuildTireWearManifest(vehicle)
    if wearManifest == nil or wearManifest.tracks == nil then return nil end
    local state = getVehicleWearState(vehicle)
    if state == nil then return nil end
    applyPendingSavedState(vehicle, state)

    local maxWear = nil
    for _, track in ipairs(wearManifest.tracks) do
        if track.wearRunningGearType == "RUBBER_TRACK" then
            local trackState = getTrackWearState(state, track)
            if trackState ~= nil then
                rvEnsureRollerState(trackState)
                local classification = rvClassifyCrawlerRollers(track)
                if classification ~= nil and classification.confident == true and #classification.rollers > 0 then
                    local w = math.clamp(safeNumber(trackState.rollerWear, 0), 0, 1)
                    maxWear = maxWear == nil and w or math.max(maxWear, w)
                end
            end
        end
    end
    return maxWear
end

-- TEST2.3.124: read-only workshop component inventory.
function ReifenVerschleissDiagnostic.getRunningGearServiceInfo(vehicle)
    local r={trackCount=0,rubberTrackCount=0,steelTrackCount=0,rollerCount=0}
    if vehicle==nil then return r end
    local wm=getOrBuildTireWearManifest(vehicle)
    if wm==nil then return r end
    r.trackCount=#(wm.tracks or {})
    for _,track in ipairs(wm.tracks or {}) do
        if track.wearRunningGearType=="STEEL_TRACK" then r.steelTrackCount=r.steelTrackCount+1
        else r.rubberTrackCount=r.rubberTrackCount+1 end
        local c=rvClassifyCrawlerRollers(track)
        if c~=nil and c.confident==true then r.rollerCount=r.rollerCount+#(c.rollers or {}) end
    end
    return r
end

function ReifenVerschleissDiagnostic.getOwnWear01ForHUD(vehicle)
    if vehicle == nil then return nil end
    local wearManifest = getOrBuildTireWearManifest(vehicle)
    if wearManifest == nil or safeNumber(wearManifest.totalWearObjectCount, 0) <= 0 then
        return nil
    end
    local state = getVehicleWearState(vehicle)
    local manifest = getOrBuildManifest(vehicle)
    if state == nil or manifest == nil then return nil end
    applyPendingSavedState(vehicle, state)
    manifest.tireWearManifest = wearManifest
    local wear01 = math.clamp(getAverageOwnWear(manifest, state), 0, RV.WEAR_MAX)
    state.totalWear = wear01
    return wear01
end

-- Public read-only HUD bridge used by Lights Symbol HUD.
-- IMPORTANT: this reads the already authoritative OWN-WEAR state. It does not
-- use GIANTS gameWear and it does not create a second HUD-side wear model.
--
-- TEST2.3.82 intentionally avoids the 2.3.81 bridge's extra aggregate chain.
-- The compact diagnostic already keeps state.totalWear synchronized with the
-- concrete wheel/track states; loaded persistence also restores this field.
-- For safety we recompute it from the same OWN-WEAR wheel/track states here
-- only after the dedicated wear manifest is known to contain wear objects.
function ReifenVerschleissDiagnostic.getHudWearState(vehicle)
    local empty = {hasWearObjects=false, wearPercent=0, wear01=0, state="green", wheelCount=0, trackCount=0, totalWearObjectCount=0}
    if vehicle == nil then return empty end

    local state = getVehicleWearState(vehicle)
    local manifest = getOrBuildManifest(vehicle)
    if state == nil or manifest == nil then return empty end

    -- This function is declared after applyPendingSavedState, so this is a real
    -- local call (not a forward-reference to a nil global as happened in older
    -- public HUD helper code).
    applyPendingSavedState(vehicle, state)

    local wearManifest = getOrBuildTireWearManifest(vehicle)
    if wearManifest == nil then return empty end

    local wheelCount = safeNumber(wearManifest.wheelCount, 0)
    local trackCount = safeNumber(wearManifest.trackCount, 0)
    local objectCount = safeNumber(wearManifest.totalWearObjectCount, wheelCount + trackCount)
    if objectCount <= 0 then return empty end

    -- Same OWN-WEAR data used by the diagnostic: per-wheel/per-track
    -- DIST-WEAR + SLIP-WEAR. No GIANTS wear and no HUD-side calculation.
    manifest.tireWearManifest = wearManifest
    local wear01 = math.clamp(getAverageOwnWear(manifest, state), 0, RV.WEAR_MAX)
    state.totalWear = wear01

    local color = "green"
    if wear01 > 0.75 then
        color = "red"
    elseif wear01 > 0.50 then
        color = "yellow"
    end

    return {
        hasWearObjects=true,
        wearPercent=wear01 * 100,
        wear01=wear01,
        state=color,
        wheelCount=wheelCount,
        trackCount=trackCount,
        totalWearObjectCount=objectCount,
        vehicle=vehicle
    }
end

function ReifenVerschleissDiagnostic.getHudAttachedWearState(vehicle)
    local sourceVehicle = vehicle or RV.currentVehicle
    local result = {count=0, hasWearObjects=false, wearPercent=0, wear01=0, state="green", vehicle=sourceVehicle}
    if sourceVehicle == nil then return result end

    -- Exactly the same attachment list used by the compact diagnostic.
    local entries = getAttachedImplementsForDisplay(sourceVehicle)
    local maxWear01 = nil
    local count = 0
    local used = {}

    for _, entry in ipairs(entries or {}) do
        local object = type(entry) == "table" and entry.object or entry
        if object ~= nil and object ~= sourceVehicle and used[object] ~= true then
            used[object] = true
            local objectState = getVehicleWearState(object)
            local objectManifest = getOrBuildManifest(object)
            if objectState ~= nil and objectManifest ~= nil then
                applyPendingSavedState(object, objectState)
                local wearManifest = getOrBuildTireWearManifest(object)
                local wc = wearManifest ~= nil and safeNumber(wearManifest.wheelCount, 0) or 0
                local tc = wearManifest ~= nil and safeNumber(wearManifest.trackCount, 0) or 0
                if wc + tc > 0 then
                    objectManifest.tireWearManifest = wearManifest
                    local wear01 = math.clamp(getAverageOwnWear(objectManifest, objectState), 0, RV.WEAR_MAX)
                    objectState.totalWear = wear01
                    count = count + 1
                    if maxWear01 == nil or wear01 > maxWear01 then maxWear01 = wear01 end
                end
            end
        end
    end

    local wear01 = maxWear01 or 0
    local color = "green"
    if wear01 > 0.75 then color = "red"
    elseif wear01 > 0.50 then color = "yellow" end

    result.count = count
    result.hasWearObjects = count > 0
    result.wearPercent = wear01 * 100
    result.wear01 = wear01
    result.state = color
    return result
end

local function printVehicleHeader(vehicle, manifest)
    local name = tostring(vehicle.configFileName or vehicle.xmlFileName or vehicle.typeName or "UNKNOWN")
    local mass = getVehicleMass(vehicle)

    print(string.format(
        "[ReifenVerschleiss][DIAG] Vehicle=%s | mass=%s t | wheels=%d | normal=%d | crawlers=%d | crawlerWheels=%d | axles=%d",
        name,
        mass ~= nil and string.format("%.0f", mass) or "?",
        manifest.totalWheelCount,
        manifest.normalWheelCount,
        manifest.crawlerCount,
        manifest.crawlerWheelCount,
        manifest.axleCount
    ))
end

local function formatShort(value, decimals)
    if value == nil then
        return "?"
    end
    return string.format("%." .. tostring(decimals or 1) .. "f", value)
end

local function getWheelDebugKey(wheel)
    return getWearKey(wheel) or tostring(wheel ~= nil and wheel.wheelIndex or "?")
end

local function printWearFormulaDebug(vehicle, manifest)
    if not RV.DEBUG_FORMULA or vehicle == nil or manifest == nil then return end
    local vehicleState = getVehicleWearState(vehicle)
    if vehicleState == nil then return end
    vehicleState.debugStep = (vehicleState.debugStep or 0) + 1

    local totalDistance, totalSlip, totalWear, wheelCount = 0, 0, 0, 0
    local logged = 0
    local function processWheel(wheel)
        if wheel == nil or logged >= RV.DEBUG_MAX_WHEELS_PER_LOG then return end
        local ws = getWheelWearState(vehicleState, wheel)
        local d = wheelDiagnostic(wheel, vehicle)
        if ws == nil or d == nil then
            print(string.format("[ReifenVerschleiss][FORMULA-ERROR] step=%d wheel=%s missing diagnostic/state",
                vehicleState.debugStep, tostring(wheel ~= nil and wheel.wheelIndex or "?")))
            return
        end
        local key = getWheelDebugKey(wheel)
        local load, rest = safeNumber(d.load, nil), safeNumber(d.restLoad, nil)
        local loadRatio = (load ~= nil and rest ~= nil and rest > 0) and load / rest or 1
        local loadFactor = getLoadFactor(d)
        local distFactor, distClass = getDistanceGroundFactor(d)
        local slipFactor, slipClass = getSlipGroundFactor(d)
        local slipPercent = clampFinite(d.slip, 0, RV.WEAR_SLIP_MAX_PERCENT, 0)
        local slipIntensity = getSlipIntensity(slipPercent)
        local contactOK = d.hasGroundContact == true
        local lastDistance = safeNumber(vehicleState.debugLastDistanceWear[key], ws.distanceWear)
        local lastSlip = safeNumber(vehicleState.debugLastSlipWear[key], ws.slipWear)
        local deltaDistance = math.max(0, ws.distanceWear - lastDistance)
        local deltaSlip = math.max(0, ws.slipWear - lastSlip)
        totalDistance = totalDistance + safeNumber(ws.distanceWear, 0)
        totalSlip = totalSlip + safeNumber(ws.slipWear, 0)
        totalWear = totalWear + safeNumber(ws.value, 0)
        wheelCount, logged = wheelCount + 1, logged + 1
        local sumOK = math.abs(ws.value - math.clamp(
            ws.distanceWear + ws.slipWear + safeNumber(ws.timeWear,0),
            0, RV.WEAR_MAX)) < 0.000001
        local finiteOK = loadFactor == loadFactor and distFactor == distFactor and slipFactor == slipFactor
            and slipIntensity == slipIntensity and ws.value == ws.value
        local inputDistance = safeNumber(ws.debugInputDistanceM, 0)
        local debugDt = safeNumber(ws.debugDtSec, 0)
        local expectedDistance = safeNumber(ws.debugExpectedDistanceWear, 0)
        local expectedSlip = safeNumber(ws.debugExpectedSlipWear, 0)
        local deltaDOK = math.abs(deltaDistance - expectedDistance) < 0.0000005
        local deltaSOK = math.abs(deltaSlip - expectedSlip) < 0.0000005

        print(string.format(
            "[ReifenVerschleiss][FORMULA] step=%d W%d %s | load=%.3ft rest=%.3ft ratio=%.3f loadF=%.3f | groundD=%s fD=%.3f groundS=%s fS=%.3f | wet=%.3f rain=%.3f snow=%.3f | slip=%.2f%% slipI=%.4f | inputDist=%.3fm dt=%.3fs | expectedD=%.9f actualD=%.9f expectedS=%.9f actualS=%.9f | cumD=%.9f cumS=%.9f total=%.9f | effD=%.3fm slipD=%.3fm | CHECK d=%s s=%s sum=%s finite=%s",
            vehicleState.debugStep, d.index or -1, contactOK and "CONTACT" or "NO_CONTACT",
            load or -1, rest or -1, loadRatio, loadFactor,
            tostring(distClass or "?"), distFactor, tostring(slipClass or "?"), slipFactor,
            safeNumber(d.wetScale, 0), safeNumber(d.rainScale, 0), safeNumber(d.snowScale, 0),
            slipPercent, slipIntensity, inputDistance, debugDt,
            expectedDistance, deltaDistance, expectedSlip, deltaSlip,
            safeNumber(ws.distanceWear, 0), safeNumber(ws.slipWear, 0), safeNumber(ws.value, 0),
            safeNumber(ws.effectiveDistanceM, 0), safeNumber(ws.slipDistanceM, 0),
            deltaDOK and "OK" or "FAIL", deltaSOK and "OK" or "FAIL",
            sumOK and "OK" or "FAIL", finiteOK and "OK" or "FAIL"))
        vehicleState.debugLastDistanceWear[key] = ws.distanceWear
        vehicleState.debugLastSlipWear[key] = ws.slipWear
        vehicleState.debugLastTotalWear[key] = ws.value
        ws.debugExpectedDistanceWear = 0
        ws.debugExpectedSlipWear = 0
        ws.debugInputDistanceM = 0
        ws.debugDtSec = 0
    end
    for _, axle in ipairs(manifest.wheelUnits or {}) do
        for _, wheel in ipairs(axle.wheels or {}) do processWheel(wheel) end
    end
    for _, crawler in ipairs(manifest.crawlers or {}) do
        for _, wheel in ipairs(crawler.wheels or {}) do processWheel(wheel) end
    end
    local avgD = wheelCount > 0 and totalDistance / wheelCount or 0
    local avgS = wheelCount > 0 and totalSlip / wheelCount or 0
    local avgT = wheelCount > 0 and totalWear / wheelCount or 0
    local stored = getAverageWear(manifest, vehicleState)
    print(string.format(
        "[ReifenVerschleiss][FORMULA-SUMMARY] step=%d wheels=%d avgD=%.9f avgS=%.9f avgT=%.9f stored=%.9f check=%s | OWN-WEAR authoritative",
        vehicleState.debugStep, wheelCount, avgD, avgS, avgT, stored,
        math.abs(avgT-stored) < 0.000001 and "OK" or "FAIL"))
end

local function printDetailedLog(vehicle, manifest)
    local speed = getVehicleSpeedKmh(vehicle)

    local vehicleState = getVehicleWearState(vehicle)
    local distWearPoints, slipWearPoints, timeWearPoints = getAverageWearComponents(manifest, vehicleState)
    local avgWear = getAverageWear(manifest, vehicleState)
    -- The internal wear values are normalized to 0..1. Diagnostics are printed
    -- on the same 0..1000 scale as the per-wheel log and HUD. This is only a
    -- presentation correction; it does not change the calculation itself.

    print(string.format(
        "[ReifenVerschleiss][DIAG] SPEED=%.2f km/h | distance=%.3f km | DIST-WEAR=%.2f/1000 | SLIP-WEAR=%.2f/1000 | TIME-WEAR=%.2f/1000 | TOTAL-WEAR=%.2f/1000 | avgWear=%.2f%% | gameTime=%.2f h | Wear calculation=ACTIVE",
        speed,
        RV.DEBUG_DISTANCE_M / 1000,
        distWearPoints * 1000,
        slipWearPoints * 1000,
        timeWearPoints * 1000,
        avgWear * 1000,
        avgWear * 100,
        RV.DEBUG_TIME_MS / 3600000
    ))

    print(string.format(
        "[ReifenVerschleiss][TIME-WEAR] field=%s | confirm=%.2fs | window=%.2fs/%.1fm | avg=%.2f km/h | rate=%.2f/h@1000 | harvestBoost=%s | ref=%dkm",
        tostring(rvWearManifestIsOnField(manifest)),
        safeNumber(vehicleState.timeWearMoveConfirmSec, 0),
        safeNumber(vehicleState.timeWearWindowSec, 0),
        safeNumber(vehicleState.timeWearWindowDistanceM, 0),
        safeNumber(vehicleState.timeWearWindowAvgSpeedKmh, speed),
        safeNumber(vehicleState.timeWearRatePointsPerHourAt1000, RV.TIME_WEAR_LOW_POINTS_PER_H_AT_1000),
        tostring(vehicleState.timeWearHarvestBoostActive == true),
        math.floor(rvGetSelectedReferenceKm() + 0.5)
    ))

    -- Explicitly expose the change since the previous detailed log. This is
    -- diagnostic-only and makes it possible to distinguish newly generated
    -- slip wear from persistent values restored from a previous save.
    local currentDistanceDelta, currentSlipDelta, currentTotalDelta, currentCount = 0, 0, 0, 0
    local function processLoggedDelta(wheel)
        local ws = getWheelWearState(vehicleState, wheel)
        if ws == nil then
            return
        end
        local key = getWearKey(wheel)
        local currentD = safeNumber(ws.distanceWear, 0)
        local currentS = safeNumber(ws.slipWear, 0)
        local currentT = safeNumber(ws.value, 0)
        local previousD = vehicleState.debugLastLoggedDistanceWear[key]
        local previousS = vehicleState.debugLastLoggedSlipWear[key]
        local previousT = vehicleState.debugLastLoggedTotalWear[key]

        if previousD ~= nil then
            currentDistanceDelta = currentDistanceDelta + math.max(0, currentD - previousD)
        end
        if previousS ~= nil then
            currentSlipDelta = currentSlipDelta + math.max(0, currentS - previousS)
        end
        if previousT ~= nil then
            currentTotalDelta = currentTotalDelta + math.max(0, currentT - previousT)
        end
        currentCount = currentCount + 1

        vehicleState.debugLastLoggedDistanceWear[key] = currentD
        vehicleState.debugLastLoggedSlipWear[key] = currentS
        vehicleState.debugLastLoggedTotalWear[key] = currentT
    end

    for _, axle in ipairs(manifest.wheelUnits or {}) do
        for _, wheel in ipairs(axle.wheels or {}) do
            processLoggedDelta(wheel)
        end
    end
    for _, crawler in ipairs(manifest.crawlers or {}) do
        for _, wheel in ipairs(crawler.wheels or {}) do
            processLoggedDelta(wheel)
        end
    end

    -- First log after vehicle activation establishes the baseline and therefore
    -- intentionally reports zero delta. Subsequent logs show newly generated
    -- wear since that previous log, averaged over the current wheel set.
    if currentCount > 0 then
        print(string.format(
            "[ReifenVerschleiss][WHEEL-WEAR-DELTA] seit letztem Log: DIST=%.3f/1000 | SLIP=%.3f/1000 | GESAMT=%.3f/1000 | Räder=%d",
            currentDistanceDelta / currentCount * 1000,
            currentSlipDelta / currentCount * 1000,
            currentTotalDelta / currentCount * 1000,
            currentCount
        ))
    end
    local wheelState = getVehicleWearState(vehicle)
    print("[ReifenVerschleiss][WHEEL-WEAR] Per-wheel OWN-WEAR is authoritative and independent.")
    for _, axle in ipairs(manifest.wheelUnits) do
        for _, wheel in ipairs(axle.wheels) do
            local ws = getWheelWearState(wheelState, wheel)
            if ws ~= nil then
                print(string.format("[ReifenVerschleiss][WHEEL-WEAR] W%d own=%.2f/1000 dist=%.2f/1000 slip=%.2f/1000", wheel.wheelIndex or -1, ws.value * 1000, safeNumber(ws.distanceWear, 0) * 1000, safeNumber(ws.slipWear, 0) * 1000))
            end
        end
    end
    for _, crawler in ipairs(manifest.crawlers) do
        for _, wheel in ipairs(crawler.wheels) do
            local ws = getWheelWearState(wheelState, wheel)
            if ws ~= nil then
                print(string.format("[ReifenVerschleiss][WHEEL-WEAR] W%d own=%.2f/1000 dist=%.2f/1000 slip=%.2f/1000", wheel.wheelIndex or -1, ws.value * 1000, safeNumber(ws.distanceWear, 0) * 1000, safeNumber(ws.slipWear, 0) * 1000))
            end
        end
    end

    local traction = getTractionWheels(vehicle)

    for _, axle in ipairs(manifest.wheelUnits) do
        local parts = {}
        for _, wheel in ipairs(axle.wheels) do
            local d = wheelDiagnostic(wheel, vehicle)
            parts[#parts + 1] = string.format(
                "W%d %s %s driveMode=%s wheelAxle=%s motorized=%s load=%s rest=%s width=%s radius=%s physF=%s(load=%s width=%s radius=%s) slip=%s rawSlip=%s rot=%s contact=%s ground=%s depth=%s field=%s road=%s wet=%s rain=%s wetSrc=%s snow=%s snowContact=%s terrainSnow=%s mud=%s nativeTire=%s nativeF=%s type=%s density=%s samples=%s dH=%s hType=%s method=%s snowH=%s snowState=%s snowMethod=%s",
                d.index or -1,
                d.driven and "DRIVE" or "FREE",
                d.tire,
                d.driveMode ~= nil and tostring(d.driveMode) or "?",
                d.wheelAxle ~= nil and tostring(d.wheelAxle) or "?",
                d.isMotorized ~= nil and tostring(d.isMotorized) or "?",
                d.load ~= nil and string.format("%.1f", d.load) or "?",
                d.restLoad ~= nil and string.format("%.1f", d.restLoad) or "?",
                d.width ~= nil and string.format("%.3f", d.width) or "?",
                d.radius ~= nil and string.format("%.3f", d.radius) or "?",
                d.physicalFactor ~= nil and string.format("%.3f", d.physicalFactor) or "?",
                d.loadFactor ~= nil and string.format("%.3f", d.loadFactor) or "?",
                d.widthFactor ~= nil and string.format("%.3f", d.widthFactor) or "?",
                d.radiusFactor ~= nil and string.format("%.3f", d.radiusFactor) or "?",
                d.slip ~= nil and string.format("%.1f%%", d.slip) or "?",
                d.rawSlip ~= nil and string.format("%.1f%%", d.rawSlip) or "?",
                d.wheelRotation and "Y" or "N",
                contactName(d.contact),
                groundName(d.groundType),
                formatShort(d.groundDepth, 2),
                d.isField and "Y" or "N",
                d.isRoad and "Y" or "N",
                formatShort(d.wetScale, 2),
                formatShort(d.rainScale, 2),
                d.wetSource or "?",
                formatShort(d.snowScale, 2),
                d.hasSnowContact == nil and "?" or (d.hasSnowContact and "Y" or "N"),
                d.terrainSnow == nil and "?" or (d.terrainSnow and "Y" or "N"),
                d.isMudTerrain and "Y" or "N",
                d.nativeTireType or "?",
                formatShort(d.nativeTireFriction, 3),
                formatShort(d.terrainTypeIndex, 0),
                formatShort(d.terrainDensity, 0),
                formatShort(d.terrainSnowSamples, 0),
                formatShort(d.densityDelta, 3),
                formatShort(d.heightTypeIndex, 0),
                d.snowMethod or "NONE",
                formatShort(d.snowHeight, 3),
                d.ownSnowState or "NONE",
                d.snowHeightMethod or "NONE"
            )
        end

        print(string.format(
            "[ReifenVerschleiss][DIAG] AXLE %d %s z=%.3f | %s",
            axle.index,
            axle.kind,
            axle.z or 0,
            table.concat(parts, " || ")
        ))
        for _, wheel in ipairs(axle.wheels) do
            local d = wheelDiagnostic(wheel, vehicle)
            print(string.format("[ReifenVerschleiss][SNOW] W%d own=%.2f state=%s profile=%s slipF=%.3f gripF=%.3f wearF=%.3f snowFall=%.2f height=%.3f temp=%.1f native=%s method=%s global=%.3f",
                d.index or 0, d.snowScale or 0, d.ownSnowState or "NONE", d.snowProfile or "DEFAULT",
                d.ownSnowSlipFactor or 1, d.ownSnowGripFactor or 1, d.ownSnowWearFactor or 1,
                d.snowfall or 0, d.snowHeight or 0, d.snowTemperature or 0,
                formatShort(d.nativeSnowScale, 2), d.snowHeightMethod or "NONE", d.globalSnowHeight or 0))
            local c = d.nativeHeightTypeCandidates or {}
            print(string.format("[ReifenVerschleiss][SNOWCHANNEL] W%d raw=%s nativeChannels=%s nativeHType=%s snowIndex=%s descIndex=%s densityType=%s states=%s low1=%s low2=%s low3=%s low4=%s low5=%s low6=%s low7=%s low8=%s low9=%s low10=%s",
                d.index or 0, formatShort(d.terrainDensity, 0), formatShort(d.nativeHeightTypeChannels, 0),
                formatShort(d.heightTypeIndex, 0), formatShort(d.terrainSnowIndex, 0), formatShort(d.descriptorHeightTypeIndex, 0),
                formatShort(d.densityTypeIndex, 0), formatShort(d.densityStateBits, 0),
                formatShort(c[1], 0), formatShort(c[2], 0), formatShort(c[3], 0), formatShort(c[4], 0), formatShort(c[5], 0),
                formatShort(c[6], 0), formatShort(c[7], 0), formatShort(c[8], 0), formatShort(c[9], 0), formatShort(c[10], 0)))
        end
    end

    for _, crawler in ipairs(manifest.crawlers) do
        print(string.format(
            "[ReifenVerschleiss][DIAG] CRAWLER %d %s type=%s source=%s z=%.3f wheels=%d movedDistance=%s",
            crawler.index,
            crawler.side,
            crawler.type,
            crawler.typeSource,
            crawler.z or 0,
            crawler.wheelCount,
            string.format("%.3f", safeNumber(crawler.crawler ~= nil and crawler.crawler.movedDistance or crawler.movedDistance, 0))
        ))

        for _, wheel in ipairs(crawler.wheels) do
            local d = wheelDiagnostic(wheel, vehicle)
            print(string.format(
                "[ReifenVerschleiss][DIAG]   CRAWLER_WHEEL W%d %s load=%s rest=%s width=%s radius=%s physF=%s(load=%s width=%s radius=%s) slip=%s rawSlip=%s rot=%s contact=%s ground=%s depth=%s field=%s road=%s wet=%s rain=%s wetSrc=%s snow=%s snowContact=%s terrainSnow=%s mud=%s nativeTire=%s nativeF=%s type=%s density=%s samples=%s dH=%s hType=%s method=%s snowH=%s snowState=%s snowMethod=%s",
                d.index or -1,
                d.tire,
                d.load ~= nil and string.format("%.1f", d.load) or "?",
                d.restLoad ~= nil and string.format("%.1f", d.restLoad) or "?",
                d.width ~= nil and string.format("%.3f", d.width) or "?",
                d.radius ~= nil and string.format("%.3f", d.radius) or "?",
                d.physicalFactor ~= nil and string.format("%.3f", d.physicalFactor) or "?",
                d.loadFactor ~= nil and string.format("%.3f", d.loadFactor) or "?",
                d.widthFactor ~= nil and string.format("%.3f", d.widthFactor) or "?",
                d.radiusFactor ~= nil and string.format("%.3f", d.radiusFactor) or "?",
                d.slip ~= nil and string.format("%.1f%%", d.slip) or "?",
                d.rawSlip ~= nil and string.format("%.1f%%", d.rawSlip) or "?",
                d.wheelRotation and "Y" or "N",
                contactName(d.contact),
                groundName(d.groundType),
                formatShort(d.groundDepth, 2),
                d.isField and "Y" or "N",
                d.isRoad and "Y" or "N",
                formatShort(d.wetScale, 2),
                formatShort(d.rainScale, 2),
                d.wetSource or "?",
                formatShort(d.snowScale, 2),
                d.hasSnowContact == nil and "?" or (d.hasSnowContact and "Y" or "N"),
                d.terrainSnow == nil and "?" or (d.terrainSnow and "Y" or "N"),
                d.isMudTerrain and "Y" or "N",
                d.nativeTireType or "?",
                formatShort(d.nativeTireFriction, 3),
                formatShort(d.terrainTypeIndex, 0),
                formatShort(d.terrainDensity, 0),
                formatShort(d.terrainSnowSamples, 0),
                formatShort(d.densityDelta, 3),
                formatShort(d.heightTypeIndex, 0),
                d.snowMethod or "NONE",
                formatShort(d.snowHeight, 3),
                d.ownSnowState or "NONE",
                d.snowHeightMethod or "NONE"
            ))
            print(string.format("[ReifenVerschleiss][SNOW] W%d own=%.2f state=%s profile=%s slipF=%.3f gripF=%.3f wearF=%.3f snowFall=%.2f height=%.3f temp=%.1f native=%s method=%s global=%.3f",
                d.index or 0, d.snowScale or 0, d.ownSnowState or "NONE", d.snowProfile or "DEFAULT",
                d.ownSnowSlipFactor or 1, d.ownSnowGripFactor or 1, d.ownSnowWearFactor or 1,
                d.snowfall or 0, d.snowHeight or 0, d.snowTemperature or 0,
                formatShort(d.nativeSnowScale, 2), d.snowHeightMethod or "NONE", d.globalSnowHeight or 0))
            local c = d.nativeHeightTypeCandidates or {}
            print(string.format("[ReifenVerschleiss][SNOWCHANNEL] W%d raw=%s nativeChannels=%s nativeHType=%s snowIndex=%s descIndex=%s densityType=%s states=%s low1=%s low2=%s low3=%s low4=%s low5=%s low6=%s low7=%s low8=%s low9=%s low10=%s",
                d.index or 0, formatShort(d.terrainDensity, 0), formatShort(d.nativeHeightTypeChannels, 0),
                formatShort(d.heightTypeIndex, 0), formatShort(d.terrainSnowIndex, 0), formatShort(d.descriptorHeightTypeIndex, 0),
                formatShort(d.densityTypeIndex, 0), formatShort(d.densityStateBits, 0),
                formatShort(c[1], 0), formatShort(c[2], 0), formatShort(c[3], 0), formatShort(c[4], 0), formatShort(c[5], 0),
                formatShort(c[6], 0), formatShort(c[7], 0), formatShort(c[8], 0), formatShort(c[9], 0), formatShort(c[10], 0)))
        end
    end
end

local function drawTextLine(y, text, size, x, alpha)
    -- TEST0.1.0.60: warm yellow/orange debug text for improved visibility.
    -- The debug HUD intentionally starts near the upper screen-left/centre area for better visibility.
    setTextColor(1.0, 0.42, 0.02, alpha or 1.0)
    renderText(x or 0.50, y, size or 0.016, text)
end

local function pct(value)
    return string.format("%.2f%%", safeNumber(value, 0))
end

local function permil(value)
    return string.format("%.2f/1000", safeNumber(value, 0) * 1000)
end

local function getMassValues(vehicle)
    if vehicle == nil or vehicle.getTotalMass == nil then
        return nil, nil, nil
    end

    -- MASS SOURCE: EXACTLY the two calls used by EnhancedVehicle HUD.
    -- EnhancedVehicle (FS25_EnhancedVehicle_HUD.lua), drawHUD(), line 1009, uses
    -- these calls in this exact order:
    --   self.vehicle:getTotalMass(true)
    --   self.vehicle:getTotalMass()
    -- The first returned value is the first EV-displayed mass; the second is
    -- the EV-displayed value after "total:". Do not add the optional second
    -- parameter and do not swap the calls.
    local vehicleOk, vehicleMass = pcall(vehicle.getTotalMass, vehicle, true)
    if not vehicleOk or type(vehicleMass) ~= "number" or math.abs(vehicleMass) >= math.huge then
        vehicleMass = nil
    end

    local combinationOk, combinationMass = pcall(vehicle.getTotalMass, vehicle)
    if not combinationOk or type(combinationMass) ~= "number" or math.abs(combinationMass) >= math.huge then
        combinationMass = nil
    end

    -- No invented mass. If the first EV query is unavailable, use the second
    -- native value for both displays; otherwise keep the exact EV call order.
    if vehicleMass == nil then
        vehicleMass = combinationMass
    end

    local attachedMass = nil
    if vehicleMass ~= nil and combinationMass ~= nil then
        attachedMass = math.max(0, combinationMass - vehicleMass)
    end

    return vehicleMass, combinationMass, attachedMass
end

local function drawDiagnostics(vehicle, manifest)
    if vehicle == nil or manifest == nil then
        return
    end

    local state = getVehicleWearState(vehicle)
    if state == nil then
        return
    end

    -- Full debug HUD: upper centre, one structured list underneath.
    -- Keep the text compact enough for large wheel counts; the log remains
    -- the authoritative source for full precision.
    local x = 0.18
    local y = 0.965
    local line = 0.0195
    local small = 0.0142
    local header = 0.0205

    local vehicleName = tostring(vehicle.configFileName or vehicle.xmlFileName or vehicle.typeName or "?")
    local vehicleMass, combinationMass, attachedMass = getMassValues(vehicle)
    local avgWear = getAverageWear(manifest, state)
    local distWear, slipWear, timeWear = getAverageWearComponents(manifest, state)
    local speed = getVehicleSpeedKmh(vehicle)

    drawTextLine(y, "FS25 REIFENVERSCHLEISS | DEBUG " .. RV.VERSION, header, x)
    y = y - line * 1.15
    drawTextLine(y, string.format("FAHRZEUG: %s", vehicleName), small, x)
    y = y - line
    local chassisEntry = manifest.chassisType
    drawTextLine(y, string.format("FAHRWERKSTYP: %s", rvGetChassisTypeLabel(chassisEntry)), small, x)
    y = y - line
    drawTextLine(y, string.format(
        "MASSE: Fahrzeug %s t | Kombination %s t | Anhänger/Anbau %s t",
        vehicleMass ~= nil and string.format("%.3f", vehicleMass) or "?",
        combinationMass ~= nil and string.format("%.3f", combinationMass) or "?",
        attachedMass ~= nil and string.format("%.3f", attachedMass) or "?"
    ), small, x)
    y = y - line
    drawTextLine(y, string.format(
        "FAHRT: %.1f km/h | Distanz: %.3f km | Räder: %d | Achsen: %d | Crawler: %d",
        speed, state.debugDistanceM / 1000, manifest.totalWheelCount,
        manifest.axleCount, manifest.crawlerCount
    ), small, x)
    y = y - line
    local refKm = 200
    local refPriceFactor = 1.0
    local refWearFactor = 1.0
    if RPReferenceSettings ~= nil then
        if RPReferenceSettings.getReferenceKm ~= nil then
            refKm = tonumber(RPReferenceSettings.getReferenceKm()) or 200
        end
        if RPReferenceSettings.getPriceReferenceFactor ~= nil then
            refPriceFactor = tonumber(RPReferenceSettings.getPriceReferenceFactor()) or 1.0
        end
        if RPReferenceSettings.getWearReferenceRateFactor ~= nil then
            refWearFactor = tonumber(RPReferenceSettings.getWearReferenceRateFactor()) or 1.0
        end
    end
    drawTextLine(y, string.format("REFERENZ: %d km | Verschleißfaktor %.3f× | Preisfaktor %.2f×", refKm, refWearFactor, refPriceFactor), small, x)
    y = y - line * 1.1

    local hookState = RV.DEBUG_WHEEL_PHYSICS_HOOK_ACTIVE and "HOOK ACTIVE" or "WAIT FOR HOOK"
    local activeDiag = rvGetObjectDiag(vehicle)
    local activeApplied = activeDiag ~= nil and activeDiag.applied or nil
    local activeBefore = activeDiag ~= nil and activeDiag.before or nil
    local activeAfter = activeDiag ~= nil and activeDiag.after or nil
    drawTextLine(y, string.format(
        "FRICTION-HOOK: %s | VEHICLE | W%s | coeff: %s -> %s | applied: %s | calls: %d",
        hookState, tostring(activeDiag ~= nil and activeDiag.lastWheel or "?"),
        activeBefore ~= nil and string.format("%.6f", activeBefore) or "?",
        activeAfter ~= nil and string.format("%.6f", activeAfter) or "?",
        activeApplied ~= nil and string.format("%.6f", activeApplied) or "?",
        activeDiag ~= nil and activeDiag.calls or 0
    ), header, x)
    y = y - line * 1.05
    local attachedCount, attachedText = 0, "NONE"
    local parts = {}
    for obj, d in pairs(RV.DEBUG_WHEEL_PHYSICS_OBJECTS) do
        if d.objectType == "ATTACHED IMPLEMENT/TRAILER" then
            attachedCount = attachedCount + 1
            parts[#parts + 1] = string.format("%s W%s A:%s", d.label, d.lastWheel or "?", d.applied ~= nil and string.format("%.2f", d.applied) or "?")
        end
    end
    if #parts > 0 then attachedText = table.concat(parts, " | ") end
    drawTextLine(y, string.format("ATTACHED IMPLEMENT/TRAILER: %d | %s", attachedCount, attachedText), small, x)
    y = y - line * 1.15

    drawTextLine(y, string.format(
        "WEAR GESAMT: %s | DIST-WEAR: %s | SLIP-WEAR: %s | TIME-WEAR: %s",
        permil(avgWear), permil(distWear), permil(slipWear), permil(timeWear)
    ), header, x)
    y = y - line * 1.15

    local wearManifest = getWearManifest(manifest)
    drawTextLine(y, string.format(
        "REIFENVERSCHLEISS: %d Rundreifen | %d Bänder | %d Verschleißobjekte",
        safeNumber(wearManifest.wheelCount, 0), safeNumber(wearManifest.trackCount, 0),
        safeNumber(wearManifest.totalWearObjectCount, 0)
    ), header, x)
    y = y - line * 1.05

    for _, track in ipairs(wearManifest.tracks or {}) do
        local ts = getTrackWearState(state, track)
        if ts ~= nil then
            drawTextLine(y, string.format(
                "BAND %02d %s | eigener Wear %.2f/1000 | Verschleiß %.2f%% | DIST %.2f | SLIP %.2f | TIME %.2f | Referenzen %d",
                safeNumber(track.index, 0), tostring(track.side or "?"),
                math.clamp(safeNumber(ts.distanceWear, 0) + safeNumber(ts.slipWear, 0) + safeNumber(ts.timeWear, 0), 0, RV.WEAR_MAX) * 1000,
                math.clamp(safeNumber(ts.distanceWear, 0) + safeNumber(ts.slipWear, 0) + safeNumber(ts.timeWear, 0), 0, RV.WEAR_MAX) * 100,
                safeNumber(ts.distanceWear, 0) * 1000, safeNumber(ts.slipWear, 0) * 1000, safeNumber(ts.timeWear, 0) * 1000,
                safeNumber(track.wheelCount, 0)
            ), small, x)
            y = y - line * 0.92
            drawTextLine(y, string.format(
                "  Pos=(%.3f,%.3f,%.3f) | movedDist=%s | inputDist=%.3fm | Slip=%.1f%% | Boden=%s",
                safeNumber(track.x, 0), safeNumber(track.y, 0), safeNumber(track.z, 0),
                track.crawler ~= nil and string.format("%.3f", safeNumber(track.crawler.movedDistance, 0)) or "?",
                safeNumber(ts.lastDistanceInputM, 0), safeNumber(ts.lastSlipInput, 0),
                tostring(ts.lastGroundClass or "UNKNOWN")
            ), small, x)
            y = y - line
        end
    end

    drawTextLine(y, "RADDETAILS – jedes Rad separat", 0.0155, x)
    y = y - line

    local rows = {}
    for _, axle in ipairs(manifest.wheelUnits) do
        for _, wheel in ipairs(axle.wheels) do
            rows[#rows + 1] = {wheel = wheel, axle = axle.index, kind = axle.kind}
        end
    end
    for _, crawler in ipairs(manifest.crawlers) do
        for _, wheel in ipairs(crawler.wheels) do
            rows[#rows + 1] = {wheel = wheel, axle = nil, kind = "C" .. tostring(crawler.index) .. " " .. tostring(crawler.side)}
        end
    end
    table.sort(rows, function(a, b)
        return safeNumber(a.wheel and a.wheel.wheelIndex, 0) < safeNumber(b.wheel and b.wheel.wheelIndex, 0)
    end)

    for _, row in ipairs(rows) do
        local d = wheelDiagnostic(row.wheel, vehicle)
        local ws = getWheelWearState(state, row.wheel)
        if d ~= nil and ws ~= nil then
            local load = safeNumber(d.load, 0)
            local refLoad = safeNumber(d.restLoad, 0)
            local loadRatio = refLoad > 0.001 and load / refLoad or 0
            local loadFactor = safeNumber(ws.lastLoadFactor, safeNumber(d.loadFactor, 1))
            local distanceFactor = safeNumber(ws.lastDistanceFactor, 1)
            local slipFactor = safeNumber(ws.lastSlipFactor, 1)
            local slip = safeNumber(d.slip, 0)
            local ground = groundName(d.groundType)
            local wet = safeNumber(d.wetScale, 0) * 100
            local rain = safeNumber(d.rainScale, 0) * 100
            local snow = safeNumber(d.snowScale, 0) * 100
            local snowContact = d.hasSnowContact and "JA" or "NEIN"
            local contact = d.hasGroundContact == true and "JA" or "NEIN"
            local driven = d.driven and "ANTRIEB" or "FREILAUF"
            local width = safeNumber(d.width, 0)
            local radius = safeNumber(d.radius, 0)

            drawTextLine(y, string.format(
                "W%02d A%s %s | %s | Kontakt:%s | %s | Reifen:%s",
                safeNumber(d.index, 0), row.axle ~= nil and tostring(row.axle) or "-",
                driven, ground, contact, d.isMudTerrain and "MUD" or (d.terrainSnow and "SCHNEE" or ground), d.nativeTireType or getTireName(row.wheel)
            ), small, x)
            y = y - line * 0.88
            drawTextLine(y, string.format(
                "  Last %.3ft / Ref %.3ft | Verhältnis %.3f | Lastfaktor %.3f | B %.3fm R %.3fm",
                load, refLoad, loadRatio, loadFactor, width, radius
            ), small, x)
            y = y - line * 0.88
            drawTextLine(y, string.format(
                "  Schlupf %s | Roh %s | Rotation %s | Slip-Faktor %.3f | Boden-D %.3f | Boden-S %.3f",
                pct(slip), pct(safeNumber(d.rawSlip, 0)), d.wheelRotation and "JA" or "NEIN", slipFactor, distanceFactor, slipFactor
            ), small, x)
            y = y - line * 0.88
            drawTextLine(y, string.format(
                "  Nässe %s | Regen %s | Schnee %s | SchneeKontakt %s | MUD %s | nativeF %.3f | Quelle %s",
                pct(wet), pct(rain), pct(snow), snowContact, d.isMudTerrain and "JA" or "NEIN", safeNumber(d.nativeTireFriction, 0), tostring(d.wetSource or "?")
            ), small, x)
            y = y - line * 0.88
            drawTextLine(y, string.format(
                "  DIST %.2f/1000 | SLIP %.2f/1000 | RAD-GESAMT %.2f/1000 | effDist %.1fm | slipDist %.1fm",
                safeNumber(ws.distanceWear, 0) * 1000,
                safeNumber(ws.slipWear, 0) * 1000,
                safeNumber(ws.value, 0) * 1000,
                safeNumber(ws.effectiveDistanceM, 0),
                safeNumber(ws.slipDistanceM, 0)
            ), small, x)
            y = y - line * 1.05

            if y < 0.055 then
                drawTextLine(y, string.format("... %d weitere Räder – vollständige Werte im Log", math.max(0, #rows - 1)), small, x)
                break
            end
        end
    end

    if y > 0.07 then
        drawTextLine(y, string.format(
            "FORMELCHECK: Dist=%.2f/1000 | Slip=%.2f/1000 | Summe=%.2f/1000",
            distWear * 1000, slipWear * 1000, (distWear + slipWear) * 1000
        ), 0.0152, x)
        y = y - line
        drawTextLine(y, "Boden/Nässe/Schnee werden je Rad getrennt erfasst; Log enthält die exakten Berechnungsschritte.", 0.0115, x)
    end
end

-- TEST0.2.0.76: Final vehicle-load visual synchronization.
-- This is deliberately separate from HUD/setControlledVehicle. It is called
-- after Vehicle:onFinishedLoading has raised all specialization onLoadFinished
-- events, so every vehicle (controlled or not) can consume its saved wear
-- state at the final native load boundary.
function RV:refreshVehicleWearVisualsAfterFinishedLoading(vehicle)
    if vehicle == nil then
        return false
    end

    local state = getVehicleWearState(vehicle)
    if state == nil then
        return false
    end

    -- Apply the already loaded persistent state exactly once. Do not create a
    -- second wear source and do not change the saved values here.
    applyPendingSavedState(vehicle, state)

    local manifest = getOrBuildManifest(vehicle)
    manifest.tireWearManifest = getOrBuildTireWearManifest(vehicle)
    state.totalWear = getAverageOwnWear(manifest, state)

    if ReifenVerschleissVisual == nil or ReifenVerschleissVisual.refreshVehicleWearVisualsImmediate == nil then
        return false
    end

    local ok, err = pcall(
        ReifenVerschleissVisual.refreshVehicleWearVisualsImmediate,
        vehicle
    )

    if not ok then
        print(string.format(
            "[ReifenVerschleiss][VISUAL-FINISHED-LOAD] refresh failed vehicle=%s error=%s",
            tostring(vehicle.configFileName or vehicle.typeName or "UNKNOWN"),
            tostring(err)
        ))
        return false
    end

    -- TEST2.3.92: some wheel/crawler render materials settle only after the
    -- final native load boundary. Retry the same visual-only worker briefly
    -- for this vehicle. This does not touch OWN-WEAR, persistence, physics or
    -- EWFS and replaces the accidental visual refresh previously caused by
    -- entering/leaving affected vehicles.
    if state.loadedFromSavegame == true
        and ReifenVerschleissVisual.queueLoadVisualRefresh ~= nil then
        ReifenVerschleissVisual.queueLoadVisualRefresh(vehicle)
    end

    print(string.format(
        "[ReifenVerschleiss][VISUAL-FINISHED-LOAD] vehicle=%s savedStateApplied=%s visualRefresh=updated",
        tostring(vehicle.configFileName or vehicle.typeName or "UNKNOWN"),
        tostring(state.loadedFromSavegame == true)
    ))
    return true
end

function RV.isVehicleManaged(vehicle)
    return vehicle ~= nil and vehicleWearStates[vehicle] ~= nil
end

function RV.isMotorStartPhase(vehicle)
    -- Shared motor-start gate for all ReifenVerschleiss systems.
    -- Uses the same proven starting-phase calculation as slip evaluation,
    -- including the vehicle-specific GIANTS motorStartDuration.
    return isMotorStartPhase(vehicle)
end

function RV.isVehicleReady(vehicle)
    local state = vehicle ~= nil and vehicleWearStates[vehicle] or nil
    return state ~= nil and state.ready == true
end

function RV.setVehicleWFSReady(vehicle)
    local state = vehicle ~= nil and vehicleWearStates[vehicle] or nil
    if state ~= nil then
        state.ready = true
        state.readySince = safeNumber(g_time, 0)
    end
end

function RV.resetVehicleWFS(vehicle)
    local state = vehicle ~= nil and vehicleWearStates[vehicle] or nil
    if state ~= nil then
        state.ready = false
        state.readySince = 0
        state.slipDisplayReady = false
        state.slipDisplayBlocked = true
    end
end

function RV:setVehicle(vehicle)
    if rvIsExplicitlyExcludedVehicle(vehicle) then
        vehicle = nil
    end

    -- TEST0.2.2.77: keep our own active vehicle reference when the HUD
    -- clears GIANTS' controlled vehicle after the player leaves the cab.
    -- Do not require speed or AI at this exact callback: the transition from
    -- player control to AD/CP/GIANTS AI can briefly report both as inactive.
    -- A newly controlled vehicle replaces this reference through this function.
    -- This does NOT modify GIANTS' controlledVehicle/isControlled state.
    if vehicle == nil and self.currentVehicle ~= nil then
        activeVehicleHeld = true
        print(string.format("[ReifenVerschleiss][ACTIVE-VEHICLE-HOLD] KEEP vehicle=%s",
            tostring(self.currentVehicle.configFileName or self.currentVehicle.xmlFileName or self.currentVehicle.typeName or "UNKNOWN")))
        return
    end

    if vehicle == self.currentVehicle then
        return
    end

    local previousVehicle = self.currentVehicle
    self.currentVehicle = vehicle
    activeVehicleHeld = vehicle ~= nil

    self.manifest = nil
    self.lastLogTime = -math.huge
    if previousVehicle ~= nil and previousVehicle ~= vehicle then
        print(string.format("[ReifenVerschleiss][LIFECYCLE] switch %s -> %s | previous state retained",
            tostring(previousVehicle.configFileName or previousVehicle.typeName or "UNKNOWN"),
            tostring(vehicle ~= nil and (vehicle.configFileName or vehicle.typeName or "UNKNOWN") or "NONE")))
    end

    if vehicle ~= nil then
        self.manifest = getOrBuildManifest(vehicle)
        printMacDonDriveTopology(vehicle)
        self.manifest.tireWearManifest = getOrBuildTireWearManifest(vehicle)
        self.tireWearManifest = self.manifest.tireWearManifest

        local vehicleState = getVehicleWearState(vehicle)
        applyPendingSavedState(vehicle, vehicleState)
        self.wear = vehicleState.wear
        self.totalEffectiveWearDistanceM = vehicleState.totalEffectiveWearDistanceM
        self.DEBUG_DISTANCE_M = vehicleState.debugDistanceM
        self.DEBUG_TIME_MS = vehicleState.debugTimeMs
        self.lastSpeedKmh = vehicleState.lastSpeedKmh
        self.lastVehicleForMotion = vehicle
        vehicleState.ready = false
        vehicleState.readySince = 0

        vehicleState.totalWear = getAverageWear(self.manifest, vehicleState)

        -- The saved wear value is already authoritative here. Force the existing
        -- wheel/track visual workers to consume it immediately; do not alter the
        -- wear value or calculation state.
        if ReifenVerschleissVisual ~= nil and ReifenVerschleissVisual.refreshVehicleWearVisualsImmediate ~= nil then
            local okVisual, errVisual = pcall(
                ReifenVerschleissVisual.refreshVehicleWearVisualsImmediate,
                vehicle
            )
            if not okVisual then
                print(string.format(
                    "[ReifenVerschleiss][VISUAL-LOAD] immediate refresh runtime error: %s",
                    tostring(errVisual)
                ))
            end
        end

        self.vehicleSerial = self.vehicleSerial + 1
        print(string.format(
            "[ReifenVerschleiss][DIAG] ===== ACTIVE VEHICLE #%d =====",
            self.vehicleSerial
        ))
        printVehicleHeader(vehicle, self.manifest)
        if self.manifest.chassisType ~= nil then
            print(string.format(
                "[ReifenVerschleiss][CHASSIS] ACTIVE %s | family=%s | brand=%s | crawlers=%d | wheels=%d | axles=%d | hint=%s",
                rvGetChassisTypeLabel(self.manifest.chassisType),
                tostring(self.manifest.chassisType.family),
                tostring(self.manifest.chassisType.brand),
                tonumber(self.manifest.chassisType.crawlerCount) or 0,
                tonumber(self.manifest.chassisType.wheelCount) or 0,
                tonumber(self.manifest.chassisType.axleCount) or 0,
                tostring(self.manifest.chassisType.vehicleHint)
            ))
        end
        print(string.format("[ReifenVerschleiss][OWN-WEAR] total=%.4f (%.2f%%) | own DIST=%.1f/1000 | own SLIP=%.1f/1000", safeNumber(vehicleState.totalWear,0), safeNumber(vehicleState.totalWear,0)*100, safeNumber(vehicleState.totalDistanceWear,0)*1000, safeNumber(vehicleState.totalSlipWear,0)*1000))
        print("[ReifenVerschleiss][DIAG] Wear formula ACTIVE | 1 km = 1000 DIST-WEAR | SLIP-WEAR time based | motor-start peaks suppressed | OWN-WEAR authoritative")
        rvPublishHudSnapshot(self)
    end
end



-- TEST2_3_40: autonomous-driver bridge. AD/CP/GIANTS provide only the
-- activation state; the concrete Vehicle instance arrives from the native
-- Motorized:onUpdate lifecycle. The existing wear engine remains unchanged.
function RV:processAutomatedVehicleUpdate(vehicle, dt)
    if vehicle == nil or vehicle == self.currentVehicle then
        return
    end
    if not isRelevantPlayerVehicle(vehicle) then
        return
    end

    local aiSource = getAutomatedDriverSource(vehicle)
    if aiSource == nil then
        return
    end

    local dtSec = math.max(0, safeNumber(dt, 0)) / 1000
    if dtSec <= 0 then
        return
    end

    local state = getVehicleWearState(vehicle)
    if state == nil then
        return
    end

    applyPendingSavedState(vehicle, state)

    local speedKmh = getVehicleSpeedKmh(vehicle)
    local distanceM = getVehicleMotionDistanceM(vehicle, dtSec)

    -- Primary input remains GIANTS' own movement data. If this background
    -- instance exposes no movement accumulator, measure the actual transform
    -- delta of this same Vehicle instance. This is measurement, not route/path
    -- reconstruction by AD, CP or our mod.
    if distanceM <= 0.000001 then
        distanceM = updateGpsDistance(state, vehicle)
    else
        updateGpsDistance(state, vehicle)
    end

    state.debugDistanceM = state.debugDistanceM + distanceM
    state.debugTimeMs = state.debugTimeMs + dt

    local manifest = getOrBuildManifest(vehicle)
    manifest.tireWearManifest = getOrBuildTireWearManifest(vehicle)
    updateWear(vehicle, manifest, distanceM, speedKmh, dtSec, state)
    state.lastSpeedKmh = speedKmh

    state.totalWear = getAverageOwnWear(manifest, state)

    if g_currentMission ~= nil then
        local now = safeNumber(g_currentMission.time, 0)
        if now - (state.lastAutomatedAdapterLogTime or -math.huge) >= RV.LOG_INTERVAL_MS then
            state.lastAutomatedAdapterLogTime = now
            print(string.format(
                "[ReifenVerschleiss][DRIVER-LINK] source=%s vehicle=%s speed=%.2f km/h distance=%.3f m DIST-WEAR=%.2f/1000 SLIP-WEAR=%.2f/1000 TIME-WEAR=%.2f/1000 TOTAL-WEAR=%.2f/1000",
                tostring(aiSource),
                tostring(vehicle.configFileName or vehicle.xmlFileName or vehicle.typeName or "UNKNOWN"),
                speedKmh, distanceM,
                safeNumber(state.totalDistanceWear, 0) * 1000,
                safeNumber(state.totalSlipWear, 0) * 1000,
                safeNumber(state.totalTimeWear, 0) * 1000,
                safeNumber(state.totalWear, 0) * 1000
            ))
        end
    end
end

function RV:update(dt)
    local dtMs = math.max(0, safeNumber(dt, 0))
    local dtSec = dtMs / 1000
    if dtSec <= 0 then
        return
    end

    -- TEST0.2.2.89:
    -- Keep the proven TEST0.2.2.77 currentVehicle path intact. Automated
    -- vehicles are NOT processed through the complete wear path every frame.
    -- Instead, owned AD/CP/GIANTS-AI vehicles are sampled every 300 ms and
    -- their real world-position delta is passed into the existing wear code.
    aiWearAccumulatorMs = aiWearAccumulatorMs + dtMs
    local processAIVehicles = false -- TEST2_3_40: autonomous vehicles enter through Motorized:onUpdate
    if processAIVehicles then
        aiWearAccumulatorMs = aiWearAccumulatorMs - RV.AI_WEAR_UPDATE_INTERVAL_MS
        if aiWearAccumulatorMs >= RV.AI_WEAR_UPDATE_INTERVAL_MS then
            aiWearAccumulatorMs = 0
        end
    end

    -- The scan itself remains throttled by VEHICLE_SCAN_INTERVAL_MS. It only
    -- discovers player-owned motorized vehicles and never processes them here.
    refreshOwnedMotorizedVehicleCache(g_currentMission ~= nil and safeNumber(g_currentMission.time, 0) or 0)

    local vehicles = {}
    local seenVehicles = {}

    -- Proven .77 behavior: the currently displayed/current vehicle is always
    -- processed, including while stationary, so HUD/slip behavior remains intact.
    if self.currentVehicle ~= nil and isRelevantPlayerVehicle(self.currentVehicle) then
        vehicles[#vehicles + 1] = self.currentVehicle
        seenVehicles[self.currentVehicle] = true
    end

    -- Discover/refresh automated-driver vehicles only on the 300 ms cadence.
    -- This is the ONLY path that adds parallel AI vehicles to this update.
    if processAIVehicles then
        for _, vehicle in ipairs(ownedMotorizedVehicleCache) do
            if vehicle ~= self.currentVehicle then
                local aiSource = getAutomatedDriverSource(vehicle)
                local speedKmh = getVehicleSpeedKmh(vehicle)
                if aiSource ~= nil then
                    aiTrackedVehicles[vehicle] = aiSource
                    activeWearVehicles[vehicle] = true
                elseif speedKmh <= 0.05 then
                    aiTrackedVehicles[vehicle] = nil
                    activeWearVehicles[vehicle] = nil
                end
            end
        end
    end

    -- Process each already registered automated vehicle only once per 300 ms.
    if processAIVehicles then
        for vehicle, active in pairs(activeWearVehicles) do
            if active == true and vehicle ~= self.currentVehicle and isRelevantPlayerVehicle(vehicle) then
                if aiTrackedVehicles[vehicle] ~= nil then
                    vehicles[#vehicles + 1] = vehicle
                    seenVehicles[vehicle] = true
                end
            else
                if vehicle ~= self.currentVehicle and not isRelevantPlayerVehicle(vehicle) then
                    activeWearVehicles[vehicle] = nil
                    aiTrackedVehicles[vehicle] = nil
                end
            end
        end
    end

    local activeVehicleProcessed = false

    for _, vehicle in ipairs(vehicles) do
        local state = getVehicleWearState(vehicle)
        if state ~= nil then
            applyPendingSavedState(vehicle, state)

            local oldWear = self.wear
            local oldTotal = self.totalEffectiveWearDistanceM

            self.wear = state.wear
            self.totalEffectiveWearDistanceM = state.totalEffectiveWearDistanceM

            local speedKmh = getVehicleSpeedKmh(vehicle)
            local aiSource = aiTrackedVehicles[vehicle]
            local distanceM
            local updateDtSec = dtSec

            if aiSource ~= nil and vehicle ~= self.currentVehicle then
                -- AI path: use actual world-position delta. This prevents
                -- lastMovedDistance/activeVehicle semantics from losing the
                -- distance driven after the player leaves the vehicle.
                distanceM = updateGpsDistance(state, vehicle)
                updateDtSec = RV.AI_WEAR_UPDATE_INTERVAL_MS / 1000
            else
                -- Proven normal/player path remains unchanged.
                distanceM = getVehicleMotionDistanceM(vehicle, dtSec)
                updateGpsDistance(state, vehicle)
            end

            state.debugDistanceM = state.debugDistanceM + distanceM
            state.debugTimeMs = state.debugTimeMs + (updateDtSec * 1000)

            if aiSource ~= nil and g_currentMission.time - (state.lastAIDriverLogTime or -math.huge) >= RV.LOG_INTERVAL_MS then
                state.lastAIDriverLogTime = g_currentMission.time
                print(string.format(
                    "[ReifenVerschleiss][AI-DRIVER] source=%s vehicle=%s speed=%.2f km/h distance=%.3f m interval=%.0f ms",
                    tostring(aiSource),
                    tostring(vehicle.configFileName or vehicle.xmlFileName or vehicle.typeName or "UNKNOWN"),
                    speedKmh, distanceM, updateDtSec * 1000
                ))
            end

            local manifest = getOrBuildManifest(vehicle)
            manifest.tireWearManifest = getOrBuildTireWearManifest(vehicle)
            updateWear(vehicle, manifest, distanceM, speedKmh, updateDtSec, state)

            if vehicle == self.currentVehicle then
                RV.updateDynamicLoadCapture(self, vehicle, manifest)
            end

            state.lastSpeedKmh = speedKmh
            self.totalEffectiveWearDistanceM = state.totalEffectiveWearDistanceM

                    state.totalWear = getAverageOwnWear(manifest, state)
        
            self.wear = oldWear
            self.totalEffectiveWearDistanceM = oldTotal

            if vehicle == self.currentVehicle then
                self.DEBUG_DISTANCE_M = state.debugDistanceM
                self.DEBUG_TIME_MS = state.debugTimeMs
                self.lastSpeedKmh = state.lastSpeedKmh
                self.wear = state.wear
                self.totalEffectiveWearDistanceM = state.totalEffectiveWearDistanceM
                activeVehicleProcessed = true
            end
        end
    end

    -- TEST0.2.2.23: passive tire wear for attached trailers/implements.
    -- The implement owns its own persistent wear state and wheel manifest.
    -- Keep the proven attachment path, but gate the actual wear update through
    -- the same player-farm/mission exclusion used for motorized vehicles.
    for _, entry in ipairs(getAttachedImplementsForDisplay()) do
        local implement = entry.object
        if entry.root ~= nil and entry.speedKmh > 0.05 and isRelevantPlayerVehicle(implement) then
            local root = entry.root
            local state = getVehicleWearState(implement)
            if state ~= nil then
                applyPendingSavedState(implement, state)

                local speedKmh = entry.speedKmh
                local distanceM = getVehicleMotionDistanceM(root, dtSec)
                updateGpsDistance(state, implement)
                state.debugDistanceM = state.debugDistanceM + distanceM
                state.debugTimeMs = state.debugTimeMs + dtMs

                local manifest = getOrBuildManifest(implement)
                manifest.tireWearManifest = getOrBuildTireWearManifest(implement)
                updateWear(implement, manifest, distanceM, speedKmh, dtSec, state, true)
                state.lastSpeedKmh = speedKmh

                            state.totalWear = getAverageOwnWear(manifest, state)

                if ReifenVerschleissVisual ~= nil and ReifenVerschleissVisual.refreshAttachedImplementVisuals ~= nil then
                    local okVisual, visualCount = pcall(
                        ReifenVerschleissVisual.refreshAttachedImplementVisuals,
                        implement
                    )
                    if not okVisual then
                        print(string.format(
                            "[ReifenVerschleiss][PASSIVE-VISUAL] refresh error object=%s error=%s",
                            tostring(implement.configFileName or implement.xmlFileName or implement.typeName or "UNKNOWN"),
                            tostring(visualCount)
                        ))
                    end
                end

                if g_currentMission.time - (state.lastPassiveLogTime or -math.huge) >= RV.LOG_INTERVAL_MS then
                    state.lastPassiveLogTime = g_currentMission.time
                    print(string.format(
                        "[ReifenVerschleiss][PASSIVE-WEAR] type=TRAILER/IMPLEMENT object=%s root=%s speed=%.2f km/h distance=%.3f km DIST-WEAR=%.2f/1000 SLIP-WEAR=%.2f/1000 TOTAL-WEAR=%.2f/1000 wheels=%d",
                        tostring(implement.configFileName or implement.xmlFileName or implement.typeName or "UNKNOWN"),
                        tostring(root.configFileName or root.xmlFileName or root.typeName or "UNKNOWN"),
                        speedKmh, distanceM / 1000,
                        safeNumber(state.totalDistanceWear, 0) * 1000,
                        safeNumber(state.totalSlipWear, 0) * 1000,
                        safeNumber(state.totalWear, 0) * 1000,
                        safeNumber(state.lastWheelCount, 0)
                    ))
                end
            end
        end
    end

    if self.currentVehicle ~= nil and self.manifest ~= nil and not activeVehicleProcessed then
        local state = getVehicleWearState(self.currentVehicle)
        if state ~= nil then
            self.wear = state.wear
            self.DEBUG_DISTANCE_M = state.debugDistanceM
            self.DEBUG_TIME_MS = state.debugTimeMs
            self.lastSpeedKmh = state.lastSpeedKmh
            self.totalEffectiveWearDistanceM = state.totalEffectiveWearDistanceM
        end
    end

    rvPublishHudSnapshot(self)

    if self.currentVehicle ~= nil and self.manifest ~= nil then
        if g_currentMission.time - self.lastLogTime >= self.LOG_INTERVAL_MS then
            self.lastLogTime = g_currentMission.time
            printDetailedLog(self.currentVehicle, self.manifest)
        end
    end
end

-- ================================================================
-- TEST0.1.0.52 – separate vehicle/combination mass capture
--
-- This is intentionally diagnostic-only. It does NOT alter wear, physics,
-- native physics/input state, or the normal calculation cadence.
-- Capture is limited to the currently controlled vehicle and is activated
-- automatically for a short window when the vehicle changes or the total
-- combination mass changes. While moving, the window is extended briefly so
-- acceleration/load-transfer can be observed without a permanent 10 Hz scan.
-- ================================================================
RV.DYNAMIC_CAPTURE_MS = 30000
RV.DYNAMIC_EXTEND_MS = 15000
RV.DYNAMIC_INTERVAL_MS = 100
RV.DYNAMIC_MASS_TRIGGER_T = 0.25

local function getWheelAngularSpeed(wheel)
    if wheel == nil or wheel.physics == nil or wheel.physics.wheelShape == nil or wheel.node == nil then
        return nil
    end
    if getWheelShapeAxleSpeed ~= nil then
        local ok, value = pcall(getWheelShapeAxleSpeed, wheel.node, wheel.physics.wheelShape)
        if ok and type(value) == "number" and math.abs(value) < math.huge then
            return value
        end
    end
    return nil
end

local function startDynamicCapture(self, reason)
    self.dynamicCaptureUntil = (g_currentMission ~= nil and g_currentMission.time or 0) + RV.DYNAMIC_CAPTURE_MS
    self.dynamicCaptureReason = reason or "TRIGGER"
end

local function printDynamicWheelLoadSample(self, vehicle, manifest)
    if vehicle == nil or manifest == nil then
        return
    end

    local vehicleMass, combinationMass, attachedMass = getMassValues(vehicle)

    local speed = getVehicleSpeedKmh(vehicle)
    local sumLoad = 0
    local count = 0
    local rows = {}

    local function addWheel(wheel, kind)
        local d = wheelDiagnostic(wheel, vehicle)
        local load = d.load
        if type(load) == "number" then
            sumLoad = sumLoad + load
            count = count + 1
        end
        local angular = getWheelAngularSpeed(wheel)
        local radius = d.radius
        local circumSpeed = nil
        if angular ~= nil and radius ~= nil then
            circumSpeed = math.abs(angular * radius) * 3.6
        end
        rows[#rows + 1] = string.format(
            "W%02d %s load=%.3ft rest=%.3ft contact=%s slip=%.2f%% ang=%s rad=%s circ=%s",
            d.index or 0,
            kind or "W",
            load or 0,
            d.restLoad or 0,
            d.hasGroundContact == true and "GROUND" or "NONE",
            d.slip or 0,
            angular ~= nil and string.format("%.3f", angular) or "?",
            radius ~= nil and string.format("%.3f", radius) or "?",
            circumSpeed ~= nil and string.format("%.2fkm/h", circumSpeed) or "?"
        )
    end

    for _, axle in ipairs(manifest.wheelUnits) do
        for _, wheel in ipairs(axle.wheels) do
            addWheel(wheel, "AX" .. tostring(axle.index))
        end
    end
    for _, crawler in ipairs(manifest.crawlers) do
        for _, wheel in ipairs(crawler.wheels) do
            addWheel(wheel, "C" .. tostring(crawler.index))
        end
    end

    print(string.format(
        "[ReifenVerschleiss][DYNAMIC-LOAD] t=%.3fs speed=%.2fkm/h vehicleMass=%s combinationMass=%s attachedMass=%s sumTireLoad=%.3ft wheels=%d reason=%s",
        (g_currentMission ~= nil and g_currentMission.time or 0) / 1000,
        speed,
        vehicleMass ~= nil and string.format("%.3f", vehicleMass) or "?",
        combinationMass ~= nil and string.format("%.3f", combinationMass) or "?",
        attachedMass ~= nil and string.format("%.3f", attachedMass) or "?",
        sumLoad,
        count,
        self.dynamicCaptureReason or "CAPTURE"
    ))
    for _, row in ipairs(rows) do
        print("[ReifenVerschleiss][DYNAMIC-LOAD] " .. row)
    end
end

RV.updateDynamicLoadCapture = function(self, vehicle, manifest)
    if vehicle == nil or manifest == nil or vehicle ~= self.currentVehicle then
        return
    end

    local now = g_currentMission ~= nil and g_currentMission.time or 0
    local _, combinationMass, _ = getMassValues(vehicle)
    local previousMass = self.dynamicLastTotalMass
    if combinationMass ~= nil and previousMass ~= nil and math.abs(combinationMass - previousMass) >= RV.DYNAMIC_MASS_TRIGGER_T then
        startDynamicCapture(self, "MASS_CHANGE")
    end
    if combinationMass ~= nil then
        self.dynamicLastTotalMass = combinationMass
    end

    if self.dynamicLastVehicle ~= vehicle then
        self.dynamicLastVehicle = vehicle
        startDynamicCapture(self, "VEHICLE_CHANGE")
    end

    local speed = getVehicleSpeedKmh(vehicle)
    if speed > 0.05 and self.dynamicCaptureUntil ~= nil and now < self.dynamicCaptureUntil then
        self.dynamicCaptureUntil = math.max(self.dynamicCaptureUntil, now + RV.DYNAMIC_EXTEND_MS)
    end

    if self.dynamicCaptureUntil == nil or now >= self.dynamicCaptureUntil then
        return
    end

    if self.dynamicLastSampleTime == nil or now - self.dynamicLastSampleTime >= RV.DYNAMIC_INTERVAL_MS then
        self.dynamicLastSampleTime = now
        printDynamicWheelLoadSample(self, vehicle, manifest)
    end
end

local function drawWheelWearLoadView(vehicle, manifest)
    if vehicle == nil or manifest == nil then
        return
    end

    -- Temporary developer-only view for the ongoing physical-load tests.
    -- It is deliberately separate from the normal diagnostic text and does
    -- not change any wear calculation or vehicle/game state.
    local x = 0.62
    local y = 0.50
    local line = 0.014

    drawTextLine(y, "TESTANSICHT – RADLAST / RAD-WEAR", 0.018, x)
    y = y - line * 1.2
    drawTextLine(y, "W = Rad | L = TireLoad | Wear = eigener berechneter Wear", 0.0125, x)
    y = y - line * 1.2

    local rows = {}
    for _, axle in ipairs(manifest.wheelUnits) do
        for _, wheel in ipairs(axle.wheels) do
            rows[#rows + 1] = {
                wheel = wheel,
                axle = axle.index,
                kind = axle.kind
            }
        end
    end
    for _, crawler in ipairs(manifest.crawlers) do
        for _, wheel in ipairs(crawler.wheels) do
            rows[#rows + 1] = {
                wheel = wheel,
                axle = nil,
                kind = "C" .. tostring(crawler.index) .. " " .. tostring(crawler.side)
            }
        end
    end

    table.sort(rows, function(a, b)
        local ai = safeNumber(a.wheel ~= nil and a.wheel.wheelIndex or nil, 0)
        local bi = safeNumber(b.wheel ~= nil and b.wheel.wheelIndex or nil, 0)
        return ai < bi
    end)

    for _, row in ipairs(rows) do
        local d = wheelDiagnostic(row.wheel, vehicle)
        local vehicleState = getVehicleWearState(vehicle)
        local state = getWheelWearState(vehicleState, row.wheel)
        local wearPoints = state ~= nil and math.clamp(safeNumber(state.value, 0) * 1000, 0, 1000) or 0
        local load = d.load ~= nil and string.format("%.2f", d.load) or "?"
        local width = d.width ~= nil and string.format("%.3f", d.width) or "?"
        local radius = d.radius ~= nil and string.format("%.3f", d.radius) or "?"
        local contact = d.hasGroundContact == true and "G" or "-"

        drawTextLine(y, string.format(
            "W%02d %s | L=%st | Wear=%5.1f/1000 | B=%sm R=%sm | %s",
            d.index or 0,
            d.driven and "D" or "-",
            load,
            wearPoints,
            width,
            radius,
            contact
        ), 0.0125, x)
        y = y - line

        if y < 0.08 then
            drawTextLine(y, string.format("... %d weitere Räder", #rows), 0.012, x)
            break
        end
    end
end

local function drawAttachedWearDiagnostics()
    if RV.getMovingAttachedImplements == nil then return end
    local entries = RV.getMovingAttachedImplements()
    if #entries == 0 then return end

    local x = 0.02
    local y = 0.30
    local line = 0.014
    drawTextLine(y, "ANHAENGER / ANBAUGERAETE – REIFENVERSCHLEISS", 0.018, x)
    y = y - line * 1.25

    for _, entry in ipairs(entries) do
        local object = entry.object
        local state = getVehicleWearState(object)
        if state ~= nil then
            local manifest = getOrBuildManifest(object)
            manifest.tireWearManifest = getOrBuildTireWearManifest(object)
            local dist = safeNumber(state.totalDistanceWear, 0) * 1000
            local slip = safeNumber(state.totalSlipWear, 0) * 1000
            local total = safeNumber(state.totalWear, 0) * 1000
            local name = tostring(object.configFileName or object.xmlFileName or object.typeName or "UNKNOWN")
            drawTextLine(y, string.format(
                "%s | W=%d | Wear %.2f/1000 | DIST %.2f | SLIP %.2f",
                name, safeNumber(manifest.totalWheelCount, 0), total, dist, slip
            ), 0.0125, x)
            y = y - line

            local shown = 0
            for _, axle in ipairs(manifest.wheelUnits or {}) do
                for _, wheel in ipairs(axle.wheels or {}) do
                    local ws = getWheelWearState(state, wheel)
                    if ws ~= nil then
                        drawTextLine(y, string.format(
                            "  W%02d | Wear %.2f | DIST %.2f | SLIP %.2f | passive",
                            safeNumber(wheel.wheelIndex, 0),
                            safeNumber(ws.value, 0) * 1000,
                            safeNumber(ws.distanceWear, 0) * 1000,
                            safeNumber(ws.slipWear, 0) * 1000
                        ), 0.0115, x)
                        y = y - line
                        shown = shown + 1
                        if shown >= 12 then break end
                    end
                end
                if shown >= 12 then break end
            end
        end
        if y < 0.08 then break end
    end
end

local function drawCompactWearDiagnostics(vehicle, manifest)
    if vehicle == nil or manifest == nil then return end

    local state = getVehicleWearState(vehicle)
    if state == nil then return end

    -- TEST0.2.2.20: dedicated compact diagnostic HUD.
    -- The original full diagnostic HUD is deliberately not drawn. This keeps
    -- the test readable and leaves enough space for attached-object wear.
    local x = 0.18
    local y = 0.965
    local line = 0.020
    local header = 0.019
    local small = 0.0145

    local vehicleName = tostring(vehicle.configFileName or vehicle.xmlFileName or vehicle.typeName or "?")
    local avgWear = getAverageWear(manifest, state)
    local distWear, slipWear, timeWear = getAverageWearComponents(manifest, state)

    drawTextLine(y, "FS25 REIFENVERSCHLEISS | KOMPAKT " .. RV.VERSION, header, x)
    y = y - line * 1.2
    drawTextLine(y, "FAHRZEUG: " .. vehicleName, small, x)
    y = y - line
    -- TEST0.2.2.22: keep the vehicle path/name on its own line so the wear
    -- values always start at the fixed HUD X position and can never be pushed
    -- outside the visible area by a long XML/config path.
    drawTextLine(y, "FAHRZEUG-WEAR", header, x)
    y = y - line
    drawTextLine(y, string.format(
        "WHEELS %d | WEAR %.2f/1000 | DIST %.2f | SLIP %.2f | TIME %.2f",
        safeNumber(manifest.totalWheelCount, 0), avgWear * 1000, distWear * 1000,
        slipWear * 1000, timeWear * 1000
    ), header, x)
    y = y - line
    drawTextLine(y, string.format(
        "FAHRZEUG STRECKE | GPS: %.3f km | berechnet: %.3f km",
        safeNumber(state.gpsDistanceM, 0) / 1000, safeNumber(state.debugDistanceM, 0) / 1000
    ), small, x)
    y = y - line

    -- TEST2.3.98: show crawler road-roller wear in the compact diagnostic.
    -- Display only: detection, mileage wear and persistence remain unchanged.
    local wearManifest = manifest.tireWearManifest
    if wearManifest ~= nil and wearManifest.tracks ~= nil and #wearManifest.tracks > 0 then
        local shownRollerHeader = false
        for _, track in ipairs(wearManifest.tracks) do
            local trackState = getTrackWearState(state, track)
            if trackState ~= nil then
                rvEnsureRollerState(trackState)
                local classification = rvClassifyCrawlerRollers(track)
                local rollerCount = classification ~= nil and #classification.rollers or safeNumber(trackState.rollerCount, 0)
                local detected = classification ~= nil and classification.confident == true
                if detected or safeNumber(trackState.rollerDistanceM, 0) > 0 or safeNumber(trackState.rollerWear, 0) > 0 then
                    if not shownRollerHeader then
                        drawTextLine(y, "LAUFROLLEN-WEAR", header, x)
                        y = y - line
                        shownRollerHeader = true
                    end
                    drawTextLine(y, string.format(
                        "%s | ROLLEN %d | WEAR %.2f/1000 | STRECKE %.3f km | FAKTOR %.2f",
                        tostring(track.side or "?"), rollerCount,
                        safeNumber(trackState.rollerWear, 0) * 1000,
                        safeNumber(trackState.rollerDistanceM, 0) / 1000,
                        safeNumber(trackState.rollerLifetimeFactor, 0)
                    ), small, x)
                    y = y - line
                end
            end
        end
    end
    y = y - line * 0.35

    local entries = RV.getAttachedImplementsForDisplay ~= nil and RV.getAttachedImplementsForDisplay() or {}
    drawTextLine(y, string.format("ANHÄNGER / ANBAUGERÄTE: %d", #entries), header, x)
    y = y - line * 1.15

    if #entries == 0 then
        drawTextLine(y, "keine angehängten Wear-Objekte erkannt", small, x)
        return
    end

    for _, entry in ipairs(entries) do
        local object = entry.object
        local objectState = getVehicleWearState(object)
        if objectState ~= nil then
            local objectManifest = getOrBuildManifest(object)
            local dist = safeNumber(objectState.totalDistanceWear, 0) * 1000
            local slip = safeNumber(objectState.totalSlipWear, 0) * 1000
            local time = safeNumber(objectState.totalTimeWear, 0) * 1000
            local total = safeNumber(objectState.totalWear, 0) * 1000
            local name = tostring(object.configFileName or object.xmlFileName or object.typeName or "UNKNOWN")

            -- Keep the object path/name separate from the numeric wear line.
            drawTextLine(y, "ANHÄNGER: " .. name, small, x)
            y = y - line
            drawTextLine(y, string.format(
                "WHEELS %d | WEAR %.2f/1000 | DIST %.2f | SLIP %.2f | TIME %.2f",
                safeNumber(objectManifest.totalWheelCount, 0), total, dist, slip, time
            ), header, x)
            y = y - line
            drawTextLine(y, string.format(
                "ANHÄNGER STRECKE | GPS: %.3f km | berechnet: %.3f km",
                safeNumber(objectState.gpsDistanceM, 0) / 1000, safeNumber(objectState.debugDistanceM, 0) / 1000
            ), small, x)
            y = y - line * 1.15
        end
        if y < 0.10 then break end
    end
end

function RV:draw()
    -- TEST0.2.2.20: hide the original overloaded diagnostic HUD completely.
    -- Only the dedicated compact wear test HUD is rendered.
    if self.currentVehicle ~= nil and self.manifest ~= nil then
        drawCompactWearDiagnostics(self.currentVehicle, self.manifest)
    end
end

print("[ReifenVerschleiss][DIAG] Diagnostic build TEST2_3_136_FIELD_ONLY_TIME_WEAR_MISSION_TRAILER_GUARD loaded.")
