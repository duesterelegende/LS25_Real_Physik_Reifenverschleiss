-- FS25_Reifenverschleiss
-- Elektronische Wegfahrsperre (EWFS)
-- TEST0.2.2.76
--
-- Fahrzeugseitige Mehrfachsperre. Kein direkter AD-/CP-Eingriff.
-- Sperrebenen:
-- 1) acceleration = 0 vor WheelsUtil.updateWheelsPhysics
-- 2) setVehicleProps torque/maxClutchTorque/maxDriveSpeed = 0, wenn erreichbar
-- 3) wheelDriveTorque = 0 über WheelsUtil.updateWheelPhysics
-- 4) setWheelShapeProps motorTorque = 0 unmittelbar vor der Radphysik
-- READY ist die einzige Freigabe. Motor AUS schärft wieder.

-- RELEASE: suppress development/diagnostic print output only.
-- Functional code paths remain identical to TEST2_3_136.
local function print(...)
end

ReifenVerschleissWegfahrsperre = {}
local WFS = ReifenVerschleissWegfahrsperre
_G.ReifenVerschleissWegfahrsperre = WFS

-- TEST0.2.2.99: DIRECT VEHICLE INSTANCE CONTROL GATE
-- Only state rule:
--   motor OFF                 -> blocker = 1
--   motor ON + 5000 ms        -> blocker = 0
--   motor OFF again           -> blocker = 1 and timer is reset
-- No READY, activeVehicle, controlledVehicle, AD, CP, HUD or other release condition.

WFS.VERSION = "TEST2_3_30_EWFS_ALL_GAS_PATHS"
WFS.installed = false
WFS.lockedVehicles = setmetatable({}, {__mode="k"})

-- Read-only EWFS HUD bridge.
-- The existing WFS.lockedVehicles marker remains the ONLY source of truth.
-- No passive visual refresh, no AI scan and no second EWFS state machine.
WFS.HUD_STATE_FIELD = "_FS25_EWFS_HUD_STATE"

local function mirrorHudState(v, locked)
    if v == nil then
        return
    end

    local value = locked == true and 1 or 0
    v[WFS.HUD_STATE_FIELD] = value

    -- GIANTS may expose a root vehicle instance to HUD/other systems.
    -- Mirror the SAME already-decided state to that alias only.
    if type(v.getRootVehicle) == "function" then
        local ok, root = pcall(v.getRootVehicle, v)
        if ok and root ~= nil then
            root[WFS.HUD_STATE_FIELD] = value
        end
    elseif v.rootVehicle ~= nil then
        v.rootVehicle[WFS.HUD_STATE_FIELD] = value
    end
end

function WFS.getHUDState(v)
    if v == nil then
        return nil
    end

    local value = v[WFS.HUD_STATE_FIELD]
    if value ~= nil then
        return tonumber(value)
    end

    if type(v.getRootVehicle) == "function" then
        local ok, root = pcall(v.getRootVehicle, v)
        if ok and root ~= nil then
            return tonumber(root[WFS.HUD_STATE_FIELD])
        end
    elseif v.rootVehicle ~= nil then
        return tonumber(v.rootVehicle[WFS.HUD_STATE_FIELD])
    end

    return nil
end

WFS.startTime = setmetatable({}, {__mode="k"})
WFS.lockedSpeedLimit = setmetatable({}, {__mode="k"})
WFS.registeredVehicles = setmetatable({}, {__mode="k"})
WFS.nodeVehicles = setmetatable({}, {__mode="k"})
WFS.shapeVehicles = setmetatable({}, {__mode="k"})
WFS.originalBrakeForce = setmetatable({}, {__mode="k"})
WFS.controlVehicleWrapped = setmetatable({}, {__mode="k"})
WFS.UPDATE_INTERVAL = 10
WFS.TIMER_DURATION = 5000
WFS.scanTimer = 0

local originalStartMotor
local originalStopMotor
local originalUpdateWheelsPhysics
local originalUpdateWheelPhysics
local originalSetVehicleProps
local originalSetWheelShapeProps
local originalGetSmoothedPedals
local originalDriveAlongCurvature
local originalDriveInDirection
local originalDriveToPoint

-- TEST2.3.96: AutoDrive wear speed cap at the proven GIANTS drive-command path.
-- TEST2.3.95 tried to hook AutoDrive's ADStateModule class globally. AutoDrive's
-- mod environment does not expose that class to this mod, so that hook never
-- installed. Here we use the already proven AIVehicleUtil path that AutoDrive
-- actually calls. While AD is active we also mirror the cap into the GIANTS
-- cruise-control speed so the active cruise display shows the same limit.
WFS.adWearCruiseOriginal = setmetatable({}, {__mode="k"})
WFS.adWearCruiseLastCap = setmetatable({}, {__mode="k"})

local function getADWearSpeedCap(v)
    if v == nil or v.ad == nil or v.ad.stateModule == nil then return nil, nil end
    if type(v.ad.stateModule.isActive) ~= "function" then return nil, nil end
    local okActive, active = pcall(v.ad.stateModule.isActive, v.ad.stateModule)
    if not okActive or active ~= true then return nil, nil end
    if ReifenVerschleissDiagnostic == nil or type(ReifenVerschleissDiagnostic.getOwnWear01ForHUD) ~= "function" then return nil, nil end
    local okWear, wear01 = pcall(ReifenVerschleissDiagnostic.getOwnWear01ForHUD, v)
    if not okWear or type(wear01) ~= "number" then return nil, nil end
    wear01 = math.max(0, math.min(1, wear01))
    local pct = wear01 * 100
    local cap = nil
    if pct >= 95 then cap = 20
    elseif pct >= 85 then cap = 25
    elseif pct >= 80 then cap = 30
    elseif pct >= 75 then cap = 35
    elseif pct >= 70 then cap = 40 end
    return cap, pct
end

local function restoreADWearCruise(v)
    local original = WFS.adWearCruiseOriginal[v]
    if original ~= nil then
        if type(v.setCruiseControlMaxSpeed) == "function" then
            pcall(v.setCruiseControlMaxSpeed, v, original)
        end
        print(string.format("[ReifenVerschleiss][AD-WEAR-LIMIT] RESTORE vehicle=%s cruise=%.2f", tostring(v.configFileName or v.typeName or "UNKNOWN"), original))
        WFS.adWearCruiseOriginal[v] = nil
        WFS.adWearCruiseLastCap[v] = nil
    end
end

local function applyADWearCruise(v, cap, pct)
    if v == nil or cap == nil then return end
    if WFS.adWearCruiseOriginal[v] == nil and type(v.getCruiseControlSpeed) == "function" then
        local ok, current = pcall(v.getCruiseControlSpeed, v)
        if ok and type(current) == "number" then WFS.adWearCruiseOriginal[v] = current end
    end
    if type(v.setCruiseControlMaxSpeed) == "function" then
        pcall(v.setCruiseControlMaxSpeed, v, cap)
    end
    if WFS.adWearCruiseLastCap[v] ~= cap then
        WFS.adWearCruiseLastCap[v] = cap
        print(string.format("[ReifenVerschleiss][AD-WEAR-LIMIT] ACTIVE vehicle=%s wear=%.2f%% cap=%.2f", tostring(v.configFileName or v.typeName or "UNKNOWN"), pct or -1, cap))
    end
end


-- TEST2.3.103: physical vehicle speed limit from crawler road-roller wear.
-- Independent of AutoDrive and cruise control. Only RUBBER_TRACK qualifies.
local function getRubberTrackRollerVehicleSpeedFactor(v)
    if v == nil or ReifenVerschleissDiagnostic == nil
    or type(ReifenVerschleissDiagnostic.getRubberTrackRollerWear01ForSpeedMalus) ~= "function" then
        return 1.0, nil
    end
    local ok, wear01 = pcall(ReifenVerschleissDiagnostic.getRubberTrackRollerWear01ForSpeedMalus, v)
    if not ok or type(wear01) ~= "number" then return 1.0, nil end
    wear01 = math.max(0, math.min(1, wear01))
    local pct = wear01 * 100
    if pct >= 90 then return 0.50, pct
    elseif pct >= 85 then return 0.60, pct
    elseif pct >= 80 then return 0.70, pct
    elseif pct >= 75 then return 0.80, pct
    elseif pct >= 70 then return 0.90, pct end
    return 1.0, pct
end

local function applyRubberTrackRollerMaxForwardSpeed(v)
    if v == nil or v.spec_motorized == nil or v.spec_motorized.motor == nil then return end
    local motor = v.spec_motorized.motor
    if type(motor.maxForwardSpeed) ~= "number" or motor.maxForwardSpeed <= 0 then return end

    WFS.rollerMaxForwardSpeedState = WFS.rollerMaxForwardSpeedState or {}
    local state = WFS.rollerMaxForwardSpeedState[v]

    -- GIANTS VehicleMotor itself preserves the original constructor value in
    -- maxForwardSpeedOrigin. Prefer it as immutable source; otherwise capture
    -- the current value once.
    local original = nil
    if type(motor.maxForwardSpeedOrigin) == "number" and motor.maxForwardSpeedOrigin > 0 then
        original = motor.maxForwardSpeedOrigin
    elseif state ~= nil and type(state.original) == "number" then
        original = state.original
    else
        original = motor.maxForwardSpeed
    end

    local factor, pct = getRubberTrackRollerVehicleSpeedFactor(v)

    if state == nil then
        state = {original = original}
        WFS.rollerMaxForwardSpeedState[v] = state
    elseif type(state.original) == "number" and state.original > 0
    and not (type(motor.maxForwardSpeedOrigin) == "number" and motor.maxForwardSpeedOrigin > 0) then
        original = state.original
    end

    local target = original * factor
    if math.abs(motor.maxForwardSpeed - target) > 0.00001 then
        motor.maxForwardSpeed = target
    end

    local signature = string.format("%.0f|%.4f|%.4f|%.2f",
        pct or -1, original, target, factor)
    if state.signature ~= signature then
        state.signature = signature
        print(string.format(
            "[ReifenVerschleiss][ROLLER-MAX-FORWARD-SPEED] vehicle=%s wear=%.2f%% factor=%.0f%% original=%.2fkmh target=%.2fkmh",
            tostring(v.configFileName or v.typeName or "UNKNOWN"),
            pct or -1, factor * 100, original * 3.6, target * 3.6))
    end
end

local function motorState(v)
    return v ~= nil and v.spec_motorized ~= nil and v.spec_motorized.motorState or nil
end

local function now()
    if g_currentMission ~= nil and g_currentMission.time ~= nil then
        return tonumber(g_currentMission.time) or 0
    end
    return tonumber(g_time) or 0
end

local function setLocked(v, locked)
    if v == nil then return end

    -- The blocker itself is the single source of truth.
    -- Do not modify persistent motor parameters here.
    WFS.lockedVehicles[v] = locked == true
    mirrorHudState(v, WFS.lockedVehicles[v] == true)
end

local function applyBrakeForcePlus100(v)
    if v == nil or v.spec_motorized == nil or v.spec_motorized.motor == nil then return end
    local motor = v.spec_motorized.motor
    if motor.brakeForce == nil then return end
    if WFS.originalBrakeForce[v] == nil then
        WFS.originalBrakeForce[v] = tonumber(motor.brakeForce) or 0
    end
    motor.brakeForce = WFS.originalBrakeForce[v] + 100
end

local function restoreBrakeForce(v)
    if v == nil or v.spec_motorized == nil or v.spec_motorized.motor == nil then return end
    local motor = v.spec_motorized.motor
    local original = WFS.originalBrakeForce[v]
    if original ~= nil then
        motor.brakeForce = original
        WFS.originalBrakeForce[v] = nil
    end
end

local function updateBlocker(v)
    if v == nil then return end

    WFS.registeredVehicles[v] = true
    applyRubberTrackRollerMaxForwardSpeed(v)
    local t = now()
    local state = motorState(v)

    -- GOLDEN RULE: ONLY the motor state OFF sets the blocker.
    -- While OFF the blocker is always 1 and the timer is cleared.
    if state == MotorState.OFF then
        WFS.startTime[v] = nil
        setLocked(v, true)
        return
    end

    -- STARTING is intentionally treated as the beginning of the
    -- 5000 ms initialization window. The same timer is then carried
    -- through ON until it expires.
    if state == MotorState.STARTING or state == MotorState.ON then
        if WFS.startTime[v] == nil then
            WFS.startTime[v] = t
            setLocked(v, true)
            applyBrakeForcePlus100(v)
            print(string.format("[ReifenVerschleiss][EWFS] TIMER_START vehicle=%s state=%s t=%dms", tostring(v.configFileName or v.typeName or "UNKNOWN"), tostring(state), math.floor(t)))
            return
        end

        if t - WFS.startTime[v] >= WFS.TIMER_DURATION then
            if WFS.lockedVehicles[v] == true then
                print(string.format("[ReifenVerschleiss][EWFS] TIMER_RELEASE vehicle=%s t=%dms elapsed=%dms", tostring(v.configFileName or v.typeName or "UNKNOWN"), math.floor(t), math.floor(t - WFS.startTime[v])))
            end
            setLocked(v, false)
            restoreBrakeForce(v)
        else
            setLocked(v, true)
            applyBrakeForcePlus100(v)
        end
    end
end

function WFS.isLocked(v)
    return v ~= nil and WFS.lockedVehicles[v] == true
end

function WFS.getState(v)
    return WFS.isLocked(v)
end

-- Refresh the existing EWFS state for a vehicle when it becomes controlled.
-- The HUD only requests this refresh; EWFS remains the sole state owner.
function WFS.refreshVehicleState(v)
    if v == nil then return end

    -- A vehicle can become controlled/tabbed without passing through the
    -- motor-start wrapper. Register and evaluate it immediately so the HUD
    -- always receives the current EWFS state for the newly controlled vehicle.
    WFS.registeredVehicles[v] = true
    updateBlocker(v)
end

-- Compatibility API retained because the existing diagnostic code calls it.
-- It deliberately does nothing: the timer alone controls the blocker.
function WFS.setReady(v)
end

function WFS.reset(v)
    if v == nil then return end
    WFS.startTime[v] = nil
    setLocked(v, true)
    applyBrakeForcePlus100(v)
end

function WFS.registerVehicle(v)
    if v == nil then return end
    WFS.registeredVehicles[v] = true

    -- TEST0.2.2.100: wrap the function actually registered on this vehicle
    -- instance. Motorized.registerFunctions() installs controlVehicle on the
    -- vehicle type; changing Motorized.controlVehicle later does not change
    -- already-created vehicle types. This instance wrapper therefore sits on
    -- the exact self:controlVehicle() path used by WheelsUtil.
    -- MANUAL GAS LOCK (3 layers):
    -- L1: Drivable:setAccelerationPedalInput()
    -- L2: spec.lastInputValues.axisAccelerate
    -- L3: Drivable:onUpdate path consuming axisAccelerate
    -- Only accelerator input is suppressed while EWFS is locked.
    -- No global input action is disabled.

    if Drivable ~= nil and type(Drivable.setAccelerationPedalInput) == "function"
       and not WFS.drivableGasHooked then
        local originalSetAccelerationPedalInput = Drivable.setAccelerationPedalInput
        Drivable.setAccelerationPedalInput = function(vehicle, inputValue)
            if WFS.lockedVehicles[vehicle] == true then
                inputValue = 0
                if vehicle._FS25_EWFS_MANUAL_GAS_BLOCK_LOGGED ~= true then
                    vehicle._FS25_EWFS_MANUAL_GAS_BLOCK_LOGGED = true
                    print(string.format("[EWFS-GAS-LOCK] L1 setAccelerationPedalInput=0 vehicle=%s t=%d",
                        tostring(vehicle.configFileName or vehicle), tonumber(g_currentMission.time) or 0))
                end
            else
                vehicle._FS25_EWFS_MANUAL_GAS_BLOCK_LOGGED = false
            end
            return originalSetAccelerationPedalInput(vehicle, inputValue)
        end
        WFS.drivableGasHooked = true
        print("[ReifenVerschleiss][EWFS] manual accelerator L1 installed")
    end

    if Drivable ~= nil and type(Drivable.onUpdate) == "function"
       and not WFS.drivableUpdateGasHooked then
        local originalDrivableOnUpdate = Drivable.onUpdate
        Drivable.onUpdate = function(vehicle, ...)
            local spec = vehicle.spec_drivable
            if WFS.lockedVehicles[vehicle] == true and spec ~= nil
               and spec.lastInputValues ~= nil then
                -- L2: zero the resolved accelerator value.
                spec.lastInputValues.axisAccelerate = 0
            end
            -- L3: GIANTS onUpdate consumes the zeroed accelerator value.
            return originalDrivableOnUpdate(vehicle, ...)
        end
        WFS.drivableUpdateGasHooked = true
        print("[ReifenVerschleiss][EWFS] manual accelerator L2/L3 installed")
    end
    if not WFS.controlVehicleWrapped[v] and type(v.controlVehicle) == "function" then
        local original = v.controlVehicle
        v.controlVehicle = function(self, acceleratorPedal, maxSpeed, maxAcceleration, minMotorRotSpeed, maxMotorRotSpeed, maxMotorRotAcceleration, minGearRatio, maxGearRatio, maxClutchTorque, neededPtoTorque, ...)
            if WFS.isLocked(self) then
                local motor = self.spec_motorized ~= nil and self.spec_motorized.motor or nil
                if motor ~= nil and motor.setGear ~= nil then
                    -- GIANTS' documented neutral state is gear 0.
                    -- Force the actual transmission state to neutral while EWFS is locked.
                    pcall(motor.setGear, motor, 0, true)
                end
                print(string.format("[ReifenVerschleiss][EWFS] CONTROLVEHICLE_BLOCKED vehicle=%s NEUTRAL_FORCED gear=0 ratios=0/0", tostring(self.configFileName or self.typeName or "UNKNOWN")))
                acceleratorPedal = 0
                maxSpeed = 0
                maxAcceleration = 0
                minGearRatio = 0
                maxGearRatio = 0
                maxClutchTorque = 0
                neededPtoTorque = 0
            end
            return original(self, acceleratorPedal, maxSpeed, maxAcceleration, minMotorRotSpeed, maxMotorRotSpeed, maxMotorRotAcceleration, minGearRatio, maxGearRatio, maxClutchTorque, neededPtoTorque, ...)
        end
        WFS.controlVehicleWrapped[v] = true
        print(string.format("[ReifenVerschleiss][EWFS] CONTROLVEHICLE_INSTANCE_WRAPPED vehicle=%s", tostring(v.configFileName or v.typeName or "UNKNOWN")))
    end

    local sm = v.spec_motorized
    if sm ~= nil and sm.motorizedNode ~= nil then
        WFS.nodeVehicles[sm.motorizedNode] = v
    end

    local wheels = v.spec_wheels ~= nil and v.spec_wheels.wheels or nil
    if wheels ~= nil then
        for _, wheel in pairs(wheels) do
            if wheel ~= nil then
                if wheel.node ~= nil then
                    WFS.nodeVehicles[wheel.node] = v
                end
                if wheel.wheelShape ~= nil then
                    WFS.shapeVehicles[wheel.wheelShape] = v
                end
                if wheel.physics ~= nil and wheel.physics.wheelShape ~= nil then
                    WFS.shapeVehicles[wheel.physics.wheelShape] = v
                end
            end
        end
    end
end

local function applyHardWheelLock(v)
    if v == nil or not WFS.isLocked(v) then return end
    local specWheels = v.spec_wheels
    if specWheels == nil or specWheels.wheels == nil then return end

    specWheels.brakePedal = 1
    for _, wheel in pairs(specWheels.wheels) do
        if wheel ~= nil then
            wheel.torque = 0
            if wheel.physics ~= nil then
                wheel.physics.torque = 0
            end
            if setWheelShapeProps ~= nil and wheel.node ~= nil and wheel.wheelShape ~= nil then
                pcall(setWheelShapeProps, wheel.node, wheel.wheelShape, 0, 0, wheel.steeringAngle or 0, wheel.rotationDamping or 0)
            end
        end
    end
end

function WFS.update(dt)
    local mission = g_currentMission
    if mission == nil then return end

    -- Register vehicles periodically. The actual five-second timer is
    -- based on mission time, not on this polling interval.
    WFS.scanTimer = WFS.scanTimer + (tonumber(dt) or 0)
    if WFS.scanTimer >= WFS.UPDATE_INTERVAL then
        WFS.scanTimer = 0
        if mission.vehicles ~= nil then
            for _, v in pairs(mission.vehicles) do
                if v ~= nil then
                    updateBlocker(v)
                end
            end
        end
    end

    -- Update already registered vehicles every mission update so the timer is
    -- checked without waiting for the next vehicle scan.
    for v, _ in pairs(WFS.registeredVehicles) do
        if v ~= nil then
            updateBlocker(v)
            local adCap, adPct = getADWearSpeedCap(v)
            if adCap ~= nil then
                applyADWearCruise(v, adCap, adPct)
            else
                restoreADWearCruise(v)
            end
        end
    end
end

function WFS.install()
    if WFS.installed then return end

    -- FS25 VehicleSystem:setEnteredVehicle is the engine-level notification
    -- point used when the entered/tabbed vehicle changes. Refresh only the
    -- selected vehicle here; the EWFS decision itself remains unchanged.
    if g_currentMission ~= nil and g_currentMission.vehicleSystem ~= nil
       and type(g_currentMission.vehicleSystem.setEnteredVehicle) == "function"
       and not WFS.vehicleSystemEnterHooked then
        local vehicleSystem = g_currentMission.vehicleSystem
        local originalSetEnteredVehicle = vehicleSystem.setEnteredVehicle
        vehicleSystem.setEnteredVehicle = function(self, vehicle)
            local result = originalSetEnteredVehicle(self, vehicle)
            if vehicle ~= nil then
                WFS.refreshVehicleState(vehicle)
            end
            return result
        end
        WFS.vehicleSystemEnterHooked = true
    end

    if Motorized ~= nil and Motorized.startMotor ~= nil then
        originalStartMotor = Motorized.startMotor
        Motorized.startMotor = Utils.prependedFunction(Motorized.startMotor, function(self, noEventSend)
            if self ~= nil then
                WFS.registerVehicle(self)
                -- Do not create a second timer here. The single WFS.update()
                -- state machine starts it when the vehicle is STARTING/ON.
            end
        end)
    end

    if Motorized ~= nil and Motorized.stopMotor ~= nil then
        originalStopMotor = Motorized.stopMotor
        Motorized.stopMotor = Utils.prependedFunction(Motorized.stopMotor, function(self, noEventSend)
            if self ~= nil then
                WFS.registerVehicle(self)
                WFS.reset(self)
            end
        end)
    end

    -- TEST0.2.2.111: block the AutoDrive/AI command at the AIVehicleUtil
    -- entry points while EWFS is locked. This is deliberately limited to
    -- the affected vehicle instance; unlocked vehicles pass through unchanged.
    if AIVehicleUtil ~= nil and AIVehicleUtil.driveAlongCurvature ~= nil then
        originalDriveAlongCurvature = AIVehicleUtil.driveAlongCurvature
        AIVehicleUtil.driveAlongCurvature = function(self, dt, curvature, maxSpeed, acceleration, ...)
            if self ~= nil then
                WFS.registerVehicle(self)
                updateBlocker(self)
                local adCap, adPct = getADWearSpeedCap(self)
                if adCap ~= nil then
                    maxSpeed = math.min(tonumber(maxSpeed) or adCap, adCap)
                    applyADWearCruise(self, adCap, adPct)
                end
                if WFS.isLocked(self) then
                    print(string.format("[ReifenVerschleiss][EWFS-AD] DRIVE_ALONG_CURVATURE_BLOCKED vehicle=%s accelerationIn=%s maxSpeedIn=%s -> acceleration=0 maxSpeed=0", tostring(self.configFileName or self.typeName or "UNKNOWN"), tostring(acceleration), tostring(maxSpeed)))
                    acceleration = 0
                    maxSpeed = 0
                end
            end
            return originalDriveAlongCurvature(self, dt, curvature, maxSpeed, acceleration, ...)
        end
    end

    -- TEST2.3.13: Courseplay uses AIVehicleUtil.driveToPoint() as its
    -- actual vehicle driving entry point (CpAIWorker:onUpdate). Apply the
    -- same EWFS gate used for AutoDrive/AI without touching Courseplay.
    if AIVehicleUtil ~= nil and AIVehicleUtil.driveToPoint ~= nil then
        originalDriveToPoint = AIVehicleUtil.driveToPoint
        AIVehicleUtil.driveToPoint = function(self, dt, acceleration, allowedToDrive, moveForwards, lx, lz, maxSpeed, ...)
            if self ~= nil then
                WFS.registerVehicle(self)
                updateBlocker(self)
                local adCap, adPct = getADWearSpeedCap(self)
                if adCap ~= nil then
                    maxSpeed = math.min(tonumber(maxSpeed) or adCap, adCap)
                    applyADWearCruise(self, adCap, adPct)
                end
                if WFS.isLocked(self) then
                    -- Block only the actual drive command. Keep steering/path
                    -- calculation alive so Courseplay can initialize normally.
                    acceleration = 0
                    allowedToDrive = false
                    maxSpeed = 0
                end
            end
            return originalDriveToPoint(self, dt, acceleration, allowedToDrive, moveForwards, lx, lz, maxSpeed, ...)
        end
    end

    if AIVehicleUtil ~= nil and AIVehicleUtil.driveInDirection ~= nil then
        originalDriveInDirection = AIVehicleUtil.driveInDirection
        AIVehicleUtil.driveInDirection = function(self, dt, steeringAngleLimit, acceleration, slowAcceleration, slowAngleLimit, allowedToDrive, moveForwards, lx, lz, maxSpeed, slowDownFactor, ...)
            if self ~= nil then
                WFS.registerVehicle(self)
                updateBlocker(self)
                local adCap, adPct = getADWearSpeedCap(self)
                if adCap ~= nil then
                    maxSpeed = math.min(tonumber(maxSpeed) or adCap, adCap)
                    applyADWearCruise(self, adCap, adPct)
                end
                if WFS.isLocked(self) then
                    print(string.format("[ReifenVerschleiss][EWFS-AD] DRIVE_IN_DIRECTION_BLOCKED vehicle=%s accelerationIn=%s slowAccelerationIn=%s allowedIn=%s maxSpeedIn=%s -> acceleration=0 slowAcceleration=0 allowed=false maxSpeed=0", tostring(self.configFileName or self.typeName or "UNKNOWN"), tostring(acceleration), tostring(slowAcceleration), tostring(allowedToDrive), tostring(maxSpeed)))
                    acceleration = 0
                    slowAcceleration = 0
                    allowedToDrive = false
                    maxSpeed = 0
                end
            end
            return originalDriveInDirection(self, dt, steeringAngleLimit, acceleration, slowAcceleration, slowAngleLimit, allowedToDrive, moveForwards, lx, lz, maxSpeed, slowDownFactor, ...)
        end
    end

    if WheelsUtil ~= nil and WheelsUtil.getSmoothedAcceleratorAndBrakePedals ~= nil then
        originalGetSmoothedPedals = WheelsUtil.getSmoothedAcceleratorAndBrakePedals
        WheelsUtil.getSmoothedAcceleratorAndBrakePedals = function(self, acceleratorPedal, brakePedal, dt)
            if self ~= nil then
                WFS.registerVehicle(self)
                if WFS.isLocked(self) then
                    return 0, 1
                end
            end
            return originalGetSmoothedPedals(self, acceleratorPedal, brakePedal, dt)
        end
    end

    if WheelsUtil ~= nil and WheelsUtil.updateWheelsPhysics ~= nil then
        originalUpdateWheelsPhysics = WheelsUtil.updateWheelsPhysics
        WheelsUtil.updateWheelsPhysics = function(self, dt, currentSpeed, acceleration, doHandbrake, stopAndGoBraking)
            if self ~= nil then
                WFS.registerVehicle(self)
                updateBlocker(self)
                if WFS.isLocked(self) then
                    acceleration = 0
                    doHandbrake = true
                end
            end
            local result = originalUpdateWheelsPhysics(self, dt, currentSpeed, acceleration, doHandbrake, stopAndGoBraking)
            if self ~= nil and WFS.isLocked(self) then
                applyHardWheelLock(self)
            end
            return result
        end
    end

    if WheelsUtil ~= nil and WheelsUtil.updateWheelPhysics ~= nil then
        originalUpdateWheelPhysics = WheelsUtil.updateWheelPhysics
        WheelsUtil.updateWheelPhysics = function(self, wheel, doHandbrake, motorTorque, brakePedal, requiredDriveMode, dt)
            if self ~= nil then
                WFS.registerVehicle(self)
                updateBlocker(self)
                if WFS.isLocked(self) then
                    motorTorque = 0
                    brakePedal = 1
                    doHandbrake = true
                end
            end
            return originalUpdateWheelPhysics(self, wheel, doHandbrake, motorTorque, brakePedal, requiredDriveMode, dt)
        end
    end

    if setVehicleProps ~= nil then
        originalSetVehicleProps = setVehicleProps
        setVehicleProps = function(node, torque, maxDriveSpeed, gearRatio, maxClutchTorque, ...)
            local owner = WFS.nodeVehicles[node]
            if owner ~= nil and WFS.isLocked(owner) then
                torque = 0
                maxDriveSpeed = 0
                maxClutchTorque = 0
            end
            return originalSetVehicleProps(node, torque, maxDriveSpeed, gearRatio, maxClutchTorque, ...)
        end
    end

    if setWheelShapeProps ~= nil then
        originalSetWheelShapeProps = setWheelShapeProps
        setWheelShapeProps = function(node, wheelShape, motorTorque, brakeTorque, steerAngle, rotationDamping, ...)
            local owner = WFS.nodeVehicles[node] or WFS.shapeVehicles[wheelShape]
            if owner ~= nil and WFS.isLocked(owner) then
                motorTorque = 0
                local brakeForce = 0
                if owner.getBrakeForce ~= nil then
                    local ok, value = pcall(owner.getBrakeForce, owner)
                    if ok and tonumber(value) ~= nil then
                        brakeForce = tonumber(value)
                    end
                end
                local factor = 1
                if wheelShape ~= nil and owner.spec_wheels ~= nil and owner.spec_wheels.wheels ~= nil then
                    for _, w in pairs(owner.spec_wheels.wheels) do
                        if w ~= nil and (w.wheelShape == wheelShape or (w.physics ~= nil and w.physics.wheelShape == wheelShape)) then
                            factor = tonumber(w.brakeFactor) or 1
                            break
                        end
                    end
                end
                -- TEST0.2.2.110: add +100 to the actual wheel brake torque while locked.
                -- brakeFactor is intentionally back to its normal value (no x1000).
                brakeTorque = brakeTorque + 100
            end
            return originalSetWheelShapeProps(node, wheelShape, motorTorque, brakeTorque, steerAngle, rotationDamping, ...)
        end
    end

    WFS.installed = true
    print("[ReifenVerschleiss][EWFS] 5-second EWFS with direct per-vehicle controlVehicle gate. OFF=BLOCK, START=BLOCK+TIMER, +5000ms=RELEASE. VERSION=TEST2_3_29_EWFS_MANUAL_GAS_LOCK")
end
