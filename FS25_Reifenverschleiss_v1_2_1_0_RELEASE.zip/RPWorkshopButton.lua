-- Real Physics - Reifenverschleiß
-- TEST0.2.0.98
-- Adds an independent "RP Reifen wechseln" button to the GIANTS WorkshopScreen.
-- The button uses the native workshop button style as a visual template but
-- does NOT call GIANTS repair/repaint and does NOT depend on Enhanced Vehicle.

-- RELEASE: suppress development/diagnostic print output only.
-- Functional code paths remain identical to TEST2_3_136.
local function print(...)
end

RPWorkshopButton = {}
RPWorkshopButton._installed = false
RPWorkshopButton._hooked = false
RPWorkshopButton._actionEventId = nil
RPWorkshopButton._activeScreen = nil
RPWorkshopButton._menuContextName = nil
RPWorkshopButton._purchaseDialogOpen = false

-- Forward declaration: onClick() is defined before updateButtonState().
local updateButtonState

local RP_REIFEN_WECHSELN_ACTION = "RP_REIFEN_WECHSELN_021"
local RP_REIFEN_WECHSELN_MIN_WEAR = 0.0 -- Test build: replacement is always available when replaceable wear objects exist.

local function getActionInput()
    return InputAction ~= nil and InputAction[RP_REIFEN_WECHSELN_ACTION] or nil
end

function RPWorkshopButton:onActionEvent(actionName, inputValue, callbackState, isAnalog)
    if inputValue == nil or inputValue > 0 then
        local screen = RPWorkshopButton._activeScreen
        if screen ~= nil and screen._rvRPWorkshopButton ~= nil then
            RPWorkshopButton.onClick(screen)
        else
            print("[ReifenVerschleiss][WORKSHOP] RP Reifen wechseln action received, but no active WorkshopScreen exists.")
        end
    end
end

local function unregisterWorkshopAction(screen)
    if RPWorkshopButton._actionEventId ~= nil and g_inputBinding ~= nil then
        pcall(g_inputBinding.removeActionEvent, g_inputBinding, RPWorkshopButton._actionEventId)
        RPWorkshopButton._actionEventId = nil
    end
    if RPWorkshopButton._activeScreen == screen then
        RPWorkshopButton._activeScreen = nil
    end
end

local function registerWorkshopAction(screen)
    if screen == nil or g_inputBinding == nil then return end
    RPWorkshopButton._activeScreen = screen

    local action = getActionInput()
    if action == nil then
        print("[ReifenVerschleiss][WORKSHOP] Input action RP_REIFEN_WECHSELN_021 not available.")
        return
    end

    if RPWorkshopButton._actionEventId ~= nil then
        return
    end

    -- The callback must be registered with an explicit target. FS25 action
    -- events are not equivalent to the ButtonElement input glyph:
    -- setInputAction() only controls the displayed binding, while
    -- registerActionEvent() is what actually receives the configured key.
    -- Use the class table as target, matching the proven FS25 custom-action
    -- pattern.
    local success, eventId = g_inputBinding:registerActionEvent(
        action, RPWorkshopButton, RPWorkshopButton.onActionEvent, false, true, false, true
    )

    if success and eventId ~= nil then
        RPWorkshopButton._actionEventId = eventId
        g_inputBinding:setActionEventTextVisibility(eventId, false)
        print(string.format("[ReifenVerschleiss][WORKSHOP] RP menu action registered (event=%s).", tostring(eventId)))
    else
        print("[ReifenVerschleiss][WORKSHOP] RP menu action registration FAILED.")
    end
end

local function safeText(element)
    if element == nil then return "" end
    local value = element.text
    if type(value) == "string" then return value end
    if element.getText ~= nil then
        local ok, result = pcall(element.getText, element)
        if ok and type(result) == "string" then return result end
    end
    return ""
end

local function isButton(element)
    return element ~= nil and element.isa ~= nil and ButtonElement ~= nil and element:isa(ButtonElement)
end

local function findRepairButton(root)
    local result = nil
    local bestScore = -math.huge

    local function scan(element)
        if element == nil then return end
        if isButton(element) then
            local name = string.lower(tostring(element.name or ""))
            local id = string.lower(tostring(element.id or ""))
            local txt = string.lower(safeText(element))
            local score = 0
            if string.find(name, "repair", 1, true) or string.find(name, "repar", 1, true) then score = score + 100 end
            if string.find(id, "repair", 1, true) or string.find(id, "repar", 1, true) then score = score + 100 end
            if string.find(txt, "repair", 1, true) or string.find(txt, "repar", 1, true) then score = score + 100 end
            -- Prefer a normal workshop action button over tiny navigation buttons.
            if element.size ~= nil and element.size[1] ~= nil and element.size[1] > 0.05 then score = score + 10 end
            if score > bestScore then
                bestScore = score
                result = element
            end
        end
        for _, child in ipairs(element.elements or {}) do
            scan(child)
        end
    end

    scan(root)
    return result
end

local function isWearableVehicle(vehicle)
    return vehicle ~= nil and type(vehicle) == "table"
        and vehicle.spec_wearable ~= nil
end

local function getWorkshopVehicleList(screen)
    if screen == nil then
        return nil
    end

    local candidates = {
        screen.vehicles,
        screen._rvWorkshopVehicles,
        g_workshopScreen ~= nil and g_workshopScreen.vehicles or nil,
        g_workshopScreen ~= nil and g_workshopScreen._rvWorkshopVehicles or nil
    }

    for _, list in ipairs(candidates) do
        if type(list) == "table" and #list > 0 then
            return list
        end
    end

    return nil
end

local function isVehicleInWorkshopList(vehicle, vehicles)
    if vehicle == nil or type(vehicles) ~= "table" then
        return false
    end
    for _, candidate in ipairs(vehicles) do
        if candidate == vehicle then
            return true
        end
    end
    return false
end

local function getSelectedVehicleFromWorkshopList(screen, vehicles)
    if screen == nil or type(vehicles) ~= "table" or #vehicles == 0 then
        return nil
    end

    -- GIANTS keeps the actual workshop selection in the WorkshopScreen/list
    -- context. We deliberately resolve an index only against the exact list
    -- supplied to this screen. This is critical when 2-3 vehicles are in the
    -- workshop at the same time: owner.currentVehicles and the HUD's
    -- controlledVehicle are NOT valid selection sources.
    local indexCandidates = {
        screen.currentVehicleIndex,
        screen.vehicleIndex,
        screen.selectedVehicleIndex,
        screen.selectedIndex,
        screen.currentIndex,
        screen.vehicleSelectionIndex,
        screen.currentVehicleId
    }

    for _, index in ipairs(indexCandidates) do
        if type(index) == "number" then
            index = math.floor(index)
            if index >= 1 and index <= #vehicles then
                return vehicles[index]
            end
            -- Some list implementations expose a zero-based selected index.
            if index >= 0 and index < #vehicles then
                return vehicles[index + 1]
            end
        end
    end

    -- Some FS GUI list elements expose the selected item/index through a
    -- getter instead of a public screen field. Only accept a result that is
    -- one of the workshop's actual vehicles.
    local listObjects = {
        screen.vehicleList,
        screen.vehicleSelector,
        screen.vehicleListBox,
        screen.vehicleListElement,
        screen.vehicleSelectorElement
    }

    for _, listObject in ipairs(listObjects) do
        if type(listObject) == "table" then
            local getters = {
                "getSelectedItem", "getSelectedData", "getSelectedObject",
                "getSelectedVehicle", "getSelectedIndex"
            }
            for _, methodName in ipairs(getters) do
                local method = listObject[methodName]
                if type(method) == "function" then
                    local ok, value = pcall(method, listObject)
                    if ok then
                        if type(value) == "number" then
                            local idx = math.floor(value)
                            if idx >= 1 and idx <= #vehicles then
                                return vehicles[idx]
                            elseif idx >= 0 and idx < #vehicles then
                                return vehicles[idx + 1]
                            end
                        elseif isVehicleInWorkshopList(value, vehicles) then
                            return value
                        elseif type(value) == "table" then
                            local nested = {value.vehicle, value.object, value.data, value.item}
                            for _, candidate in ipairs(nested) do
                                if isVehicleInWorkshopList(candidate, vehicles) then
                                    return candidate
                                end
                            end
                        end
                    end
                end
            end
        end
    end

    -- A currentVehicle field is only accepted if it is actually one of the
    -- vehicles currently offered by this WorkshopScreen. This prevents the
    -- previous bug where the HUD's last controlled vehicle (e.g. T8) was used
    -- while the workshop selection was T9.
    if isVehicleInWorkshopList(screen.currentVehicle, vehicles) then
        return screen.currentVehicle
    end
    if isVehicleInWorkshopList(screen.selectedVehicle, vehicles) then
        return screen.selectedVehicle
    end
    if isVehicleInWorkshopList(screen._rvWorkshopSelectedVehicle, vehicles) then
        return screen._rvWorkshopSelectedVehicle
    end

    -- Never guess when several vehicles are present. A wrong reset is worse
    -- than a temporarily disabled button.
    if #vehicles == 1 then
        return vehicles[1]
    end

    return nil
end

local function getWorkshopVehicle(screen)
    local vehicles = getWorkshopVehicleList(screen)
    if vehicles == nil then
        return nil
    end

    return getSelectedVehicleFromWorkshopList(screen, vehicles)
end

local function getVehicleWearForButton(vehicle)
    if vehicle == nil then return 0 end

    local ownWear = 0
    if ReifenVerschleissDiagnostic ~= nil and ReifenVerschleissDiagnostic.getVehicleWearPercent ~= nil then
        local ok, value = pcall(ReifenVerschleissDiagnostic.getVehicleWearPercent, vehicle)
        if ok and type(value) == "number" and value == value then
            ownWear = math.clamp(value / 100, 0, 1)
        end
    end

    return ownWear
end

-- ============================================================================
-- TEST0.2.0.106: dynamische Preisgestaltung über Fahrzeuggewicht
-- ============================================================================
local RP_TIRE_BASE_PRICE_PER_REFERENCE = 1875
local RP_PRICE_REFERENCE_BASE_KM = 200
local RP_TIRE_REF_DIAMETER = 1.60
local RP_TIRE_REF_WIDTH = 0.60
local RP_TRACK_BASE_PRICE = 12500

-- TEST0.2.0.106: vehicle-weight price variation (displayed nowhere).
-- 0-5 t: -20% -> 0%; 5-10 t: 0%; 10-20 t: 0% -> +15%;
-- 20-50 t: +15% -> +25%; 50-100 t: +25% -> +50%; >100 t capped at +50%.
local function rvGetVehicleMassTons(vehicle)
    if vehicle == nil or vehicle.getTotalMass == nil then
        return nil
    end
    local ok, mass = pcall(vehicle.getTotalMass, vehicle, true)
    if ok and type(mass) == "number" and mass == mass and mass >= 0 and mass < math.huge then
        return mass
    end
    local ok2, mass2 = pcall(vehicle.getTotalMass, vehicle)
    if ok2 and type(mass2) == "number" and mass2 == mass2 and mass2 >= 0 and mass2 < math.huge then
        return mass2
    end
    return nil
end

local function rvSafeNumber(value, fallback)
    if type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge then
        return value
    end
    return fallback
end

local function rvGetWeightPriceFactor(massTons)
    local m = rvSafeNumber(massTons, 5)
    if m <= 5 then
        return -0.20 + (m / 5) * 0.20
    elseif m <= 10 then
        return 0.0
    elseif m <= 20 then
        return (m - 10) / 10 * 0.15
    elseif m <= 50 then
        return 0.15 + (m - 20) / 30 * 0.10
    elseif m <= 100 then
        return 0.25 + (m - 50) / 50 * 0.25
    end
    return 0.50
end

local function rvGetWheelSize(wheel)
    if wheel == nil or wheel.physics == nil then
        return 0, 0
    end
    local radius = rvSafeNumber(wheel.physics.radius, 0)
    local width = rvSafeNumber(wheel.physics.width, 0)
    if width <= 0 then
        width = rvSafeNumber(wheel.physics.wheelShapeWidth, 0)
    end
    return radius * 2, width
end

-- Count the actual mounted tire instances represented by one GIANTS wheel.
-- GIANTS can keep one physics wheel while visualWheels contains 2 or 3
-- mounted tires for dual/triple configurations. Those tires all wear and
-- therefore all have to be included in the purchase count and tire price.
local function rvGetMountedTireCount(wheel)
    if wheel == nil then
        return 0
    end

    local visualWheels = wheel.visualWheels
    if type(visualWheels) == "table" then
        local count = 0
        for _, visualWheel in pairs(visualWheels) do
            if visualWheel ~= nil then
                count = count + 1
            end
        end
        if count > 0 then
            return count
        end
    end

    -- A normal wheel without a populated visualWheels table still represents
    -- one mounted tire. Crawler wheels are filtered before this function is
    -- used, so they cannot become tires through this fallback.
    return 1
end

local function rvGetTireName(wheel)
    if wheel == nil then
        return "UNKNOWN"
    end
    if WheelsUtil ~= nil and wheel.tireType ~= nil then
        if WheelsUtil.getTireTypeName ~= nil then
            local ok, value = pcall(WheelsUtil.getTireTypeName, wheel.tireType)
            if ok and value ~= nil and tostring(value) ~= "unknown" then
                return tostring(value)
            end
        end
        if WheelsUtil.tireTypes ~= nil and WheelsUtil.tireTypes[wheel.tireType] ~= nil then
            local value = WheelsUtil.tireTypes[wheel.tireType].name
            if value ~= nil then
                return tostring(value)
            end
        end
    end
    if wheel.tireTypeName ~= nil then
        return tostring(wheel.tireTypeName)
    end
    return "UNKNOWN"
end

local function rvCategorizeTire(name)
    local n = string.lower(tostring(name or ""))
    if string.find(n, "forest", 1, true) or string.find(n, "forestry", 1, true) then
        return "Forst"
    end
    if string.find(n, "narrow", 1, true) or string.find(n, "row", 1, true) or string.find(n, "care", 1, true) or string.find(n, "crop", 1, true) then
        return "Pflege"
    end
    if string.find(n, "road", 1, true) or string.find(n, "street", 1, true) or string.find(n, "highway", 1, true) then
        return "Straße"
    end
    if string.find(n, "mud", 1, true) or string.find(n, "field", 1, true) or string.find(n, "agri", 1, true) or string.find(n, "tractor", 1, true) then
        return "Feld"
    end
    if string.find(n, "wide", 1, true) then
        return "Breitreifen"
    end
    return "Allround"
end

local function rvSizeClass(diameter, width)
    local d = rvSafeNumber(diameter, 0)
    local w = rvSafeNumber(width, 0)
    if d <= 0 then
        return "Mittel"
    end
    local score = (d / 1.60) * 0.70 + (w / 0.60) * 0.30
    if score < 0.65 then
        return "Klein"
    elseif score < 1.05 then
        return "Mittel"
    elseif score < 1.55 then
        return "Groß"
    end
    return "Riesig"
end

local function rvTrackSizeClass(length)
    local value = rvSafeNumber(length, 0)
    -- Keep the existing track price bands as the classification basis.
    -- Small compact tracks (<4 m) are explicitly Klein; this fixes compact
    -- loaders such as the Kubota SVL97-2, which previously could never be
    -- classified as Klein because the old function started at Mittel.
    if value > 0 and value < 4 then
        return "Klein"
    elseif value < 8 then
        return "Mittel"
    elseif value < 12 then
        return "Groß"
    end
    return "Riesig"
end

local function rvFormatMoney(amount)
    local value = math.floor(rvSafeNumber(amount, 0) + 0.5)
    if g_i18n ~= nil and g_i18n.formatMoney ~= nil then
        local ok, result = pcall(g_i18n.formatMoney, g_i18n, value, 0, true)
        if ok and type(result) == "string" then
            return result
        end
    end
    return string.format("%d €", value)
end

local function rvAddUnique(list, seen, wheel)
    if wheel ~= nil and not seen[wheel] then
        seen[wheel] = true
        list[#list + 1] = wheel
    end
end

local function rvIsCrawlerTire(wheel)
    if wheel == nil or WheelsUtil == nil or WheelsUtil.getTireType == nil then
        return false
    end
    local crawlerType = WheelsUtil.getTireType("crawler")
    return crawlerType ~= nil and wheel.tireType == crawlerType
end

-- Resolve the actual crawler wheel members using the same GIANTS structures
-- already used by the diagnostic path. A crawler wheel must not subsequently
-- be counted as a normal tire.
local function rvGetCrawlerMembers(vehicle, crawler, allWheels)
    local members = {}
    local seen = {}
    if crawler == nil then
        return members
    end

    if crawler.wheels ~= nil then
        for _, wheelData in pairs(crawler.wheels) do
            local wheel = wheelData ~= nil and wheelData.wheel or nil
            rvAddUnique(members, seen, wheel)
        end
    end

    if crawler.wheelNodes ~= nil then
        for _, node in pairs(crawler.wheelNodes) do
            if node ~= nil then
                for _, wheel in pairs(allWheels or {}) do
                    if wheel ~= nil and (wheel.repr == node or wheel.driveNode == node or wheel.linkNode == node) then
                        rvAddUnique(members, seen, wheel)
                    end
                end
            end
        end
    end

    if crawler.wheelIndices ~= nil then
        for _, index in pairs(crawler.wheelIndices) do
            rvAddUnique(members, seen, allWheels[index])
        end
    end

    -- Defensive recovery when the runtime exposes only one crawler reference wheel.
    if #members == 1 and crawler.wheelIndices == nil and crawler.wheelNodes == nil then
        local reference = members[1]
        local referenceIndex = reference ~= nil and reference.wheelIndex or nil
        if referenceIndex ~= nil then
            local sideSign = crawler.isLeft == true and -1 or 1
            if crawler.linkNode ~= nil and vehicle ~= nil and vehicle.rootNode ~= nil and localToLocal ~= nil then
                local ok, x = pcall(localToLocal, crawler.linkNode, vehicle.rootNode, 0, 0, 0)
                if ok and x ~= nil and math.abs(x) > 0.02 then
                    sideSign = x < 0 and -1 or 1
                end
            end
            local i = referenceIndex + 1
            while allWheels[i] ~= nil do
                local candidate = allWheels[i]
                if candidate.repr == nil then
                    break
                end
                local ok, x = true, nil
                if localToLocal ~= nil and vehicle ~= nil and vehicle.rootNode ~= nil then
                    ok, x = pcall(localToLocal, candidate.repr, vehicle.rootNode, 0, 0, 0)
                end
                if not ok or x == nil or x * sideSign <= 0.02 then
                    break
                end
                rvAddUnique(members, seen, candidate)
                i = i + 1
            end
        end
    end

    -- Last-resort recovery: only crawler-typed wheels are eligible.
    if #members == 0 then
        local sideSign = crawler.isLeft == true and -1 or 1
        local candidates = {}
        for _, wheel in pairs(allWheels or {}) do
            if wheel ~= nil and wheel.repr ~= nil and rvIsCrawlerTire(wheel) and localToLocal ~= nil and vehicle ~= nil and vehicle.rootNode ~= nil then
                local ok, x, _, z = pcall(localToLocal, wheel.repr, vehicle.rootNode, 0, 0, 0)
                if ok and x ~= nil and z ~= nil and x * sideSign > 0.02 then
                    candidates[#candidates + 1] = {wheel = wheel, z = z}
                end
            end
        end
        table.sort(candidates, function(a, b) return (a.z or 0) > (b.z or 0) end)
        for _, candidate in ipairs(candidates) do
            rvAddUnique(members, seen, candidate.wheel)
        end
    end
    return members
end

local function rvGetLocalZ(vehicle, wheel)
    if vehicle == nil or vehicle.rootNode == nil or wheel == nil or wheel.node == nil or localToLocal == nil then
        return nil
    end
    local ok, _, _, z = pcall(localToLocal, wheel.node, vehicle.rootNode, 0, 0, 0)
    if ok then
        return z
    end
    return nil
end

local function rvEstimateTrackSize(vehicle, crawler, members)
    local minZ = math.huge
    local maxZ = -math.huge
    local maxRadius = 0
    local maxWidth = 0
    local count = 0

    for _, wheel in ipairs(members or {}) do
        local z = rvGetLocalZ(vehicle, wheel)
        if z ~= nil then
            minZ = math.min(minZ, z)
            maxZ = math.max(maxZ, z)
        end
        local diameter, width = rvGetWheelSize(wheel)
        maxRadius = math.max(maxRadius, diameter * 0.5)
        maxWidth = math.max(maxWidth, width)
        count = count + 1
    end

    local length = 0
    if minZ ~= math.huge and maxZ ~= -math.huge then
        length = (maxZ - minZ) + maxRadius * 2
    end
    if length <= 0 and crawler ~= nil and crawler.length ~= nil then
        length = rvSafeNumber(crawler.length, 0)
    end
    return length, maxWidth, count
end

function RPWorkshopButton.getPurchaseInfo(vehicle)
    if ReifenVerschleissDiagnostic ~= nil
        and ReifenVerschleissDiagnostic.isVehicleExcluded ~= nil
        and ReifenVerschleissDiagnostic.isVehicleExcluded(vehicle) then
        return nil
    end
    local info = {
        tireCount = 0,
        trackCount = 0,
        innerWheelCount = 0,
        tireDiameter = 0,
        tireWidth = 0,
        trackLength = 0,
        trackWidth = 0,
        tireType = "Allround",
        tireSizeClass = "Mittel",
        trackSizeClass = "Mittel",
        tirePrice = 0,
        trackPrice = 0,
        totalPrice = 0,
        vehicleMassTons = nil,
        weightPriceFactor = 0,
        hasTires = false,
        hasTracks = false
    }

    if vehicle == nil or vehicle.spec_wheels == nil or vehicle.spec_wheels.wheels == nil then
        return info
    end

    local crawlerAssigned = {}
    local crawlerTireTypes = {}
    local crawlers = vehicle.spec_crawlers ~= nil and vehicle.spec_crawlers.crawlers or nil

    if crawlers ~= nil then
        for _, crawler in ipairs(crawlers) do
            local members = rvGetCrawlerMembers(vehicle, crawler, vehicle.spec_wheels.wheels)
            for _, wheel in ipairs(members) do
                crawlerAssigned[wheel] = true
                if wheel.wheelIndex ~= nil then
                    crawlerAssigned[wheel.wheelIndex] = true
                end

                -- Do not depend exclusively on WheelsUtil.getTireType("crawler").
                -- Some crawler implementations expose the correct native tireType
                -- value on their wheel objects, while the helper lookup does not
                -- resolve that value reliably at runtime. The crawler members
                -- themselves are the structural reference: any other wheel with
                -- the same native tireType belongs to the same crawler system and
                -- must not be counted as a normal tire.
                if wheel.tireType ~= nil then
                    crawlerTireTypes[wheel.tireType] = true
                end
            end
            local length, width, memberCount = rvEstimateTrackSize(vehicle, crawler, members)
            info.trackCount = info.trackCount + 1
            info.innerWheelCount = info.innerWheelCount + memberCount
            info.trackLength = math.max(info.trackLength, length)
            info.trackWidth = math.max(info.trackWidth, width)
        end
    end

    local tireNames = {}
    for index, wheel in pairs(vehicle.spec_wheels.wheels) do
        local isCrawler = crawlerAssigned[wheel] or crawlerAssigned[index]
        if not isCrawler and wheel ~= nil and wheel.wheelIndex ~= nil then
            isCrawler = crawlerAssigned[wheel.wheelIndex]
        end
        if not isCrawler and wheel ~= nil and rvIsCrawlerTire(wheel) then
            isCrawler = true
        end
        if not isCrawler and wheel ~= nil and wheel.tireType ~= nil and crawlerTireTypes[wheel.tireType] then
            isCrawler = true
        end
        if not isCrawler and wheel ~= nil then
            local diameter, width = rvGetWheelSize(wheel)
            if diameter > 0 and width > 0 then
                local mountedTireCount = rvGetMountedTireCount(wheel)
                info.tireCount = info.tireCount + mountedTireCount
                info.tireDiameter = math.max(info.tireDiameter, diameter)
                info.tireWidth = math.max(info.tireWidth, width)
                tireNames[#tireNames + 1] = rvGetTireName(wheel)
            end
        end
    end

    info.hasTires = info.tireCount > 0
    info.hasTracks = info.trackCount > 0
    info.rollerCount=0; info.rubberTrackCount=0; info.steelTrackCount=0
    if info.hasTracks and ReifenVerschleissDiagnostic~=nil
        and ReifenVerschleissDiagnostic.getRunningGearServiceInfo~=nil then
        local ok,rg=pcall(ReifenVerschleissDiagnostic.getRunningGearServiceInfo,vehicle)
        if ok and type(rg)=="table" then
            info.rollerCount=math.max(0,math.floor(rvSafeNumber(rg.rollerCount,0)))
            info.rubberTrackCount=math.max(0,math.floor(rvSafeNumber(rg.rubberTrackCount,0)))
            info.steelTrackCount=math.max(0,math.floor(rvSafeNumber(rg.steelTrackCount,0)))
        end
    end
    if #tireNames > 0 then
        info.tireType = rvCategorizeTire(tireNames[1])
    end

    info.tireSizeClass = rvSizeClass(info.tireDiameter, info.tireWidth)
    info.trackSizeClass = rvTrackSizeClass(info.trackLength)

    if info.hasTires then
        local referencePriceFactor = 1.0
        local referencePriceKm = 200
        if RPReferenceSettings ~= nil and RPReferenceSettings.getPriceReferenceSnapshot ~= nil then
            referencePriceKm, referencePriceFactor = RPReferenceSettings.getPriceReferenceSnapshot()
            referencePriceFactor = math.max(0.01, tonumber(referencePriceFactor) or 1.0)
        end
        local perTire = RP_TIRE_BASE_PRICE_PER_REFERENCE
            * referencePriceFactor
            * math.pow(math.max(info.tireDiameter, 0.1) / RP_TIRE_REF_DIAMETER, 1.20)
            * math.pow(math.max(info.tireWidth, 0.1) / RP_TIRE_REF_WIDTH, 0.80)
        info.tirePrice = math.floor(info.tireCount * perTire / 50 + 0.5) * 50
    end

    if info.hasTracks then
        local length = info.trackLength
        local sizeFactor = 1.0
        if length > 0 and length < 4 then
            sizeFactor = 0.60
        elseif length < 6 then
            sizeFactor = 0.75
        elseif length < 8 then
            sizeFactor = 0.90
        elseif length < 10 then
            sizeFactor = 1.00
        elseif length < 12 then
            sizeFactor = 1.08
        elseif length >= 12 then
            sizeFactor = 1.15
        end
        local wheelsPerTrack = info.innerWheelCount / math.max(info.trackCount, 1)
        local wheelFactor = math.clamp(1.0 + (wheelsPerTrack - 3) * 0.04, 0.85, 1.20)
        local referencePriceFactor = 1.0
        local referencePriceKm = 200
        if RPReferenceSettings ~= nil and RPReferenceSettings.getPriceReferenceSnapshot ~= nil then
            referencePriceKm, referencePriceFactor = RPReferenceSettings.getPriceReferenceSnapshot()
            referencePriceFactor = math.max(0.01, tonumber(referencePriceFactor) or 1.0)
        end
        info.trackPrice = math.floor(info.trackCount * RP_TRACK_BASE_PRICE * referencePriceFactor * sizeFactor * wheelFactor / 50 + 0.5) * 50
    end

    local baseTotal = info.tirePrice + info.trackPrice
    info.priceReferenceKm = 200
    info.priceReferenceFactor = 1.0
    if RPReferenceSettings ~= nil and RPReferenceSettings.getPriceReferenceSnapshot ~= nil then
        info.priceReferenceKm, info.priceReferenceFactor = RPReferenceSettings.getPriceReferenceSnapshot()
        info.priceReferenceFactor = math.max(0.01, tonumber(info.priceReferenceFactor) or 1.0)
    end
    info.vehicleMassTons = rvGetVehicleMassTons(vehicle)
    info.weightPriceFactor = rvGetWeightPriceFactor(info.vehicleMassTons)
    info.totalPrice = math.floor(baseTotal * (1 + info.weightPriceFactor) / 50 + 0.5) * 50
    -- TEST2.3.129 pricing:
    -- * complete purchase keeps the proven totalPrice unchanged
    -- * tire-only contribution is the weighted tire share
    -- * on tracked running gear, its remaining price share is split 50:50
    --   between band/chain and rollers
    local weightedTirePrice = math.floor(info.tirePrice * (1 + info.weightPriceFactor) / 50 + 0.5) * 50
    info.tireOnlyPrice = info.hasTires and math.min(info.totalPrice, weightedTirePrice) or 0

    if info.hasTracks and info.rollerCount > 0 then
        local runningGearPrice = math.max(0, info.totalPrice - info.tireOnlyPrice)
        info.trackOnlyPrice = math.floor((runningGearPrice * 0.5) / 50 + 0.5) * 50
        info.rollerOnlyPrice = math.max(0, runningGearPrice - info.trackOnlyPrice)
    elseif info.hasTracks then
        info.trackOnlyPrice = math.max(0, info.totalPrice - info.tireOnlyPrice)
        info.rollerOnlyPrice = 0
    else
        info.trackOnlyPrice = 0
        info.rollerOnlyPrice = 0
        info.tireOnlyPrice = info.totalPrice
    end

    print(string.format("[ReifenVerschleiss][WORKSHOP] Dynamic price: reference=%skm | refPriceFactor=%.3f | mass=%s t | weightFactor=%+.1f%% | base=%s | total=%s",
        RPReferenceSettings ~= nil and tostring(RPReferenceSettings.getReferenceKm()) or "200",
        RPReferenceSettings ~= nil and tonumber(RPReferenceSettings.getPriceReferenceFactor()) or 1.0,
        info.vehicleMassTons ~= nil and string.format("%.2f", info.vehicleMassTons) or "?",
        info.weightPriceFactor * 100,
        rvFormatMoney(baseTotal),
        rvFormatMoney(info.totalPrice)))
    print(string.format("[ReifenVerschleiss][WORKSHOP][PRICE-REFERENCE] selectedKm=%d | priceFactor=%.3f | expectedFactorForSelectedKm=%.3f",
        tonumber(info.priceReferenceKm) or 200,
        tonumber(info.priceReferenceFactor) or 1.0,
        RPReferenceSettings ~= nil and RPReferenceSettings.getPriceReferenceFactorForKm ~= nil and RPReferenceSettings.getPriceReferenceFactorForKm(info.priceReferenceKm) or 1.0))
    return info
end

local function rvPurchaseText(info)
    local lines = {}
    lines[#lines + 1] = ""

    -- Only show components that were actually detected.
    -- Inner running wheels of tracked vehicles are NOT tires.
    if info.hasTires then
        lines[#lines + 1] = "Erkannt: Reifen"
        if info.tireType ~= nil and info.tireType ~= "" then
            lines[#lines + 1] = string.format("Erkannt: Reifentyp %s", info.tireType)
        end
    end

    if info.hasTracks then
        if (info.innerWheelCount or 0) > 0 then
            lines[#lines + 1] = "Erkannt: innere Laufrollen"
        end
        if (info.trackCount or 0) > 0 then
            lines[#lines + 1] = "Erkannt: Antriebsbänder"
        end
    end

    lines[#lines + 1] = ""

    local totalParts = {}
    if info.hasTires and (info.tireCount or 0) > 0 then
        totalParts[#totalParts + 1] = string.format("%d Reifen", info.tireCount)
    end
    if info.hasTracks and (info.innerWheelCount or 0) > 0 then
        totalParts[#totalParts + 1] = string.format("%d innere Laufrollen", info.innerWheelCount)
    end
    if info.hasTracks and (info.trackCount or 0) > 0 then
        totalParts[#totalParts + 1] = string.format("%d Antriebsbänder", info.trackCount)
    end
    if #totalParts > 0 then
        lines[#lines + 1] = "Insgesamt: " .. table.concat(totalParts, " + ")
    end

    local classification = nil
    if info.hasTracks then
        classification = info.trackSizeClass
    elseif info.hasTires then
        classification = info.tireSizeClass
    end
    if classification ~= nil and classification ~= "" then
        lines[#lines + 1] = "Klassifizierung: " .. classification
    end

    lines[#lines + 1] = ""
    lines[#lines + 1] = "Gesamtpreis: " .. rvFormatMoney(info.totalPrice)
    if info.hasTracks then
        local trackLabel="Band/Kette"
        if (info.steelTrackCount or 0)>0 and (info.rubberTrackCount or 0)<=0 then trackLabel="Kette"
        elseif (info.rubberTrackCount or 0)>0 and (info.steelTrackCount or 0)<=0 then trackLabel="Band" end
        if info.hasTires then
            lines[#lines + 1] = string.format("Räder/Reifen kaufen: %s",rvFormatMoney(info.tireOnlyPrice))
        end
        lines[#lines + 1] = string.format("%s kaufen: %s",trackLabel,rvFormatMoney(info.trackOnlyPrice))
        lines[#lines + 1] = string.format("Laufrollen kaufen: %s",rvFormatMoney(info.rollerOnlyPrice))
    end
    lines[#lines + 1] = ""

    if info.hasTires and info.hasTracks then
        lines[#lines + 1] = "Wollen Sie die Reifen/Fahrwerke kaufen?"
    elseif info.hasTracks then
        lines[#lines + 1] = "Wollen Sie die Fahrwerke kaufen?"
    else
        lines[#lines + 1] = "Wollen Sie die Reifen kaufen?"
    end
    return table.concat(lines, "\n")
end

local function rvModePrice(info, mode)
    if info == nil then return 0 end
    mode = tostring(mode or "ALL")
    if mode == "WHEELS" then return rvSafeNumber(info.tireOnlyPrice, 0) end
    if mode == "TRACKS" then return rvSafeNumber(info.trackOnlyPrice, 0) end
    if mode == "ROLLERS" then return rvSafeNumber(info.rollerOnlyPrice, 0) end
    return rvSafeNumber(info.totalPrice, 0)
end

local function rvDeleteDialogExtraButtons()
    for _, button in ipairs(RPWorkshopButton._dialogExtraButtons or {}) do
        if button ~= nil and button.delete ~= nil then
            pcall(button.delete, button)
        end
    end
    RPWorkshopButton._dialogExtraButtons = {}
end

local function rvClosePurchaseDialog(target)
    rvDeleteDialogExtraButtons()
    RPWorkshopButton._purchaseDialogOpen = false
    if target ~= nil and target.close ~= nil then
        pcall(target.close, target)
    elseif g_gui ~= nil and g_gui.closeDialogByName ~= nil then
        pcall(g_gui.closeDialogByName, g_gui, "YesNoDialog")
    end
end

local function rvExecuteModePurchase(vehicle, mode, expectedPrice)
    if vehicle == nil then return false end
    mode = tostring(mode or "ALL")

    local info = RPWorkshopButton.getPurchaseInfo(vehicle)
    local price = rvModePrice(info, mode)
    if info == nil or price <= 0 then
        print(string.format("[ReifenVerschleiss][WORKSHOP129] unavailable mode=%s", mode))
        return false
    end

    if expectedPrice ~= nil and math.abs(price-rvSafeNumber(expectedPrice,price))>0.01 then
        print(string.format("[ReifenVerschleiss][WORKSHOP129] price changed mode=%s old=%s new=%s",
            mode,tostring(expectedPrice),tostring(price)))
    end

    if RPReifenWechselnEvent == nil or RPReifenWechselnEvent.executePurchase == nil then
        print("[ReifenVerschleiss][WORKSHOP129] purchase event unavailable")
        return false
    end

    local result = RPReifenWechselnEvent.executePurchase(vehicle, mode)
    print(string.format(
        "[ReifenVerschleiss][WORKSHOP129] request mode=%s vehicle=%s price=%s result=%s",
        mode,
        tostring(vehicle.configFileName or vehicle.typeName or "UNKNOWN"),
        tostring(price),
        tostring(result)
    ))
    return result
end

local function rvCollectDialogButtons(element, result)
    if element == nil then return end
    if isButton(element) then result[#result+1]=element end
    for _, child in ipairs(element.elements or {}) do
        rvCollectDialogButtons(child,result)
    end
end

local function rvFindDialogButtonByText(dialogRoot, wanted)
    local buttons={}
    rvCollectDialogButtons(dialogRoot,buttons)
    wanted=string.lower(tostring(wanted or ""))
    for _,button in ipairs(buttons) do
        if string.lower(safeText(button))==wanted then
            return button
        end
    end
    return nil
end

local function rvBindDialogButton(button, callback)
    if button == nil then return end
    button.target = RPWorkshopButton
    button.onClickCallback = callback
    button.inputActionName = nil
end

local function rvInstallTrackedPurchaseButtons(dialog, vehicle, info)
    if dialog == nil or dialog.target == nil then return false end

    rvDeleteDialogExtraButtons()

    local target=dialog.target
    if target.setButtonTexts ~= nil then
        target:setButtonTexts("ALLES","ZURÜCK")
    end

    local allButton=rvFindDialogButtonByText(dialog,"ALLES")
    local backButton=rvFindDialogButtonByText(dialog,"ZURÜCK")
    if allButton==nil or backButton==nil or allButton.parent==nil then
        print(string.format("[ReifenVerschleiss][WORKSHOP129] native buttons missing all=%s back=%s",
            tostring(allButton),tostring(backButton)))
        return false
    end

    -- CRITICAL .129 fix:
    -- Never replace the direct callbacks on the two native YesNo buttons.
    -- The YesNoDialog instance is reused by GIANTS. In .126/.128 those direct
    -- callbacks survived into later tire-only dialogs, which is why tire
    -- purchase stopped working. ALL/BACK now remain fully native and use the
    -- dialog's normal target:setCallback() path.
    local parent=allButton.parent
    local extras={}

    local function cloneComponentButton(name,label,mode,price)
        local b=allButton:clone(parent,false,true)
        if b==nil then return nil end
        b.name=name; b.id=nil; b:setText(label)
        rvBindDialogButton(b,function()
            rvClosePurchaseDialog(target)
            rvExecuteModePurchase(vehicle,mode,price)
        end)
        extras[#extras+1]=b
        return b
    end

    if info.hasTires and info.hasTracks then
        cloneComponentButton("rvBuyWheels","RÄDER/REIFEN","WHEELS",info.tireOnlyPrice)
    end

    local trackLabel="BAND/KETTE"
    if (info.steelTrackCount or 0)>0 and (info.rubberTrackCount or 0)<=0 then
        trackLabel="KETTE"
    elseif (info.rubberTrackCount or 0)>0 and (info.steelTrackCount or 0)<=0 then
        trackLabel="BAND"
    end

    cloneComponentButton("rvBuyTrack",trackLabel,"TRACKS",info.trackOnlyPrice)
    cloneComponentButton("rvBuyRollers","LAUFROLLEN","ROLLERS",info.rollerOnlyPrice)

    RPWorkshopButton._dialogExtraButtons=extras
    if parent.invalidateLayout~=nil then parent:invalidateLayout() end

    print(string.format(
        "[ReifenVerschleiss][WORKSHOP129] buttons ready all=%s wheels=%s track=%s rollers=%s extras=%d",
        tostring(info.totalPrice),tostring(info.tireOnlyPrice),tostring(info.trackOnlyPrice),
        tostring(info.rollerOnlyPrice),#extras))
    return true
end

function RPWorkshopButton:onDialogResult(yes,args)
    rvDeleteDialogExtraButtons()
    RPWorkshopButton._purchaseDialogOpen=false
    if not yes or args==nil or args.vehicle==nil then return end
    rvExecuteModePurchase(args.vehicle,"ALL",args.price)
end

function RPWorkshopButton:onClick()
    local screen=self
    if RPWorkshopButton._purchaseDialogOpen then return end

    local vehicle=getWorkshopVehicle(screen)
    if vehicle==nil then return end

    local info=RPWorkshopButton.getPurchaseInfo(vehicle)
    if info==nil or info.totalPrice<=0 then return end

    rvDeleteDialogExtraButtons()

    local title="ÜBERSICHT UND PREISAUFLISTUNG"
    local text=rvPurchaseText(info)

    if g_gui==nil or g_gui.showDialog==nil then return end

    RPWorkshopButton._purchaseDialogOpen=true
    local dialog=g_gui:showDialog("YesNoDialog")
    if dialog==nil or dialog.target==nil then
        RPWorkshopButton._purchaseDialogOpen=false
        return
    end

    local target=dialog.target
    if target.setText~=nil then target:setText(text) end
    if target.setTitle~=nil then target:setTitle(title) end
    if target.setDialogType~=nil and DialogElement~=nil and DialogElement.TYPE_QUESTION~=nil then
        target:setDialogType(DialogElement.TYPE_QUESTION)
    end

    if target.setCallback~=nil then
        target:setCallback(RPWorkshopButton.onDialogResult,RPWorkshopButton,{
            vehicle=vehicle,price=info.totalPrice
        })
    end

    if info.hasTracks and (info.rollerCount or 0)>0 then
        if not rvInstallTrackedPurchaseButtons(dialog,vehicle,info) then
            if target.setButtonTexts~=nil then target:setButtonTexts("KAUFEN","ZURÜCK") end
        end
    else
        if target.setButtonTexts~=nil then target:setButtonTexts("KAUFEN","ZURÜCK") end
    end

    print("[ReifenVerschleiss][WORKSHOP129] proven native overview opened")
end

updateButtonState = function(screen)
    local button = screen._rvRPWorkshopButton
    if button == nil then return end
    local vehicle = getWorkshopVehicle(screen)
    local relevant = isWearableVehicle(vehicle)
    local info = relevant and RPWorkshopButton.getPurchaseInfo(vehicle) or nil
    local enabled = relevant and info ~= nil and info.totalPrice > 0
    button:setDisabled(not enabled)
    button:setVisible(true)

    if enabled then
        local label = info.hasTracks and info.hasTires and "RP Reifen + Fahrwerk wechseln"
            or (info.hasTracks and "RP Fahrwerk wechseln" or "RP Reifen wechseln")
        button:setText(label)
    else
        button:setText("RP Reifen wechseln")
    end

    local lastEnabled = button._rvEnabled
    if lastEnabled ~= enabled then
        button._rvEnabled = enabled
        print(string.format("[ReifenVerschleiss][WORKSHOP] RP button state: vehicle=%s enabled=%s price=%s", tostring(vehicle ~= nil and (vehicle.configFileName or vehicle.typeName or "UNKNOWN") or "NONE"), tostring(enabled), tostring(info ~= nil and info.totalPrice or 0)))
    end
end

local function installButton(screen)
    if screen == nil or screen._rvRPWorkshopButton ~= nil then
        updateButtonState(screen)
        return
    end

    local template = findRepairButton(screen)
    if template == nil then
        print("[ReifenVerschleiss][WORKSHOP] Could not find a native workshop action button to clone.")
        return
    end

    local parent = template.parent
    if parent == nil then
        print("[ReifenVerschleiss][WORKSHOP] Native workshop button has no parent.")
        return
    end

    local button = template:clone(parent, false, true)
    button.name = "rvRPReifenWechseln"
    button.id = nil
    button.target = screen
    button.onClickCallback = function() RPWorkshopButton.onClick(screen) end

    -- ButtonElement:clone() copies inputActionName from the repair button.
    -- That is why .21 still displayed the GIANTS repair key (C) on the new
    -- button. Replace the inherited glyph source with our own configurable
    -- RP action so the workshop button always shows the same binding that is
    -- configured under Game Settings -> Controls.
    if button.setInputAction ~= nil then
        button:setInputAction(RP_REIFEN_WECHSELN_ACTION)
    else
        button.inputActionName = RP_REIFEN_WECHSELN_ACTION
    end

    button:setText("RP Reifen wechseln")
    button:setDisabled(false)
    button:setVisible(true)

    -- Place the cloned action after the existing workshop action buttons.
    -- Do not use a fixed offset from the repair button: the workshop GUI is
    -- laid out dynamically and the old approach could overlap on first open.
    local maxRight = template.position[1] + template.size[1]
    local rowY = template.position[2]
    local rowHeight = template.size[2]
    local rowTolerance = math.max(0.005, rowHeight * 0.35)
    for _, sibling in ipairs(parent.elements or {}) do
        if sibling ~= button and sibling ~= template and isButton(sibling) and sibling.position ~= nil and sibling.size ~= nil then
            if math.abs((sibling.position[2] or 0) - rowY) <= rowTolerance then
                local right = sibling.position[1] + sibling.size[1]
                if right > maxRight then
                    maxRight = right
                end
            end
        end
    end

    local spacing = 0.012
    local x = maxRight + spacing
    local y = rowY

    -- If the action would leave the visible row, put it directly below the
    -- action row instead of overlapping an existing button.
    if x + button.size[1] > 0.98 then
        x = template.position[1]
        y = rowY + rowHeight + spacing
    end

    button:setPosition(x, y)
    button:updateAbsolutePosition()
    if parent.invalidateLayout ~= nil then
        parent:invalidateLayout()
    end

    screen._rvRPWorkshopButton = button
    print("[ReifenVerschleiss][WORKSHOP] Added independent button: RP Reifen wechseln (TEST2.3.00)")
    local updateFn = updateButtonState
    updateFn(screen)
end

local function hookGuiMenuContext()
    -- No global GUI hook is required. The action is registered exactly when
    -- WorkshopScreen is opened, while the native menu context is active.
    return true
end

local function captureWorkshopVehicleList(screen, vehicles)
    if screen == nil or type(vehicles) ~= "table" then
        return
    end

    screen._rvWorkshopVehicles = vehicles
    -- Do not copy or reorder the list. GIANTS owns the selection order; our
    -- code must operate on exactly the same table/order as the WorkshopScreen.
    if #vehicles == 1 then
        screen._rvWorkshopSelectedVehicle = vehicles[1]
    end
end

local function hookWorkshopVehicleSelection()
    if WorkshopScreen == nil then
        return
    end

    if WorkshopScreen.setVehicles ~= nil and not WorkshopScreen._rvVehicleListHooked then
        WorkshopScreen._rvVehicleListHooked = true
        WorkshopScreen.setVehicles = Utils.appendedFunction(
            WorkshopScreen.setVehicles,
            function(screen, vehicles)
                captureWorkshopVehicleList(screen, vehicles)
            end
        )
    end

    if WorkshopScreen.updateVehicles ~= nil and not WorkshopScreen._rvVehicleUpdateHooked then
        WorkshopScreen._rvVehicleUpdateHooked = true
        WorkshopScreen.updateVehicles = Utils.appendedFunction(
            WorkshopScreen.updateVehicles,
            function(screen, vehicles)
                captureWorkshopVehicleList(screen, vehicles)
            end
        )
    end

    -- If the current FS25 WorkshopScreen exposes a setVehicle-style selector,
    -- mirror only the selected vehicle. The selected object is still validated
    -- against screen._rvWorkshopVehicles before it can be used for a reset.
    for _, methodName in ipairs({"setVehicle", "setSelectedVehicle", "setCurrentVehicle"}) do
        local method = WorkshopScreen[methodName]
        local flag = "_rv" .. methodName .. "Hooked"
        if method ~= nil and not WorkshopScreen[flag] then
            WorkshopScreen[methodName] = Utils.appendedFunction(
                method,
                function(screen, value)
                    local vehicles = getWorkshopVehicleList(screen)
                    if type(value) == "number" and type(vehicles) == "table" then
                        local idx = math.floor(value)
                        if idx >= 1 and idx <= #vehicles then
                            screen._rvWorkshopSelectedVehicle = vehicles[idx]
                        elseif idx >= 0 and idx < #vehicles then
                            screen._rvWorkshopSelectedVehicle = vehicles[idx + 1]
                        end
                    elseif isVehicleInWorkshopList(value, vehicles) then
                        screen._rvWorkshopSelectedVehicle = value
                    end
                end
            )
        end
    end
end

local function hookWorkshopScreen()
    if RPWorkshopButton._hooked or WorkshopScreen == nil then return false end
    RPWorkshopButton._hooked = true

    hookWorkshopVehicleSelection()

    if WorkshopScreen.onOpen ~= nil then
        WorkshopScreen.onOpen = Utils.appendedFunction(
            WorkshopScreen.onOpen,
            function(screen)
                installButton(screen)
                registerWorkshopAction(screen)
            end
        )
    end

    if WorkshopScreen.update ~= nil then
        WorkshopScreen.update = Utils.appendedFunction(
            WorkshopScreen.update,
            function(screen)
                if screen._rvRPWorkshopButton == nil then
                    installButton(screen)
                else
                    updateButtonState(screen)
                    registerWorkshopAction(screen)
                end
            end
        )
    end

    if WorkshopScreen.onClose ~= nil then
        WorkshopScreen.onClose = Utils.appendedFunction(
            WorkshopScreen.onClose,
            function(screen)
                unregisterWorkshopAction(screen)
                if screen._rvRPWorkshopButton ~= nil then
                    screen._rvRPWorkshopButton:delete()
                    screen._rvRPWorkshopButton = nil
                end
            end
        )
    end

    print("[ReifenVerschleiss][WORKSHOP] WorkshopScreen hooks installed (TEST2.3.00).")
    return true
end

function RPWorkshopButton.install()
    if RPWorkshopButton._installed then return end
    local guiOk = hookGuiMenuContext()
    local workshopOk = hookWorkshopScreen()
    if guiOk and workshopOk then
        RPWorkshopButton._installed = true
    end
end
