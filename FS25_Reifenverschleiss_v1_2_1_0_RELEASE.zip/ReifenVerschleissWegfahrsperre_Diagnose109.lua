-- FS25_Reifenverschleiss TEST0.2.2.109
-- Erweiterte Diagnose: Motor-/Blocker-/Getriebe-/Bremszustände
-- Diese Datei verändert KEINE Fahrzeugphysik und keine Sperrwerte.
-- Sie ist für die zeitliche Korrelation mit einem Testvideo gedacht.

local EWFS_Diag109 = {}

EWFS_Diag109.VERSION = "TEST2_3_30_EWFS_ALL_GAS_PATHS"
EWFS_Diag109.INTERVAL_MS = 100
EWFS_Diag109.lastLogTime = {}
EWFS_Diag109.lastGear = {}
EWFS_Diag109.lastTargetGear = {}
EWFS_Diag109.lastMotorState = {}
EWFS_Diag109.lastBlocker = {}
EWFS_Diag109.startTime = {}

local function nowMs()
    return math.floor(g_currentMission.time or 0)
end

local function safeNumber(v)
    return type(v) == "number" and string.format("%.4f", v) or tostring(v)
end

local function vehicleId(vehicle)
    return tostring(vehicle and vehicle.rootNode or vehicle)
end

local function getSpeed(vehicle)
    if vehicle and vehicle.getLastSpeed then
        return safeNumber(vehicle:getLastSpeed() * 3600)
    end
    return "n/a"
end

local function getMotorState(vehicle)
    local spec = vehicle and vehicle.spec_motorized
    if spec then
        return tostring(spec.motorState or "nil")
    end
    return "nil"
end

local function getGear(vehicle)
    local spec = vehicle and vehicle.spec_motorized
    if spec and spec.motor then
        return tostring(spec.motor.currentGear or "nil")
    end
    return "nil"
end

local function getTargetGear(vehicle)
    local spec = vehicle and vehicle.spec_motorized
    if spec and spec.motor then
        return tostring(spec.motor.targetGear or "nil")
    end
    return "nil"
end

local function getDirection(vehicle)
    local spec = vehicle and vehicle.spec_motorized
    if spec and spec.motor then
        return tostring(spec.motor.gearDirection or spec.motor.direction or "nil")
    end
    return "nil"
end

function EWFS_Diag109.log(vehicle, blocker, eventName)
    if vehicle == nil then return end

    local id = vehicleId(vehicle)
    local t = nowMs()

    if EWFS_Diag109.startTime[id] == nil then
        EWFS_Diag109.startTime[id] = t
    end

    local elapsed = t - EWFS_Diag109.startTime[id]
    local gear = getGear(vehicle)
    local targetGear = getTargetGear(vehicle)
    local motorState = getMotorState(vehicle)
    local direction = getDirection(vehicle)

    local spec = vehicle.spec_wheels
    local brakePedal = spec and spec.brakePedal or "nil"
    local doHandbrake = spec and spec.doHandbrake or "nil"

    print(string.format(
        "[EWFS109] %s t=%d elapsed=%d blocker=%s motorState=%s gear=%s targetGear=%s direction=%s speed=%s accel=%s brakePedal=%s doHandbrake=%s",
        eventName or "SAMPLE",
        t, elapsed, tostring(blocker), motorState, gear, targetGear, direction,
        getSpeed(vehicle), "n/a", safeNumber(brakePedal), tostring(doHandbrake)
    ))
end

function EWFS_Diag109.gearTransition(vehicle, blocker)
    if vehicle == nil then return end

    local id = vehicleId(vehicle)
    local gear = getGear(vehicle)
    local targetGear = getTargetGear(vehicle)
    local motorState = getMotorState(vehicle)
    local block = tostring(blocker)

    if EWFS_Diag109.lastGear[id] ~= gear then
        EWFS_Diag109.lastGear[id] = gear
        EWFS_Diag109.log(vehicle, blocker, "GEAR_CHANGE")
    end

    if EWFS_Diag109.lastTargetGear[id] ~= targetGear then
        EWFS_Diag109.lastTargetGear[id] = targetGear
        EWFS_Diag109.log(vehicle, blocker, "TARGET_GEAR_CHANGE")
    end

    if EWFS_Diag109.lastMotorState[id] ~= motorState then
        EWFS_Diag109.lastMotorState[id] = motorState
        EWFS_Diag109.log(vehicle, blocker, "MOTORSTATE_CHANGE")
    end

    if EWFS_Diag109.lastBlocker[id] ~= block then
        EWFS_Diag109.lastBlocker[id] = block
        EWFS_Diag109.log(vehicle, blocker, "BLOCKER_CHANGE")
    end
end

function EWFS_Diag109.sample(vehicle, blocker)
    if vehicle == nil then return end

    local id = vehicleId(vehicle)
    local t = nowMs()
    if EWFS_Diag109.lastLogTime[id] == nil or t - EWFS_Diag109.lastLogTime[id] >= EWFS_Diag109.INTERVAL_MS then
        EWFS_Diag109.lastLogTime[id] = t
        EWFS_Diag109.log(vehicle, blocker, "SAMPLE")
    end
    EWFS_Diag109.gearTransition(vehicle, blocker)
end

return EWFS_Diag109
