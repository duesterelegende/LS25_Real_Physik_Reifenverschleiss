-- FS25_Reifenverschleiss - MudSystemPhysics compatibility diagnostic
-- TEST2_4_0_82: worn pressure-baseline ownership test.
-- The proven 4_0_55/4_0_77 visual pressure shader is left untouched.
-- 4_0_81 proved that forcing physics.radius + wheel.radius + netInfo to one
-- post-Mud value gives perfect position but suppresses the visible pressure shape.
-- 4_0_82 therefore stops fighting Mud after it runs. Instead, RP owns only the
-- tire-pressure physical baseline: after Mud has finished a frame, __tpOrigRadius
-- is moved to RP's wear-only physical radius. On the following frame Mud computes
-- its own native pressure radius from that worn baseline and keeps its own shader,
-- dirty flags, wheel lifecycle and visual/physical pressure differential intact.

RPMudCompatibilityDiagnostic = RPMudCompatibilityDiagnostic or {}
local D = RPMudCompatibilityDiagnostic

-- RELEASE: keep the compatibility code active but suppress development diagnostics.
local function print(...)
end

D.enabled = true
D.diagnosticsEnabled = false
D.intervalMs = 1000
D.elapsedMs = 0
D.hooksInstalled = false
D.detectLogged = false
D.deepDumpLogged = false
D.deepWheelDumpLogged = false
D.lastVehicle = nil
D.radiusCombinerEnabled = true
D.radiusCombinerEpsilon = 0.0005
D.radiusRebuildStep = 0.002
D.finalOwnerHookInstalled = false
D.finalOwnerInProgress = false
D.finalOwnerFallbackMs = 0
D.finalOwnerFallbackDelayMs = 750
D.MOD_NAMES = {
    "FS25_MudSystemPhysics",
    "MudSystemPhysics"
}

local function num(v)
    return type(v) == "number" and v == v and v or nil
end

local function fmt(v, digits)
    if num(v) == nil then return "nil" end
    return string.format("%." .. tostring(digits or 4) .. "f", v)
end

local function bool(v)
    return v == true and "true" or "false"
end

local function getMudEnvironment()
    for _, name in ipairs(D.MOD_NAMES) do
        local env = rawget(_G, name)
        if type(env) == "table" then
            local tp = rawget(env, "TirePressureSystem")
            local wd = rawget(env, "WheelDirtAddon")
            if type(tp) == "table" or type(wd) == "table" then
                return env, name
            end
        end
    end

    -- Development/global fallback.
    if type(rawget(_G, "TirePressureSystem")) == "table"
        or type(rawget(_G, "WheelDirtAddon")) == "table" then
        return _G, "runtime"
    end
    return nil, nil
end



local function safeKeyString(k)
    local ok, v = pcall(tostring, k)
    return ok and v or "<?>"
end

local function safeValueString(v)
    local t = type(v)
    if t == "number" then return fmt(v, 6) end
    if t == "string" or t == "boolean" or t == "nil" then return tostring(v) end
    return "<" .. t .. ">"
end

local function keyMatches(k)
    local s = string.lower(safeKeyString(k))
    return string.find(s, "press", 1, true) ~= nil
        or string.find(s, "radius", 1, true) ~= nil
        or string.find(s, "tire", 1, true) ~= nil
        or string.find(s, "wheel", 1, true) ~= nil
        or string.find(s, "morph", 1, true) ~= nil
        or string.find(s, "physics", 1, true) ~= nil
        or string.find(s, "field", 1, true) ~= nil
        or string.find(s, "road", 1, true) ~= nil
        or string.find(s, "mud", 1, true) ~= nil
        or string.find(s, "desired", 1, true) ~= nil
        or string.sub(s, 1, 4) == "__tp"
end

local function dumpMatchingTable(prefix, tbl, maxItems)
    if type(tbl) ~= "table" then
        print(string.format("[ReifenVerschleiss][MUD-DEEP][%s] not-table type=%s", tostring(prefix), type(tbl)))
        return
    end
    local rows = {}
    for k, v in pairs(tbl) do
        if keyMatches(k) then
            rows[#rows + 1] = {k=safeKeyString(k), v=safeValueString(v), t=type(v), raw=v}
        end
    end
    table.sort(rows, function(a,b) return a.k < b.k end)
    local limit = math.min(#rows, maxItems or 80)
    print(string.format("[ReifenVerschleiss][MUD-DEEP][%s] matches=%d showing=%d", tostring(prefix), #rows, limit))
    for i=1,limit do
        local r=rows[i]
        print(string.format("[ReifenVerschleiss][MUD-DEEP][%s] %s type=%s value=%s", tostring(prefix), r.k, r.t, r.v))
    end
end

local function dumpFunctionInventory(prefix, tbl, maxItems)
    if type(tbl) ~= "table" then return end
    local names={}
    for k,v in pairs(tbl) do
        if type(v)=="function" and keyMatches(k) then names[#names+1]=safeKeyString(k) end
    end
    table.sort(names)
    local limit=math.min(#names,maxItems or 60)
    print(string.format("[ReifenVerschleiss][MUD-DEEP][%s-FUNCS] matches=%d showing=%d", tostring(prefix),#names,limit))
    for i=1,limit do print(string.format("[ReifenVerschleiss][MUD-DEEP][%s-FUNCS] %s",tostring(prefix),names[i])) end
end

local function dumpNestedCandidates(prefix, tbl)
    if type(tbl) ~= "table" then return end
    local names={}
    for k,v in pairs(tbl) do
        if type(v)=="table" and keyMatches(k) then names[#names+1]={k=safeKeyString(k),v=v} end
    end
    table.sort(names,function(a,b)return a.k<b.k end)
    local limit=math.min(#names,12)
    for i=1,limit do dumpMatchingTable(prefix .. "." .. names[i].k,names[i].v,50) end
end

function D:deepDump(tp, vehicle, wheel)
    if self.deepDumpLogged ~= true then
        self.deepDumpLogged = true
        print("[ReifenVerschleiss][MUD-DEEP] ===== TirePressure runtime inventory START =====")
        dumpMatchingTable("TP", tp, 120)
        dumpFunctionInventory("TP", tp, 100)
        dumpNestedCandidates("TP", tp)
        local mt = type(tp)=="table" and getmetatable(tp) or nil
        if type(mt)=="table" then
            dumpMatchingTable("TP-MT", mt, 80)
            dumpFunctionInventory("TP-MT", mt, 80)
            local idx=rawget(mt,"__index")
            if type(idx)=="table" and idx~=tp then
                dumpMatchingTable("TP-MT.__index", idx, 120)
                dumpFunctionInventory("TP-MT.__index", idx, 120)
            end
        end
        print("[ReifenVerschleiss][MUD-DEEP] ===== TirePressure runtime inventory END =====")
    end

    if self.deepWheelDumpLogged ~= true and wheel ~= nil and wheel.physics ~= nil then
        self.deepWheelDumpLogged = true
        print("[ReifenVerschleiss][MUD-DEEP] ===== Wheel#1 runtime inventory START =====")
        dumpMatchingTable("WHEEL", wheel, 120)
        dumpNestedCandidates("WHEEL", wheel)
        dumpMatchingTable("WHEEL.PHYSICS", wheel.physics, 160)
        dumpNestedCandidates("WHEEL.PHYSICS", wheel.physics)
        print("[ReifenVerschleiss][MUD-DEEP] ===== Wheel#1 runtime inventory END =====")
    end
end

local function getWheelIndex(vehicle, wheel)
    local wheels = vehicle ~= nil and vehicle.spec_wheels ~= nil and vehicle.spec_wheels.wheels or nil
    for i, w in ipairs(wheels or {}) do
        if w == wheel then return i end
    end
    return 0
end

local function getShapeParam(node, name)
    if node == nil or node == 0 or getShaderParameter == nil then return nil, nil, nil, nil end
    local ok, a, b, c, d = pcall(getShaderParameter, node, name)
    if not ok then return nil, nil, nil, nil end
    return a, b, c, d
end

local function getPressureData(tp, vehicle, wheel)
    if tp == nil or wheel == nil or wheel.physics == nil then
        return nil, nil, nil, nil, nil
    end

    local wp = wheel.physics
    local current, target, p01 = nil, nil, nil
    local states = rawget(tp, "_wheelStates")
    if type(states) == "table" then
        local st = states[wp]
        if type(st) == "table" then
            current = num(st.current)
            target = num(st.target)
        end
    end

    if type(tp.getWheelPressure01) == "function" then
        local ok, value = pcall(tp.getWheelPressure01, tp, wp)
        if ok then p01 = num(value) end
    end

    local minP = num(tp.minPressure)
    local maxP = num(tp.maxPressure)
    if current == nil and p01 ~= nil and minP ~= nil and maxP ~= nil then
        current = minP + (maxP - minP) * p01
    end

    local shaderW = nil
    if p01 ~= nil and type(tp.getShaderWFromPressure01) == "function" then
        local ok, value = pcall(tp.getShaderWFromPressure01, tp, p01)
        if ok then shaderW = num(value) end
    end

    local calcRadius = nil
    local r0 = num(wp.__tpOrigRadius) or num(wp.radiusOriginal) or num(wp.radius)
    if r0 ~= nil and p01 ~= nil and type(tp.getRadiusFromPressure01) == "function" then
        local ok, value = pcall(tp.getRadiusFromPressure01, tp, r0, p01)
        if ok then calcRadius = num(value) end
    end

    return current, target, p01, shaderW, calcRadius
end

local function getMudState(wheel)
    local st = wheel ~= nil and wheel.__mudSystemWheelDirtState or nil
    if type(st) ~= "table" then return nil end
    return st
end

function D:installWheelDirtHooks()
    if self.hooksInstalled == true then return end
    if Wheels == nil or Utils == nil or Utils.overwrittenFunction == nil then return end
    if Wheels.updateWheelDirtAmount == nil or Wheels.updateWheelMudAmount == nil then return end

    Wheels.updateWheelDirtAmount = Utils.overwrittenFunction(
        Wheels.updateWheelDirtAmount,
        function(vehicle, superFunc, nodeData, dt, allowsWashingByRain, rainScale, timeSinceLastRain, temperature)
            local dirt, wet = superFunc(vehicle, nodeData, dt, allowsWashingByRain, rainScale, timeSinceLastRain, temperature)
            local wheel = nodeData ~= nil and nodeData.wheel or nil
            if wheel ~= nil then
                wheel.__rvMudDiagDirtAmount = num(dirt)
                wheel.__rvMudDiagDirtNodeAmount = num(nodeData.dirtAmount)
                wheel.__rvMudDiagDirtNode = nodeData.node or nodeData.shape or nodeData.object
            end
            return dirt, wet
        end
    )

    Wheels.updateWheelMudAmount = Utils.overwrittenFunction(
        Wheels.updateWheelMudAmount,
        function(vehicle, superFunc, nodeData, dt, allowsWashingByRain, rainScale, timeSinceLastRain, temperature)
            local dirt, wet = superFunc(vehicle, nodeData, dt, allowsWashingByRain, rainScale, timeSinceLastRain, temperature)
            local wheel = nodeData ~= nil and nodeData.wheel or nil
            if wheel ~= nil then
                wheel.__rvMudDiagMudAmount = num(dirt)
                wheel.__rvMudDiagMudNodeAmount = num(nodeData.dirtAmount)
                wheel.__rvMudDiagMudNode = nodeData.node or nodeData.shape or nodeData.object
            end
            return dirt, wet
        end
    )

    self.hooksInstalled = true
    print("[ReifenVerschleiss][MUD-DIAG] read-only Wheels dirt/mud probes installed")
end

function D:logVehicle(vehicle)
    if vehicle == nil or vehicle.spec_wheels == nil then return end

    local env, mudName = getMudEnvironment()
    local tp = env ~= nil and rawget(env, "TirePressureSystem") or nil
    local wd = env ~= nil and rawget(env, "WheelDirtAddon") or nil

    local firstWheel = vehicle.spec_wheels.wheels ~= nil and vehicle.spec_wheels.wheels[1] or nil
    self:deepDump(tp, vehicle, firstWheel)

    if self.detectLogged ~= true then
        self.detectLogged = true
        print(string.format(
            "[ReifenVerschleiss][MUD-DIAG] MudSystem detected=%s env=%s TirePressureSystem=%s WheelDirtAddon=%s",
            tostring(env ~= nil), tostring(mudName), tostring(type(tp) == "table"), tostring(type(wd) == "table")
        ))
        if type(tp) == "table" then
            print(string.format(
                "[ReifenVerschleiss][MUD-DIAG] pressure-config min=%s field=%s road=%s max=%s shaderFieldW=%s shaderRoadW=%s physicsFieldW=%s radiusScale=%s minRadiusFactor=%s",
                fmt(tp.minPressure,2), fmt(tp.fieldPressure,2), fmt(tp.roadPressure,2), fmt(tp.maxPressure,2),
                fmt(tp.shaderFieldW,4), fmt(tp.shaderRoadW,4), fmt(tp.physicsFieldW,4),
                fmt(tp.physicsRadiusScale,3), fmt(tp.physicsMinRadiusFactor,3)
            ))
        end
    end

    local name = vehicle.getName ~= nil and vehicle:getName() or vehicle.typeName or vehicle.configFileName or "vehicle"
    local speed = num(vehicle.lastSpeedReal) ~= nil and math.abs(vehicle.lastSpeedReal) * 3600 or nil
    print(string.format("[ReifenVerschleiss][MUD-DIAG][VEH] name=%s speedKmh=%s wheels=%d", tostring(name), fmt(speed,2), #(vehicle.spec_wheels.wheels or {})))

    for i, wheel in ipairs(vehicle.spec_wheels.wheels or {}) do
        local wp = wheel.physics
        if wp ~= nil then
            local wear = nil
            if ReifenVerschleissDiagnostic ~= nil and type(ReifenVerschleissDiagnostic.getWheelWearValue) == "function" then
                local ok, value = pcall(ReifenVerschleissDiagnostic.getWheelWearValue, vehicle, wheel)
                if ok then wear = num(value) end
            end

            local pCur, pTarget, p01, shaderW, pressureRadius = getPressureData(tp, vehicle, wheel)
            local rawSlip = wp.netInfo ~= nil and num(wp.netInfo.slip) or num(wp.slip)
            local mudState = getMudState(wheel)

            local morphW, rpWearX = nil, nil
            local shapeNode = nil
            if type(wheel.__tpShaderShapes) == "table" and #wheel.__tpShaderShapes > 0 then
                shapeNode = wheel.__tpShaderShapes[1].node
                local mx, my, mz, mw = getShapeParam(shapeNode, "morphPos")
                morphW = num(mw)
                wheel.__rvDiagMorphX = num(mx)
                wheel.__rvDiagMorphY = num(my)
                wheel.__rvDiagMorphZ = num(mz)
                local rw = getShapeParam(shapeNode, "rpTireWearData")
                rpWearX = num(rw)
            end

            print(string.format(
                "[ReifenVerschleiss][MUD-DIAG][W%d] wear=%s pressure=%s target=%s p01=%s shaderW(calc/actual)=%s/%s radius wheel=%s physics=%s orig=%s tpOrig=%s tpDesired=%s tpCalc=%s mpDesired=%s fgDesired=%s puncture=%s ttd=%s uyt=%s slipRaw=%s contact=%s",
                i, fmt(wear,4), fmt(pCur,2), fmt(pTarget,2), fmt(p01,4), fmt(shaderW,4), fmt(morphW,4),
                fmt(wheel.radius,5), fmt(wp.radius,5), fmt(wp.radiusOriginal,5), fmt(wp.__tpOrigRadius,5), fmt(wp.__tpDesiredRadius,5), fmt(pressureRadius,5),
                fmt(wp.__mpDesiredRadius,5), fmt(wp.__fgDesiredRadius,5), fmt(wp.__punctureDesiredRadius,5), fmt(wp.__ttdDesiredRadius,5), fmt(wp.__uytDesiredRadius,5),
                fmt(rawSlip,4), bool(wp.contact == true or wp.hasGroundContact == true)
            ))

            local tpOrig = num(wp.__tpOrigRadius) or num(wp.radiusOriginal)
            local tpDesired = num(wp.__tpDesiredRadius)
            local tpDelta = (tpOrig ~= nil and tpDesired ~= nil) and (tpDesired - tpOrig) or nil
            local visualPush = morphW
            local pressureMismatch = (visualPush ~= nil and tpDelta ~= nil) and (visualPush + tpDelta) or nil
            local relativeMismatch = (visualPush ~= nil and tpDelta ~= nil) and (visualPush - math.abs(tpDelta)) or nil
            print(string.format(
                "[ReifenVerschleiss][PRESSURE-SYNC][W%d] morph=(%s,%s,%s,%s) tpOrig=%s tpDesired=%s tpDelta=%s absTpDelta=%s visualPushW=%s pushMinusAbsDelta=%s wheelRadius=%s physicsRadius=%s wearBase=%s combined=%s",
                i, fmt(wheel.__rvDiagMorphX,5), fmt(wheel.__rvDiagMorphY,5), fmt(wheel.__rvDiagMorphZ,5), fmt(morphW,5),
                fmt(tpOrig,5), fmt(tpDesired,5), fmt(tpDelta,5), fmt(tpDelta ~= nil and math.abs(tpDelta) or nil,5),
                fmt(visualPush,5), fmt(relativeMismatch,5), fmt(wheel.radius,5), fmt(wp.radius,5),
                fmt(wheel.rvRoundPhysicalRadius,5), fmt(wheel.__rvMudCombinedRadius,5)
            ))

            print(string.format(
                "[ReifenVerschleiss][MUD-DIAG][W%d-MUD] surface=%s raw=%s signal=%s tireTarget=%s meshTarget=%s dirtRet=%s dirtNode=%s mudRet=%s mudNode=%s speed=%s inWater=%s hasContact=%s shaderNode=%s rpWearParam=%s",
                i,
                tostring(mudState ~= nil and mudState.surfaceKind or "nil"),
                fmt(mudState ~= nil and mudState.rawSignal or nil,4),
                fmt(mudState ~= nil and mudState.surfaceSignal or nil,4),
                fmt(mudState ~= nil and mudState.tireTarget or nil,4),
                fmt(mudState ~= nil and mudState.meshTarget or nil,4),
                fmt(wheel.__rvMudDiagDirtAmount,4), fmt(wheel.__rvMudDiagDirtNodeAmount,4),
                fmt(wheel.__rvMudDiagMudAmount,4), fmt(wheel.__rvMudDiagMudNodeAmount,4),
                fmt(mudState ~= nil and mudState.speedKph or nil,2),
                bool(mudState ~= nil and mudState.inWater == true), bool(mudState ~= nil and mudState.hasContact == true),
                tostring(shapeNode), fmt(rpWearX,4)
            ))
        end
    end
end


local function getWheelVisualPressurePush(wheel)
    if wheel == nil or type(wheel.__tpShaderShapes) ~= "table" then return nil, nil end

    -- Diagnostic only. TirePressure's morphPos.w is a VISUAL deformation input
    -- and must never be translated 1:1 into a physical wheel-radius loss.
    for _, entry in ipairs(wheel.__tpShaderShapes) do
        local node = type(entry) == "table" and entry.node or nil
        if node ~= nil then
            local _, _, _, mw = getShapeParam(node, "morphPos")
            mw = num(mw)
            if mw ~= nil then
                return math.max(0, mw), node
            end
        end
    end
    return nil, nil
end

local function maxValid(current, candidate)
    candidate = num(candidate)
    if candidate == nil or candidate <= 0.05 then return current end
    if current == nil or candidate > current then return candidate end
    return current
end

-- TEST2_4_0_81:
-- Reconstruct MudSystemPhysics' NATIVE physical radius state from the public
-- compatibility fields that Mud itself maintains. The critical rule is that
-- morphPos.w is visual-only; the physical pressure loss comes from the native
-- desired-radius fields (__tpDesiredRadius etc.).
--
-- We intentionally ignore __uytDesiredRadius here. RP wear is applied exactly
-- once by transferring the native external delta onto rvRoundPhysicalRadius.
local function getMudNativePhysicalDelta(wp, wheel)
    if wp == nil then return 0, nil, nil, "wear-only", nil end

    local nativeOrigin = nil
    nativeOrigin = maxValid(nativeOrigin, wp.__mpOrigRadius)
    nativeOrigin = maxValid(nativeOrigin, wp.__fgOrigRadius)
    nativeOrigin = maxValid(nativeOrigin, wp.__tpOrigRadius)
    nativeOrigin = maxValid(nativeOrigin, wp.__punctureOrigRadius)
    nativeOrigin = maxValid(nativeOrigin, wp.__ttdOrigRadius)
    nativeOrigin = maxValid(nativeOrigin, wp.radiusOriginal)
    nativeOrigin = maxValid(nativeOrigin, wheel ~= nil and wheel.ttdOriginalRadius or nil)

    local nativeTarget = nil
    local source = nil
    local function considerDesired(candidate, name)
        candidate = num(candidate)
        if candidate ~= nil and candidate > 0.05 then
            if nativeTarget == nil or candidate < nativeTarget then
                nativeTarget = candidate
                source = name
            end
        end
    end

    -- Same native absolute radius channels MudSystemPhysics uses for physical
    -- wheel deformation. These are already pressure/mud/field/puncture aware.
    considerDesired(wp.__mpDesiredRadius, "mud")
    considerDesired(wp.__fgDesiredRadius, "fieldGround")
    considerDesired(wp.__tpDesiredRadius, "tirePressure")
    considerDesired(wp.__punctureDesiredRadius, "puncture")
    considerDesired(wp.__ttdDesiredRadius, "ttd")

    -- On some lifecycle/client-transition frames Mud exposes only its FX
    -- desired radius. Use it only as a fallback/extra minimum; never let a
    -- stale FX value override a smaller live TirePressure desired radius.
    local fxDesired = num(wp.__mpFxDesiredRadius)
    if fxDesired ~= nil and fxDesired > 0.05 then
        local mudState = wheel ~= nil and wheel.__mudSystemWheelDirtState or nil
        local mudSignal = type(mudState) == "table" and num(mudState.surfaceSignal) or nil
        local mudTarget = type(mudState) == "table" and num(mudState.tireTarget) or nil
        local mudActive = wp.__mpWasMud == true
            or math.abs(num(wp.__mpWheelSink) or 0) > 0.0001
            or math.abs(num(wp.__mpMudDeepFactor) or 0) > 0.0001
            or (mudSignal ~= nil and mudSignal > 0.0001)
            or (mudTarget ~= nil and mudTarget > 0.0001)

        if mudActive and nativeTarget == nil then
            nativeTarget = fxDesired
            source = "mpFx-fallback"
        elseif mudActive and fxDesired < nativeTarget then
            nativeTarget = fxDesired
            source = "mpFx-extra"
        end
    end

    local visualPush, visualNode = getWheelVisualPressurePush(wheel)

    if nativeOrigin == nil then
        return 0, nil, nativeTarget, source or "wear-only", visualPush, visualNode
    end
    if nativeTarget == nil then
        nativeTarget = nativeOrigin
        source = "native-original"
    end

    -- Native physical delta, never visual morphPos.w.
    local externalDelta = math.min(0, nativeTarget - nativeOrigin)
    return externalDelta, nativeOrigin, nativeTarget, source or "native", visualPush, visualNode
end

function D:applyRadiusCombiner(vehicle, finalOwnerPass)
    if self.radiusCombinerEnabled ~= true or vehicle == nil or vehicle.isServer ~= true then return end
    local wheels = vehicle.spec_wheels ~= nil and vehicle.spec_wheels.wheels or nil
    if wheels == nil then return end

    for i, wheel in ipairs(wheels) do
        local wp = wheel ~= nil and wheel.physics or nil
        local wearBase = wheel ~= nil and num(wheel.rvRoundPhysicalRadius) or nil
        local wearOriginal = wheel ~= nil and num(wheel.rvRoundOriginalPhysicsRadius) or nil
        local wear = wheel ~= nil and num(wheel.rvRoundPhysicalWear) or nil

        -- rvRoundPhysicalRadius is intentionally only written by our proven
        -- round-tire path. Crawler/track physics therefore stays untouched.
        if wp ~= nil and wearBase ~= nil and wearOriginal ~= nil and wear ~= nil and wear > 0 then
            local externalDelta, externalOrigin, externalTarget, source, visualPush, visualNode = getMudNativePhysicalDelta(wp, wheel)
            if externalDelta ~= nil then
                -- Add only RP's wear loss to MudSystemPhysics' own native
                -- physical deformation. This preserves the exact native pressure
                -- calibration while the untouched 4_0_55 shader keeps the full
                -- visible inflation/deflation shape.
                --
                -- Equivalent forms when origins agree:
                --   wearBase + (nativeTarget-nativeOrigin)
                --   nativeTarget - (wearOriginal-wearBase)
                local target = math.max(0.05, wearBase + externalDelta)
                local previousApplied = num(wheel.__rvMudCombinedRadius)
                local current = num(wp.radius)
                local physicsRadiusChanged = current == nil or math.abs(current - target) > self.radiusCombinerEpsilon

                if physicsRadiusChanged then
                    wp.radius = target
                end

                -- Keep all three GIANTS radius views coherent. 4_0_68/69 proved
                -- that a stale wheel/netInfo radius can keep the visual wheel at
                -- the old height even when physics.radius is already correct.
                -- rvRoundPhysicalRadius remains the immutable wear-only base, so
                -- this cannot accumulate shrinkage frame to frame.
                local currentWheelRadius = num(wheel.radius)
                local wheelRadiusChanged = currentWheelRadius == nil or math.abs(currentWheelRadius - target) > self.radiusCombinerEpsilon
                if wheelRadiusChanged then
                    wheel.radius = target
                end

                -- Keep netInfo on the exact same combined physical target. This
                -- is bookkeeping only; TirePressure morphPos remains untouched.
                local currentNetRadius = wp.netInfo ~= nil and num(wp.netInfo.wheelRadius) or nil
                local netRadiusChanged = wp.netInfo ~= nil and (currentNetRadius == nil or math.abs(currentNetRadius - target) > self.radiusCombinerEpsilon)
                if netRadiusChanged then
                    wp.netInfo.wheelRadius = target
                end

                local anyRadiusChanged = physicsRadiusChanged or wheelRadiusChanged or netRadiusChanged
                local materialChange = previousApplied == nil or math.abs(previousApplied - target) >= self.radiusRebuildStep
                if anyRadiusChanged then
                    -- Keep both the modern WheelPhysics flags and the GIANTS Wheels
                    -- specialization flags coherent. The final-owner hook runs after
                    -- all onUpdate listeners (including Mud) and before onPostUpdate,
                    -- so Wheels:onPostUpdate can rebuild the wheel base from OUR final
                    -- radius in the same frame.
                    wp.isPositionDirty = true
                    if materialChange then
                        wp.isFrictionDirty = true
                    end
                    if vehicle.setWheelPositionDirty ~= nil then
                        pcall(vehicle.setWheelPositionDirty, vehicle, wheel)
                    else
                        wheel.isPositionDirty = true
                    end
                    if materialChange then
                        if vehicle.setWheelTireFrictionDirty ~= nil then
                            pcall(vehicle.setWheelTireFrictionDirty, vehicle, wheel)
                        else
                            wheel.isFrictionDirty = true
                        end
                    end
                end

                wheel.__rvMudCombinedRadius = target
                wheel.__rvMudCombinedSource = source
                wheel.__rvMudCombinedExternalDelta = externalDelta
                if finalOwnerPass == true then
                    wheel.__rvFinalOwnerSeen = true
                    wheel.__rvFinalOwnerLastTime = g_time
                end

                -- In the true final-owner pass we deliberately do NOT call
                -- updateWheelBase directly. We are positioned between onUpdate and
                -- onPostUpdate; GIANTS' own dirty-wheel lifecycle performs the rebuild
                -- immediately afterwards. Outside that lifecycle (startup fallback)
                -- we may still need one direct rebuild.
                if materialChange and finalOwnerPass ~= true then
                    if vehicle.updateWheelBase ~= nil then
                        local ok, err = pcall(vehicle.updateWheelBase, vehicle, wheel)
                        if not ok then
                            print(string.format("[ReifenVerschleiss][MUD-COMBINE][WARN] W%d updateWheelBase failed: %s", i, tostring(err)))
                        end
                    elseif vehicle.setWheelPositionDirty ~= nil then
                        pcall(vehicle.setWheelPositionDirty, vehicle, wheel)
                    end
                end

                if materialChange or (finalOwnerPass == true and wheel.__rvFinalOwnerLogged ~= true) then
                    local wearLoss = math.max(0, wearOriginal - wearBase)
                    print(string.format(
                        "[ReifenVerschleiss][R81-FINAL][W%d] pass=%s source=%s wear=%.3f wearOrig=%.5f wearBase=%.5f wearLoss=%.5f nativeOrig=%s nativeTarget=%s nativeDelta=%+.5f visualMorphW=%s prePhys=%s preWheel=%s preNet=%s final=%.5f node=%s",
                        i, finalOwnerPass == true and "POST_MUD" or "FALLBACK", tostring(source), wear, wearOriginal, wearBase, wearLoss,
                        fmt(externalOrigin,5), fmt(externalTarget,5), externalDelta, fmt(visualPush,5),
                        fmt(current,5), fmt(currentWheelRadius,5), fmt(currentNetRadius,5), target, tostring(visualNode)
                    ))
                    if finalOwnerPass == true then
                        wheel.__rvFinalOwnerLogged = true
                    end
                end
            end
        end
    end
end


function D:logContactGeometry(vehicle)
    if vehicle == nil or vehicle.spec_wheels == nil or vehicle.spec_wheels.wheels == nil then return end
    local mission = g_currentMission
    for i, wheel in ipairs(vehicle.spec_wheels.wheels) do
        local wp = wheel ~= nil and wheel.physics or nil
        if wheel ~= nil and wp ~= nil and wheel.node ~= nil and wp.wheelShape ~= nil then
            local cx, cy, cz, skin = nil, nil, nil, nil
            local contactLen = nil
            local contactWorldY = nil
            local terrainY = nil
            local centerY = nil
            local reprY = nil

            if getWheelShapeContactPointVector ~= nil then
                local ok, x, y, z, sk = pcall(getWheelShapeContactPointVector, wheel.node, wp.wheelShape)
                if ok and type(x) == "number" and type(y) == "number" and type(z) == "number" then
                    cx, cy, cz, skin = x, y, z, sk
                    contactLen = math.sqrt(x*x + y*y + z*z)
                    if localToWorld ~= nil then
                        local okW, wx, wy, wz = pcall(localToWorld, wheel.node, x, y, z)
                        if okW and type(wy) == "number" then
                            contactWorldY = wy
                            if mission ~= nil and mission.terrainRootNode ~= nil and getTerrainHeightAtWorldPos ~= nil then
                                local okT, h = pcall(getTerrainHeightAtWorldPos, mission.terrainRootNode, wx, wy, wz)
                                if okT and type(h) == "number" then terrainY = h end
                            end
                        end
                    end
                end
            end

            if getWorldTranslation ~= nil then
                local okN, _, ny, _ = pcall(getWorldTranslation, wheel.node)
                if okN and type(ny) == "number" then centerY = ny end
                if wheel.repr ~= nil then
                    local okR, _, ry, _ = pcall(getWorldTranslation, wheel.repr)
                    if okR and type(ry) == "number" then reprY = ry end
                end
            end

            local groundGap = nil
            if contactWorldY ~= nil and terrainY ~= nil then groundGap = contactWorldY - terrainY end
            local centerToTerrain = nil
            if centerY ~= nil and terrainY ~= nil then centerToTerrain = centerY - terrainY end

            print(string.format(
                "[ReifenVerschleiss][CONTACT-GEO][W%d] wheelRadius=%s physicsRadius=%s orig=%s shape=%s contactLocal=(%s,%s,%s) contactLen=%s skin=%s nodeY=%s reprY=%s contactY=%s terrainY=%s gap=%s centerToTerrain=%s",
                i, fmt(wheel.radius), fmt(wp.radius), fmt(wp.radiusOriginal), tostring(wp.wheelShape),
                fmt(cx), fmt(cy), fmt(cz), fmt(contactLen), fmt(skin), fmt(centerY), fmt(reprY),
                fmt(contactWorldY), fmt(terrainY), fmt(groundGap), fmt(centerToTerrain)
            ))
        end
    end
end

function D:update(dt)
    if self.enabled ~= true then return end
    if self.diagnosticsEnabled == true then
        self:installWheelDirtHooks()
    end

    -- Sleeping/startup fleet safety: establish the worn pressure baseline even
    -- for a vehicle that is not currently receiving its normal vehicle update.
    -- This changes only Mud's pressure-origin field and wheel.radius; it never
    -- writes physics.radius/netInfo or dirty flags.
    self.finalOwnerFallbackMs = (self.finalOwnerFallbackMs or 0) + (num(dt) or 0)
    if self.finalOwnerFallbackMs >= self.finalOwnerFallbackDelayMs then
        self.finalOwnerFallbackMs = 0
        local mission = g_currentMission
        local vehicles = mission ~= nil and mission.vehicleSystem ~= nil and mission.vehicleSystem.vehicles or nil
        if vehicles ~= nil then
            for _, fleetVehicle in pairs(vehicles) do
                if fleetVehicle ~= nil and fleetVehicle.spec_wheels ~= nil then
                    self:finalOwnerCommit(fleetVehicle)
                end
            end
        end
    end

    if self.diagnosticsEnabled ~= true then
        return
    end

    self.elapsedMs = (self.elapsedMs or 0) + (num(dt) or 0)
    if self.elapsedMs < self.intervalMs then return end
    self.elapsedMs = self.elapsedMs % self.intervalMs

    local vehicle = ReifenVerschleissDiagnostic ~= nil
        and ReifenVerschleissDiagnostic.currentVehicle or nil
    if vehicle == nil then
        local mission = g_currentMission
        vehicle = mission ~= nil and (mission.controlledVehicle or mission.currentVehicle) or nil
    end
    if vehicle == nil or vehicle.spec_wheels == nil then return end
    self:logVehicle(vehicle)
    self:logContactGeometry(vehicle)
end

function D:logFinalOwnerOrder(vehicle)
    if vehicle == nil or vehicle.__rvFinalOwnerOrderLogged == true then return end
    vehicle.__rvFinalOwnerOrderLogged = true
    local names = {}
    local listeners = vehicle.eventListeners ~= nil and vehicle.eventListeners.onUpdate or nil
    if listeners ~= nil then
        for index, spec in ipairs(listeners) do
            local name = spec ~= nil and (spec.className or spec.name) or nil
            if name == nil and spec ~= nil then
                name = tostring(spec)
            end
            names[#names + 1] = string.format("%d:%s", index, tostring(name or "<?>"))
        end
    end
    print(string.format(
        "[ReifenVerschleiss][R82-ORDER] vehicle=%s onUpdate=[%s] -> RP_WEAR_BASELINE_FOR_NEXT_MUD_FRAME -> onPostUpdate",
        tostring(vehicle.getName ~= nil and vehicle:getName() or vehicle.typeName or vehicle.configFileName or "vehicle"),
        table.concat(names, " | ")
    ))
end

function D:finalOwnerCommit(vehicle)
    if self.enabled ~= true then return end
    if vehicle == nil or vehicle.isDeleted == true or vehicle.isDeleting == true then return end
    if vehicle.spec_wheels == nil or vehicle.spec_wheels.wheels == nil then return end

    local touched = false
    for i, wheel in ipairs(vehicle.spec_wheels.wheels) do
        local wp = wheel ~= nil and wheel.physics or nil
        local wearBase = wheel ~= nil and num(wheel.rvRoundPhysicalRadius) or nil
        local wearOriginal = wheel ~= nil and num(wheel.rvRoundOriginalPhysicsRadius) or nil
        local wear = wheel ~= nil and num(wheel.rvRoundPhysicalWear) or nil

        -- Round tires only. Crawler/track physics has no rvRoundPhysicalRadius.
        if wp ~= nil and wearBase ~= nil and wearOriginal ~= nil and wear ~= nil and wear > 0 then
            touched = true

            local oldTpOrig = num(wp.__tpOrigRadius)
            local oldTpDesired = num(wp.__tpDesiredRadius)
            local nativeDelta = nil
            if oldTpOrig ~= nil and oldTpDesired ~= nil then
                nativeDelta = oldTpDesired - oldTpOrig
            end

            -- This is the core of TEST2_4_0_82. Mud's TirePressureSystem uses
            -- __tpOrigRadius as the input for getRadiusFromPressure01(). By
            -- replacing only that baseline with the wear-only radius, Mud itself
            -- computes e.g. wearBase-10.8 mm at road pressure and wearBase-48.6 mm
            -- at field pressure. We do NOT overwrite physics.radius or netInfo
            -- afterwards, so Mud/GIANTS keep their native pressure lifecycle.
            wp.__tpOrigRadius = wearBase

            -- Preserve RP's wear-only visual/base wheel radius. Native Mud does
            -- not collapse wheel.radius onto physics.radius; that differential is
            -- part of the pressure visual. 4_0_81 erased it and the deformation.
            local preWheelRadius = num(wheel.radius)
            if preWheelRadius == nil or math.abs(preWheelRadius - wearBase) > self.radiusCombinerEpsilon then
                wheel.radius = wearBase
            end

            wheel.__rvFinalOwnerSeen = true
            wheel.__rvFinalOwnerLastTime = g_time

            local baselineChanged = oldTpOrig == nil or math.abs(oldTpOrig - wearBase) > self.radiusCombinerEpsilon
            if baselineChanged or wheel.__rv82BaselineLogged ~= true then
                local predicted = nativeDelta ~= nil and (wearBase + nativeDelta) or nil
                print(string.format(
                    "[ReifenVerschleiss][R82-BASELINE][W%d] wear=%.3f wearOrig=%.5f wearBase=%.5f oldTpOrig=%s oldTpDesired=%s nativeDelta=%s predictedNext=%s prePhys=%s preWheel=%s preNet=%s morphW=%s",
                    i, wear, wearOriginal, wearBase, fmt(oldTpOrig,5), fmt(oldTpDesired,5),
                    fmt(nativeDelta,5), fmt(predicted,5), fmt(num(wp.radius),5),
                    fmt(preWheelRadius,5), fmt(wp.netInfo ~= nil and num(wp.netInfo.wheelRadius) or nil,5),
                    fmt(select(1, getWheelVisualPressurePush(wheel)),5)
                ))
                wheel.__rv82BaselineLogged = true
            end
        end
    end

    if touched then
        self:logFinalOwnerOrder(vehicle)
    end
end

function D:installFinalOwnerHook()
    if self.finalOwnerHookInstalled == true then return end
    if SpecializationUtil == nil or SpecializationUtil.raiseEvent == nil
        or Utils == nil or Utils.appendedFunction == nil then
        print("[ReifenVerschleiss][R82-BASELINE][ERROR] SpecializationUtil.raiseEvent hook unavailable")
        return
    end

    local owner = self
    SpecializationUtil.raiseEvent = Utils.appendedFunction(
        SpecializationUtil.raiseEvent,
        function(object, eventName, ...)
            -- Vehicle:update raises onUpdate, then onPostUpdate. Mud's
            -- TirePressureVehicleAction has already completed here. We do not
            -- overwrite its just-applied wheel state. We only move the pressure
            -- origin to RP's wear-only baseline for Mud's next frame.
            if eventName == "onUpdate" and owner.finalOwnerInProgress ~= true then
                owner.finalOwnerInProgress = true
                local ok, err = pcall(owner.finalOwnerCommit, owner, object)
                owner.finalOwnerInProgress = false
                if not ok then
                    print(string.format("[ReifenVerschleiss][R82-BASELINE][ERROR] %s", tostring(err)))
                end
            end
        end
    )
    self.finalOwnerHookInstalled = true
    print("[ReifenVerschleiss][R82-BASELINE] post-Mud wear-baseline hook installed; no post-Mud radius overwrite")
end

function D:loadMap()
    self.elapsedMs = 0
    self.detectLogged = false
    self.deepDumpLogged = false
    self.deepWheelDumpLogged = false
    self.hooksInstalled = false
    self.finalOwnerFallbackMs = 0
    self.finalOwnerInProgress = false
    self:installFinalOwnerHook()
    print("[ReifenVerschleiss][MUD-DIAG] TEST2_4_0_82 MUD_WORN_PRESSURE_BASELINE_TEST active; 4_0_55/77 pressure visuals untouched; RP no longer overwrites Mud radius after onUpdate; only __tpOrigRadius is moved to the RP wear-only radius so Mud computes native pressure deformation on the worn tire baseline")
end

function D:deleteMap()
end

addModEventListener(D)
