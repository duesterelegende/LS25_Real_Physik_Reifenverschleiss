-- FS25_Reifenverschleiss - MudSystemPhysics runtime/version detection
-- RELEASE_1_2_2_67_MUD_VERSION_GUARD
--
-- Purpose:
-- * Mud compatibility is completely dormant when FS25_MudSystemPhysics is not active.
-- * The active Mud version is detected once the mission is available.
-- * Known Mud generations can use separate compatibility profiles without
--   changing Reifenverschleiss core ownership of tire wear/radius.
-- * Unknown/newer versions fall back conservatively to the last known profile.

RPMudVersionCompatibility = RPMudVersionCompatibility or {}
local V = RPMudVersionCompatibility

V.MOD_NAMES = {"FS25_MudSystemPhysics"}
V.active = false
V.modName = nil
V.versionString = nil
V.version = nil
V.profile = "NONE"
V._loggedSignature = nil

local function normalizeVersionString(value)
    if value == nil then return nil end
    local s = tostring(value)
    local a,b,c,d = s:match("(%d+)%.(%d+)%.(%d+)%.(%d+)")
    if a ~= nil then
        return string.format("%d.%d.%d.%d", tonumber(a), tonumber(b), tonumber(c), tonumber(d))
    end
    a,b,c = s:match("(%d+)%.(%d+)%.(%d+)")
    if a ~= nil then
        return string.format("%d.%d.%d.0", tonumber(a), tonumber(b), tonumber(c))
    end
    return nil
end

local function versionToNumber(s)
    if s == nil then return nil end
    local a,b,c,d = s:match("^(%d+)%.(%d+)%.(%d+)%.(%d+)$")
    if a == nil then return nil end
    return tonumber(a) * 1000000 + tonumber(b) * 10000 + tonumber(c) * 100 + tonumber(d)
end

local function detectFromModList(mods)
    if type(mods) ~= "table" then return nil, nil end
    for _, info in pairs(mods) do
        if info ~= nil then
            for _, wanted in ipairs(V.MOD_NAMES) do
                if info.modName == wanted then
                    local ver = normalizeVersionString(info.versionString)
                        or normalizeVersionString(info.version)
                        or normalizeVersionString(info.modVersion)
                    return wanted, ver
                end
            end
        end
    end
    return nil, nil
end

function V:detect()
    local activeName = nil
    if g_modIsLoaded ~= nil then
        for _, name in ipairs(self.MOD_NAMES) do
            if g_modIsLoaded[name] == true then
                activeName = name
                break
            end
        end
    end

    local detectedName, detectedVersion = nil, nil
    local mission = g_currentMission
    local dyn = (mission ~= nil and mission.missionDynamicInfo)
        or (g_mpLoadingScreen ~= nil and g_mpLoadingScreen.missionDynamicInfo)
    detectedName, detectedVersion = detectFromModList(dyn ~= nil and dyn.mods or nil)

    if detectedName == nil and g_modManager ~= nil then
        detectedName, detectedVersion = detectFromModList(g_modManager.mods)
    end

    if activeName == nil then activeName = detectedName end

    if activeName == nil then
        for _, name in ipairs(self.MOD_NAMES) do
            if type(rawget(_G, name)) == "table" then
                activeName = name
                break
            end
        end
    end

    self.active = activeName ~= nil
    self.modName = activeName
    self.versionString = detectedVersion
    self.version = versionToNumber(detectedVersion)

    if self.active ~= true then
        self.profile = "NONE"
    elseif self.version ~= nil and self.version >= versionToNumber("1.3.4.0") then
        self.profile = "MUD_1_3_4_ROAD_CONTACT"
    elseif self.version ~= nil and self.version <= versionToNumber("1.3.2.0") then
        self.profile = "MUD_1_3_2_LEGACY"
    else
        self.profile = "MUD_UNKNOWN_SAFE_LEGACY"
    end

    -- Release build: development/diagnostic Mud compatibility logging disabled.
    self._loggedSignature = string.format("%s|%s|%s", tostring(self.active), tostring(self.versionString), tostring(self.profile))

    return self.active, self.profile, self.versionString
end

function V:isActive()
    return self.active == true
end

function V:isRoadContact134OrNewer()
    return self.active == true and self.profile == "MUD_1_3_4_ROAD_CONTACT"
end

function V:loadMap()
    self:detect()
end

function V:deleteMap()
    self.active = false
    self.modName = nil
    self.versionString = nil
    self.version = nil
    self.profile = "NONE"
end

addModEventListener(V)
