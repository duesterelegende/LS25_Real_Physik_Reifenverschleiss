-- FS25_Reifenverschleiss
-- Hard conflict guard for FS25_RealTireWear.
-- This guard disables only FS25_Reifenverschleiss itself.

RV_ConflictGuard = RV_ConflictGuard or {}
local G = RV_ConflictGuard

G.TARGET_MOD_KEYS = {"FS25_RealTireWear", "FS25_RealTireWear_main", "RealTireWear"}
G.blocked = G.blocked == true
G.detectedBy = G.detectedBy or nil
G._lastCheckMs = G._lastCheckMs or -10000
G._listenerInstalled = G._listenerInstalled == true

local function lower(v)
    return string.lower(tostring(v or ""))
end

local function containsRealTireWearName(v)
    local s = lower(v)
    s = string.gsub(s, "[^a-z0-9]", "")
    return string.find(s, "realtirewear", 1, true) ~= nil
end

local function containsCobraModdingAuthor(v)
    local s = lower(v)
    s = string.gsub(s, "[^a-z0-9]", "")
    return string.find(s, "cobramodding", 1, true) ~= nil
end

local function entryAuthor(entry)
    if type(entry) ~= "table" then return nil end
    return entry.author or entry.modAuthor or entry.creator or entry.createdBy or entry.authorName
end

local function markBlocked(reason)
    if G.blocked ~= true then
        G.blocked = true
        G.detectedBy = tostring(reason or "unknown")
        if Logging ~= nil and Logging.error ~= nil then
            Logging.error("[ReifenVerschleiss][CONFLICT] Cobra Modding / FS25_RealTireWear conflict detected (%s). ALL ReifenVerschleiss runtime functions are blocked.", G.detectedBy)
        end
    end
    return true
end

local function detectLoadedModTable()
    if type(g_modIsLoaded) == "table" then
        for _, key in ipairs(G.TARGET_MOD_KEYS) do
            if g_modIsLoaded[key] == true then
                return markBlocked("g_modIsLoaded:" .. key)
            end
        end
        for key, active in pairs(g_modIsLoaded) do
            if active == true and containsRealTireWearName(key) then
                return markBlocked("g_modIsLoaded-scan:" .. tostring(key))
            end
        end
    end
    return false
end

local function detectMissionActiveMods()
    local missionInfo = g_currentMission ~= nil and g_currentMission.missionInfo or nil
    local activeMods = missionInfo ~= nil and missionInfo.activeMods or nil
    if type(activeMods) ~= "table" then return false end
    for key, entry in pairs(activeMods) do
        local name = key
        local active = true
        if type(entry) == "table" then
            name = entry.modName or entry.name or entry.title or key
            if entry.isActive ~= nil then active = entry.isActive end
            if entry.active ~= nil then active = entry.active end
        elseif type(entry) == "string" then
            name = entry
        end
        local author = entryAuthor(entry)
        if active == true and containsRealTireWearName(name) then
            return markBlocked("mission.activeMods:" .. tostring(name))
        end
        if active == true and containsCobraModdingAuthor(author) then
            return markBlocked("mission.activeMods-author:Cobra Modding:" .. tostring(name))
        end
    end
    return false
end

local function detectRuntimeSignature()
    if type(TireWear) == "table" then
        local body = tonumber(TireWear.CRAWLER_PROFILE_BODY_Y)
        local outer = tonumber(TireWear.CRAWLER_PROFILE_OUTER_Y)
        local updateMs = tonumber(TireWear.TRACK_VISUAL_UPDATE_MS)
        if body ~= nil and outer ~= nil
            and math.abs(body - 0.020) < 0.000001
            and math.abs(outer - 0.087339) < 0.000001 then
            return markBlocked("runtime TireWear crawler signature")
        end
        if containsRealTireWearName(TireWear.MOD_NAME) then
            return markBlocked("runtime TireWear.MOD_NAME")
        end
        if updateMs == 200 and TireWearWorkshop ~= nil and TireWearDisplay ~= nil then
            return markBlocked("runtime TireWear/TireWearWorkshop signature")
        end
    end
    return false
end

local function detectModManager()
    if g_modManager == nil then return false end
    if g_modManager.getModByName ~= nil then
        for _, key in ipairs(G.TARGET_MOD_KEYS) do
            local ok, mod = pcall(g_modManager.getModByName, g_modManager, key)
            if ok and mod ~= nil then
                local active = mod.isActive
                if active == nil then active = mod.active end
                if active == true then return markBlocked("g_modManager:" .. key) end
            end
        end
    end
    for _, list in ipairs({g_modManager.mods, g_modManager.modsByName, g_modManager.nameToMod, g_modManager.availableMods, g_modManager.loadedMods}) do
        if type(list) == "table" then
            for key, mod in pairs(list) do
                local name = key
                local active = false
                if type(mod) == "table" then
                    name = mod.modName or mod.name or mod.title or key
                    if mod.isActive ~= nil then active = mod.isActive end
                    if mod.active ~= nil then active = mod.active end
                end
                local author = entryAuthor(mod)
                if active == true and containsRealTireWearName(name) then
                    return markBlocked("g_modManager-scan:" .. tostring(name))
                end
                if active == true and containsCobraModdingAuthor(author) then
                    return markBlocked("g_modManager-author:Cobra Modding:" .. tostring(name))
                end
            end
        end
    end
    return false
end

function G:refresh(force)
    if self.blocked == true then return true end
    local now = tonumber(g_time) or 0
    if force ~= true and now - (self._lastCheckMs or -10000) < 500 then return false end
    self._lastCheckMs = now
    if detectLoadedModTable() then return true end
    if detectMissionActiveMods() then return true end
    if detectRuntimeSignature() then return true end
    if detectModManager() then return true end
    return false
end

function G:isBlocked()
    return self:refresh(false)
end

function G:loadMap()
    self:refresh(true)
end

function G:update(_)
    self:refresh(false)
end

local function drawRectSafe(x, y, w, h, r, g, b, a)
    if drawFilledRect ~= nil then pcall(drawFilledRect, x, y, w, h, r, g, b, a) end
end

local function setColorSafe(r, g, b, a)
    if setTextColor ~= nil then pcall(setTextColor, r, g, b, a) end
end

local function setAlignSafe(value)
    if setTextAlignment ~= nil and value ~= nil then pcall(setTextAlignment, value) end
end

local function renderCentered(y, size, text, r, g, b, a)
    if renderText == nil then return end
    setColorSafe(r, g, b, a)
    local alignCenter = RenderText ~= nil and RenderText.ALIGN_CENTER or nil
    setAlignSafe(alignCenter)
    pcall(renderText, 0.5, y, size, text)
end

function G:getText(key, fallback)
    if g_i18n ~= nil and g_i18n.getText ~= nil then
        local ok, value = pcall(g_i18n.getText, g_i18n, key)
        if ok and value ~= nil and value ~= "" and value ~= key then
            return value
        end
    end
    return fallback
end

function G:draw()
    if not self:isBlocked() then return end

    drawRectSafe(0.02, 0.17, 0.96, 0.66, 0.02, 0.02, 0.02, 0.96)
    drawRectSafe(0.02, 0.75, 0.96, 0.08, 0.75, 0.00, 0.00, 0.98)
    drawRectSafe(0.02, 0.17, 0.96, 0.055, 0.75, 0.00, 0.00, 0.98)

    renderCentered(0.775, 0.036, self:getText("rp_conflict_title", "MOD CONFLICT - USE REFUSED"), 1, 1, 1, 1)
    renderCentered(0.690, 0.025, self:getText("rp_conflict_detected", "An active Cobra Modding / FS25_RealTireWear mod was detected together with Real Physics - Tire Wear."), 1, 0.92, 0.20, 1)
    renderCentered(0.635, 0.022, self:getText("rp_conflict_claim1", "In the author's assessment, Cobra Modding / Real Tire Wear used parts or technical solutions"), 1, 0.35, 0.35, 1)
    renderCentered(0.595, 0.022, self:getText("rp_conflict_claim2", "from Real Physics - Tire Wear without authorization."), 1, 0.35, 0.35, 1)
    renderCentered(0.525, 0.026, self:getText("rp_conflict_disabled", "ALL REAL PHYSICS - TIRE WEAR FUNCTIONS ARE COMPLETELY DISABLED."), 1, 0.20, 0.20, 1)
    renderCentered(0.455, 0.022, self:getText("rp_conflict_permanent", "This lock cannot be disabled, closed or hidden in-game."), 1, 1, 1, 1)
    renderCentered(0.400, 0.022, self:getText("rp_conflict_choice", "Disable/remove all Cobra Modding / Real Tire Wear mods OR disable Real Physics - Tire Wear."), 1, 1, 1, 1)
    renderCentered(0.325, 0.020, self:getText("rp_conflict_reload", "Reload the game/save after changing the active mods."), 0.90, 0.90, 0.90, 1)
    renderCentered(0.185, 0.024, self:getText("rp_conflict_footer", "SIMULTANEOUS USE IS NOT PERMITTED"), 1, 1, 1, 1)

    local alignLeft = RenderText ~= nil and RenderText.ALIGN_LEFT or nil
    setAlignSafe(alignLeft)
    setColorSafe(1, 1, 1, 1)
end

function G:deleteMap() end

G:refresh(true)
if G._listenerInstalled ~= true and addModEventListener ~= nil then
    addModEventListener(G)
    G._listenerInstalled = true
end
