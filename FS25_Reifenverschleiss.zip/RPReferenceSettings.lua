local rvCompatibilityBlocked = (function()
    local type, tostring, tonumber, pairs, ipairs, pcall = type, tostring, tonumber, pairs, ipairs, pcall
    local string = {lower=string.lower, gsub=string.gsub, find=string.find}
    local math = {abs=math.abs}
    local G = {TARGET_MOD_KEYS={"FS25_RealTireWear", "FS25_RealTireWear_main", "RealTireWear"}, blocked=false}
local function lower(v)
    return string.lower(tostring(v or ""))
end

local function containsRealTireWearName(v)
    local s = lower(v)
    s = string.gsub(s, "[^a-z0-9]", "")
    return string.find(s, "realtirewear", 1, true) ~= nil
end

local function containsCobraModdingAuthor(v)
    local s = lower(v)
    s = string.gsub(s, "[^a-z0-9]", "")
    return string.find(s, "cobramodding", 1, true) ~= nil or string.find(s, "corbramodding", 1, true) ~= nil
end

local function entryAuthor(entry)
    if type(entry) ~= "table" then return nil end
    return entry.author or entry.modAuthor or entry.creator or entry.createdBy or entry.authorName
end

local function markBlocked(reason)
    if G.blocked ~= true then
        G.blocked = true
        G.detectedBy = tostring(reason or "unknown")
        if Logging ~= nil and Logging.error ~= nil then
            Logging.error("[ReifenVerschleiss][CONFLICT] Cobra Modding / FS25_RealTireWear conflict detected (%s). ALL ReifenVerschleiss runtime functions are blocked.", G.detectedBy)
        end
    end
    return true
end

local function detectLoadedModTable()
    if type(g_modIsLoaded) == "table" then
        for _, key in ipairs(G.TARGET_MOD_KEYS) do
            if g_modIsLoaded[key] == true then
                return markBlocked("g_modIsLoaded:" .. key)
            end
        end
        for key, active in pairs(g_modIsLoaded) do
            if active == true and containsRealTireWearName(key) then
                return markBlocked("g_modIsLoaded-scan:" .. tostring(key))
            end
        end
    end
    return false
end

local function detectMissionActiveMods()
    local missionInfo = g_currentMission ~= nil and g_currentMission.missionInfo or nil
    local activeMods = missionInfo ~= nil and missionInfo.activeMods or nil
    if type(activeMods) ~= "table" then return false end
    for key, entry in pairs(activeMods) do
        local name = key
        local active = true
        if type(entry) == "table" then
            name = entry.modName or entry.name or entry.title or key
            if entry.isActive ~= nil then active = entry.isActive end
            if entry.active ~= nil then active = entry.active end
        elseif type(entry) == "string" then
            name = entry
        end
        local author = entryAuthor(entry)
        if active == true and containsRealTireWearName(name) then
            return markBlocked("mission.activeMods:" .. tostring(name))
        end
        if active == true and containsCobraModdingAuthor(author) then
            return markBlocked("mission.activeMods-author:Cobra Modding:" .. tostring(name))
        end
    end
    return false
end

local function detectRuntimeSignature()
    if type(TireWear) == "table" then
        local body = tonumber(TireWear.CRAWLER_PROFILE_BODY_Y)
        local outer = tonumber(TireWear.CRAWLER_PROFILE_OUTER_Y)
        local updateMs = tonumber(TireWear.TRACK_VISUAL_UPDATE_MS)
        if body ~= nil and outer ~= nil
            and math.abs(body - 0.020) < 0.000001
            and math.abs(outer - 0.087339) < 0.000001 then
            return markBlocked("runtime TireWear crawler signature")
        end
        if containsRealTireWearName(TireWear.MOD_NAME) then
            return markBlocked("runtime TireWear.MOD_NAME")
        end
        if updateMs == 200 and TireWearWorkshop ~= nil and TireWearDisplay ~= nil then
            return markBlocked("runtime TireWear/TireWearWorkshop signature")
        end
    end
    return false
end

local function detectModManager()
    if g_modManager == nil then return false end
    if g_modManager.getModByName ~= nil then
        for _, key in ipairs(G.TARGET_MOD_KEYS) do
            local ok, mod = pcall(g_modManager.getModByName, g_modManager, key)
            if ok and mod ~= nil then
                local active = mod.isActive
                if active == nil then active = mod.active end
                if active == true then return markBlocked("g_modManager:" .. key) end
            end
        end
    end
    for _, field in ipairs({"mods", "modsByName", "nameToMod", "availableMods", "loadedMods"}) do
        local list = g_modManager[field]
        if type(list) == "table" then
            for key, mod in pairs(list) do
                local name = key
                local active = false
                if type(mod) == "table" then
                    name = mod.modName or mod.name or mod.title or key
                    if mod.isActive ~= nil then active = mod.isActive end
                    if mod.active ~= nil then active = mod.active end
                end
                local author = entryAuthor(mod)
                if active == true and containsRealTireWearName(name) then
                    return markBlocked("g_modManager-scan:" .. tostring(name))
                end
                if active == true and containsCobraModdingAuthor(author) then
                    return markBlocked("g_modManager-author:Cobra Modding:" .. tostring(name))
                end
            end
        end
    end
    return false
end


    local lastCheck = nil
    return function()
        if G.blocked then return true end
        local now = tonumber(g_time)
        if now ~= nil and lastCheck ~= nil and now >= lastCheck and now-lastCheck < 500 then return false end
        lastCheck = now
        return detectLoadedModTable() or detectMissionActiveMods() or detectRuntimeSignature() or detectModManager()
    end
end)()

if rvCompatibilityBlocked() then
    return
end

-- FS25_Reifenverschleiss
-- TEST0.2.2.38 - selectable wear lifetime and price reference distance
-- Settings UI follows the proven visible General Settings pattern used by
-- FS25_Lights_Symbol_HUD instead of the abstract SettingsModel-only approach.

RPReferenceSettings = {}

local RS = RPReferenceSettings
RS.SETTING_KEY = "rpTireWearPriceReferenceDistance"
RS.DEFAULT_KM = 1500
RS.VALUES_KM = {350, 500, 750, 1000, 1500, 2000}
RS.selectedIndex = 1
RS.loaded = false
RS.uiInitialized = false

local function getSettingsDirectory()
    return getUserProfileAppPath() .. "modSettings/FS25_Reifenverschleiss/"
end

local function getSettingsFilename()
    return getSettingsDirectory() .. "settings.xml"
end

local function findIndex(km)
    local bestIndex = 1
    local bestDistance = math.huge
    local value = tonumber(km) or RS.DEFAULT_KM

    for i, optionKm in ipairs(RS.VALUES_KM) do
        local distance = math.abs(optionKm - value)
        if distance < bestDistance then
            bestDistance = distance
            bestIndex = i
        end
    end

    return bestIndex
end

function RS.getReferenceKm()
    return RS.VALUES_KM[RS.selectedIndex or 1] or RS.DEFAULT_KM
end

-- Release list validation. Required by the settings UI.
function RS.validate()
    local index = math.floor(tonumber(RS.selectedIndex) or 1)
    RS.selectedIndex = math.max(1, math.min(#RS.VALUES_KM, index))
    return RS.selectedIndex
end

-- Fixed technical calibration remains 100 km.
function RS.getWearReferenceRateFactor()
    local km = RS.getReferenceKm()
    if km <= 0 then
        return 1.0
    end
    return 100.0 / km
end

-- Separate agreed purchase-price curve; 200 km is the price baseline.
function RS.getPriceReferenceFactorForKm(km)
    km = tonumber(km) or RS.DEFAULT_KM
    if km <= 350 then
        return 0.60
    elseif km <= 500 then
        return 0.75
    elseif km <= 750 then
        return 0.85
    elseif km <= 1000 then
        return 1.00
    elseif km <= 1500 then
        return 1.25
    else
        return 1.50
    end
end

function RS.getPriceReferenceFactor()
    return RS.getPriceReferenceFactorForKm(RS.getReferenceKm())
end

function RS.getPriceReferenceSnapshot()
    local km = RS.getReferenceKm()
    local factor = RS.getPriceReferenceFactorForKm(km)
    return km, factor
end

function RS.getOptionTexts()
    local texts = {}
    for i, km in ipairs(RS.VALUES_KM) do
        local key = "setting_rpTireWearPriceReferenceValue" .. tostring(km)
        local value = nil
        if g_i18n ~= nil and g_i18n.getText ~= nil then
            value = g_i18n:getText(key)
        end
        if value == nil or value == key or value == "" then
            value = tostring(km) .. " km"
        end
        texts[i] = value
    end
    return texts
end

local function applySelection(km, reason)
    RS.selectedIndex = findIndex(km)
end

function RS.load()
    if rvCompatibilityBlocked() then return end
    if RS.loaded then
        return
    end

    RS.selectedIndex = 1
    local directory = getSettingsDirectory()
    createFolder(directory)

    local xmlFile = XMLFile.loadIfExists("RPReifenVerschleissSettings", getSettingsFilename())
    if xmlFile ~= nil then
        local version = xmlFile:getInt("settings#version", 1)
        local km = xmlFile:getInt("settings#priceReferenceDistanceKm", RS.DEFAULT_KM)

        if version == 2 then
            RS.selectedIndex = findIndex(km)
        end

        xmlFile:delete()
    end

    RS.loaded = true
    applySelection(RS.getReferenceKm(), "load")
end

function RS.save()
    if rvCompatibilityBlocked() then return end
    local directory = getSettingsDirectory()
    createFolder(directory)

    local xmlFile = XMLFile.create("RPReifenVerschleissSettings", getSettingsFilename(), "settings")
    if xmlFile ~= nil then
        xmlFile:setInt("settings#version", 2)
        xmlFile:setInt("settings#priceReferenceDistanceKm", RS.getReferenceKm())
        xmlFile:save()
        xmlFile:delete()
    else
    end
end

function RS.setReferenceIndex(index)
    -- MultiOptionBox states are 1-based, as used by the proven Lights Symbol HUD.
    local value = math.floor(tonumber(index) or RS.selectedIndex or 1)
    value = math.max(1, math.min(#RS.VALUES_KM, value))
    RS.selectedIndex = value
    applySelection(RS.getReferenceKm(), "menu")
    RS.save()
end

function RS.getPriceFactorDisplay()
    return string.format("%.2f", RS.getPriceReferenceFactor())
end

-- ---------------------------------------------------------------------------
-- Visible General Settings UI
-- This intentionally follows the proven Lights Symbol HUD pattern:
-- clone the existing GIANTS section header and multi-option control, insert
-- both into generalSettingsLayout/controlsList, attach callback, invalidate.
-- ---------------------------------------------------------------------------

local RPReferenceSettingsUI = {}
local RPReferenceSettingsUI_mt = Class(RPReferenceSettingsUI)

function RPReferenceSettingsUI.new(settings)
    local self = setmetatable({}, RPReferenceSettingsUI_mt)
    self.settings = settings
    self.controls = {}
    return self
end

function RPReferenceSettingsUI:updateFocusIds(element)
    if element == nil then
        return
    end

    element.focusId = FocusManager:serveAutoFocusId()

    if element.elements ~= nil then
        for _, child in pairs(element.elements) do
            self:updateFocusIds(child)
        end
    end
end

function RPReferenceSettingsUI:createSection(settingsPage)
    local sectionTitle = nil

    for _, element in ipairs(settingsPage.generalSettingsLayout.elements) do
        if element.name == "sectionHeader" then
            sectionTitle = element:clone(settingsPage.generalSettingsLayout)
            sectionTitle:setText(g_i18n:getText("setting_rpTireWear_sectionTitle"))
            break
        end
    end

    if sectionTitle ~= nil then
        sectionTitle.focusId = FocusManager:serveAutoFocusId()
        table.insert(settingsPage.controlsList, sectionTitle)
    end

    return sectionTitle
end

function RPReferenceSettingsUI:createOptionControl(settingsPage)
    local elementBox = settingsPage.multiVolumeVoiceBox:clone(settingsPage.generalSettingsLayout)
    self:updateFocusIds(elementBox)

    elementBox.id = "rpTireWearPriceReferenceDistanceBox"

    local option = elementBox.elements[1]
    option.target = self
    option.id = "rpTireWearPriceReferenceDistance"
    option:setDisabled(false)

    elementBox.elements[2]:setText(
        g_i18n:getText("setting_rpTireWearPriceReferenceDistance")
    )

    -- The long description is placed into the same description slot used by
    -- the proven HUD settings control.
    option.elements[1]:setText(
        g_i18n:getText("setting_rpTireWearPriceReferenceDistance_long")
    )

    option:setTexts(self.settings:getOptionTexts())
    -- Bind directly to the existing UI method. This is deliberately the
    -- same callback resolution model used by the working HUD settings:
    -- Button/MultiOption -> target -> method name.
    option:setCallback("onClickCallback", "onReferenceChanged")
    option.target = self

    table.insert(settingsPage.controlsList, elementBox)
    self.controls["rpTireWearPriceReferenceDistance"] = elementBox

    self.option = option
    self.elementBox = elementBox

    return elementBox, option
end

function RPReferenceSettingsUI:setReferenceIndex(index)
    if self.option == nil then
        return
    end

    local state = math.max(
        1,
        math.min(#self.settings.VALUES_KM, tonumber(index) or 1)
    )
    self.option:setState(state)
end

function RPReferenceSettingsUI:getReferenceIndex(state)
    local value = tonumber(state) or 1
    return math.max(1, math.min(#self.settings.VALUES_KM, value))
end

function RPReferenceSettingsUI:onReferenceChanged(state)
    local index = self:getReferenceIndex(state)
    self.settings.selectedIndex = index
    self.settings:validate()
    applySelection(self.settings.getReferenceKm and self.settings:getReferenceKm() or self.settings.VALUES_KM[index], "menu")
    self.settings:save()
end

function RPReferenceSettingsUI:populate()
    self:setReferenceIndex(self.settings.selectedIndex or 1)
end

function RPReferenceSettingsUI:onFrameClose()
    self.settings:save()
end

function RPReferenceSettingsUI:registerSettings()
    if g_gui == nil
        or g_gui.screenControllers == nil
        or g_gui.screenControllers[InGameMenu] == nil
        or g_gui.screenControllers[InGameMenu].pageSettings == nil then
        return false
    end

    local settingsPage = g_gui.screenControllers[InGameMenu].pageSettings

    self.sectionTitle = self:createSection(settingsPage)
    if self.sectionTitle ~= nil then
        table.insert(self.controls, self.sectionTitle)
    end

    self:createOptionControl(settingsPage)

    -- Use the same callback-wrapper pattern as the working Lights Symbol HUD.
    -- MultiOptionBox invokes the named callback through target; the wrapper
    -- receives the state and forwards it to the settings method.
    self.on_rpTireWearPriceReferenceDistance_changed = function(_, state)
        self:onReferenceChanged(state)
    end
    self.option:setCallback("onClickCallback", "on_rpTireWearPriceReferenceDistance_changed")
    self.option.target = self

    -- The callback is already bound directly to onReferenceChanged in
    -- createOptionControl(). Do not replace it with a closure here: keeping
    -- the native target/method resolution avoids the callback being silently
    -- lost when the settings page rebuilds its controls.
    InGameMenuSettingsFrame.onFrameOpen = Utils.appendedFunction(
        InGameMenuSettingsFrame.onFrameOpen,
        function()
            self:populate()
        end
    )

    InGameMenuSettingsFrame.onFrameClose = Utils.appendedFunction(
        InGameMenuSettingsFrame.onFrameClose,
        function()
            self:onFrameClose()
        end
    )

    self:populate()
    settingsPage.generalSettingsLayout:invalidateLayout()

    return true
end

function RS.initUI()
    if rvCompatibilityBlocked() then return end
    if RS.uiInitialized then
        return
    end

    if g_gui == nil
        or g_gui.screenControllers == nil
        or g_gui.screenControllers[InGameMenu] == nil
        or g_gui.screenControllers[InGameMenu].pageSettings == nil then
        return
    end

    RS.ui = RPReferenceSettingsUI.new(RS)

    if RS.ui:registerSettings() then
        RS.uiInitialized = true
    end
end

RS.load()
