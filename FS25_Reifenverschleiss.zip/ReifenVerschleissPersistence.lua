local rvCompatibilityBlocked = (function()
    local type, tostring, tonumber, pairs, ipairs, pcall = type, tostring, tonumber, pairs, ipairs, pcall
    local string = {lower=string.lower, gsub=string.gsub, find=string.find}
    local math = {abs=math.abs}
    local G = {TARGET_MOD_KEYS={"FS25_RealTireWear", "FS25_RealTireWear_main", "RealTireWear"}, blocked=false}
local function lower(v)
    return string.lower(tostring(v or ""))
end

local function containsRealTireWearName(v)
    local s = lower(v)
    s = string.gsub(s, "[^a-z0-9]", "")
    return string.find(s, "realtirewear", 1, true) ~= nil
end

local function containsCobraModdingAuthor(v)
    local s = lower(v)
    s = string.gsub(s, "[^a-z0-9]", "")
    return string.find(s, "cobramodding", 1, true) ~= nil or string.find(s, "corbramodding", 1, true) ~= nil
end

local function entryAuthor(entry)
    if type(entry) ~= "table" then return nil end
    return entry.author or entry.modAuthor or entry.creator or entry.createdBy or entry.authorName
end

local function markBlocked(reason)
    if G.blocked ~= true then
        G.blocked = true
        G.detectedBy = tostring(reason or "unknown")
        if Logging ~= nil and Logging.error ~= nil then
            Logging.error("[ReifenVerschleiss][CONFLICT] Cobra Modding / FS25_RealTireWear conflict detected (%s). ALL ReifenVerschleiss runtime functions are blocked.", G.detectedBy)
        end
    end
    return true
end

local function detectLoadedModTable()
    if type(g_modIsLoaded) == "table" then
        for _, key in ipairs(G.TARGET_MOD_KEYS) do
            if g_modIsLoaded[key] == true then
                return markBlocked("g_modIsLoaded:" .. key)
            end
        end
        for key, active in pairs(g_modIsLoaded) do
            if active == true and containsRealTireWearName(key) then
                return markBlocked("g_modIsLoaded-scan:" .. tostring(key))
            end
        end
    end
    return false
end

local function detectMissionActiveMods()
    local missionInfo = g_currentMission ~= nil and g_currentMission.missionInfo or nil
    local activeMods = missionInfo ~= nil and missionInfo.activeMods or nil
    if type(activeMods) ~= "table" then return false end
    for key, entry in pairs(activeMods) do
        local name = key
        local active = true
        if type(entry) == "table" then
            name = entry.modName or entry.name or entry.title or key
            if entry.isActive ~= nil then active = entry.isActive end
            if entry.active ~= nil then active = entry.active end
        elseif type(entry) == "string" then
            name = entry
        end
        local author = entryAuthor(entry)
        if active == true and containsRealTireWearName(name) then
            return markBlocked("mission.activeMods:" .. tostring(name))
        end
        if active == true and containsCobraModdingAuthor(author) then
            return markBlocked("mission.activeMods-author:Cobra Modding:" .. tostring(name))
        end
    end
    return false
end

local function detectRuntimeSignature()
    if type(TireWear) == "table" then
        local body = tonumber(TireWear.CRAWLER_PROFILE_BODY_Y)
        local outer = tonumber(TireWear.CRAWLER_PROFILE_OUTER_Y)
        local updateMs = tonumber(TireWear.TRACK_VISUAL_UPDATE_MS)
        if body ~= nil and outer ~= nil
            and math.abs(body - 0.020) < 0.000001
            and math.abs(outer - 0.087339) < 0.000001 then
            return markBlocked("runtime TireWear crawler signature")
        end
        if containsRealTireWearName(TireWear.MOD_NAME) then
            return markBlocked("runtime TireWear.MOD_NAME")
        end
        if updateMs == 200 and TireWearWorkshop ~= nil and TireWearDisplay ~= nil then
            return markBlocked("runtime TireWear/TireWearWorkshop signature")
        end
    end
    return false
end

local function detectModManager()
    if g_modManager == nil then return false end
    if g_modManager.getModByName ~= nil then
        for _, key in ipairs(G.TARGET_MOD_KEYS) do
            local ok, mod = pcall(g_modManager.getModByName, g_modManager, key)
            if ok and mod ~= nil then
                local active = mod.isActive
                if active == nil then active = mod.active end
                if active == true then return markBlocked("g_modManager:" .. key) end
            end
        end
    end
    for _, field in ipairs({"mods", "modsByName", "nameToMod", "availableMods", "loadedMods"}) do
        local list = g_modManager[field]
        if type(list) == "table" then
            for key, mod in pairs(list) do
                local name = key
                local active = false
                if type(mod) == "table" then
                    name = mod.modName or mod.name or mod.title or key
                    if mod.isActive ~= nil then active = mod.isActive end
                    if mod.active ~= nil then active = mod.active end
                end
                local author = entryAuthor(mod)
                if active == true and containsRealTireWearName(name) then
                    return markBlocked("g_modManager-scan:" .. tostring(name))
                end
                if active == true and containsCobraModdingAuthor(author) then
                    return markBlocked("g_modManager-author:Cobra Modding:" .. tostring(name))
                end
            end
        end
    end
    return false
end


    local lastCheck = nil
    return function()
        if G.blocked then return true end
        local now = tonumber(g_time)
        if now ~= nil and lastCheck ~= nil and now >= lastCheck and now-lastCheck < 500 then return false end
        lastCheck = now
        return detectLoadedModTable() or detectMissionActiveMods() or detectRuntimeSignature() or detectModManager()
    end
end)()

-- FS25_Reifenverschleiss - native vehicle specialization used only for
-- persistence of the already existing OWN-WEAR runtime state.
-- No wear calculation, EWFS, HUD, visual or attachment logic lives here.

ReifenVerschleissPersistence = {}

local function vehicleBaseKeyFromSpecializationKey(key)
    if type(key) ~= "string" then return nil end

    -- Vehicle:saveToXMLFile calls each specialization with
    -- "vehicles.vehicle(n).<specializationName>". The OWN-WEAR schema is kept
    -- deliberately version-independent at "vehicles.vehicle(n).reifenVerschleiss".
    local base = string.match(key, "^(vehicles%.vehicle%(%d+%))")
    return base
end

function ReifenVerschleissPersistence.prerequisitesPresent(specializations)
    if rvCompatibilityBlocked() then return false end
    -- Attach to all vehicle types. The diagnostic persistence writer itself
    -- exits immediately for objects without wheel/track wear objects.
    return true
end

function ReifenVerschleissPersistence.initSpecialization()
    local schema = Vehicle ~= nil and Vehicle.xmlSchemaSavegame or nil
    if schema == nil or XMLValueType == nil then
        Logging.error("[ReifenVerschleiss][SAVE] Persistence specialization could not access Vehicle.xmlSchemaSavegame")
        return
    end

    local base = "vehicles.vehicle(?).reifenVerschleiss"
    schema:register(XMLValueType.INT, base .. "#version", "Reifenverschleiss OWN-WEAR schema version")
    schema:register(XMLValueType.FLOAT, base .. "#totalDistanceWear", "Own total distance wear")
    schema:register(XMLValueType.FLOAT, base .. "#totalSlipWear", "Own total slip wear")
    schema:register(XMLValueType.FLOAT, base .. "#totalTimeWear", "Own total active-movement time wear")
    schema:register(XMLValueType.FLOAT, base .. "#totalForceWear", "Own total longitudinal force wear")
    schema:register(XMLValueType.FLOAT, base .. "#totalWear", "Own aggregate wear")
    schema:register(XMLValueType.FLOAT, base .. "#totalEffectiveWearDistanceM", "Own effective wear distance")

    for _, child in ipairs({"wheel(?)", "track(?)"}) do
        local key = base .. "." .. child
        schema:register(XMLValueType.STRING, key .. "#key", "Stable own-wear object key")
        if child == "track(?)" then
            schema:register(XMLValueType.INT, key .. "#index", "Stable crawler index")
            schema:register(XMLValueType.STRING, key .. "#side", "Crawler side")
            schema:register(XMLValueType.FLOAT, key .. "#rollerWear", "Crawler roller mileage wear")
            schema:register(XMLValueType.FLOAT, key .. "#rollerLifetimeFactor", "Persistent crawler roller lifetime factor")
            schema:register(XMLValueType.FLOAT, key .. "#rollerDistanceM", "Crawler roller travelled distance")
        end
        schema:register(XMLValueType.FLOAT, key .. "#distanceWear", "Own distance wear")
        schema:register(XMLValueType.FLOAT, key .. "#slipWear", "Own slip wear")
        schema:register(XMLValueType.FLOAT, key .. "#timeWear", "Own active-movement time wear")
        schema:register(XMLValueType.FLOAT, key .. "#forceWear", "Own longitudinal force wear")
        schema:register(XMLValueType.FLOAT, key .. "#totalWear", "Own total wear")
        schema:register(XMLValueType.FLOAT, key .. "#effectiveDistanceM", "Own effective distance")
        schema:register(XMLValueType.FLOAT, key .. "#slipDistanceM", "Own slip distance")
        schema:register(XMLValueType.FLOAT, key .. "#lastSlip", "Last slip percent")
        schema:register(XMLValueType.FLOAT, key .. "#lastSlipWearPointsPerSecond", "Last slip wear rate")
        schema:register(XMLValueType.STRING, key .. "#lastGroundClass", "Last ground class")
        schema:register(XMLValueType.FLOAT, key .. "#lastDistanceFactor", "Last distance factor")
        schema:register(XMLValueType.FLOAT, key .. "#lastSlipFactor", "Last slip factor")
        schema:register(XMLValueType.FLOAT, key .. "#lastLoadFactor", "Last load factor")
    end

end

function ReifenVerschleissPersistence.registerEventListeners(vehicleType)
    SpecializationUtil.registerEventListener(vehicleType, "onLoad", ReifenVerschleissPersistence)
    SpecializationUtil.registerEventListener(vehicleType, "onLoadFinished", ReifenVerschleissPersistence)
    SpecializationUtil.registerEventListener(vehicleType, "saveToXMLFile", ReifenVerschleissPersistence)
end

function ReifenVerschleissPersistence:onLoad(savegame)
    if rvCompatibilityBlocked() then return end
    if ReifenVerschleissCore ~= nil
        and ReifenVerschleissCore.isVehicleExcluded ~= nil
        and ReifenVerschleissCore.isVehicleExcluded(self) then
        return
    end
    if ReifenVerschleissCore == nil or type(ReifenVerschleissCore.captureVehicleWearSavegame) ~= "function" then
        return
    end

    -- Capture only. The wear manifest is intentionally not built here because
    -- onLoad is earlier than the final wheel/crawler lifecycle. Restoration is
    -- applied at onLoadFinished, after the concrete vehicle is complete.
    local ok, err = pcall(ReifenVerschleissCore.captureVehicleWearSavegame, self, savegame)
    if not ok then
        Logging.error("[ReifenVerschleiss][SAVE] specialization onLoad capture failed for '%s': %s", tostring(self.configFileName or self.typeName), tostring(err))
    elseif savegame ~= nil then
    end
end

function ReifenVerschleissPersistence:onLoadFinished(savegame)
    if rvCompatibilityBlocked() then return end
    if ReifenVerschleissCore ~= nil
        and ReifenVerschleissCore.isVehicleExcluded ~= nil
        and ReifenVerschleissCore.isVehicleExcluded(self) then
        return
    end
    if ReifenVerschleissCore == nil or type(ReifenVerschleissCore.applyCapturedVehicleWearSavegame) ~= "function" then
        return
    end

    local ok, applied = pcall(ReifenVerschleissCore.applyCapturedVehicleWearSavegame, self)
    if not ok then
        Logging.error("[ReifenVerschleiss][SAVE] specialization restore failed for '%s': %s", tostring(self.configFileName or self.typeName), tostring(applied))
    elseif applied == true then

        -- TEST2.3.93: the specialization restore event is the first boundary at
        -- which OWN-WEAR is demonstrably present on every affected vehicle.
        -- Tab-switching already proved that calling the existing visual worker
        -- after this point makes T9/Raptor consume the correct saved state.
        -- Do the same synchronization here without changing controlledVehicle,
        -- enter/leave state, camera, input, physics, EWFS or the wear values.
        if ReifenVerschleissVisual ~= nil and
           type(ReifenVerschleissVisual.refreshVehicleWearVisualsImmediate) == "function" then
            local okVisual, errVisual = pcall(
                ReifenVerschleissVisual.refreshVehicleWearVisualsImmediate,
                self
            )
            if not okVisual then
                Logging.error("[ReifenVerschleiss][VISUAL-RESTORE] immediate refresh failed for '%s': %s",
                    tostring(self.configFileName or self.typeName), tostring(errVisual))
            else
            end

            -- Keep the already existing .92 visual-only settling queue as a
            -- short safety net for asynchronously finalised crawler materials.
            -- Unlike .92, it is now armed from the proven persistence-restore
            -- boundary instead of relying on the generic Vehicle hook ordering.
            if type(ReifenVerschleissVisual.queueLoadVisualRefresh) == "function" then
                ReifenVerschleissVisual.queueLoadVisualRefresh(self)
            end
        end
    end
end

function ReifenVerschleissPersistence:saveToXMLFile(xmlFile, key, usedModNames)
    if rvCompatibilityBlocked() then return end
    if ReifenVerschleissCore ~= nil
        and ReifenVerschleissCore.isVehicleExcluded ~= nil
        and ReifenVerschleissCore.isVehicleExcluded(self) then
        return
    end
    if ReifenVerschleissCore == nil or type(ReifenVerschleissCore.saveVehicleWearToSavegame) ~= "function" then
        return
    end

    local vehicleKey = vehicleBaseKeyFromSpecializationKey(key)
    if vehicleKey == nil then
        Logging.error("[ReifenVerschleiss][SAVE] specialization could not resolve vehicle base key from '%s'", tostring(key))
        return
    end

    local ok, err = pcall(ReifenVerschleissCore.saveVehicleWearToSavegame, self, xmlFile, vehicleKey)
    if not ok then
        Logging.error("[ReifenVerschleiss][SAVE] specialization write failed vehicle='%s' key='%s': %s", tostring(self.configFileName or self.typeName), tostring(vehicleKey), tostring(err))
    end
end
