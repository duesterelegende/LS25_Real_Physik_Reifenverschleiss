local rvCompatibilityBlocked = (function()
    local type, tostring, tonumber, pairs, ipairs, pcall = type, tostring, tonumber, pairs, ipairs, pcall
    local string = {lower=string.lower, gsub=string.gsub, find=string.find}
    local math = {abs=math.abs}
    local G = {TARGET_MOD_KEYS={"FS25_RealTireWear", "FS25_RealTireWear_main", "RealTireWear"}, blocked=false}
local function lower(v)
    return string.lower(tostring(v or ""))
end

local function containsRealTireWearName(v)
    local s = lower(v)
    s = string.gsub(s, "[^a-z0-9]", "")
    return string.find(s, "realtirewear", 1, true) ~= nil
end

local function containsCobraModdingAuthor(v)
    local s = lower(v)
    s = string.gsub(s, "[^a-z0-9]", "")
    return string.find(s, "cobramodding", 1, true) ~= nil or string.find(s, "corbramodding", 1, true) ~= nil
end

local function entryAuthor(entry)
    if type(entry) ~= "table" then return nil end
    return entry.author or entry.modAuthor or entry.creator or entry.createdBy or entry.authorName
end

local function markBlocked(reason)
    if G.blocked ~= true then
        G.blocked = true
        G.detectedBy = tostring(reason or "unknown")
        if Logging ~= nil and Logging.error ~= nil then
            Logging.error("[ReifenVerschleiss][CONFLICT] Cobra Modding / FS25_RealTireWear conflict detected (%s). ALL ReifenVerschleiss runtime functions are blocked.", G.detectedBy)
        end
    end
    return true
end

local function detectLoadedModTable()
    if type(g_modIsLoaded) == "table" then
        for _, key in ipairs(G.TARGET_MOD_KEYS) do
            if g_modIsLoaded[key] == true then
                return markBlocked("g_modIsLoaded:" .. key)
            end
        end
        for key, active in pairs(g_modIsLoaded) do
            if active == true and containsRealTireWearName(key) then
                return markBlocked("g_modIsLoaded-scan:" .. tostring(key))
            end
        end
    end
    return false
end

local function detectMissionActiveMods()
    local missionInfo = g_currentMission ~= nil and g_currentMission.missionInfo or nil
    local activeMods = missionInfo ~= nil and missionInfo.activeMods or nil
    if type(activeMods) ~= "table" then return false end
    for key, entry in pairs(activeMods) do
        local name = key
        local active = true
        if type(entry) == "table" then
            name = entry.modName or entry.name or entry.title or key
            if entry.isActive ~= nil then active = entry.isActive end
            if entry.active ~= nil then active = entry.active end
        elseif type(entry) == "string" then
            name = entry
        end
        local author = entryAuthor(entry)
        if active == true and containsRealTireWearName(name) then
            return markBlocked("mission.activeMods:" .. tostring(name))
        end
        if active == true and containsCobraModdingAuthor(author) then
            return markBlocked("mission.activeMods-author:Cobra Modding:" .. tostring(name))
        end
    end
    return false
end

local function detectRuntimeSignature()
    if type(TireWear) == "table" then
        local body = tonumber(TireWear.CRAWLER_PROFILE_BODY_Y)
        local outer = tonumber(TireWear.CRAWLER_PROFILE_OUTER_Y)
        local updateMs = tonumber(TireWear.TRACK_VISUAL_UPDATE_MS)
        if body ~= nil and outer ~= nil
            and math.abs(body - 0.020) < 0.000001
            and math.abs(outer - 0.087339) < 0.000001 then
            return markBlocked("runtime TireWear crawler signature")
        end
        if containsRealTireWearName(TireWear.MOD_NAME) then
            return markBlocked("runtime TireWear.MOD_NAME")
        end
        if updateMs == 200 and TireWearWorkshop ~= nil and TireWearDisplay ~= nil then
            return markBlocked("runtime TireWear/TireWearWorkshop signature")
        end
    end
    return false
end

local function detectModManager()
    if g_modManager == nil then return false end
    if g_modManager.getModByName ~= nil then
        for _, key in ipairs(G.TARGET_MOD_KEYS) do
            local ok, mod = pcall(g_modManager.getModByName, g_modManager, key)
            if ok and mod ~= nil then
                local active = mod.isActive
                if active == nil then active = mod.active end
                if active == true then return markBlocked("g_modManager:" .. key) end
            end
        end
    end
    for _, field in ipairs({"mods", "modsByName", "nameToMod", "availableMods", "loadedMods"}) do
        local list = g_modManager[field]
        if type(list) == "table" then
            for key, mod in pairs(list) do
                local name = key
                local active = false
                if type(mod) == "table" then
                    name = mod.modName or mod.name or mod.title or key
                    if mod.isActive ~= nil then active = mod.isActive end
                    if mod.active ~= nil then active = mod.active end
                end
                local author = entryAuthor(mod)
                if active == true and containsRealTireWearName(name) then
                    return markBlocked("g_modManager-scan:" .. tostring(name))
                end
                if active == true and containsCobraModdingAuthor(author) then
                    return markBlocked("g_modManager-author:Cobra Modding:" .. tostring(name))
                end
            end
        end
    end
    return false
end


    local lastCheck = nil
    return function()
        if G.blocked then return true end
        local now = tonumber(g_time)
        if now ~= nil and lastCheck ~= nil and now >= lastCheck and now-lastCheck < 500 then return false end
        lastCheck = now
        return detectLoadedModTable() or detectMissionActiveMods() or detectRuntimeSignature() or detectModManager()
    end
end)()

local rvDisplayReady = (function()
    local pcall, type, pairs = pcall, type, pairs
    local drawFilledRect, setTextColor, setTextAlignment, renderText = drawFilledRect, setTextColor, setTextAlignment, renderText
    local RenderText = RenderText
    local addListener = addModEventListener
local function drawRectSafe(x, y, w, h, r, g, b, a)
    if drawFilledRect ~= nil then pcall(drawFilledRect, x, y, w, h, r, g, b, a) end
end

local function setColorSafe(r, g, b, a)
    if setTextColor ~= nil then pcall(setTextColor, r, g, b, a) end
end

local function setAlignSafe(value)
    if setTextAlignment ~= nil and value ~= nil then pcall(setTextAlignment, value) end
end

local function renderCentered(y, size, text, r, g, b, a)
    if renderText == nil then return end
    setColorSafe(r, g, b, a)
    local alignCenter = RenderText ~= nil and RenderText.ALIGN_CENTER or nil
    setAlignSafe(alignCenter)
    pcall(renderText, 0.5, y, size, text)
end

local function rvText(key, fallback)
    if g_i18n ~= nil and g_i18n.getText ~= nil then
        local ok, value = pcall(g_i18n.getText, g_i18n, key)
        if ok and value ~= nil and value ~= "" and value ~= key then
            return value
        end
    end
    return fallback
end


    local function display()
        if not rvCompatibilityBlocked() then return end
    drawRectSafe(0.02, 0.17, 0.96, 0.66, 0.02, 0.02, 0.02, 0.96)
    drawRectSafe(0.02, 0.75, 0.96, 0.08, 0.75, 0.00, 0.00, 0.98)
    drawRectSafe(0.02, 0.17, 0.96, 0.055, 0.75, 0.00, 0.00, 0.98)

    renderCentered(0.775, 0.036, rvText("rp_conflict_title", "MOD CONFLICT - USE REFUSED"), 1, 1, 1, 1)
    renderCentered(0.690, 0.025, rvText("rp_conflict_detected", "An active Cobra Modding / FS25_RealTireWear mod was detected together with Real Physics - Tire Wear."), 1, 0.92, 0.20, 1)
    renderCentered(0.635, 0.022, rvText("rp_conflict_claim1", "In the author's assessment, Cobra Modding / Real Tire Wear used parts or technical solutions"), 1, 0.35, 0.35, 1)
    renderCentered(0.595, 0.022, rvText("rp_conflict_claim2", "from Real Physics - Tire Wear without authorization."), 1, 0.35, 0.35, 1)
    renderCentered(0.525, 0.026, rvText("rp_conflict_disabled", "ALL REAL PHYSICS - TIRE WEAR FUNCTIONS ARE COMPLETELY DISABLED."), 1, 0.20, 0.20, 1)
    renderCentered(0.455, 0.022, rvText("rp_conflict_permanent", "This lock cannot be disabled, closed or hidden in-game."), 1, 1, 1, 1)
    renderCentered(0.400, 0.022, rvText("rp_conflict_choice", "Disable/remove all Cobra Modding / Real Tire Wear mods OR disable Real Physics - Tire Wear."), 1, 1, 1, 1)
    renderCentered(0.325, 0.020, rvText("rp_conflict_reload", "Reload the game/save after changing the active mods."), 0.90, 0.90, 0.90, 1)
    renderCentered(0.185, 0.024, rvText("rp_conflict_footer", "SIMULTANEOUS USE IS NOT PERMITTED"), 1, 1, 1, 1)

    local alignLeft = RenderText ~= nil and RenderText.ALIGN_LEFT or nil
    setAlignSafe(alignLeft)
    setColorSafe(1, 1, 1, 1)
    end
    local listener = {}
    local function restore()
        listener.draw = display
        listener.update = restore
        listener.loadMap = restore
        if type(g_modEventListeners) == "table" then
            local found = false
            for _, item in pairs(g_modEventListeners) do
                if item == listener then found = true; break end
            end
            if not found and type(addListener) == "function" then addListener(listener) end
        end
    end
    listener.draw = display
    listener.update = restore
    listener.loadMap = restore
    listener.deleteMap = function() end
    listener.keyEvent = function() end
    listener.mouseEvent = function() end
    if type(addListener) == "function" then addListener(listener) end
    if FSBaseMission ~= nil and type(FSBaseMission.update) == "function" then
        local original = FSBaseMission.update
        FSBaseMission.update = function(self, ...)
            restore()
            return original(self, ...)
        end
    end
    return true
end)()



-- FS25_Reifenverschleiss
-- Runtime loader

local directory = g_currentModDirectory
if rvCompatibilityBlocked() then
    if Logging ~= nil and Logging.error ~= nil then
        Logging.error("[ReifenVerschleiss][CONFLICT] Runtime loader aborted because FS25_RealTireWear is active.")
    end
    return
end
local ReifenVerschleissInstance = nil
ReifenVerschleissVisualModDirectory = directory

source(Utils.getFilename("RPReifenWechselnEvent.lua", directory))
source(Utils.getFilename("ReifenVerschleissCore.lua", directory))
source(Utils.getFilename("ReifenVerschleissVisual.lua", directory))
source(Utils.getFilename("RPReferenceSettings.lua", directory))
source(Utils.getFilename("RPWorkshopButton.lua", directory))
source(Utils.getFilename("ReifenVerschleissWegfahrsperre.lua", directory))
source(Utils.getFilename("RPMudVersionCompatibility.lua", directory))
source(Utils.getFilename("RPMudCompatibility.lua", directory))
source(Utils.getFilename("RPMudOverlayCompatibility.lua", directory))

-- TEST0.2.2.47: proven pre-update EWFS path retained.
-- Runs before AD/CP driver updates so ENGINE-OFF is locked before they can drive.
if FSBaseMission ~= nil and FSBaseMission.update ~= nil and ReifenVerschleissWegfahrsperre ~= nil then
    FSBaseMission.update = Utils.prependedFunction(FSBaseMission.update, function(_, dt)
        local ok, err = pcall(ReifenVerschleissWegfahrsperre.update, dt)
    end)
end

local function RV_initSettingUI()
    if RPReferenceSettings ~= nil then
        RPReferenceSettings.initUI()
    end
end

if InGameMenu ~= nil then
    InGameMenu.onMenuOpened =
        Utils.appendedFunction(InGameMenu.onMenuOpened, RV_initSettingUI)
end

-- OWN-WEAR persistence is implemented as a real GIANTS vehicle specialization.
-- The specialization itself is declared in modDesc.xml. It must be attached to
-- all vehicle types before TypeManager finalizes them so its native onLoad,
-- onLoadFinished and saveToXMLFile callbacks become part of every concrete
-- vehicle class. The persistence writer immediately ignores objects without
-- tire/track wear objects, and saves only OWNED farm property.
local RV_PERSISTENCE_SPEC_SHORT = "rvOwnWearPersistence"
local RV_PERSISTENCE_SPEC_FULL = tostring(g_currentModName) .. "." .. RV_PERSISTENCE_SPEC_SHORT
local rvPersistenceAttached = false

local function RV_attachPersistenceSpecialization(typeManager)
    -- TypeManager is shared by vehicles, placeables and other object types.
    -- GIANTS calls validateTypes() on each concrete manager. Do not compare
    -- against g_vehicleTypeManager here: during this early lifecycle the
    -- global can still differ/be unavailable even though 'self' already is
    -- the real vehicle TypeManager. The manager's own typeName is the stable
    -- discriminator (TypeManager.new("vehicle", ...)).
    if rvPersistenceAttached then
        return
    end
    if typeManager == nil or typeManager.typeName ~= "vehicle" then
        return
    end

    local specializationManager = typeManager.specializationManager or g_specializationManager
    if specializationManager == nil then
        Logging.error("[ReifenVerschleiss][SAVE] vehicle TypeManager has no specialization manager; OWN-WEAR persistence cannot attach")
        return
    end

    local attachName = nil
    if specializationManager:getSpecializationObjectByName(RV_PERSISTENCE_SPEC_FULL) ~= nil then
        attachName = RV_PERSISTENCE_SPEC_FULL
    elseif specializationManager:getSpecializationObjectByName(RV_PERSISTENCE_SPEC_SHORT) ~= nil then
        attachName = RV_PERSISTENCE_SPEC_SHORT
    end

    if attachName == nil then
        Logging.error("[ReifenVerschleiss][SAVE] persistence specialization unavailable full=%s short=%s", tostring(RV_PERSISTENCE_SPEC_FULL), tostring(RV_PERSISTENCE_SPEC_SHORT))
        return
    end

    local types = typeManager:getTypes() or {}
    local totalTypes = 0
    local attachedCount = 0
    local alreadyAttachedCount = 0
    local failedCount = 0

    for typeName, typeEntry in pairs(types) do
        totalTypes = totalTypes + 1
        local byName = typeEntry ~= nil and typeEntry.specializationsByName or nil
        if byName ~= nil and byName[attachName] ~= nil then
            alreadyAttachedCount = alreadyAttachedCount + 1
        else
            local ok = typeManager:addSpecialization(typeName, attachName)
            if ok == true then
                -- Hard verification: addSpecialization() is only considered
                -- successful if the concrete type entry now contains the spec.
                local verifyEntry = types[typeName]
                if verifyEntry ~= nil and verifyEntry.specializationsByName ~= nil and verifyEntry.specializationsByName[attachName] ~= nil then
                    attachedCount = attachedCount + 1
                else
                    failedCount = failedCount + 1
                    Logging.error("[ReifenVerschleiss][SAVE] persistence attach verification failed for vehicle type '%s'", tostring(typeName))
                end
            else
                failedCount = failedCount + 1
            end
        end
    end

    local activeCount = attachedCount + alreadyAttachedCount
    if totalTypes <= 0 or activeCount ~= totalTypes or failedCount > 0 then
        Logging.error("[ReifenVerschleiss][SAVE] persistence specialization attach INCOMPLETE total=%d active=%d new=%d existing=%d failed=%d spec=%s",
            totalTypes, activeCount, attachedCount, alreadyAttachedCount, failedCount, tostring(attachName))
        -- Do not latch success. If GIANTS invokes validation again, retry.
        return
    end

    rvPersistenceAttached = true
end

if TypeManager ~= nil and TypeManager.validateTypes ~= nil then
    -- GIANTS validates prerequisites from typeEntry.specializations immediately
    -- inside validateTypes(). Therefore the custom specialization must be in
    -- every vehicle type BEFORE the original validateTypes body runs.
    TypeManager.validateTypes = Utils.prependedFunction(TypeManager.validateTypes, RV_attachPersistenceSpecialization)
else
    Logging.error("[ReifenVerschleiss][SAVE] TypeManager.validateTypes unavailable; persistence specialization cannot attach")
end

if ReifenVerschleissVisual ~= nil then
    ReifenVerschleissVisual.MOD_DIRECTORY = directory
end

local rvFinishedLoadingHookInstalled = false

local function RV_installVehicleFinishedLoadingHook()
    if rvFinishedLoadingHookInstalled then
        return
    end

    if Vehicle == nil or Vehicle.onFinishedLoading == nil then
        return
    end

    Vehicle.onFinishedLoading = Utils.appendedFunction(
        Vehicle.onFinishedLoading,
        function(vehicle)
            if vehicle == nil or ReifenVerschleissCore == nil then
                return
            end

            -- TEST2.3.03: Ignore shop/menu preview vehicles. They are not live
            -- physics vehicles and must not trigger the full visual refresh.
            if vehicle.isAddedToPhysics ~= true then
                return
            end

            local ok, err = pcall(
                ReifenVerschleissCore.refreshVehicleWearVisualsAfterFinishedLoading,
                ReifenVerschleissCore,
                vehicle
            )
        end
    )

    rvFinishedLoadingHookInstalled = true
end

RV_installVehicleFinishedLoadingHook()

local function RV_loadedMission(mission)
    if rvCompatibilityBlocked() then ReifenVerschleissInstance = nil; return end
    if mission == nil or mission.cancelLoading then
        return
    end

    if RPWorkshopButton ~= nil then
        RPWorkshopButton.install()
    end

    if mission.hud == nil or mission.hud.speedMeter == nil then
        return
    end

    if ReifenVerschleissInstance == nil then
        ReifenVerschleissInstance = ReifenVerschleissCore

        if ReifenVerschleissWegfahrsperre ~= nil then
            ReifenVerschleissWegfahrsperre.install()
        end


        mission.hud.drawControlledEntityHUD =
            Utils.appendedFunction(
                mission.hud.drawControlledEntityHUD,
                function(hud)
                    if ReifenVerschleissInstance ~= nil then
                        local ok, err = pcall(
                            ReifenVerschleissInstance.draw,
                            ReifenVerschleissInstance
                        )
                    end
                end
            )


        mission.hud.setControlledVehicle =
            Utils.appendedFunction(
                mission.hud.setControlledVehicle,
                function(_, vehicle)
                    if ReifenVerschleissInstance ~= nil then
                        local ok, err = pcall(
                            ReifenVerschleissInstance.setVehicle,
                            ReifenVerschleissInstance,
                            vehicle
                        )
                    end
                end
            )


        -- GIANTS publishes these messages after the native workshop action has
        -- completed. Using the message bus is safer than replacing the vehicle
        -- method itself: it also catches multiplayer/network repair events and
        -- repaint actions triggered by other compatible workshop systems.
        if g_messageCenter ~= nil and MessageType ~= nil and not ReifenVerschleissInstance._workshopMessageHooksInstalled then
            if MessageType.VEHICLE_REPAIRED ~= nil then
                g_messageCenter:subscribe(
                    MessageType.VEHICLE_REPAIRED,
                    ReifenVerschleissInstance.onVehicleRepaired,
                    ReifenVerschleissInstance
                )
            end

            if MessageType.VEHICLE_REPAINTED ~= nil then
                g_messageCenter:subscribe(
                    MessageType.VEHICLE_REPAINTED,
                    ReifenVerschleissInstance.onVehicleRepainted,
                    ReifenVerschleissInstance
                )
            end

            ReifenVerschleissInstance._workshopMessageHooksInstalled = true
        end

        -- Connect the verified own Snow model to the actual wheel friction.
        -- GIANTS calculates its native snow friction first; our conservative
        -- profile is then applied as an additional multiplier.
        if Wheels ~= nil and Wheels.updateWheelFriction ~= nil then
            Wheels.updateWheelFriction = Utils.appendedFunction(
                Wheels.updateWheelFriction,
                function(_, wheel)
                    if wheel ~= nil and ReifenVerschleissInstance ~= nil then
                        local ok, err = pcall(
                            ReifenVerschleissInstance.applySnowFriction,
                            wheel
                        )
                    end
                end
            )
        else
        end

        -- RELEASE PERFORMANCE CLEAN: apply the wear-dependent friction target
        -- directly, without the former diagnostic before/after probe hooks.
        if WheelPhysics ~= nil and WheelPhysics.updateFriction ~= nil and not WheelPhysics._rvWearTargetHookInstalled then
            WheelPhysics._rvWearTargetHookInstalled = true
            WheelPhysics.updateFriction = Utils.appendedFunction(
                WheelPhysics.updateFriction,
                function(physics)
                    if physics ~= nil and type(physics.frictionScale) == "number" and physics.frictionScale ~= 0 then
                        local wheel = physics.wheel
                        local vehicle = wheel ~= nil and wheel.vehicle or nil
                        local targetApplied = nil
                        if ReifenVerschleissInstance ~= nil and ReifenVerschleissInstance.getWearAppliedTarget ~= nil then
                            targetApplied = ReifenVerschleissInstance.getWearAppliedTarget(vehicle, wheel)
                        end
                        if type(targetApplied) == "number" then
                            physics.tireGroundFrictionCoeff = targetApplied / physics.frictionScale
                        end
                    end
                end
            )
        end
    end
end

-- TEST2_3_40: use GIANTS' existing Motorized per-vehicle update as the
-- integration point. We observe only; original Motorized.onUpdate remains
-- untouched and its return value is not altered.
local rvMotorizedUpdateHookInstalled = false

local function RV_installMotorizedUpdateHook()
    if rvCompatibilityBlocked() then return end
    if rvMotorizedUpdateHookInstalled then
        return
    end

    if Motorized == nil or Motorized.onUpdate == nil then
        return
    end

    Motorized.onUpdate = Utils.appendedFunction(
        Motorized.onUpdate,
        function(vehicle, dt, isActiveForInput, isActiveForInputIgnoreSelection, isSelected)
            if rvCompatibilityBlocked() then ReifenVerschleissInstance = nil; return end
            if ReifenVerschleissInstance == nil then
                return
            end

            local ok, err = pcall(
                ReifenVerschleissInstance.processAutomatedVehicleUpdate,
                ReifenVerschleissInstance,
                vehicle,
                dt
            )
        end
    )

    rvMotorizedUpdateHookInstalled = true
end

RV_installMotorizedUpdateHook()

local function RV_updateMission(self, dt)
    if rvCompatibilityBlocked() then ReifenVerschleissInstance = nil; return end
    if ReifenVerschleissInstance == nil then
        return
    end

    -- Workshop tire replacement can target a vehicle that is not the
    -- currently controlled vehicle. Keep the short visual refresh queue alive
    -- independently of the controlledVehicle HUD source.
    if ReifenVerschleissVisual ~= nil and ReifenVerschleissVisual.updatePendingVisualResets ~= nil then
        local ok, err = pcall(
            ReifenVerschleissVisual.updatePendingVisualResets,
            dt
        )
    end

    if ReifenVerschleissVisual ~= nil and ReifenVerschleissVisual.updatePendingLoadVisualRefreshes ~= nil then
        local ok, err = pcall(
            ReifenVerschleissVisual.updatePendingLoadVisualRefreshes,
            dt
        )
    end

    -- The HUD setControlledVehicle hook is the authoritative vehicle source.
    -- Do NOT call setVehicle(nil) from the mission update path: in FS25 the
    -- mission controlledVehicle value can be temporarily nil while the HUD
    -- still owns the valid controlled vehicle. Clearing it here was the cause
    -- of TEST0.1.0.5 losing both the HUD diagnosis and distance accumulation.
    local ok, err = pcall(
        ReifenVerschleissInstance.update,
        ReifenVerschleissInstance,
        dt
    )

end

local function RV_unload()
    if ReifenVerschleissInstance ~= nil then
        if g_messageCenter ~= nil then
            g_messageCenter:unsubscribeAll(ReifenVerschleissInstance)
        end
        ReifenVerschleissInstance.currentVehicle = nil
        ReifenVerschleissInstance.manifest = nil
        ReifenVerschleissInstance = nil
    end
end

Mission00.loadMission00Finished =
    Utils.appendedFunction(Mission00.loadMission00Finished, RV_loadedMission)

FSBaseMission.update =
    Utils.appendedFunction(FSBaseMission.update, RV_updateMission)

FSBaseMission.delete =
    Utils.appendedFunction(FSBaseMission.delete, RV_unload)

