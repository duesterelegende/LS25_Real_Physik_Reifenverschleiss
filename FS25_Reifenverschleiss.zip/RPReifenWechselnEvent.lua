local rvCompatibilityBlocked = (function()
    local type, tostring, tonumber, pairs, ipairs, pcall = type, tostring, tonumber, pairs, ipairs, pcall
    local string = {lower=string.lower, gsub=string.gsub, find=string.find}
    local math = {abs=math.abs}
    local G = {TARGET_MOD_KEYS={"FS25_RealTireWear", "FS25_RealTireWear_main", "RealTireWear"}, blocked=false}
local function lower(v)
    return string.lower(tostring(v or ""))
end

local function containsRealTireWearName(v)
    local s = lower(v)
    s = string.gsub(s, "[^a-z0-9]", "")
    return string.find(s, "realtirewear", 1, true) ~= nil
end

local function containsCobraModdingAuthor(v)
    local s = lower(v)
    s = string.gsub(s, "[^a-z0-9]", "")
    return string.find(s, "cobramodding", 1, true) ~= nil or string.find(s, "corbramodding", 1, true) ~= nil
end

local function entryAuthor(entry)
    if type(entry) ~= "table" then return nil end
    return entry.author or entry.modAuthor or entry.creator or entry.createdBy or entry.authorName
end

local function markBlocked(reason)
    if G.blocked ~= true then
        G.blocked = true
        G.detectedBy = tostring(reason or "unknown")
        if Logging ~= nil and Logging.error ~= nil then
            Logging.error("[ReifenVerschleiss][CONFLICT] Cobra Modding / FS25_RealTireWear conflict detected (%s). ALL ReifenVerschleiss runtime functions are blocked.", G.detectedBy)
        end
    end
    return true
end

local function detectLoadedModTable()
    if type(g_modIsLoaded) == "table" then
        for _, key in ipairs(G.TARGET_MOD_KEYS) do
            if g_modIsLoaded[key] == true then
                return markBlocked("g_modIsLoaded:" .. key)
            end
        end
        for key, active in pairs(g_modIsLoaded) do
            if active == true and containsRealTireWearName(key) then
                return markBlocked("g_modIsLoaded-scan:" .. tostring(key))
            end
        end
    end
    return false
end

local function detectMissionActiveMods()
    local missionInfo = g_currentMission ~= nil and g_currentMission.missionInfo or nil
    local activeMods = missionInfo ~= nil and missionInfo.activeMods or nil
    if type(activeMods) ~= "table" then return false end
    for key, entry in pairs(activeMods) do
        local name = key
        local active = true
        if type(entry) == "table" then
            name = entry.modName or entry.name or entry.title or key
            if entry.isActive ~= nil then active = entry.isActive end
            if entry.active ~= nil then active = entry.active end
        elseif type(entry) == "string" then
            name = entry
        end
        local author = entryAuthor(entry)
        if active == true and containsRealTireWearName(name) then
            return markBlocked("mission.activeMods:" .. tostring(name))
        end
        if active == true and containsCobraModdingAuthor(author) then
            return markBlocked("mission.activeMods-author:Cobra Modding:" .. tostring(name))
        end
    end
    return false
end

local function detectRuntimeSignature()
    if type(TireWear) == "table" then
        local body = tonumber(TireWear.CRAWLER_PROFILE_BODY_Y)
        local outer = tonumber(TireWear.CRAWLER_PROFILE_OUTER_Y)
        local updateMs = tonumber(TireWear.TRACK_VISUAL_UPDATE_MS)
        if body ~= nil and outer ~= nil
            and math.abs(body - 0.020) < 0.000001
            and math.abs(outer - 0.087339) < 0.000001 then
            return markBlocked("runtime TireWear crawler signature")
        end
        if containsRealTireWearName(TireWear.MOD_NAME) then
            return markBlocked("runtime TireWear.MOD_NAME")
        end
        if updateMs == 200 and TireWearWorkshop ~= nil and TireWearDisplay ~= nil then
            return markBlocked("runtime TireWear/TireWearWorkshop signature")
        end
    end
    return false
end

local function detectModManager()
    if g_modManager == nil then return false end
    if g_modManager.getModByName ~= nil then
        for _, key in ipairs(G.TARGET_MOD_KEYS) do
            local ok, mod = pcall(g_modManager.getModByName, g_modManager, key)
            if ok and mod ~= nil then
                local active = mod.isActive
                if active == nil then active = mod.active end
                if active == true then return markBlocked("g_modManager:" .. key) end
            end
        end
    end
    for _, field in ipairs({"mods", "modsByName", "nameToMod", "availableMods", "loadedMods"}) do
        local list = g_modManager[field]
        if type(list) == "table" then
            for key, mod in pairs(list) do
                local name = key
                local active = false
                if type(mod) == "table" then
                    name = mod.modName or mod.name or mod.title or key
                    if mod.isActive ~= nil then active = mod.isActive end
                    if mod.active ~= nil then active = mod.active end
                end
                local author = entryAuthor(mod)
                if active == true and containsRealTireWearName(name) then
                    return markBlocked("g_modManager-scan:" .. tostring(name))
                end
                if active == true and containsCobraModdingAuthor(author) then
                    return markBlocked("g_modManager-author:Cobra Modding:" .. tostring(name))
                end
            end
        end
    end
    return false
end


    local lastCheck = nil
    return function()
        if G.blocked then return true end
        local now = tonumber(g_time)
        if now ~= nil and lastCheck ~= nil and now >= lastCheck and now-lastCheck < 500 then return false end
        lastCheck = now
        return detectLoadedModTable() or detectMissionActiveMods() or detectRuntimeSignature() or detectModManager()
    end
end)()

local rvDisplayReady = (function()
    local pcall, type, pairs = pcall, type, pairs
    local drawFilledRect, setTextColor, setTextAlignment, renderText = drawFilledRect, setTextColor, setTextAlignment, renderText
    local RenderText = RenderText
    local addListener = addModEventListener
local function drawRectSafe(x, y, w, h, r, g, b, a)
    if drawFilledRect ~= nil then pcall(drawFilledRect, x, y, w, h, r, g, b, a) end
end

local function setColorSafe(r, g, b, a)
    if setTextColor ~= nil then pcall(setTextColor, r, g, b, a) end
end

local function setAlignSafe(value)
    if setTextAlignment ~= nil and value ~= nil then pcall(setTextAlignment, value) end
end

local function renderCentered(y, size, text, r, g, b, a)
    if renderText == nil then return end
    setColorSafe(r, g, b, a)
    local alignCenter = RenderText ~= nil and RenderText.ALIGN_CENTER or nil
    setAlignSafe(alignCenter)
    pcall(renderText, 0.5, y, size, text)
end

local function rvText(key, fallback)
    if g_i18n ~= nil and g_i18n.getText ~= nil then
        local ok, value = pcall(g_i18n.getText, g_i18n, key)
        if ok and value ~= nil and value ~= "" and value ~= key then
            return value
        end
    end
    return fallback
end


    local function display()
        if not rvCompatibilityBlocked() then return end
    drawRectSafe(0.02, 0.17, 0.96, 0.66, 0.02, 0.02, 0.02, 0.96)
    drawRectSafe(0.02, 0.75, 0.96, 0.08, 0.75, 0.00, 0.00, 0.98)
    drawRectSafe(0.02, 0.17, 0.96, 0.055, 0.75, 0.00, 0.00, 0.98)

    renderCentered(0.775, 0.036, rvText("rp_conflict_title", "MOD CONFLICT - USE REFUSED"), 1, 1, 1, 1)
    renderCentered(0.690, 0.025, rvText("rp_conflict_detected", "An active Cobra Modding / FS25_RealTireWear mod was detected together with Real Physics - Tire Wear."), 1, 0.92, 0.20, 1)
    renderCentered(0.635, 0.022, rvText("rp_conflict_claim1", "In the author's assessment, Cobra Modding / Real Tire Wear used parts or technical solutions"), 1, 0.35, 0.35, 1)
    renderCentered(0.595, 0.022, rvText("rp_conflict_claim2", "from Real Physics - Tire Wear without authorization."), 1, 0.35, 0.35, 1)
    renderCentered(0.525, 0.026, rvText("rp_conflict_disabled", "ALL REAL PHYSICS - TIRE WEAR FUNCTIONS ARE COMPLETELY DISABLED."), 1, 0.20, 0.20, 1)
    renderCentered(0.455, 0.022, rvText("rp_conflict_permanent", "This lock cannot be disabled, closed or hidden in-game."), 1, 1, 1, 1)
    renderCentered(0.400, 0.022, rvText("rp_conflict_choice", "Disable/remove all Cobra Modding / Real Tire Wear mods OR disable Real Physics - Tire Wear."), 1, 1, 1, 1)
    renderCentered(0.325, 0.020, rvText("rp_conflict_reload", "Reload the game/save after changing the active mods."), 0.90, 0.90, 0.90, 1)
    renderCentered(0.185, 0.024, rvText("rp_conflict_footer", "SIMULTANEOUS USE IS NOT PERMITTED"), 1, 1, 1, 1)

    local alignLeft = RenderText ~= nil and RenderText.ALIGN_LEFT or nil
    setAlignSafe(alignLeft)
    setColorSafe(1, 1, 1, 1)
    end
    local listener = {}
    local function restore()
        listener.draw = display
        listener.update = restore
        listener.loadMap = restore
        if type(g_modEventListeners) == "table" then
            local found = false
            for _, item in pairs(g_modEventListeners) do
                if item == listener then found = true; break end
            end
            if not found and type(addListener) == "function" then addListener(listener) end
        end
    end
    listener.draw = display
    listener.update = restore
    listener.loadMap = restore
    listener.deleteMap = function() end
    listener.keyEvent = function() end
    listener.mouseEvent = function() end
    if type(addListener) == "function" then addListener(listener) end
    if FSBaseMission ~= nil and type(FSBaseMission.update) == "function" then
        local original = FSBaseMission.update
        FSBaseMission.update = function(self, ...)
            restore()
            return original(self, ...)
        end
    end
    return true
end)()



if rvCompatibilityBlocked() then
    return
end

-- Real Physics - Reifenverschleiß
-- TEST0.2.0.98
-- Server-authoritative tire / running-gear replacement purchase.

RPReifenWechselnEvent = {}
local RPReifenWechselnEvent_mt = Class(RPReifenWechselnEvent, Event)

InitEventClass(RPReifenWechselnEvent, "RPReifenWechselnEvent")

function RPReifenWechselnEvent.emptyNew()
    local self = Event.new(RPReifenWechselnEvent_mt)
    return self
end

function RPReifenWechselnEvent.new(vehicle, mode)
    local self = RPReifenWechselnEvent.emptyNew()
    self.vehicle = vehicle
    self.mode = tostring(mode or "ALL")
    return self
end

function RPReifenWechselnEvent:writeStream(streamId, connection)
    NetworkUtil.writeNodeObject(streamId, self.vehicle)
    streamWriteString(streamId, tostring(self.mode or "ALL"))
end

function RPReifenWechselnEvent:readStream(streamId, connection)
    self.vehicle = NetworkUtil.readNodeObject(streamId)
    self.mode = streamReadString(streamId)
    self:run(connection)
end

local function getFarmId(vehicle)
    if vehicle ~= nil and vehicle.getOwnerFarmId ~= nil then
        local ok, value = pcall(vehicle.getOwnerFarmId, vehicle)
        if ok and type(value) == "number" then
            return value
        end
    end
    if vehicle ~= nil and type(vehicle.ownerFarmId) == "number" then
        return vehicle.ownerFarmId
    end
    if g_currentMission ~= nil and g_currentMission.player ~= nil then
        return g_currentMission.player.farmId
    end
    return nil
end

local function executeAuthoritativePurchase(vehicle, mode)
    if rvCompatibilityBlocked() then return false end
    if vehicle == nil then
        return false
    end

    if RPWorkshopButton == nil or RPWorkshopButton.getPurchaseInfo == nil then
        return false
    end

    local info = RPWorkshopButton.getPurchaseInfo(vehicle)
    mode = tostring(mode or "ALL")
    local price = info ~= nil and info.totalPrice or 0
    if info ~= nil and mode == "WHEELS" then
        price = info.tireOnlyPrice or 0
    elseif info ~= nil and mode == "TRACKS" then
        price = info.trackOnlyPrice or 0
    elseif info ~= nil and mode == "ROLLERS" then
        price = info.rollerOnlyPrice or 0
    end
    if type(price) ~= "number" or price <= 0 then
        return false
    end

    local farmId = getFarmId(vehicle)
    if farmId == nil or FarmManager ~= nil and FarmManager.SPECTATOR_FARM_ID ~= nil and farmId == FarmManager.SPECTATOR_FARM_ID then
        return false
    end

    -- TEST build: deliberately NO balance/affordability check.
    -- First perform the actual wear replacement. Money is only debited after
    -- the reset succeeded, so a failed reset can never consume the test price.
    if ReifenVerschleissCore == nil then
        return false
    end

    local ok, result
    if mode == "ALL" then
        local resetFn = ReifenVerschleissCore.resetRunningGearWorkshop
            or ReifenVerschleissCore.resetVehicleWear
        if resetFn == ReifenVerschleissCore.resetRunningGearWorkshop then
            ok, result = pcall(resetFn, vehicle, "ALL", "RP-FAHRZEUG-WECHSEL-ALL")
        else
            ok, result = pcall(resetFn, vehicle, "RP-FAHRZEUG-WECHSEL-ALL")
        end
    else
        local resetFn = ReifenVerschleissCore.resetRunningGearWorkshop
        if resetFn == nil then
            return false
        end
        ok, result = pcall(resetFn, vehicle, mode, "RP-FAHRZEUG-WECHSEL-" .. mode)
    end
    if not ok or result ~= true then
        return false
    end

    if g_currentMission == nil or g_currentMission.addMoney == nil then
        return false
    end

    g_currentMission:addMoney(-price, farmId, MoneyType.OTHER, true, true)

    if mode == "ALL" and ReifenVerschleissVisual ~= nil and ReifenVerschleissVisual.resetVehicleWearVisualsImmediate ~= nil then
        local visualFn = ReifenVerschleissVisual.resetVehicleWearVisualsImmediate
        local visualOk, visualErr = pcall(visualFn, vehicle)
        if ReifenVerschleissVisual.queueImmediateVisualReset ~= nil then
            ReifenVerschleissVisual.queueImmediateVisualReset(vehicle)
        end
    end


    return true
end

function RPReifenWechselnEvent.executePurchase(vehicle, mode)
    if vehicle == nil then
        return false
    end

    if g_server ~= nil then
        local result = executeAuthoritativePurchase(vehicle, mode)
        if result and g_server.broadcastEvent ~= nil then
            -- The server has already reset its state. Clients need only mirror
            -- the custom wear reset/visual refresh; the event is intentionally
            -- reused as the synchronization message below.
            local event = RPReifenWechselnEvent.new(vehicle, mode)
            g_server:broadcastEvent(event, nil, nil, vehicle)
        end
        return result
    end

    if RPReifenWechselnEvent.sendEvent ~= nil and g_client ~= nil and g_client:getServerConnection() ~= nil then
        RPReifenWechselnEvent.sendEvent(vehicle, mode)
        return true
    end

    return false
end

function RPReifenWechselnEvent:run(connection)
    if g_server ~= nil then
        -- Client request: the server recalculates the complete purchase price
        -- from the actual vehicle and performs the debit/reset authoritatively.
        if self.vehicle == nil or not self.vehicle:getIsSynchronized() then
            return
        end
        if connection == nil then
            return
        end

        local result = executeAuthoritativePurchase(self.vehicle, self.mode)
        if result and g_server.broadcastEvent ~= nil then
            g_server:broadcastEvent(self, false, connection, self.vehicle)
        end
        return
    end

    -- Client: mirror custom wear state and refresh already-created visuals.
    if self.vehicle ~= nil and ReifenVerschleissCore ~= nil then
        local stateOk, stateErr
        if tostring(self.mode or "ALL") == "ALL" and ReifenVerschleissCore.resetVehicleCustomWearState ~= nil then
            stateOk, stateErr = pcall(
                ReifenVerschleissCore.resetVehicleCustomWearState,
                self.vehicle, "RP-FAHRZEUG-WECHSEL-NETWORK-CLIENT"
            )
        elseif ReifenVerschleissCore.resetRunningGearWorkshop ~= nil then
            stateOk, stateErr = pcall(
                ReifenVerschleissCore.resetRunningGearWorkshop,
                self.vehicle, tostring(self.mode or "ALL"),
                "RP-FAHRZEUG-WECHSEL-NETWORK-CLIENT-" .. tostring(self.mode or "ALL")
            )
        end
    end

    if self.vehicle ~= nil and tostring(self.mode or "ALL") == "ALL" and ReifenVerschleissVisual ~= nil and
       ReifenVerschleissVisual.resetVehicleWearVisualsImmediate ~= nil then
        local visualFn = ReifenVerschleissVisual.resetVehicleWearVisualsImmediate
        local ok, err = pcall(visualFn, self.vehicle)
        if ReifenVerschleissVisual.queueImmediateVisualReset ~= nil then
            ReifenVerschleissVisual.queueImmediateVisualReset(self.vehicle)
        end
    end
end

function RPReifenWechselnEvent.sendEvent(vehicle, mode)
    if vehicle == nil then
        return
    end
    local event = RPReifenWechselnEvent.new(vehicle, mode)
    if g_client ~= nil and g_client:getServerConnection() ~= nil then
        g_client:getServerConnection():sendEvent(event)
    end
end
