local rvCompatibilityBlocked = (function()
    local type, tostring, tonumber, pairs, ipairs, pcall = type, tostring, tonumber, pairs, ipairs, pcall
    local string = {lower=string.lower, gsub=string.gsub, find=string.find}
    local math = {abs=math.abs}
    local G = {TARGET_MOD_KEYS={"FS25_RealTireWear", "FS25_RealTireWear_main", "RealTireWear"}, blocked=false}
local function lower(v)
    return string.lower(tostring(v or ""))
end

local function containsRealTireWearName(v)
    local s = lower(v)
    s = string.gsub(s, "[^a-z0-9]", "")
    return string.find(s, "realtirewear", 1, true) ~= nil
end

local function containsCobraModdingAuthor(v)
    local s = lower(v)
    s = string.gsub(s, "[^a-z0-9]", "")
    return string.find(s, "cobramodding", 1, true) ~= nil or string.find(s, "corbramodding", 1, true) ~= nil
end

local function entryAuthor(entry)
    if type(entry) ~= "table" then return nil end
    return entry.author or entry.modAuthor or entry.creator or entry.createdBy or entry.authorName
end

local function markBlocked(reason)
    if G.blocked ~= true then
        G.blocked = true
        G.detectedBy = tostring(reason or "unknown")
        if Logging ~= nil and Logging.error ~= nil then
            Logging.error("[ReifenVerschleiss][CONFLICT] Cobra Modding / FS25_RealTireWear conflict detected (%s). ALL ReifenVerschleiss runtime functions are blocked.", G.detectedBy)
        end
    end
    return true
end

local function detectLoadedModTable()
    if type(g_modIsLoaded) == "table" then
        for _, key in ipairs(G.TARGET_MOD_KEYS) do
            if g_modIsLoaded[key] == true then
                return markBlocked("g_modIsLoaded:" .. key)
            end
        end
        for key, active in pairs(g_modIsLoaded) do
            if active == true and containsRealTireWearName(key) then
                return markBlocked("g_modIsLoaded-scan:" .. tostring(key))
            end
        end
    end
    return false
end

local function detectMissionActiveMods()
    local missionInfo = g_currentMission ~= nil and g_currentMission.missionInfo or nil
    local activeMods = missionInfo ~= nil and missionInfo.activeMods or nil
    if type(activeMods) ~= "table" then return false end
    for key, entry in pairs(activeMods) do
        local name = key
        local active = true
        if type(entry) == "table" then
            name = entry.modName or entry.name or entry.title or key
            if entry.isActive ~= nil then active = entry.isActive end
            if entry.active ~= nil then active = entry.active end
        elseif type(entry) == "string" then
            name = entry
        end
        local author = entryAuthor(entry)
        if active == true and containsRealTireWearName(name) then
            return markBlocked("mission.activeMods:" .. tostring(name))
        end
        if active == true and containsCobraModdingAuthor(author) then
            return markBlocked("mission.activeMods-author:Cobra Modding:" .. tostring(name))
        end
    end
    return false
end

local function detectRuntimeSignature()
    if type(TireWear) == "table" then
        local body = tonumber(TireWear.CRAWLER_PROFILE_BODY_Y)
        local outer = tonumber(TireWear.CRAWLER_PROFILE_OUTER_Y)
        local updateMs = tonumber(TireWear.TRACK_VISUAL_UPDATE_MS)
        if body ~= nil and outer ~= nil
            and math.abs(body - 0.020) < 0.000001
            and math.abs(outer - 0.087339) < 0.000001 then
            return markBlocked("runtime TireWear crawler signature")
        end
        if containsRealTireWearName(TireWear.MOD_NAME) then
            return markBlocked("runtime TireWear.MOD_NAME")
        end
        if updateMs == 200 and TireWearWorkshop ~= nil and TireWearDisplay ~= nil then
            return markBlocked("runtime TireWear/TireWearWorkshop signature")
        end
    end
    return false
end

local function detectModManager()
    if g_modManager == nil then return false end
    if g_modManager.getModByName ~= nil then
        for _, key in ipairs(G.TARGET_MOD_KEYS) do
            local ok, mod = pcall(g_modManager.getModByName, g_modManager, key)
            if ok and mod ~= nil then
                local active = mod.isActive
                if active == nil then active = mod.active end
                if active == true then return markBlocked("g_modManager:" .. key) end
            end
        end
    end
    for _, field in ipairs({"mods", "modsByName", "nameToMod", "availableMods", "loadedMods"}) do
        local list = g_modManager[field]
        if type(list) == "table" then
            for key, mod in pairs(list) do
                local name = key
                local active = false
                if type(mod) == "table" then
                    name = mod.modName or mod.name or mod.title or key
                    if mod.isActive ~= nil then active = mod.isActive end
                    if mod.active ~= nil then active = mod.active end
                end
                local author = entryAuthor(mod)
                if active == true and containsRealTireWearName(name) then
                    return markBlocked("g_modManager-scan:" .. tostring(name))
                end
                if active == true and containsCobraModdingAuthor(author) then
                    return markBlocked("g_modManager-author:Cobra Modding:" .. tostring(name))
                end
            end
        end
    end
    return false
end


    local lastCheck = nil
    return function()
        if G.blocked then return true end
        local now = tonumber(g_time)
        if now ~= nil and lastCheck ~= nil and now >= lastCheck and now-lastCheck < 500 then return false end
        lastCheck = now
        return detectLoadedModTable() or detectMissionActiveMods() or detectRuntimeSignature() or detectModManager()
    end
end)()

if rvCompatibilityBlocked() then
    return
end

-- FS25_Reifenverschleiss - MudSystemPhysics compatibility runtime
-- DEV 1.2.2.68 COMPAT API TEST:
-- publish an explicit Reifenverschleiss radius channel when Mud supports it;
-- retain the 1.2.2.67 __tpOrigRadius fallback for current Mud 1.3.4.
-- Functional purpose is unchanged: RP owns the worn tire-pressure baseline
-- after Mud/GIANTS has completed its update, without overwriting Mud's native
-- pressure deformation result.

RPMudCompatibility = RPMudCompatibility or {}
local D = RPMudCompatibility

D.enabled = true

local function mudActive()
    return RPMudVersionCompatibility ~= nil and RPMudVersionCompatibility:isActive()
end
D.radiusCombinerEpsilon = 0.0005
D.finalOwnerHookInstalled = false
D.finalOwnerInProgress = false
D.finalOwnerFallbackMs = 0
D.finalOwnerFallbackDelayMs = 750

local function num(v)
    return type(v) == "number" and v == v and v or nil
end

function D:hasOfficialRadiusChannel()
    if not mudActive() then return false end
    local combiner = _G ~= nil and _G.__MudRadiusCombiner or nil
    return type(combiner) == "table"
        and combiner.supportsReifenverschleissRadiusChannel == true
end

function D:publishWheelRadiusChannel(vehicle, wheel)
    if vehicle == nil or wheel == nil or wheel.physics == nil then return false end
    if ReifenVerschleissCore == nil or ReifenVerschleissCore.getWheelWearRadius == nil then return false end
    local wearRadius, originalRadius, wear01 = ReifenVerschleissCore.getWheelWearRadius(vehicle, wheel)
    if num(wearRadius) == nil or num(originalRadius) == nil then return false end
    local wp = wheel.physics
    wp.__rvOrigRadius = originalRadius
    wp.__rvDesiredRadius = wearRadius
    wp.__rvWear01 = num(wear01) or 0
    return true
end

function D:update(dt)
    if rvCompatibilityBlocked() then return end
    if self.enabled ~= true or not mudActive() then return end

    -- Sleeping/startup fleet safety: establish the worn pressure baseline even
    -- for vehicles that are not currently receiving their normal vehicle update.
    self.finalOwnerFallbackMs = (self.finalOwnerFallbackMs or 0) + (num(dt) or 0)
    if self.finalOwnerFallbackMs >= self.finalOwnerFallbackDelayMs then
        self.finalOwnerFallbackMs = 0
        local mission = g_currentMission
        local vehicles = mission ~= nil and mission.vehicleSystem ~= nil and mission.vehicleSystem.vehicles or nil
        if vehicles ~= nil then
            for _, fleetVehicle in pairs(vehicles) do
                if fleetVehicle ~= nil and fleetVehicle.spec_wheels ~= nil then
                    self:finalOwnerCommit(fleetVehicle)
                end
            end
        end
    end
end

function D:finalOwnerCommit(vehicle)
    if self.enabled ~= true or not mudActive() then return end
    if vehicle == nil or vehicle.isDeleted == true or vehicle.isDeleting == true then return end
    if vehicle.spec_wheels == nil or vehicle.spec_wheels.wheels == nil then return end

    for _, wheel in ipairs(vehicle.spec_wheels.wheels) do
        local wp = wheel ~= nil and wheel.physics or nil
        local wearBase = wheel ~= nil and num(wheel.rvRoundPhysicalRadius) or nil
        local wearOriginal = wheel ~= nil and num(wheel.rvRoundOriginalPhysicsRadius) or nil
        local wear = wheel ~= nil and num(wheel.rvRoundPhysicalWear) or nil

        -- Round tires only. Crawler/track physics has no rvRoundPhysicalRadius.
        if wp ~= nil and wearBase ~= nil and wearOriginal ~= nil and wear ~= nil then
            -- Always publish RP's own read-only radius channel. Current Mud 1.3.4
            -- ignores it; a partner build can advertise official support via
            -- __MudRadiusCombiner.supportsReifenverschleissRadiusChannel=true.
            self:publishWheelRadiusChannel(vehicle, wheel)

            if self:hasOfficialRadiusChannel() then
                -- Official path: Mud consumes __rvOrigRadius/__rvDesiredRadius.
                -- Do not disguise RP's wear radius as TirePressure input.
                wp.__tpOrigRadius = nil
            elseif wear > 0 then
                -- Backward-compatible path for the released Mud 1.3.4:
                -- its TirePressureSystem has no RP channel yet.
                wp.__tpOrigRadius = wearBase
            end

            -- wheel.radius stays RP's wear-only/base radius. Temporary external
            -- deformation belongs only in physics.radius and must never become
            -- RP's new wear baseline.
            local currentWheelRadius = num(wheel.radius)
            if currentWheelRadius == nil or math.abs(currentWheelRadius - wearBase) > self.radiusCombinerEpsilon then
                wheel.radius = wearBase
            end

            wheel.__rvFinalOwnerSeen = true
            wheel.__rvFinalOwnerLastTime = g_time
        end
    end
end

function D:installFinalOwnerHook()
    if not mudActive() then return end
    if self.finalOwnerHookInstalled == true then return end
    if SpecializationUtil == nil or SpecializationUtil.raiseEvent == nil
        or Utils == nil or Utils.appendedFunction == nil then
        return
    end

    local owner = self
    SpecializationUtil.raiseEvent = Utils.appendedFunction(
        SpecializationUtil.raiseEvent,
        function(object, eventName, ...)
            -- Vehicle:update raises onUpdate after the native specialization
            -- updates. Do not overwrite Mud's current-frame pressure result;
            -- only move its pressure baseline for the following frame.
            if eventName == "onUpdate" and owner.finalOwnerInProgress ~= true then
                owner.finalOwnerInProgress = true
                pcall(owner.finalOwnerCommit, owner, object)
                owner.finalOwnerInProgress = false
            end
        end
    )
    self.finalOwnerHookInstalled = true
end

function D:loadMap()
    if rvCompatibilityBlocked() then return end
    self.finalOwnerFallbackMs = 0
    self.finalOwnerInProgress = false
    if RPMudVersionCompatibility ~= nil then RPMudVersionCompatibility:detect() end
    if mudActive() then
        self:installFinalOwnerHook()
    end
end

function D:deleteMap()
end

addModEventListener(D)
