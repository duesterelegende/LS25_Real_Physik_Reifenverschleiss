if RV_ConflictGuard ~= nil and RV_ConflictGuard:isBlocked() then
    return
end

-- FS25_Reifenverschleiss - MudSystemPhysics compatibility runtime
-- DEV 1.2.2.68 COMPAT API TEST:
-- publish an explicit Reifenverschleiss radius channel when Mud supports it;
-- retain the 1.2.2.67 __tpOrigRadius fallback for current Mud 1.3.4.
-- Functional purpose is unchanged: RP owns the worn tire-pressure baseline
-- after Mud/GIANTS has completed its update, without overwriting Mud's native
-- pressure deformation result.

RPMudCompatibility = RPMudCompatibility or {}
local D = RPMudCompatibility

D.enabled = true

local function mudActive()
    return RPMudVersionCompatibility ~= nil and RPMudVersionCompatibility:isActive()
end
D.radiusCombinerEpsilon = 0.0005
D.finalOwnerHookInstalled = false
D.finalOwnerInProgress = false
D.finalOwnerFallbackMs = 0
D.finalOwnerFallbackDelayMs = 750

local function num(v)
    return type(v) == "number" and v == v and v or nil
end

function D:hasOfficialRadiusChannel()
    if not mudActive() then return false end
    local combiner = _G ~= nil and _G.__MudRadiusCombiner or nil
    return type(combiner) == "table"
        and combiner.supportsReifenverschleissRadiusChannel == true
end

function D:publishWheelRadiusChannel(vehicle, wheel)
    if vehicle == nil or wheel == nil or wheel.physics == nil then return false end
    if ReifenVerschleissCore == nil or ReifenVerschleissCore.getWheelWearRadius == nil then return false end
    local wearRadius, originalRadius, wear01 = ReifenVerschleissCore.getWheelWearRadius(vehicle, wheel)
    if num(wearRadius) == nil or num(originalRadius) == nil then return false end
    local wp = wheel.physics
    wp.__rvOrigRadius = originalRadius
    wp.__rvDesiredRadius = wearRadius
    wp.__rvWear01 = num(wear01) or 0
    return true
end

function D:update(dt)
    if RV_ConflictGuard ~= nil and RV_ConflictGuard:isBlocked() then return end
    if self.enabled ~= true or not mudActive() then return end

    -- Sleeping/startup fleet safety: establish the worn pressure baseline even
    -- for vehicles that are not currently receiving their normal vehicle update.
    self.finalOwnerFallbackMs = (self.finalOwnerFallbackMs or 0) + (num(dt) or 0)
    if self.finalOwnerFallbackMs >= self.finalOwnerFallbackDelayMs then
        self.finalOwnerFallbackMs = 0
        local mission = g_currentMission
        local vehicles = mission ~= nil and mission.vehicleSystem ~= nil and mission.vehicleSystem.vehicles or nil
        if vehicles ~= nil then
            for _, fleetVehicle in pairs(vehicles) do
                if fleetVehicle ~= nil and fleetVehicle.spec_wheels ~= nil then
                    self:finalOwnerCommit(fleetVehicle)
                end
            end
        end
    end
end

function D:finalOwnerCommit(vehicle)
    if self.enabled ~= true or not mudActive() then return end
    if vehicle == nil or vehicle.isDeleted == true or vehicle.isDeleting == true then return end
    if vehicle.spec_wheels == nil or vehicle.spec_wheels.wheels == nil then return end

    for _, wheel in ipairs(vehicle.spec_wheels.wheels) do
        local wp = wheel ~= nil and wheel.physics or nil
        local wearBase = wheel ~= nil and num(wheel.rvRoundPhysicalRadius) or nil
        local wearOriginal = wheel ~= nil and num(wheel.rvRoundOriginalPhysicsRadius) or nil
        local wear = wheel ~= nil and num(wheel.rvRoundPhysicalWear) or nil

        -- Round tires only. Crawler/track physics has no rvRoundPhysicalRadius.
        if wp ~= nil and wearBase ~= nil and wearOriginal ~= nil and wear ~= nil then
            -- Always publish RP's own read-only radius channel. Current Mud 1.3.4
            -- ignores it; a partner build can advertise official support via
            -- __MudRadiusCombiner.supportsReifenverschleissRadiusChannel=true.
            self:publishWheelRadiusChannel(vehicle, wheel)

            if self:hasOfficialRadiusChannel() then
                -- Official path: Mud consumes __rvOrigRadius/__rvDesiredRadius.
                -- Do not disguise RP's wear radius as TirePressure input.
                wp.__tpOrigRadius = nil
            elseif wear > 0 then
                -- Backward-compatible path for the released Mud 1.3.4:
                -- its TirePressureSystem has no RP channel yet.
                wp.__tpOrigRadius = wearBase
            end

            -- wheel.radius stays RP's wear-only/base radius. Temporary external
            -- deformation belongs only in physics.radius and must never become
            -- RP's new wear baseline.
            local currentWheelRadius = num(wheel.radius)
            if currentWheelRadius == nil or math.abs(currentWheelRadius - wearBase) > self.radiusCombinerEpsilon then
                wheel.radius = wearBase
            end

            wheel.__rvFinalOwnerSeen = true
            wheel.__rvFinalOwnerLastTime = g_time
        end
    end
end

function D:installFinalOwnerHook()
    if not mudActive() then return end
    if self.finalOwnerHookInstalled == true then return end
    if SpecializationUtil == nil or SpecializationUtil.raiseEvent == nil
        or Utils == nil or Utils.appendedFunction == nil then
        return
    end

    local owner = self
    SpecializationUtil.raiseEvent = Utils.appendedFunction(
        SpecializationUtil.raiseEvent,
        function(object, eventName, ...)
            -- Vehicle:update raises onUpdate after the native specialization
            -- updates. Do not overwrite Mud's current-frame pressure result;
            -- only move its pressure baseline for the following frame.
            if eventName == "onUpdate" and owner.finalOwnerInProgress ~= true then
                owner.finalOwnerInProgress = true
                pcall(owner.finalOwnerCommit, owner, object)
                owner.finalOwnerInProgress = false
            end
        end
    )
    self.finalOwnerHookInstalled = true
end

function D:loadMap()
    if RV_ConflictGuard ~= nil and RV_ConflictGuard:isBlocked() then return end
    self.finalOwnerFallbackMs = 0
    self.finalOwnerInProgress = false
    if RPMudVersionCompatibility ~= nil then RPMudVersionCompatibility:detect() end
    if mudActive() then
        self:installFinalOwnerHook()
    end
end

function D:deleteMap()
end

addModEventListener(D)
