local rvCompatibilityBlocked = (function()
    local type, tostring, tonumber, pairs, ipairs, pcall = type, tostring, tonumber, pairs, ipairs, pcall
    local string = {lower=string.lower, gsub=string.gsub, find=string.find}
    local math = {abs=math.abs}
    local G = {TARGET_MOD_KEYS={"FS25_RealTireWear", "FS25_RealTireWear_main", "RealTireWear"}, blocked=false}
local function lower(v)
    return string.lower(tostring(v or ""))
end

local function containsRealTireWearName(v)
    local s = lower(v)
    s = string.gsub(s, "[^a-z0-9]", "")
    return string.find(s, "realtirewear", 1, true) ~= nil
end

local function containsCobraModdingAuthor(v)
    local s = lower(v)
    s = string.gsub(s, "[^a-z0-9]", "")
    return string.find(s, "cobramodding", 1, true) ~= nil or string.find(s, "corbramodding", 1, true) ~= nil
end

local function entryAuthor(entry)
    if type(entry) ~= "table" then return nil end
    return entry.author or entry.modAuthor or entry.creator or entry.createdBy or entry.authorName
end

local function markBlocked(reason)
    if G.blocked ~= true then
        G.blocked = true
        G.detectedBy = tostring(reason or "unknown")
        if Logging ~= nil and Logging.error ~= nil then
            Logging.error("[ReifenVerschleiss][CONFLICT] Cobra Modding / FS25_RealTireWear conflict detected (%s). ALL ReifenVerschleiss runtime functions are blocked.", G.detectedBy)
        end
    end
    return true
end

local function detectLoadedModTable()
    if type(g_modIsLoaded) == "table" then
        for _, key in ipairs(G.TARGET_MOD_KEYS) do
            if g_modIsLoaded[key] == true then
                return markBlocked("g_modIsLoaded:" .. key)
            end
        end
        for key, active in pairs(g_modIsLoaded) do
            if active == true and containsRealTireWearName(key) then
                return markBlocked("g_modIsLoaded-scan:" .. tostring(key))
            end
        end
    end
    return false
end

local function detectMissionActiveMods()
    local missionInfo = g_currentMission ~= nil and g_currentMission.missionInfo or nil
    local activeMods = missionInfo ~= nil and missionInfo.activeMods or nil
    if type(activeMods) ~= "table" then return false end
    for key, entry in pairs(activeMods) do
        local name = key
        local active = true
        if type(entry) == "table" then
            name = entry.modName or entry.name or entry.title or key
            if entry.isActive ~= nil then active = entry.isActive end
            if entry.active ~= nil then active = entry.active end
        elseif type(entry) == "string" then
            name = entry
        end
        local author = entryAuthor(entry)
        if active == true and containsRealTireWearName(name) then
            return markBlocked("mission.activeMods:" .. tostring(name))
        end
        if active == true and containsCobraModdingAuthor(author) then
            return markBlocked("mission.activeMods-author:Cobra Modding:" .. tostring(name))
        end
    end
    return false
end

local function detectRuntimeSignature()
    if type(TireWear) == "table" then
        local body = tonumber(TireWear.CRAWLER_PROFILE_BODY_Y)
        local outer = tonumber(TireWear.CRAWLER_PROFILE_OUTER_Y)
        local updateMs = tonumber(TireWear.TRACK_VISUAL_UPDATE_MS)
        if body ~= nil and outer ~= nil
            and math.abs(body - 0.020) < 0.000001
            and math.abs(outer - 0.087339) < 0.000001 then
            return markBlocked("runtime TireWear crawler signature")
        end
        if containsRealTireWearName(TireWear.MOD_NAME) then
            return markBlocked("runtime TireWear.MOD_NAME")
        end
        if updateMs == 200 and TireWearWorkshop ~= nil and TireWearDisplay ~= nil then
            return markBlocked("runtime TireWear/TireWearWorkshop signature")
        end
    end
    return false
end

local function detectModManager()
    if g_modManager == nil then return false end
    if g_modManager.getModByName ~= nil then
        for _, key in ipairs(G.TARGET_MOD_KEYS) do
            local ok, mod = pcall(g_modManager.getModByName, g_modManager, key)
            if ok and mod ~= nil then
                local active = mod.isActive
                if active == nil then active = mod.active end
                if active == true then return markBlocked("g_modManager:" .. key) end
            end
        end
    end
    for _, field in ipairs({"mods", "modsByName", "nameToMod", "availableMods", "loadedMods"}) do
        local list = g_modManager[field]
        if type(list) == "table" then
            for key, mod in pairs(list) do
                local name = key
                local active = false
                if type(mod) == "table" then
                    name = mod.modName or mod.name or mod.title or key
                    if mod.isActive ~= nil then active = mod.isActive end
                    if mod.active ~= nil then active = mod.active end
                end
                local author = entryAuthor(mod)
                if active == true and containsRealTireWearName(name) then
                    return markBlocked("g_modManager-scan:" .. tostring(name))
                end
                if active == true and containsCobraModdingAuthor(author) then
                    return markBlocked("g_modManager-author:Cobra Modding:" .. tostring(name))
                end
            end
        end
    end
    return false
end


    local lastCheck = nil
    return function()
        if G.blocked then return true end
        local now = tonumber(g_time)
        if now ~= nil and lastCheck ~= nil and now >= lastCheck and now-lastCheck < 500 then return false end
        lastCheck = now
        return detectLoadedModTable() or detectMissionActiveMods() or detectRuntimeSignature() or detectModManager()
    end
end)()

local rvDisplayReady = (function()
    local pcall, type, pairs = pcall, type, pairs
    local drawFilledRect, setTextColor, setTextAlignment, renderText = drawFilledRect, setTextColor, setTextAlignment, renderText
    local RenderText = RenderText
    local addListener = addModEventListener
local function drawRectSafe(x, y, w, h, r, g, b, a)
    if drawFilledRect ~= nil then pcall(drawFilledRect, x, y, w, h, r, g, b, a) end
end

local function setColorSafe(r, g, b, a)
    if setTextColor ~= nil then pcall(setTextColor, r, g, b, a) end
end

local function setAlignSafe(value)
    if setTextAlignment ~= nil and value ~= nil then pcall(setTextAlignment, value) end
end

local function renderCentered(y, size, text, r, g, b, a)
    if renderText == nil then return end
    setColorSafe(r, g, b, a)
    local alignCenter = RenderText ~= nil and RenderText.ALIGN_CENTER or nil
    setAlignSafe(alignCenter)
    pcall(renderText, 0.5, y, size, text)
end

local function rvText(key, fallback)
    if g_i18n ~= nil and g_i18n.getText ~= nil then
        local ok, value = pcall(g_i18n.getText, g_i18n, key)
        if ok and value ~= nil and value ~= "" and value ~= key then
            return value
        end
    end
    return fallback
end


    local function display()
        if not rvCompatibilityBlocked() then return end
    drawRectSafe(0.02, 0.17, 0.96, 0.66, 0.02, 0.02, 0.02, 0.96)
    drawRectSafe(0.02, 0.75, 0.96, 0.08, 0.75, 0.00, 0.00, 0.98)
    drawRectSafe(0.02, 0.17, 0.96, 0.055, 0.75, 0.00, 0.00, 0.98)

    renderCentered(0.775, 0.036, rvText("rp_conflict_title", "MOD CONFLICT - USE REFUSED"), 1, 1, 1, 1)
    renderCentered(0.690, 0.025, rvText("rp_conflict_detected", "An active Cobra Modding / FS25_RealTireWear mod was detected together with Real Physics - Tire Wear."), 1, 0.92, 0.20, 1)
    renderCentered(0.635, 0.022, rvText("rp_conflict_claim1", "In the author's assessment, Cobra Modding / Real Tire Wear used parts or technical solutions"), 1, 0.35, 0.35, 1)
    renderCentered(0.595, 0.022, rvText("rp_conflict_claim2", "from Real Physics - Tire Wear without authorization."), 1, 0.35, 0.35, 1)
    renderCentered(0.525, 0.026, rvText("rp_conflict_disabled", "ALL REAL PHYSICS - TIRE WEAR FUNCTIONS ARE COMPLETELY DISABLED."), 1, 0.20, 0.20, 1)
    renderCentered(0.455, 0.022, rvText("rp_conflict_permanent", "This lock cannot be disabled, closed or hidden in-game."), 1, 1, 1, 1)
    renderCentered(0.400, 0.022, rvText("rp_conflict_choice", "Disable/remove all Cobra Modding / Real Tire Wear mods OR disable Real Physics - Tire Wear."), 1, 1, 1, 1)
    renderCentered(0.325, 0.020, rvText("rp_conflict_reload", "Reload the game/save after changing the active mods."), 0.90, 0.90, 0.90, 1)
    renderCentered(0.185, 0.024, rvText("rp_conflict_footer", "SIMULTANEOUS USE IS NOT PERMITTED"), 1, 1, 1, 1)

    local alignLeft = RenderText ~= nil and RenderText.ALIGN_LEFT or nil
    setAlignSafe(alignLeft)
    setColorSafe(1, 1, 1, 1)
    end
    local listener = {}
    local function restore()
        listener.draw = display
        listener.update = restore
        listener.loadMap = restore
        if type(g_modEventListeners) == "table" then
            local found = false
            for _, item in pairs(g_modEventListeners) do
                if item == listener then found = true; break end
            end
            if not found and type(addListener) == "function" then addListener(listener) end
        end
    end
    listener.draw = display
    listener.update = restore
    listener.loadMap = restore
    listener.deleteMap = function() end
    listener.keyEvent = function() end
    listener.mouseEvent = function() end
    if type(addListener) == "function" then addListener(listener) end
    if FSBaseMission ~= nil and type(FSBaseMission.update) == "function" then
        local original = FSBaseMission.update
        FSBaseMission.update = function(self, ...)
            restore()
            return original(self, ...)
        end
    end
    return true
end)()



if rvCompatibilityBlocked() then
    return
end

-- FS25_Reifenverschleiss
-- Elektronische Wegfahrsperre (EWFS)
-- TEST0.2.2.76
--
-- Fahrzeugseitige Mehrfachsperre. Kein direkter AD-/CP-Eingriff.
-- Sperrebenen:
-- 1) acceleration = 0 vor WheelsUtil.updateWheelsPhysics
-- 2) setVehicleProps torque/maxClutchTorque/maxDriveSpeed = 0, wenn erreichbar
-- 3) wheelDriveTorque = 0 über WheelsUtil.updateWheelPhysics
-- 4) setWheelShapeProps motorTorque = 0 unmittelbar vor der Radphysik
-- READY ist die einzige Freigabe. Motor AUS schärft wieder.

ReifenVerschleissWegfahrsperre = {}
local WFS = ReifenVerschleissWegfahrsperre
_G.ReifenVerschleissWegfahrsperre = WFS

-- TEST0.2.2.99: DIRECT VEHICLE INSTANCE CONTROL GATE
-- Only state rule:
--   motor OFF                 -> blocker = 1
--   motor ON + 5000 ms        -> blocker = 0
--   motor OFF again           -> blocker = 1 and timer is reset
-- No READY, activeVehicle, controlledVehicle, AD, CP, HUD or other release condition.

WFS.VERSION = "TEST2_3_30_EWFS_ALL_GAS_PATHS"
WFS.installed = false
WFS.lockedVehicles = setmetatable({}, {__mode="k"})

-- Read-only EWFS HUD bridge.
-- The existing WFS.lockedVehicles marker remains the ONLY source of truth.
-- No passive visual refresh, no AI scan and no second EWFS state machine.
WFS.HUD_STATE_FIELD = "_FS25_EWFS_HUD_STATE"

local function mirrorHudState(v, locked)
    if v == nil then
        return
    end

    local value = locked == true and 1 or 0
    v[WFS.HUD_STATE_FIELD] = value

    -- GIANTS may expose a root vehicle instance to HUD/other systems.
    -- Mirror the SAME already-decided state to that alias only.
    if type(v.getRootVehicle) == "function" then
        local ok, root = pcall(v.getRootVehicle, v)
        if ok and root ~= nil then
            root[WFS.HUD_STATE_FIELD] = value
        end
    elseif v.rootVehicle ~= nil then
        v.rootVehicle[WFS.HUD_STATE_FIELD] = value
    end
end

function WFS.getHUDState(v)
    if v == nil then
        return nil
    end

    local value = v[WFS.HUD_STATE_FIELD]
    if value ~= nil then
        return tonumber(value)
    end

    if type(v.getRootVehicle) == "function" then
        local ok, root = pcall(v.getRootVehicle, v)
        if ok and root ~= nil then
            return tonumber(root[WFS.HUD_STATE_FIELD])
        end
    elseif v.rootVehicle ~= nil then
        return tonumber(v.rootVehicle[WFS.HUD_STATE_FIELD])
    end

    return nil
end

WFS.startTime = setmetatable({}, {__mode="k"})
WFS.lockedSpeedLimit = setmetatable({}, {__mode="k"})
WFS.registeredVehicles = setmetatable({}, {__mode="k"})
WFS.nodeVehicles = setmetatable({}, {__mode="k"})
WFS.shapeVehicles = setmetatable({}, {__mode="k"})
WFS.originalBrakeForce = setmetatable({}, {__mode="k"})
WFS.controlVehicleWrapped = setmetatable({}, {__mode="k"})
WFS.UPDATE_INTERVAL = 10
WFS.TIMER_DURATION = 5000
WFS.scanTimer = 0

local originalStartMotor
local originalStopMotor
local originalUpdateWheelsPhysics
local originalUpdateWheelPhysics
local originalSetVehicleProps
local originalSetWheelShapeProps
local originalGetSmoothedPedals
local originalDriveAlongCurvature
local originalDriveInDirection
local originalDriveToPoint

-- TEST2.3.96: AutoDrive wear speed cap at the proven GIANTS drive-command path.
-- TEST2.3.95 tried to hook AutoDrive's ADStateModule class globally. AutoDrive's
-- mod environment does not expose that class to this mod, so that hook never
-- installed. Here we use the already proven AIVehicleUtil path that AutoDrive
-- actually calls. While AD is active we also mirror the cap into the GIANTS
-- cruise-control speed so the active cruise display shows the same limit.
WFS.adWearCruiseOriginal = setmetatable({}, {__mode="k"})
WFS.adWearCruiseLastCap = setmetatable({}, {__mode="k"})

local function getADWearSpeedCap(v)
    if v == nil or v.ad == nil or v.ad.stateModule == nil then return nil, nil end
    if type(v.ad.stateModule.isActive) ~= "function" then return nil, nil end
    local okActive, active = pcall(v.ad.stateModule.isActive, v.ad.stateModule)
    if not okActive or active ~= true then return nil, nil end
    if ReifenVerschleissCore == nil or type(ReifenVerschleissCore.getOwnWear01ForHUD) ~= "function" then return nil, nil end
    local okWear, wear01 = pcall(ReifenVerschleissCore.getOwnWear01ForHUD, v)
    if not okWear or type(wear01) ~= "number" then return nil, nil end
    wear01 = math.max(0, math.min(1, wear01))
    local pct = wear01 * 100
    local cap = nil
    if pct >= 95 then cap = 20
    elseif pct >= 85 then cap = 25
    elseif pct >= 80 then cap = 30
    elseif pct >= 75 then cap = 35
    elseif pct >= 70 then cap = 40 end
    return cap, pct
end

local function restoreADWearCruise(v)
    local original = WFS.adWearCruiseOriginal[v]
    if original ~= nil then
        if type(v.setCruiseControlMaxSpeed) == "function" then
            pcall(v.setCruiseControlMaxSpeed, v, original)
        end
        WFS.adWearCruiseOriginal[v] = nil
        WFS.adWearCruiseLastCap[v] = nil
    end
end

local function applyADWearCruise(v, cap, pct)
    if v == nil or cap == nil then return end
    if WFS.adWearCruiseOriginal[v] == nil and type(v.getCruiseControlSpeed) == "function" then
        local ok, current = pcall(v.getCruiseControlSpeed, v)
        if ok and type(current) == "number" then WFS.adWearCruiseOriginal[v] = current end
    end
    if type(v.setCruiseControlMaxSpeed) == "function" then
        pcall(v.setCruiseControlMaxSpeed, v, cap)
    end
    if WFS.adWearCruiseLastCap[v] ~= cap then
        WFS.adWearCruiseLastCap[v] = cap
    end
end


-- TEST2.3.103: physical vehicle speed limit from crawler road-roller wear.
-- Independent of AutoDrive and cruise control. Only RUBBER_TRACK qualifies.
local function getRubberTrackRollerVehicleSpeedFactor(v)
    if v == nil or ReifenVerschleissCore == nil
    or type(ReifenVerschleissCore.getRubberTrackRollerWear01ForSpeedMalus) ~= "function" then
        return 1.0, nil
    end
    local ok, wear01 = pcall(ReifenVerschleissCore.getRubberTrackRollerWear01ForSpeedMalus, v)
    if not ok or type(wear01) ~= "number" then return 1.0, nil end
    wear01 = math.max(0, math.min(1, wear01))
    local pct = wear01 * 100
    if pct >= 90 then return 0.50, pct
    elseif pct >= 85 then return 0.60, pct
    elseif pct >= 80 then return 0.70, pct
    elseif pct >= 75 then return 0.80, pct
    elseif pct >= 70 then return 0.90, pct end
    return 1.0, pct
end

local function applyRubberTrackRollerMaxForwardSpeed(v)
    if v == nil or v.spec_motorized == nil or v.spec_motorized.motor == nil then return end
    local motor = v.spec_motorized.motor
    if type(motor.maxForwardSpeed) ~= "number" or motor.maxForwardSpeed <= 0 then return end

    WFS.rollerMaxForwardSpeedState = WFS.rollerMaxForwardSpeedState or {}
    local state = WFS.rollerMaxForwardSpeedState[v]

    -- GIANTS VehicleMotor itself preserves the original constructor value in
    -- maxForwardSpeedOrigin. Prefer it as immutable source; otherwise capture
    -- the current value once.
    local original = nil
    if type(motor.maxForwardSpeedOrigin) == "number" and motor.maxForwardSpeedOrigin > 0 then
        original = motor.maxForwardSpeedOrigin
    elseif state ~= nil and type(state.original) == "number" then
        original = state.original
    else
        original = motor.maxForwardSpeed
    end

    local factor, pct = getRubberTrackRollerVehicleSpeedFactor(v)

    if state == nil then
        state = {original = original}
        WFS.rollerMaxForwardSpeedState[v] = state
    elseif type(state.original) == "number" and state.original > 0
    and not (type(motor.maxForwardSpeedOrigin) == "number" and motor.maxForwardSpeedOrigin > 0) then
        original = state.original
    end

    local target = original * factor
    if math.abs(motor.maxForwardSpeed - target) > 0.00001 then
        motor.maxForwardSpeed = target
    end

    local signature = string.format("%.0f|%.4f|%.4f|%.2f",
        pct or -1, original, target, factor)
    if state.signature ~= signature then
        state.signature = signature
    end
end

local function motorState(v)
    return v ~= nil and v.spec_motorized ~= nil and v.spec_motorized.motorState or nil
end

local function now()
    if g_currentMission ~= nil and g_currentMission.time ~= nil then
        return tonumber(g_currentMission.time) or 0
    end
    return tonumber(g_time) or 0
end

local function setLocked(v, locked)
    if v == nil then return end

    -- The blocker itself is the single source of truth.
    -- Do not modify persistent motor parameters here.
    WFS.lockedVehicles[v] = locked == true
    mirrorHudState(v, WFS.lockedVehicles[v] == true)
end

local function applyBrakeForcePlus100(v)
    if v == nil or v.spec_motorized == nil or v.spec_motorized.motor == nil then return end
    local motor = v.spec_motorized.motor
    if motor.brakeForce == nil then return end
    if WFS.originalBrakeForce[v] == nil then
        WFS.originalBrakeForce[v] = tonumber(motor.brakeForce) or 0
    end
    motor.brakeForce = WFS.originalBrakeForce[v] + 100
end

local function restoreBrakeForce(v)
    if v == nil or v.spec_motorized == nil or v.spec_motorized.motor == nil then return end
    local motor = v.spec_motorized.motor
    local original = WFS.originalBrakeForce[v]
    if original ~= nil then
        motor.brakeForce = original
        WFS.originalBrakeForce[v] = nil
    end
end

local function updateBlocker(v)
    if v == nil then return end

    WFS.registeredVehicles[v] = true
    applyRubberTrackRollerMaxForwardSpeed(v)
    local t = now()
    local state = motorState(v)

    -- GOLDEN RULE: ONLY the motor state OFF sets the blocker.
    -- While OFF the blocker is always 1 and the timer is cleared.
    if state == MotorState.OFF then
        WFS.startTime[v] = nil
        setLocked(v, true)
        return
    end

    -- STARTING is intentionally treated as the beginning of the
    -- 5000 ms initialization window. The same timer is then carried
    -- through ON until it expires.
    if state == MotorState.STARTING or state == MotorState.ON then
        if WFS.startTime[v] == nil then
            WFS.startTime[v] = t
            setLocked(v, true)
            applyBrakeForcePlus100(v)
            return
        end

        if t - WFS.startTime[v] >= WFS.TIMER_DURATION then
            setLocked(v, false)
            restoreBrakeForce(v)
        else
            setLocked(v, true)
            applyBrakeForcePlus100(v)
        end
    end
end

function WFS.isLocked(v)
    if rvCompatibilityBlocked() then return false end
    return v ~= nil and WFS.lockedVehicles[v] == true
end

function WFS.getState(v)
    if rvCompatibilityBlocked() then return nil end
    return WFS.isLocked(v)
end

-- Refresh the existing EWFS state for a vehicle when it becomes controlled.
-- The HUD only requests this refresh; EWFS remains the sole state owner.
function WFS.refreshVehicleState(v)
    if v == nil then return end

    -- A vehicle can become controlled/tabbed without passing through the
    -- motor-start wrapper. Register and evaluate it immediately so the HUD
    -- always receives the current EWFS state for the newly controlled vehicle.
    WFS.registeredVehicles[v] = true
    updateBlocker(v)
end

-- Compatibility API retained because the existing diagnostic code calls it.
-- It deliberately does nothing: the timer alone controls the blocker.
function WFS.setReady(v)
end

function WFS.reset(v)
    if v == nil then return end
    WFS.startTime[v] = nil
    setLocked(v, true)
    applyBrakeForcePlus100(v)
end

function WFS.registerVehicle(v)
    if v == nil then return end
    WFS.registeredVehicles[v] = true

    -- TEST0.2.2.100: wrap the function actually registered on this vehicle
    -- instance. Motorized.registerFunctions() installs controlVehicle on the
    -- vehicle type; changing Motorized.controlVehicle later does not change
    -- already-created vehicle types. This instance wrapper therefore sits on
    -- the exact self:controlVehicle() path used by WheelsUtil.
    -- MANUAL GAS LOCK (3 layers):
    -- L1: Drivable:setAccelerationPedalInput()
    -- L2: spec.lastInputValues.axisAccelerate
    -- L3: Drivable:onUpdate path consuming axisAccelerate
    -- Only accelerator input is suppressed while EWFS is locked.
    -- No global input action is disabled.

    if Drivable ~= nil and type(Drivable.setAccelerationPedalInput) == "function"
       and not WFS.drivableGasHooked then
        local originalSetAccelerationPedalInput = Drivable.setAccelerationPedalInput
        Drivable.setAccelerationPedalInput = function(vehicle, inputValue)
            if WFS.lockedVehicles[vehicle] == true then
                inputValue = 0
                if vehicle._FS25_EWFS_MANUAL_GAS_BLOCK_LOGGED ~= true then
                    vehicle._FS25_EWFS_MANUAL_GAS_BLOCK_LOGGED = true
                end
            else
                vehicle._FS25_EWFS_MANUAL_GAS_BLOCK_LOGGED = false
            end
            return originalSetAccelerationPedalInput(vehicle, inputValue)
        end
        WFS.drivableGasHooked = true
    end

    if Drivable ~= nil and type(Drivable.onUpdate) == "function"
       and not WFS.drivableUpdateGasHooked then
        local originalDrivableOnUpdate = Drivable.onUpdate
        Drivable.onUpdate = function(vehicle, ...)
            local spec = vehicle.spec_drivable
            if WFS.lockedVehicles[vehicle] == true and spec ~= nil
               and spec.lastInputValues ~= nil then
                -- L2: zero the resolved accelerator value.
                spec.lastInputValues.axisAccelerate = 0
            end
            -- L3: GIANTS onUpdate consumes the zeroed accelerator value.
            return originalDrivableOnUpdate(vehicle, ...)
        end
        WFS.drivableUpdateGasHooked = true
    end
    if not WFS.controlVehicleWrapped[v] and type(v.controlVehicle) == "function" then
        local original = v.controlVehicle
        v.controlVehicle = function(self, acceleratorPedal, maxSpeed, maxAcceleration, minMotorRotSpeed, maxMotorRotSpeed, maxMotorRotAcceleration, minGearRatio, maxGearRatio, maxClutchTorque, neededPtoTorque, ...)
            if WFS.isLocked(self) then
                local motor = self.spec_motorized ~= nil and self.spec_motorized.motor or nil
                if motor ~= nil and motor.setGear ~= nil then
                    -- GIANTS' documented neutral state is gear 0.
                    -- Force the actual transmission state to neutral while EWFS is locked.
                    pcall(motor.setGear, motor, 0, true)
                end
                acceleratorPedal = 0
                maxSpeed = 0
                maxAcceleration = 0
                minGearRatio = 0
                maxGearRatio = 0
                maxClutchTorque = 0
                neededPtoTorque = 0
            end
            return original(self, acceleratorPedal, maxSpeed, maxAcceleration, minMotorRotSpeed, maxMotorRotSpeed, maxMotorRotAcceleration, minGearRatio, maxGearRatio, maxClutchTorque, neededPtoTorque, ...)
        end
        WFS.controlVehicleWrapped[v] = true
    end

    local sm = v.spec_motorized
    if sm ~= nil and sm.motorizedNode ~= nil then
        WFS.nodeVehicles[sm.motorizedNode] = v
    end

    local wheels = v.spec_wheels ~= nil and v.spec_wheels.wheels or nil
    if wheels ~= nil then
        for _, wheel in pairs(wheels) do
            if wheel ~= nil then
                if wheel.node ~= nil then
                    WFS.nodeVehicles[wheel.node] = v
                end
                if wheel.wheelShape ~= nil then
                    WFS.shapeVehicles[wheel.wheelShape] = v
                end
                if wheel.physics ~= nil and wheel.physics.wheelShape ~= nil then
                    WFS.shapeVehicles[wheel.physics.wheelShape] = v
                end
            end
        end
    end
end

local function applyHardWheelLock(v)
    if v == nil or not WFS.isLocked(v) then return end
    local specWheels = v.spec_wheels
    if specWheels == nil or specWheels.wheels == nil then return end

    specWheels.brakePedal = 1
    for _, wheel in pairs(specWheels.wheels) do
        if wheel ~= nil then
            wheel.torque = 0
            if wheel.physics ~= nil then
                wheel.physics.torque = 0
            end
            if setWheelShapeProps ~= nil and wheel.node ~= nil and wheel.wheelShape ~= nil then
                pcall(setWheelShapeProps, wheel.node, wheel.wheelShape, 0, 0, wheel.steeringAngle or 0, wheel.rotationDamping or 0)
            end
        end
    end
end

function WFS.update(dt)
    if rvCompatibilityBlocked() then return end
    local mission = g_currentMission
    if mission == nil then return end

    -- Register vehicles periodically. The actual five-second timer is
    -- based on mission time, not on this polling interval.
    WFS.scanTimer = WFS.scanTimer + (tonumber(dt) or 0)
    if WFS.scanTimer >= WFS.UPDATE_INTERVAL then
        WFS.scanTimer = 0
        if mission.vehicles ~= nil then
            for _, v in pairs(mission.vehicles) do
                if v ~= nil then
                    updateBlocker(v)
                end
            end
        end
    end

    -- Update already registered vehicles every mission update so the timer is
    -- checked without waiting for the next vehicle scan.
    for v, _ in pairs(WFS.registeredVehicles) do
        if v ~= nil then
            updateBlocker(v)
            local adCap, adPct = getADWearSpeedCap(v)
            if adCap ~= nil then
                applyADWearCruise(v, adCap, adPct)
            else
                restoreADWearCruise(v)
            end
        end
    end
end

function WFS.install()
    if rvCompatibilityBlocked() then return false end
    if WFS.installed then return end

    -- FS25 VehicleSystem:setEnteredVehicle is the engine-level notification
    -- point used when the entered/tabbed vehicle changes. Refresh only the
    -- selected vehicle here; the EWFS decision itself remains unchanged.
    if g_currentMission ~= nil and g_currentMission.vehicleSystem ~= nil
       and type(g_currentMission.vehicleSystem.setEnteredVehicle) == "function"
       and not WFS.vehicleSystemEnterHooked then
        local vehicleSystem = g_currentMission.vehicleSystem
        local originalSetEnteredVehicle = vehicleSystem.setEnteredVehicle
        vehicleSystem.setEnteredVehicle = function(self, vehicle)
            local result = originalSetEnteredVehicle(self, vehicle)
            if vehicle ~= nil then
                WFS.refreshVehicleState(vehicle)
            end
            return result
        end
        WFS.vehicleSystemEnterHooked = true
    end

    if Motorized ~= nil and Motorized.startMotor ~= nil then
        originalStartMotor = Motorized.startMotor
        Motorized.startMotor = Utils.prependedFunction(Motorized.startMotor, function(self, noEventSend)
            if self ~= nil then
                WFS.registerVehicle(self)
                -- Do not create a second timer here. The single WFS.update()
                -- state machine starts it when the vehicle is STARTING/ON.
            end
        end)
    end

    if Motorized ~= nil and Motorized.stopMotor ~= nil then
        originalStopMotor = Motorized.stopMotor
        Motorized.stopMotor = Utils.prependedFunction(Motorized.stopMotor, function(self, noEventSend)
            if self ~= nil then
                WFS.registerVehicle(self)
                WFS.reset(self)
            end
        end)
    end

    -- TEST0.2.2.111: block the AutoDrive/AI command at the AIVehicleUtil
    -- entry points while EWFS is locked. This is deliberately limited to
    -- the affected vehicle instance; unlocked vehicles pass through unchanged.
    if AIVehicleUtil ~= nil and AIVehicleUtil.driveAlongCurvature ~= nil then
        originalDriveAlongCurvature = AIVehicleUtil.driveAlongCurvature
        AIVehicleUtil.driveAlongCurvature = function(self, dt, curvature, maxSpeed, acceleration, ...)
            if self ~= nil then
                WFS.registerVehicle(self)
                updateBlocker(self)
                local adCap, adPct = getADWearSpeedCap(self)
                if adCap ~= nil then
                    maxSpeed = math.min(tonumber(maxSpeed) or adCap, adCap)
                    applyADWearCruise(self, adCap, adPct)
                end
                if WFS.isLocked(self) then
                    acceleration = 0
                    maxSpeed = 0
                end
            end
            return originalDriveAlongCurvature(self, dt, curvature, maxSpeed, acceleration, ...)
        end
    end

    -- TEST2.3.13: Courseplay uses AIVehicleUtil.driveToPoint() as its
    -- actual vehicle driving entry point (CpAIWorker:onUpdate). Apply the
    -- same EWFS gate used for AutoDrive/AI without touching Courseplay.
    if AIVehicleUtil ~= nil and AIVehicleUtil.driveToPoint ~= nil then
        originalDriveToPoint = AIVehicleUtil.driveToPoint
        AIVehicleUtil.driveToPoint = function(self, dt, acceleration, allowedToDrive, moveForwards, lx, lz, maxSpeed, ...)
            if self ~= nil then
                WFS.registerVehicle(self)
                updateBlocker(self)
                local adCap, adPct = getADWearSpeedCap(self)
                if adCap ~= nil then
                    maxSpeed = math.min(tonumber(maxSpeed) or adCap, adCap)
                    applyADWearCruise(self, adCap, adPct)
                end
                if WFS.isLocked(self) then
                    -- Block only the actual drive command. Keep steering/path
                    -- calculation alive so Courseplay can initialize normally.
                    acceleration = 0
                    allowedToDrive = false
                    maxSpeed = 0
                end
            end
            return originalDriveToPoint(self, dt, acceleration, allowedToDrive, moveForwards, lx, lz, maxSpeed, ...)
        end
    end

    if AIVehicleUtil ~= nil and AIVehicleUtil.driveInDirection ~= nil then
        originalDriveInDirection = AIVehicleUtil.driveInDirection
        AIVehicleUtil.driveInDirection = function(self, dt, steeringAngleLimit, acceleration, slowAcceleration, slowAngleLimit, allowedToDrive, moveForwards, lx, lz, maxSpeed, slowDownFactor, ...)
            if self ~= nil then
                WFS.registerVehicle(self)
                updateBlocker(self)
                local adCap, adPct = getADWearSpeedCap(self)
                if adCap ~= nil then
                    maxSpeed = math.min(tonumber(maxSpeed) or adCap, adCap)
                    applyADWearCruise(self, adCap, adPct)
                end
                if WFS.isLocked(self) then
                    acceleration = 0
                    slowAcceleration = 0
                    allowedToDrive = false
                    maxSpeed = 0
                end
            end
            return originalDriveInDirection(self, dt, steeringAngleLimit, acceleration, slowAcceleration, slowAngleLimit, allowedToDrive, moveForwards, lx, lz, maxSpeed, slowDownFactor, ...)
        end
    end

    if WheelsUtil ~= nil and WheelsUtil.getSmoothedAcceleratorAndBrakePedals ~= nil then
        originalGetSmoothedPedals = WheelsUtil.getSmoothedAcceleratorAndBrakePedals
        WheelsUtil.getSmoothedAcceleratorAndBrakePedals = function(self, acceleratorPedal, brakePedal, dt)
            if self ~= nil then
                WFS.registerVehicle(self)
                if WFS.isLocked(self) then
                    return 0, 1
                end
            end
            return originalGetSmoothedPedals(self, acceleratorPedal, brakePedal, dt)
        end
    end

    if WheelsUtil ~= nil and WheelsUtil.updateWheelsPhysics ~= nil then
        originalUpdateWheelsPhysics = WheelsUtil.updateWheelsPhysics
        WheelsUtil.updateWheelsPhysics = function(self, dt, currentSpeed, acceleration, doHandbrake, stopAndGoBraking)
            if self ~= nil then
                WFS.registerVehicle(self)
                updateBlocker(self)
                if WFS.isLocked(self) then
                    acceleration = 0
                    doHandbrake = true
                end
            end
            local result = originalUpdateWheelsPhysics(self, dt, currentSpeed, acceleration, doHandbrake, stopAndGoBraking)
            if self ~= nil and WFS.isLocked(self) then
                applyHardWheelLock(self)
            end
            return result
        end
    end

    if WheelsUtil ~= nil and WheelsUtil.updateWheelPhysics ~= nil then
        originalUpdateWheelPhysics = WheelsUtil.updateWheelPhysics
        WheelsUtil.updateWheelPhysics = function(self, wheel, doHandbrake, motorTorque, brakePedal, requiredDriveMode, dt)
            if self ~= nil then
                WFS.registerVehicle(self)
                updateBlocker(self)
                if WFS.isLocked(self) then
                    motorTorque = 0
                    brakePedal = 1
                    doHandbrake = true
                end
            end
            return originalUpdateWheelPhysics(self, wheel, doHandbrake, motorTorque, brakePedal, requiredDriveMode, dt)
        end
    end

    if setVehicleProps ~= nil then
        originalSetVehicleProps = setVehicleProps
        setVehicleProps = function(node, torque, maxDriveSpeed, gearRatio, maxClutchTorque, ...)
            local owner = WFS.nodeVehicles[node]
            if owner ~= nil and WFS.isLocked(owner) then
                torque = 0
                maxDriveSpeed = 0
                maxClutchTorque = 0
            end
            return originalSetVehicleProps(node, torque, maxDriveSpeed, gearRatio, maxClutchTorque, ...)
        end
    end

    if setWheelShapeProps ~= nil then
        originalSetWheelShapeProps = setWheelShapeProps
        setWheelShapeProps = function(node, wheelShape, motorTorque, brakeTorque, steerAngle, rotationDamping, ...)
            local owner = WFS.nodeVehicles[node] or WFS.shapeVehicles[wheelShape]
            if owner ~= nil and WFS.isLocked(owner) then
                motorTorque = 0
                local brakeForce = 0
                if owner.getBrakeForce ~= nil then
                    local ok, value = pcall(owner.getBrakeForce, owner)
                    if ok and tonumber(value) ~= nil then
                        brakeForce = tonumber(value)
                    end
                end
                local factor = 1
                if wheelShape ~= nil and owner.spec_wheels ~= nil and owner.spec_wheels.wheels ~= nil then
                    for _, w in pairs(owner.spec_wheels.wheels) do
                        if w ~= nil and (w.wheelShape == wheelShape or (w.physics ~= nil and w.physics.wheelShape == wheelShape)) then
                            factor = tonumber(w.brakeFactor) or 1
                            break
                        end
                    end
                end
                -- TEST0.2.2.110: add +100 to the actual wheel brake torque while locked.
                -- brakeFactor is intentionally back to its normal value (no x1000).
                brakeTorque = brakeTorque + 100
            end
            return originalSetWheelShapeProps(node, wheelShape, motorTorque, brakeTorque, steerAngle, rotationDamping, ...)
        end
    end

    WFS.installed = true
end
