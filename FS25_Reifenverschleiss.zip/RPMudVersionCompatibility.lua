local rvCompatibilityBlocked = (function()
    local type, tostring, tonumber, pairs, ipairs, pcall = type, tostring, tonumber, pairs, ipairs, pcall
    local string = {lower=string.lower, gsub=string.gsub, find=string.find}
    local math = {abs=math.abs}
    local G = {TARGET_MOD_KEYS={"FS25_RealTireWear", "FS25_RealTireWear_main", "RealTireWear"}, blocked=false}
local function lower(v)
    return string.lower(tostring(v or ""))
end

local function containsRealTireWearName(v)
    local s = lower(v)
    s = string.gsub(s, "[^a-z0-9]", "")
    return string.find(s, "realtirewear", 1, true) ~= nil
end

local function containsCobraModdingAuthor(v)
    local s = lower(v)
    s = string.gsub(s, "[^a-z0-9]", "")
    return string.find(s, "cobramodding", 1, true) ~= nil or string.find(s, "corbramodding", 1, true) ~= nil
end

local function entryAuthor(entry)
    if type(entry) ~= "table" then return nil end
    return entry.author or entry.modAuthor or entry.creator or entry.createdBy or entry.authorName
end

local function markBlocked(reason)
    if G.blocked ~= true then
        G.blocked = true
        G.detectedBy = tostring(reason or "unknown")
        if Logging ~= nil and Logging.error ~= nil then
            Logging.error("[ReifenVerschleiss][CONFLICT] Cobra Modding / FS25_RealTireWear conflict detected (%s). ALL ReifenVerschleiss runtime functions are blocked.", G.detectedBy)
        end
    end
    return true
end

local function detectLoadedModTable()
    if type(g_modIsLoaded) == "table" then
        for _, key in ipairs(G.TARGET_MOD_KEYS) do
            if g_modIsLoaded[key] == true then
                return markBlocked("g_modIsLoaded:" .. key)
            end
        end
        for key, active in pairs(g_modIsLoaded) do
            if active == true and containsRealTireWearName(key) then
                return markBlocked("g_modIsLoaded-scan:" .. tostring(key))
            end
        end
    end
    return false
end

local function detectMissionActiveMods()
    local missionInfo = g_currentMission ~= nil and g_currentMission.missionInfo or nil
    local activeMods = missionInfo ~= nil and missionInfo.activeMods or nil
    if type(activeMods) ~= "table" then return false end
    for key, entry in pairs(activeMods) do
        local name = key
        local active = true
        if type(entry) == "table" then
            name = entry.modName or entry.name or entry.title or key
            if entry.isActive ~= nil then active = entry.isActive end
            if entry.active ~= nil then active = entry.active end
        elseif type(entry) == "string" then
            name = entry
        end
        local author = entryAuthor(entry)
        if active == true and containsRealTireWearName(name) then
            return markBlocked("mission.activeMods:" .. tostring(name))
        end
        if active == true and containsCobraModdingAuthor(author) then
            return markBlocked("mission.activeMods-author:Cobra Modding:" .. tostring(name))
        end
    end
    return false
end

local function detectRuntimeSignature()
    if type(TireWear) == "table" then
        local body = tonumber(TireWear.CRAWLER_PROFILE_BODY_Y)
        local outer = tonumber(TireWear.CRAWLER_PROFILE_OUTER_Y)
        local updateMs = tonumber(TireWear.TRACK_VISUAL_UPDATE_MS)
        if body ~= nil and outer ~= nil
            and math.abs(body - 0.020) < 0.000001
            and math.abs(outer - 0.087339) < 0.000001 then
            return markBlocked("runtime TireWear crawler signature")
        end
        if containsRealTireWearName(TireWear.MOD_NAME) then
            return markBlocked("runtime TireWear.MOD_NAME")
        end
        if updateMs == 200 and TireWearWorkshop ~= nil and TireWearDisplay ~= nil then
            return markBlocked("runtime TireWear/TireWearWorkshop signature")
        end
    end
    return false
end

local function detectModManager()
    if g_modManager == nil then return false end
    if g_modManager.getModByName ~= nil then
        for _, key in ipairs(G.TARGET_MOD_KEYS) do
            local ok, mod = pcall(g_modManager.getModByName, g_modManager, key)
            if ok and mod ~= nil then
                local active = mod.isActive
                if active == nil then active = mod.active end
                if active == true then return markBlocked("g_modManager:" .. key) end
            end
        end
    end
    for _, field in ipairs({"mods", "modsByName", "nameToMod", "availableMods", "loadedMods"}) do
        local list = g_modManager[field]
        if type(list) == "table" then
            for key, mod in pairs(list) do
                local name = key
                local active = false
                if type(mod) == "table" then
                    name = mod.modName or mod.name or mod.title or key
                    if mod.isActive ~= nil then active = mod.isActive end
                    if mod.active ~= nil then active = mod.active end
                end
                local author = entryAuthor(mod)
                if active == true and containsRealTireWearName(name) then
                    return markBlocked("g_modManager-scan:" .. tostring(name))
                end
                if active == true and containsCobraModdingAuthor(author) then
                    return markBlocked("g_modManager-author:Cobra Modding:" .. tostring(name))
                end
            end
        end
    end
    return false
end


    local lastCheck = nil
    return function()
        if G.blocked then return true end
        local now = tonumber(g_time)
        if now ~= nil and lastCheck ~= nil and now >= lastCheck and now-lastCheck < 500 then return false end
        lastCheck = now
        return detectLoadedModTable() or detectMissionActiveMods() or detectRuntimeSignature() or detectModManager()
    end
end)()

if rvCompatibilityBlocked() then
    return
end

-- FS25_Reifenverschleiss - MudSystemPhysics runtime/version detection
-- DEV_1_2_2_67_MUD_VERSION_GUARD
--
-- Purpose:
-- * Mud compatibility is completely dormant when FS25_MudSystemPhysics is not active.
-- * The active Mud version is detected once the mission is available.
-- * Known Mud generations can use separate compatibility profiles without
--   changing Reifenverschleiss core ownership of tire wear/radius.
-- * Unknown/newer versions fall back conservatively to the last known profile.

RPMudVersionCompatibility = RPMudVersionCompatibility or {}
local V = RPMudVersionCompatibility

V.MOD_NAMES = {"FS25_MudSystemPhysics"}
V.active = false
V.modName = nil
V.versionString = nil
V.version = nil
V.profile = "NONE"
V._loggedSignature = nil

local function normalizeVersionString(value)
    if value == nil then return nil end
    local s = tostring(value)
    local a,b,c,d = s:match("(%d+)%.(%d+)%.(%d+)%.(%d+)")
    if a ~= nil then
        return string.format("%d.%d.%d.%d", tonumber(a), tonumber(b), tonumber(c), tonumber(d))
    end
    a,b,c = s:match("(%d+)%.(%d+)%.(%d+)")
    if a ~= nil then
        return string.format("%d.%d.%d.0", tonumber(a), tonumber(b), tonumber(c))
    end
    return nil
end

local function versionToNumber(s)
    if s == nil then return nil end
    local a,b,c,d = s:match("^(%d+)%.(%d+)%.(%d+)%.(%d+)$")
    if a == nil then return nil end
    return tonumber(a) * 1000000 + tonumber(b) * 10000 + tonumber(c) * 100 + tonumber(d)
end

local function detectFromModList(mods)
    if type(mods) ~= "table" then return nil, nil end
    for _, info in pairs(mods) do
        if info ~= nil then
            for _, wanted in ipairs(V.MOD_NAMES) do
                if info.modName == wanted then
                    local ver = normalizeVersionString(info.versionString)
                        or normalizeVersionString(info.version)
                        or normalizeVersionString(info.modVersion)
                    return wanted, ver
                end
            end
        end
    end
    return nil, nil
end

function V:detect()
    local activeName = nil
    if g_modIsLoaded ~= nil then
        for _, name in ipairs(self.MOD_NAMES) do
            if g_modIsLoaded[name] == true then
                activeName = name
                break
            end
        end
    end

    local detectedName, detectedVersion = nil, nil
    local mission = g_currentMission
    local dyn = (mission ~= nil and mission.missionDynamicInfo)
        or (g_mpLoadingScreen ~= nil and g_mpLoadingScreen.missionDynamicInfo)
    detectedName, detectedVersion = detectFromModList(dyn ~= nil and dyn.mods or nil)

    if detectedName == nil and g_modManager ~= nil then
        detectedName, detectedVersion = detectFromModList(g_modManager.mods)
    end

    if activeName == nil then activeName = detectedName end

    if activeName == nil then
        for _, name in ipairs(self.MOD_NAMES) do
            if type(rawget(_G, name)) == "table" then
                activeName = name
                break
            end
        end
    end

    self.active = activeName ~= nil
    self.modName = activeName
    self.versionString = detectedVersion
    self.version = versionToNumber(detectedVersion)

    if self.active ~= true then
        self.profile = "NONE"
    elseif self.version ~= nil and self.version >= versionToNumber("1.3.4.0") then
        self.profile = "MUD_1_3_4_ROAD_CONTACT"
    elseif self.version ~= nil and self.version <= versionToNumber("1.3.2.0") then
        self.profile = "MUD_1_3_2_LEGACY"
    else
        self.profile = "MUD_UNKNOWN_SAFE_LEGACY"
    end

    local signature = string.format("%s|%s|%s", tostring(self.active), tostring(self.versionString), tostring(self.profile))
    if signature ~= self._loggedSignature then
        self._loggedSignature = signature
        if Logging ~= nil and Logging.info ~= nil then
            if self.active then
                Logging.info("[ReifenVerschleiss][MUD-COMPAT] active=true mod=%s version=%s profile=%s",
                    tostring(self.modName), tostring(self.versionString or "unknown"), tostring(self.profile))
            else
                Logging.info("[ReifenVerschleiss][MUD-COMPAT] active=false; Mud compatibility dormant")
            end
        end
    end

    return self.active, self.profile, self.versionString
end

function V:isActive()
    return self.active == true
end

function V:isRoadContact134OrNewer()
    return self.active == true and self.profile == "MUD_1_3_4_ROAD_CONTACT"
end

function V:loadMap()
    if rvCompatibilityBlocked() then return end
    self:detect()
end

function V:deleteMap()
    self.active = false
    self.modName = nil
    self.versionString = nil
    self.version = nil
    self.profile = "NONE"
end

addModEventListener(V)
