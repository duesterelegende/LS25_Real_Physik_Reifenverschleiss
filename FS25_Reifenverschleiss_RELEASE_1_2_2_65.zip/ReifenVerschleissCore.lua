--[[
    FS25_Reifenverschleiss
    Runtime wear core

    Purpose of this build:
      - validate the proven Lights & Symbol HUD chassis recognition approach
      - separate normal wheels from GIANTS Crawler objects
      - expose crawler objects individually
      - collect distance, speed, slip, tire type, contact, load and crawler data
      - test tire wear is calculated and stored only in the independent own-wear model
      - NO tire deformation or tire-pressure dependency
      - NO changes to vehicle physics
      - TEST0.1.0.44 adds the first physically based load/width/radius wear model.

]]

ReifenVerschleissCore = {}

local RV = ReifenVerschleissCore

-- Explicitly excluded third-party vehicle with incompatible custom tire shader/UV layout.
local function rvIsExplicitlyExcludedVehicle(vehicle)
    if vehicle == nil then return false end
    local config = string.lower(tostring(vehicle.configFileName or vehicle.xmlFileName or ""))
    config = string.gsub(config, "\\", "/")
    return string.find(config, "/fs25_johndeere_7r_2020/", 1, true) ~= nil
end

function RV.isVehicleExcluded(vehicle)
    return rvIsExplicitlyExcludedVehicle(vehicle)
end
RV.VERSION = "RELEASE_1_2_2_65"


-- Wear model uses the proven 100 km reference.
RV.WEAR_REFERENCE_DISTANCE_M = 100000
RV.WEAR_MAX = 1

-- Physical-load test model (REALISTIC BASELINE, NOT GAME-TUNED YET).
-- The later FS25 game scaling must remain separate from these physical inputs.
RV.PHYSICS_REFERENCE_LOAD_T = 2.5       -- nominal tire-load reference
RV.PHYSICS_REFERENCE_WIDTH_M = 0.60     -- nominal tire-width reference
RV.PHYSICS_REFERENCE_RADIUS_M = 0.75    -- nominal tire-radius reference
RV.PHYSICS_LOAD_EXPONENT = 0.75
RV.PHYSICS_WIDTH_EXPONENT = 0.50
RV.PHYSICS_RADIUS_EXPONENT = 0.35
RV.totalEffectiveWearDistanceM = 0
RV.lastSpeedKmh = 0
RV.lastVehicleForMotion = nil

RV.currentVehicle = nil
-- Vehicles that were explicitly handed over to an automated driver remain
-- eligible for wear processing after the player leaves the cab.
local aiTrackedVehicles = {}

-- TEST0.2.2.78: independent per-vehicle wear activity. This is deliberately
-- separate from currentVehicle/activeVehicle so changing the player's vehicle
-- cannot remove an already running AD/CP/GIANTS-AI vehicle from wear processing.
local activeWearVehicles = setmetatable({}, {__mode = "k"})

-- TEST0.2.2.77: experimental activeVehicle hold. The existing diagnostic
-- currentVehicle is retained when the HUD clears its controlled vehicle while
-- the same vehicle is still moving or has an automated driver. No GIANTS
-- controlledVehicle field is modified.
local activeVehicleHeld = false
local aiWearAccumulatorMs = 0
RV.manifest = nil
RV.lastDisplayTime = 0
RV.vehicleSerial = 0

local manifestCache = setmetatable({}, {__mode = "k"})

-- Persistent per-vehicle wear state. The calculation belongs to the
-- relevant player-owned vehicle, not to the currently entered vehicle.
-- Vehicles owned by other farms/players and unowned/AI mission vehicles are
-- deliberately excluded from wear processing.
local vehicleWearStates = setmetatable({}, {__mode = "k"})

-- OWN-WEAR persistence is stored directly inside each GIANTS vehicles.xml
-- vehicle node. The pending table is keyed by the concrete vehicle object, so
-- save/load does not need a parallel sidecar file or a second identity mapping.
local pendingSavedWearStates = setmetatable({}, {__mode = "k"})
local capturedVehicleWearSavegame = setmetatable({}, {__mode = "k"})
local lastVehicleScanTime = -math.huge
local ownedMotorizedVehicleCache = {}
local ownedAttachedImplementCache = {}
RV.VEHICLE_SCAN_INTERVAL_MS = 1000
-- TEST0.2.2.89: automated-driver wear tracker cadence.
-- AI vehicles are sampled from world position every 300 ms; the player
-- controlled vehicle keeps the proven normal update cadence.
RV.AI_WEAR_UPDATE_INTERVAL_MS = 300
RV.SAVE_SCHEMA_VERSION = 15

-- TEST0.2.2.01: non-invasive physics-hook probe.
-- This does NOT apply a traction/wear malus. It only proves whether the
-- already installed Wheels.updateWheelFriction callback reaches our code.

-- TEST0.2.2.08: native WheelPhysics friction reference probe.
-- TEST0.2.2.12 applies a wear-dependent target to coeff*frictionScale; frictionScale itself remains untouched.
-- It only records the values immediately before/after the native GIANTS
-- updateFriction/updateTireFriction path.
-- TEST0.2.2.13: keep friction diagnostics separated per physical vehicle object.

local function rvGetObjectType(vehicle)
    if vehicle == nil then return "UNKNOWN" end
    if vehicle.getAttacherVehicle ~= nil then
        local ok, parent = pcall(vehicle.getAttacherVehicle, vehicle)
        if ok and parent ~= nil then return "ATTACHED IMPLEMENT/TRAILER" end
    end
    return "VEHICLE"
end

local function rvGetObjectLabel(vehicle)
    if vehicle == nil then return "UNKNOWN" end
    return tostring(vehicle.configFileName or vehicle.xmlFileName or vehicle.typeName or "UNKNOWN")
end

-- Backward-compatible names retained for the existing HUD/diagnostic code.
-- TEST0.2.2.14: native-GIANTS-scaled wear -> applied friction target curve.
-- The proven 1.80 reference curve is scaled to the native GIANTS frictionScale
-- for the current wheel. From 90% wear onward the absolute end curve is fixed
-- at 0.55 -> 0.40 -> 0.30 for every native start value.
function ReifenVerschleissCore.getWearAppliedTarget(vehicle, wheel)
    if vehicle == nil or wheel == nil then
        return nil, nil
    end

    local wear = ReifenVerschleissCore.getWheelWearValue(vehicle, wheel)
    if type(wear) ~= "number" then
        return nil, nil
    end
    wear = math.clamp(wear, 0, 1)
    local pct = wear * 100

    local function lerp(a, b, t)
        return a + (b - a) * math.clamp(t, 0, 1)
    end

    -- Use the native GIANTS frictionScale as the individual 0% reference.
    -- This keeps the complete 1.80 reference curve proportional through 75%.
    local nativeStart = nil
    if wheel.physics ~= nil and type(wheel.physics.frictionScale) == "number" then
        nativeStart = wheel.physics.frictionScale
    elseif wheel.wheelPhysics ~= nil and type(wheel.wheelPhysics.frictionScale) == "number" then
        nativeStart = wheel.wheelPhysics.frictionScale
    end

    if type(nativeStart) ~= "number" or nativeStart <= 0 then
        return nil, pct
    end

    local scale = nativeStart / 1.80
    local applied
    if pct <= 15 then
        applied = 1.80 * scale
    elseif pct <= 25 then
        applied = lerp(1.80, 1.60, (pct - 15) / 10) * scale
    elseif pct <= 40 then
        applied = lerp(1.60, 1.40, (pct - 25) / 15) * scale
    elseif pct <= 60 then
        applied = lerp(1.40, 1.20, (pct - 40) / 20) * scale
    elseif pct <= 75 then
        applied = lerp(1.20, 1.00, (pct - 60) / 15) * scale
    elseif pct <= 90 then
        -- 75% keeps the scaled 1.00 reference point; 90% MUST reach 0.55
        -- absolute, regardless of the native starting value.
        local start75 = 1.00 * scale
        applied = lerp(start75, 0.55, (pct - 75) / 15)
    elseif pct <= 95 then
        applied = lerp(0.55, 0.40, (pct - 90) / 5)
    else
        applied = lerp(0.40, 0.30, (pct - 95) / 5)
    end

    return applied, pct
end

local function getVehicleWearState(vehicle)
    if vehicle == nil then
        return nil
    end

    local state = vehicleWearStates[vehicle]
    if state == nil then
        state = {
            wear = {},
            wheelWear = {},
            trackWear = {},
            totalEffectiveWearDistanceM = 0,
            lastSpeedKmh = 0,
            gpsDistanceM = 0,
            gpsLastX = nil,
            gpsLastY = nil,
            gpsLastZ = nil,
            initialized = false,
            ready = false,
            readySince = 0,
            lastReadyLog = false,
            totalDistanceWear = 0,
            totalSlipWear = 0,
            totalTimeWear = 0,
            totalForceWear = 0,
            totalWear = 0,
            timeWearMoveConfirmSec = 0,
            timeWearWindowSec = 0,
            timeWearWindowDistanceM = 0,
            timeWearRatePointsPerHourAt1000 = 7.5,
            timeWearWindowAvgSpeedKmh = 0,
            timeWearHarvestBoostActive = false,
            lastWheelCount = 0,
            loadedFromSavegame = false,
            slipDisplayReady = false,
            slipDisplayLast = {},
            slipDisplayRotation = {},
            slipDisplayBlocked = true
        }
        vehicleWearStates[vehicle] = state
    end

    return state
end


local function safeNumber(value, fallback)
    if type(value) == "number" and value == value and math.abs(value) < math.huge then
        return value
    end
    return fallback
end

local function updateGpsDistance(state, object)
    if state == nil or object == nil or object.rootNode == nil or getWorldTranslation == nil then
        return 0
    end

    local x, y, z = getWorldTranslation(object.rootNode)
    x, y, z = safeNumber(x, nil), safeNumber(y, nil), safeNumber(z, nil)
    if x == nil or y == nil or z == nil then
        return 0
    end

    local delta = 0
    if state.gpsLastX ~= nil and state.gpsLastY ~= nil and state.gpsLastZ ~= nil then
        local dx = x - state.gpsLastX
        local dy = y - state.gpsLastY
        local dz = z - state.gpsLastZ
        delta = math.sqrt(dx * dx + dy * dy + dz * dz)
        -- Ignore implausible teleport/spawn jumps in the diagnostic GPS counter.
        if delta > 25 then
            delta = 0
        end
    end

    state.gpsLastX, state.gpsLastY, state.gpsLastZ = x, y, z
    state.gpsDistanceM = safeNumber(state.gpsDistanceM, 0) + math.max(0, delta)
    return delta
end

local function getWheelIndexKey(wheel, fallbackIndex)
    if wheel ~= nil and wheel.wheelIndex ~= nil then
        return wheel.wheelIndex
    end
    return fallbackIndex
end

local function isCrawlerTire(wheel)
    if wheel == nil or WheelsUtil == nil or WheelsUtil.getTireType == nil then
        return false
    end

    local crawlerType = WheelsUtil.getTireType("crawler")
    return crawlerType ~= nil and wheel.tireType == crawlerType
end

-- Resolve the GIANTS tire type name before any snow-profile code uses it.
-- This must be declared before getSnowProfile(): local Lua functions are
-- lexical, so a later local declaration is not visible to earlier functions.
local function getTireName(wheel)
    if wheel == nil then
        return "UNKNOWN"
    end

    -- Primary GIANTS source: tireType is an index into WheelsUtil.tireTypes.
    if WheelsUtil ~= nil and wheel.tireType ~= nil then
        if WheelsUtil.getTireTypeName ~= nil then
            local ok, name = pcall(WheelsUtil.getTireTypeName, wheel.tireType)
            if ok and name ~= nil and tostring(name) ~= "unknown" then
                return tostring(name)
            end
        end

        if WheelsUtil.tireTypes ~= nil and WheelsUtil.tireTypes[wheel.tireType] ~= nil then
            local name = WheelsUtil.tireTypes[wheel.tireType].name
            if name ~= nil then
                return tostring(name)
            end
        end
    end

    -- Some modded/crawler wheel objects expose the tire name on the wheel itself.
    if wheel.tireTypeName ~= nil then
        return tostring(wheel.tireTypeName)
    end
    if wheel.name ~= nil then
        return tostring(wheel.name)
    end

    return "UNKNOWN"
end

-- Same drivetrain traversal principle used by the proven HUD:
-- recursively resolve motorized differentials into wheel indices.
local function getTractionWheels(vehicle)
    local traction = {}
    local specMotorized = vehicle ~= nil and vehicle.spec_motorized or nil

    if specMotorized ~= nil and specMotorized.differentials ~= nil then
        local diffs = specMotorized.differentials
        local visited = {}

        local function visitDiff(index)
            if index == nil or visited[index] then
                return
            end

            visited[index] = true
            local diff = diffs[index]
            if diff == nil then
                return
            end

            if diff.diffIndex1IsWheel then
                traction[diff.diffIndex1] = true
            else
                visitDiff(diff.diffIndex1)
            end

            if diff.diffIndex2IsWheel then
                traction[diff.diffIndex2] = true
            else
                visitDiff(diff.diffIndex2)
            end
        end

        for index, _ in pairs(diffs) do
            visitDiff(index)
        end
    end

    return traction
end

local function addUnique(list, seen, wheel)
    if wheel ~= nil and not seen[wheel] then
        seen[wheel] = true
        list[#list + 1] = wheel
    end
end

local function getCrawlerMembers(vehicle, crawler, allWheels)
    local members = {}
    local seen = {}

    if crawler ~= nil and crawler.wheels ~= nil then
        for _, wheelData in pairs(crawler.wheels) do
            local wheel = wheelData ~= nil and wheelData.wheel or nil
            addUnique(members, seen, wheel)
        end
    end

    if crawler ~= nil and crawler.wheelNodes ~= nil then
        for _, node in pairs(crawler.wheelNodes) do
            if node ~= nil then
                for _, wheel in pairs(allWheels or {}) do
                    if wheel ~= nil and (wheel.repr == node or wheel.driveNode == node or wheel.linkNode == node) then
                        addUnique(members, seen, wheel)
                    end
                end
            end
        end
    end

    if crawler ~= nil and crawler.wheelIndices ~= nil then
        for _, index in pairs(crawler.wheelIndices) do
            local wheel = allWheels[index]
            addUnique(members, seen, wheel)
        end
    end

    -- Defensive recovery for runtimes exposing only a single reference wheel.
    if #members == 1 and crawler ~= nil and crawler.wheelIndices == nil and crawler.wheelNodes == nil then
        local reference = members[1]
        local referenceIndex = reference ~= nil and reference.wheelIndex or nil

        if referenceIndex ~= nil then
            local sideSign = crawler.isLeft == true and -1 or 1

            if crawler.linkNode ~= nil and vehicle ~= nil and vehicle.rootNode ~= nil then
                local ok, x = pcall(localToLocal, crawler.linkNode, vehicle.rootNode, 0, 0, 0)
                if ok and x ~= nil and math.abs(x) > 0.02 then
                    sideSign = x < 0 and -1 or 1
                end
            end

            local i = referenceIndex + 1
            while allWheels[i] ~= nil do
                local candidate = allWheels[i]
                if candidate.repr == nil then
                    break
                end

                local ok, x = pcall(localToLocal, candidate.repr, vehicle.rootNode, 0, 0, 0)
                if not ok or x == nil or x * sideSign <= 0.02 then
                    break
                end

                addUnique(members, seen, candidate)
                i = i + 1
            end
        end
    end

    -- Last-resort geometric recovery only when the Crawler object supplied no
    -- wheel membership at all. This is intentionally not a normal path.
    if #members == 0 and crawler ~= nil then
        local sideSign = crawler.isLeft == true and -1 or 1
        local candidates = {}

        for _, wheel in pairs(allWheels or {}) do
            if wheel ~= nil and wheel.repr ~= nil and isCrawlerTire(wheel) then
                local ok, x, _, z = pcall(localToLocal, wheel.repr, vehicle.rootNode, 0, 0, 0)
                if ok and x ~= nil and z ~= nil and x * sideSign > 0.02 then
                    candidates[#candidates + 1] = {wheel = wheel, z = z}
                end
            end
        end

        table.sort(candidates, function(a, b)
            return (a.z or 0) > (b.z or 0)
        end)

        for _, candidate in ipairs(candidates) do
            addUnique(members, seen, candidate.wheel)
        end
    end

    return members
end

local function getWheelLocalPosition(vehicle, wheel)
    if vehicle == nil or vehicle.rootNode == nil or wheel == nil or wheel.repr == nil then
        return nil, nil, nil
    end

    local ok, x, y, z = pcall(localToLocal, wheel.repr, vehicle.rootNode, 0, 0, 0)
    if ok then
        return x, y, z
    end

    return nil, nil, nil
end

local function getCrawlerLocalPosition(vehicle, crawler)
    if vehicle == nil or vehicle.rootNode == nil or crawler == nil or crawler.linkNode == nil then
        return nil, nil, nil
    end

    local ok, x, y, z = pcall(localToLocal, crawler.linkNode, vehicle.rootNode, 0, 0, 0)
    if ok then
        return x, y, z
    end

    return nil, nil, nil
end

-- ============================================================================
-- Fahrwerkstyp-Erkennung
--
-- Ziel: Nicht nur "Crawler" erkennen, sondern das konkrete Fahrwerk anhand
-- seiner tatsächlich vorhandenen GIANTS-Struktur eindeutig gruppieren.
-- Ein unbekanntes Strukturmuster wird während der Laufzeit automatisch als
-- neuer Fahrwerkstyp angelegt. Es ist deshalb keine manuelle Liste für jedes
-- neue Fahrzeug erforderlich.
--
-- Die Bezeichnung basiert NICHT allein auf dem Fahrzeugnamen. Entscheidend
-- sind Crawler-/Radanzahl, Seitenlage, Radpositionen, Radabmessungen und die
-- vorhandenen Crawler-Knoten. Der Fahrzeugname dient nur als lesbarer Hinweis.
-- ============================================================================
RV.CHASSIS_TYPE_REGISTRY = RV.CHASSIS_TYPE_REGISTRY or {}
RV.CHASSIS_TYPE_BY_SIGNATURE = RV.CHASSIS_TYPE_BY_SIGNATURE or {}
RV.NEXT_CHASSIS_TYPE_ID = RV.NEXT_CHASSIS_TYPE_ID or 1

local function rvRound(value, decimals)
    if type(value) ~= "number" then return 0 end
    local factor = 10 ^ (decimals or 3)
    return math.floor(value * factor + 0.5) / factor
end

local function rvNodeName(node)
    if node == nil then return "-" end
    if getName ~= nil then
        local ok, name = pcall(getName, node)
        if ok and name ~= nil and tostring(name) ~= "" then
            return tostring(name)
        end
    end
    return "NODE"
end

local function rvVehicleHint(vehicle)
    local raw = tostring(vehicle ~= nil and (vehicle.configFileName or vehicle.xmlFileName or vehicle.typeName or "") or "")
    local name = string.lower(raw)
    local brand = "UNKNOWN"
    if string.find(name, "johndeere", 1, true) or string.find(name, "john_deere", 1, true) or string.find(name, "john deere", 1, true) then
        brand = "JOHN_DEERE"
    elseif string.find(name, "newholland", 1, true) or string.find(name, "new_holland", 1, true) or string.find(name, "new holland", 1, true) then
        brand = "NEW_HOLLAND"
    elseif string.find(name, "caseih", 1, true) or string.find(name, "case_ih", 1, true) or string.find(name, "caseih", 1, true) then
        brand = "CASE_IH"
    elseif string.find(name, "case", 1, true) then
        brand = "CASE"
    elseif string.find(name, "fendt", 1, true) then
        brand = "FENDT"
    elseif string.find(name, "claas", 1, true) then
        brand = "CLAAS"
    elseif string.find(name, "ropa", 1, true) then
        brand = "ROPA"
    elseif string.find(name, "leitwolf", 1, true) then
        brand = "LEITWOLF"
    elseif string.find(name, "jf", 1, true) then
        brand = "JF"
    end
    return brand
end

local function rvChassisFamily(vehicle, manifest)
    if manifest ~= nil and (manifest.crawlerCount or 0) > 0 then
        return "CRAWLER"
    end
    local name = string.lower(tostring(vehicle ~= nil and (vehicle.configFileName or vehicle.xmlFileName or vehicle.typeName or "") or ""))
    if string.find(name, "harvester", 1, true) or string.find(name, "combine", 1, true) or string.find(name, "ernter", 1, true) then
        return "HARVESTER"
    end
    if string.find(name, "tractor", 1, true) or string.find(name, "traktor", 1, true) then
        return "TRACTOR"
    end
    return "WHEEL"
end

local function rvGetStableWheelRadius(wheel)
    if wheel == nil then return 0 end
    local physics = wheel.physics
    local candidates = {
        wheel.rvT9OriginalRadius,
        wheel.radiusOriginal,
        physics ~= nil and physics.radiusOriginal or nil,
        wheel.radius,
        physics ~= nil and physics.radius or nil
    }
    for _, value in ipairs(candidates) do
        if type(value) == "number" and value > 0 then
            return value
        end
    end
    return 0
end

local function rvGetStableWheelWidth(wheel)
    if wheel == nil then return 0 end
    local physics = wheel.physics
    local candidates = {
        wheel.width,
        physics ~= nil and physics.width or nil
    }
    for _, value in ipairs(candidates) do
        if type(value) == "number" and value > 0 then
            return value
        end
    end
    return 0
end

local function rvMakeWheelSignature(vehicle, wheel, driven)
    local wx, wy, wz = getWheelLocalPosition(vehicle, wheel)
    return string.format(
        "W@%.3f,%.3f,%.3f:r%.3f:w%.3f:d%d:c%d",
        rvRound(wx,3), rvRound(wy,3), rvRound(wz,3),
        rvRound(rvGetStableWheelRadius(wheel),3),
        rvRound(rvGetStableWheelWidth(wheel),3),
        driven and 1 or 0,
        isCrawlerTire(wheel) and 1 or 0
    )
end

local function rvMakeCrawlerSignature(vehicle, crawler, members)
    local parts = {}
    local x, y, z = getCrawlerLocalPosition(vehicle, crawler)
    parts[#parts + 1] = "C"
    parts[#parts + 1] = crawler.isLeft == true and "L" or "R"
    parts[#parts + 1] = string.format("N%d", #members)
    parts[#parts + 1] = string.format("P%.3f,%.3f,%.3f", rvRound(x,3), rvRound(y,3), rvRound(z,3))

    local wheelParts = {}
    for _, wheel in ipairs(members) do
        local wx, wy, wz = getWheelLocalPosition(vehicle, wheel)
        wheelParts[#wheelParts + 1] = string.format(
            "W@%.3f,%.3f,%.3f:r%.3f:w%.3f",
            rvRound(wx,3), rvRound(wy,3), rvRound(wz,3),
            rvRound(rvGetStableWheelRadius(wheel),3),
            rvRound(rvGetStableWheelWidth(wheel),3)
        )
    end
    table.sort(wheelParts)
    for _, value in ipairs(wheelParts) do
        parts[#parts + 1] = value
    end
    return table.concat(parts, "|")
end

local function rvMakeRunningGearSignature(vehicle, manifest)
    local parts = {}
    local traction = getTractionWheels(vehicle)

    for _, crawler in ipairs(manifest.crawlers or {}) do
        parts[#parts + 1] = rvMakeCrawlerSignature(vehicle, crawler.crawler, crawler.wheels)
    end

    local normalWheels = {}
    for _, unit in ipairs(manifest.wheelUnits or {}) do
        for _, wheel in ipairs(unit.wheels or {}) do
            normalWheels[#normalWheels + 1] = rvMakeWheelSignature(
                vehicle, wheel, traction[wheel.wheelIndex] == true
            )
        end
    end
    table.sort(normalWheels)
    for _, value in ipairs(normalWheels) do
        parts[#parts + 1] = value
    end

    return table.concat(parts, "||")
end

local function rvRegisterChassisType(vehicle, manifest)
    local family = rvChassisFamily(vehicle, manifest)
    local brand = rvVehicleHint(vehicle)
    local signature = string.format(
        "C=%d|W=%d|A=%d|%s",
        manifest.crawlerCount or 0,
        manifest.totalWheelCount or 0,
        manifest.axleCount or 0,
        rvMakeRunningGearSignature(vehicle, manifest)
    )

    local existing = RV.CHASSIS_TYPE_BY_SIGNATURE[signature]
    if existing ~= nil then
        return existing, RV.CHASSIS_TYPE_REGISTRY[existing]
    end

    local id = string.format("FW-%03d", RV.NEXT_CHASSIS_TYPE_ID)
    RV.NEXT_CHASSIS_TYPE_ID = RV.NEXT_CHASSIS_TYPE_ID + 1
    local entry = {
        id = id,
        family = family,
        brand = brand,
        signature = signature,
        vehicleHint = tostring(vehicle ~= nil and (vehicle.configFileName or vehicle.xmlFileName or vehicle.typeName or "UNKNOWN") or "UNKNOWN"),
        crawlerCount = manifest.crawlerCount or 0,
        wheelCount = manifest.totalWheelCount or 0,
        axleCount = manifest.axleCount or 0
    }
    RV.CHASSIS_TYPE_BY_SIGNATURE[signature] = id
    RV.CHASSIS_TYPE_REGISTRY[id] = entry

    return id, entry
end

local function rvGetChassisTypeLabel(entry)
    if entry == nil then return "FW-??? | UNKNOWN" end
    return string.format("%s | %s | %s", entry.id, entry.family, entry.brand)
end

local function rvDetectCrawlerMotionPathKind(crawler)
    if crawler == nil then return nil, nil end
    local root = crawler.loadedCrawler
    if root == nil or root == 0 then return nil, nil end

    local foundSteel = nil
    local foundRubber = nil
    I3DUtil.iterateRecursively(root, function(node)
        if node == nil or node == 0 then return end
        local okShape, isShape = pcall(getHasClassId, node, ClassIds.SHAPE)
        if not okShape or not isShape then return end
        local count = 1
        local okCount, n = pcall(getNumOfMaterials, node)
        if okCount and tonumber(n) and n > 0 then count = n end
        for materialIndex = 0, count - 1 do
            local okMat, materialId = pcall(getMaterial, node, materialIndex)
            if okMat and materialId ~= nil and materialId ~= 0 then
                local okVar, variation = pcall(getMaterialCustomShaderVariation, materialId)
                if okVar then
                    if variation == "motionPath" or variation == "motionPath_vmaskUV2" then
                        foundSteel = variation
                    elseif variation == "motionPathRubber" or variation == "motionPathRubber_vmaskUV2" then
                        foundRubber = variation
                    end
                end
            end
        end
    end)

    if foundSteel ~= nil then return "STEEL", foundSteel end
    if foundRubber ~= nil then return "RUBBER", foundRubber end
    return nil, nil
end

local function classifyCrawler(vehicle, crawler)
    -- Known special case from the project analysis:
    -- Leitwolf uses an external/shared crawler definition whose material is
    -- not safely available from the vehicle package itself.
    local name = ""
    if vehicle ~= nil then
        name = tostring(vehicle.configFileName or vehicle.xmlFileName or vehicle.typeName or "")
        name = string.lower(name)
    end

    if string.find(name, "leitwolf", 1, true) ~= nil then
        return "CRAWLER_STEEL", "SPECIAL_LEITWOLF"
    end
    if string.find(name, "raptor", 1, true) ~= nil then
        return "CRAWLER_STEEL", "SPECIAL_RAPTOR_METAL"
    end
    if string.find(name, "a8800mr", 1, true) ~= nil
        or string.find(name, "jacto_hover_500", 1, true) ~= nil
        or string.find(name, "hover_500", 1, true) ~= nil
        or string.find(name, "hover500", 1, true) ~= nil then
        return "CRAWLER_STEEL", "SPECIAL_A8800MR_STEEL"
    end

    -- TEST2_4_0_20: runtime material classification.  Do not rely on vehicle
    -- names for normal GIANTS crawler families: the actual custom shader
    -- variation tells us whether the visible running gear is a segmented
    -- steel MotionPath or a continuous rubber MotionPathRubber belt.
    local runtimeKind, runtimeVariation = rvDetectCrawlerMotionPathKind(crawler)
    if runtimeKind == "STEEL" then
        return "CRAWLER_STEEL", "AUTO_MOTION_PATH_" .. tostring(runtimeVariation)
    elseif runtimeKind == "RUBBER" then
        return "RUBBER_TRACK", "AUTO_MOTION_PATH_RUBBER_" .. tostring(runtimeVariation)
    end

    return "RUBBER_TRACK", "GENERIC_CRAWLER_DEFAULT"
end

local function getTerrainSnowInfo(wheel)
    -- FS25: use the actual wheel-shape contact point first. The wheel repr is
    -- not guaranteed to be the point that touches the terrain.
    local mission = g_currentMission
    local terrainId = mission ~= nil and mission.terrainDetailHeightId or nil
    if terrainId == nil or wheel == nil or wheel.node == nil or wheel.physics == nil then
        return nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
    end

    local snowIndex = nil
    local snowSystem = mission ~= nil and mission.snowSystem or nil
    if snowSystem ~= nil and type(snowSystem.snowHeightTypeIndex) == "number" then
        snowIndex = snowSystem.snowHeightTypeIndex
    elseif mission ~= nil and mission.environment ~= nil and type(mission.environment.snowHeightTypeIndex) == "number" then
        snowIndex = mission.environment.snowHeightTypeIndex
    end

    local wx, wy, wz
    local contactSkin = nil
    local gotContactPoint = false
    if getWheelShapeContactPointVector ~= nil and wheel.physics.wheelShape ~= nil then
        local ok, cx, cy, cz, skin = pcall(getWheelShapeContactPointVector, wheel.node, wheel.physics.wheelShape)
        if ok and type(cx) == "number" and type(cy) == "number" and type(cz) == "number" then
            local okWorld, x, y, z = pcall(localToWorld, wheel.node, cx, cy, cz)
            if okWorld then
                wx, wy, wz = x, y, z
                contactSkin = skin
                gotContactPoint = true
            end
        end
    end

    if not gotContactPoint then
        local okPos, x, y, z = pcall(getWorldTranslation, wheel.repr)
        if not okPos then
            return snowIndex, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
        end
        local radius = type(wheel.physics.radius) == "number" and wheel.physics.radius or 0
        wx, wy, wz = x, y - radius, z
    end

    local density = nil
    local typeIndex = nil
    local states = nil
    local channels = nil
    local densityHeight = nil
    local densityDelta = nil
    local terrainHeight = nil
    local heightTypeIndex = nil
    local heightTypeName = nil
    local densityHeightBits = nil
    local nativeHeightTypeChannels = nil
    local nativeHeightTypeCandidates = {}
    local densityTypeIndex = nil
    local densityStateBits = nil

    -- IMPORTANT: this follows the native GIANTS wheel snow-contact logic.
    -- Wheels:updateWheelContact() reads the raw terrainDetailHeight density
    -- value and extracts the height type from the low height-type channels:
    --
    --   densityBits = getDensityAtWorldPos(terrainDetailHeightId, wx, wy, wz)
    --   heightType = bitAND(densityBits, 2^numChannels - 1)
    --   hasSnowContact = heightType == snowHeightTypeIndex
    --
    -- Do NOT use getDensityTypeIndexAtWorldPos() here. That function does not
    -- represent the packed terrain height-type field used by the basegame
    -- snow-contact test.
    if getDensityAtWorldPos ~= nil then
        local ok, value = pcall(getDensityAtWorldPos, terrainId, wx, wy, wz)
        if ok and type(value) == "number" then
            density = value
            densityHeightBits = value
        end
    end

    if densityHeightBits ~= nil then
        -- TEST0.1.0.30: The raw terrainDetailHeight value observed in the
        -- previous channel test is packed with the terrain height-type in
        -- the lower 6 bits. Example from the real log: raw=106 -> 106 & 63 = 42,
        -- while the SnowSystem reports snowHeightTypeIndex=42. The exposed
        -- manager value reported 7, but using all 7 bits reproduced raw=106
        -- and therefore could never match the actual snow type 42.
        -- Use the verified 6-bit height-type field for the Snow decision.
        local numChannels = 6
        nativeHeightTypeChannels = numChannels
        heightTypeIndex = bitAND(densityHeightBits, 2^numChannels - 1)
        typeIndex = heightTypeIndex

        -- Diagnostic channel sweep. This is deliberately read-only and is
        -- used to identify which low bit-channel width reproduces the native
        -- height-type index. No candidate is used for the actual Snow state.
        for n = 1, 10 do
            nativeHeightTypeCandidates[n] = bitAND(densityHeightBits, 2^n - 1)
        end
    end

    if getDensityTypeIndexAtWorldPos ~= nil then
        local ok, value = pcall(getDensityTypeIndexAtWorldPos, terrainId, wx, wy, wz)
        if ok and type(value) == "number" then
            densityTypeIndex = value
        end
    end
    if getDensityStatesAtWorldPos ~= nil then
        local ok, value = pcall(getDensityStatesAtWorldPos, terrainId, wx, wy, wz)
        if ok and type(value) == "number" then
            densityStateBits = value
            states = value
        end
    end
    if getTerrainDetailNumChannels ~= nil then
        local ok, value = pcall(getTerrainDetailNumChannels, terrainId)
        if ok and type(value) == "number" then channels = value end
    end
    if getDensityHeightAtWorldPos ~= nil then
        local ok, h, delta = pcall(getDensityHeightAtWorldPos, terrainId, wx, wy, wz)
        if ok then
            if type(h) == "number" then densityHeight = h end
            if type(delta) == "number" then densityDelta = delta end
        end
    end
    if getTerrainHeightAtWorldPos ~= nil and mission.terrainRootNode ~= nil then
        local ok, h = pcall(getTerrainHeightAtWorldPos, mission.terrainRootNode, wx, wy, wz)
        if ok and type(h) == "number" then terrainHeight = h end
    end

    -- This descriptor is useful as a separate comparison value.
    -- IMPORTANT: never overwrite the native packed heightTypeIndex with desc.index.
    -- In the previous build that masked the actual low-channel value (e.g. 42)
    -- with the descriptor index (e.g. 106), which made the Snow comparison fail.
    local descriptorHeightTypeIndex = nil
    if DensityMapHeightUtil ~= nil and DensityMapHeightUtil.getHeightTypeDescAtWorldPos ~= nil then
        local ok, desc = pcall(DensityMapHeightUtil.getHeightTypeDescAtWorldPos, wx, wy, wz, 0.05)
        if ok and type(desc) == "table" then
            if type(desc.index) == "number" then descriptorHeightTypeIndex = desc.index end
            heightTypeName = desc.name or desc.fillTypeName or desc.title
        end
    end

    local snowFound = false
    local method = "NONE"

    -- Native FS25 snow-contact test. This is the decisive result for lying
    -- snow at the wheel contact point. It is independent of snowfall state
    -- and does not require getSnowHeightAtArea().
    if snowIndex ~= nil and heightTypeIndex ~= nil and heightTypeIndex == snowIndex then
        snowFound = true
        method = "NATIVE_HEIGHT_TYPE"
    elseif snowSystem ~= nil and snowSystem.isEnabled == true and densityDelta ~= nil and densityDelta > 0.015 then
        -- Secondary fallback for a raised terrain-height layer when the snow
        -- type descriptor is temporarily unavailable.
        snowFound = true
        method = "HEIGHT_DELTA"
    end

    return snowIndex, snowFound, typeIndex, density, states, channels, 1,
        densityHeight, densityDelta, terrainHeight, heightTypeIndex, heightTypeName, contactSkin, method,
        nativeHeightTypeChannels, nativeHeightTypeCandidates, densityTypeIndex, densityStateBits, descriptorHeightTypeIndex
end

-- Own snow model: deliberately conservative and close to the normal game range.
-- These are relative gameplay factors, not manufacturer test values.
local SNOW_PROFILES = {
    -- These are ONLY our additional snow modifiers. GIANTS' native
    -- frictionCoeffsSnow remains the base value and is never replaced.
    STREET      = {slip = 1.16, grip = 0.86, wear = 1.06},
    OFFROAD     = {slip = 1.075, grip = 0.93, wear = 1.04},
    MUD         = {slip = 1.03, grip = 0.97, wear = 1.02},
    RUBBER_TRACK= {slip = 1.01, grip = 0.99, wear = 1.01},
    STEEL_TRACK = {slip = 1.00, grip = 1.00, wear = 1.00},
    CHAIN       = {slip = 0.98, grip = 1.02, wear = 0.99},
    DEFAULT     = {slip = 1.00, grip = 1.00, wear = 1.00}
}

local function getSnowProfile(wheel)
    local name = getTireName(wheel):upper()
    if string.find(name, "CHAIN", 1, true) or string.find(name, "KETTE", 1, true) then
        return "CHAIN", SNOW_PROFILES.CHAIN
    end

    if isCrawlerTire(wheel) then
        if string.find(name, "STEEL", 1, true) or string.find(name, "LEITWOLF", 1, true) then
            return "STEEL_TRACK", SNOW_PROFILES.STEEL_TRACK
        end
        return "RUBBER_TRACK", SNOW_PROFILES.RUBBER_TRACK
    end

    if string.find(name, "MUD", 1, true) then
        return "MUD", SNOW_PROFILES.MUD
    end

    -- Many real FS25 tire configuration names do not contain the literal
    -- word OFFROAD. For example, the verified log contains "Conti CrossTrac HD3".
    -- CrossTrac is an all-terrain/off-road tractor tire and must therefore not
    -- fall through to DEFAULT. Keep this classification name-based and local
    -- to the tire profile; do not alter GIANTS' native friction values.
    local offroadTokens = {
        "OFFROAD", "OFF-ROAD", "CROSSTRAC", "ALLTERRAIN", "ALL-TERRAIN",
        "AGRO", "AGRICULT", "TRACTOR", "FIELD", "TERRAIN", "FIELDFORCE",
        "MULTITERRA", "MULTI-TERRA", "SOIL", "RIB", "LUG"
    }
    for _, token in ipairs(offroadTokens) do
        if string.find(name, token, 1, true) then
            return "OFFROAD", SNOW_PROFILES.OFFROAD
        end
    end

    if string.find(name, "STREET", 1, true)
        or string.find(name, "ROAD", 1, true)
        or string.find(name, "HIGHWAY", 1, true)
        or string.find(name, "ASPHALT", 1, true) then
        return "STREET", SNOW_PROFILES.STREET
    end

    -- Unknown names remain neutral instead of silently receiving the OFFROAD
    -- modifier. This prevents an unrecognised tire from changing traction.
    return "DEFAULT", SNOW_PROFILES.DEFAULT
end

local function getWheelWearRunningGearType(wheel)
    if wheel == nil then return "OFFROAD" end
    if isCrawlerTire(wheel) then
        local profileName = getSnowProfile(wheel)
        if profileName == "STEEL_TRACK" or profileName == "CHAIN" then
            return "STEEL_TRACK"
        end
        return "RUBBER_TRACK"
    end

    local profileName = getSnowProfile(wheel)
    if profileName == "STREET" then
        return "STREET"
    end
    return "OFFROAD"
end

local function getWheelContactWorldPosition(wheel)
    if wheel == nil or wheel.node == nil or wheel.physics == nil then
        return nil, nil, nil
    end

    if getWheelShapeContactPointVector ~= nil and wheel.physics.wheelShape ~= nil then
        local ok, cx, cy, cz = pcall(getWheelShapeContactPointVector, wheel.node, wheel.physics.wheelShape)
        if ok and type(cx) == "number" and type(cy) == "number" and type(cz) == "number" then
            local okWorld, x, y, z = pcall(localToWorld, wheel.node, cx, cy, cz)
            if okWorld and type(x) == "number" and type(y) == "number" and type(z) == "number" then
                return x, y, z
            end
        end
    end

    local repr = wheel.repr
    if repr ~= nil then
        local okPos, x, y, z = pcall(getWorldTranslation, repr)
        if okPos and type(x) == "number" and type(y) == "number" and type(z) == "number" then
            local radius = type(wheel.physics.radius) == "number" and wheel.physics.radius or 0
            return x, y - radius, z
        end
    end

    return nil, nil, nil
end

-- Own snow environment:
-- IMPORTANT: snowfall and lying snow are separate states.
-- GIANTS exposes the actual accumulated snow height through
-- snowSystem:getSnowHeightAtArea(x1,z1,x2,z2,x3,z3). This is the value used
-- by basegame code to decide whether an area is covered by snow.
-- The current snowfall rate is only an additional temporary factor.
local function getOwnSnowEnvironment(wheel)
    local mission = g_currentMission
    local snowSystem = mission ~= nil and mission.snowSystem or nil
    local env = mission ~= nil and mission.environment or nil
    local weather = env ~= nil and env.weather or nil

    if snowSystem == nil then
        return 0, 0, 0, 0, "OFF"
    end

    local snowfall = 0
    for _, obj in ipairs({snowSystem, weather}) do
        if obj ~= nil then
            for _, key in ipairs({"snowfallScale", "snowFallScale", "snowScale", "snowIntensity", "snowfallIntensity"}) do
                local v = obj[key]
                if type(v) == "number" then
                    snowfall = math.max(snowfall, math.clamp(v, 0, 1))
                end
            end
        end
    end

    local temp = 0
    if weather ~= nil then
        for _, key in ipairs({"temperature", "currentTemperature", "temperatureCelsius"}) do
            local v = weather[key]
            if type(v) == "number" then
                temp = v
                break
            end
        end
    end

    -- Actual accumulated snow at the wheel contact area.
    -- This is intentionally independent of current snowfall.
    local snowHeight = 0
    local snowHeightMethod = "NONE"
    local areaQueryAvailable = false
    local areaQuerySucceeded = false
    local globalSnowHeight = 0
    if type(snowSystem.height) == "number" and snowSystem.height == snowSystem.height then
        globalSnowHeight = math.max(0, snowSystem.height)
    end

    -- Use the same triangle convention used by GIANTS basegame code:
    -- getSnowHeightAtArea(x,z, x+0.1,z+0.1, x+0.1,z).
    -- The query works in world X/Z only; the Y coordinate is intentionally not
    -- part of this API. First use the real physics contact point, then the wheel
    -- representation as a robust fallback if the contact point is not available.
    local x, y, z = getWheelContactWorldPosition(wheel)
    local candidates = {}
    if x ~= nil and z ~= nil then
        candidates[#candidates + 1] = {x=x, z=z, method="AREA_CONTACT"}
    end

    if wheel ~= nil and wheel.repr ~= nil then
        local okPos, rx, ry, rz = pcall(getWorldTranslation, wheel.repr)
        if okPos and type(rx) == "number" and type(rz) == "number" then
            local duplicate = x ~= nil and math.abs(rx-x) < 0.001 and math.abs(rz-z) < 0.001
            if not duplicate then
                candidates[#candidates + 1] = {x=rx, z=rz, method="AREA_REPR"}
            end
        end
    end

    if snowSystem.getSnowHeightAtArea ~= nil then
        areaQueryAvailable = true
        for _, c in ipairs(candidates) do
            local ok, h = pcall(snowSystem.getSnowHeightAtArea, snowSystem,
                c.x, c.z,
                c.x + 0.10, c.z + 0.10,
                c.x + 0.10, c.z)
            if ok and type(h) == "number" and h == h then
                areaQuerySucceeded = true
                if h > snowHeight then
                    snowHeight = math.max(0, h)
                    snowHeightMethod = c.method
                end
            end
            if snowHeight > 0 then
                break
            end
        end
    end

    -- Only use the global SnowSystem height when the per-area API is unavailable
    -- or could not be called. A successful area result of 0 is authoritative:
    -- this prevents globally lying snow from falsely being applied to a locally
    -- cleared road/area.
    if not areaQueryAvailable or not areaQuerySucceeded then
        for _, obj in ipairs({snowSystem, env}) do
            if obj ~= nil then
                for _, key in ipairs({"height", "snowHeight", "snowDepth", "currentSnowHeight", "snowLayerHeight"}) do
                    local v = obj[key]
                    if type(v) == "number" and v == v and v > snowHeight then
                        snowHeight = math.max(0, v)
                        snowHeightMethod = "GLOBAL_" .. key
                    end
                end
            end
        end
    end

    -- 0.20 m is the full-strength reference height for the own model.
    local heightFactor = math.clamp(snowHeight / 0.20, 0, 1)

    -- Snowfall alone may create a small temporary effect, but it must NEVER
    -- replace the accumulated-snow test. Once snowfall stops, heightFactor
    -- remains active as long as snow is still lying on the ground.
    local snowfallFactor = snowfall
    if snowfall > 0 then
        snowfallFactor = math.max(snowfallFactor, 0.35 + snowfall * 0.65)
    end

    if temp > 1 then
        snowfallFactor = 0
    end

    local target = math.max(heightFactor, snowfallFactor)
    local state
    if heightFactor > 0.02 then
        state = "LYING"
    elseif snowfallFactor > 0.02 then
        state = "FALLING"
    else
        state = "NONE"
    end

    return math.clamp(target, 0, 1), snowfall, temp, snowHeight, state, snowHeightMethod, globalSnowHeight
end

-- Returns the already verified own-Snow traction modifier without running
-- the full diagnostic/environment query. This is used only by the physics hook.
local function getOwnSnowPhysicsModifier(wheel)
    if wheel == nil then
        return 1, 0, "DEFAULT", 1, 1
    end

    -- GIANTS updates hasSnowContact from the terrain height type. This remains
    -- valid after snowfall has stopped because it represents lying snow.
    local snowActive = wheel.hasSnowContact == true

    -- Keep our verified native height-type test as a fallback. This avoids
    -- depending exclusively on a visual/physics flag on unusual wheel objects.
    if not snowActive then
        local ok, _, terrainSnow = pcall(getTerrainSnowInfo, wheel)
        if ok and terrainSnow == true then
            snowActive = true
        end
    end

    if not snowActive then
        return 1, 0, "NONE", 1, 1
    end

    local profileName, profile = getSnowProfile(wheel)
    local gripFactor = safeNumber(profile.grip, 1)
    local slipFactor = safeNumber(profile.slip, 1)
    local wearFactor = safeNumber(profile.wear, 1)

    return gripFactor, 1, profileName, slipFactor, wearFactor
end

-- Apply the own Snow traction factor after GIANTS has calculated its native
-- tire-ground friction. The native snow friction remains intact; our factor
-- is deliberately conservative and only reduces the resulting grip on snow.
-- This naturally increases slip without inventing a separate wheel-slip force.
function ReifenVerschleissCore.applySnowFriction(wheel)
    if wheel == nil or type(wheel.tireGroundFrictionCoeff) ~= "number" then
        return false
    end

    local gripFactor, active, profileName, slipFactor, wearFactor = getOwnSnowPhysicsModifier(wheel)

    -- IMPORTANT: never leave a previous Snow modifier on the wheel.
    -- updateWheelFriction may be called again after leaving snow; the normal
    -- GIANTS coefficient must remain untouched on ROAD/HARD/MUD/etc.
    if active ~= 1 then
        local currentCoeff = wheel.tireGroundFrictionCoeff
        local previousFactor = safeNumber(wheel.reifenVerschleissAppliedGripFactor, 1)
        local previousCoeff = safeNumber(wheel.reifenVerschleissAppliedCoeff, nil)
        if previousFactor ~= 1 and previousCoeff ~= nil and math.abs(currentCoeff - previousCoeff) <= 0.000001 then
            wheel.tireGroundFrictionCoeff = currentCoeff / previousFactor
            if wheel.vehicle ~= nil and wheel.vehicle.setWheelTireFrictionDirty ~= nil then
                pcall(wheel.vehicle.setWheelTireFrictionDirty, wheel.vehicle, wheel)
            end
        end
        wheel.reifenVerschleissSnowActive = false
        wheel.reifenVerschleissSnowProfile = "NONE"
        wheel.reifenVerschleissSnowGripFactor = 1
        wheel.reifenVerschleissSnowSlipFactor = 1
        wheel.reifenVerschleissSnowWearFactor = 1
        wheel.reifenVerschleissAppliedGripFactor = 1
        wheel.reifenVerschleissAppliedCoeff = nil
        return false
    end

    -- GIANTS calculates tireGroundFrictionCoeff first, including its own
    -- frictionCoeffsSnow. Never multiply an already modified value again.
    -- If the current value is still our previously applied value, recover the
    -- native coefficient first. If GIANTS has already recalculated it, use the
    -- current value untouched as the native base.
    local currentCoeff = wheel.tireGroundFrictionCoeff
    local previousFactor = safeNumber(wheel.reifenVerschleissAppliedGripFactor, 1)
    local previousCoeff = safeNumber(wheel.reifenVerschleissAppliedCoeff, nil)
    local nativeCoeff = currentCoeff

    if previousFactor ~= 1 and previousCoeff ~= nil and math.abs(currentCoeff - previousCoeff) <= 0.000001 then
        nativeCoeff = currentCoeff / previousFactor
    end

    local modifiedCoeff = nativeCoeff * gripFactor
    if math.abs(modifiedCoeff - currentCoeff) > 0.000001 then
        wheel.tireGroundFrictionCoeff = modifiedCoeff
        if wheel.vehicle ~= nil and wheel.vehicle.setWheelTireFrictionDirty ~= nil then
            pcall(wheel.vehicle.setWheelTireFrictionDirty, wheel.vehicle, wheel)
        end
    end

    wheel.reifenVerschleissSnowActive = true
    wheel.reifenVerschleissSnowProfile = profileName
    wheel.reifenVerschleissSnowGripFactor = gripFactor
    wheel.reifenVerschleissSnowSlipFactor = slipFactor
    wheel.reifenVerschleissSnowWearFactor = wearFactor
    wheel.reifenVerschleissAppliedGripFactor = gripFactor
    wheel.reifenVerschleissAppliedCoeff = modifiedCoeff
    return true
end

local function rvGetWheelGroundSamplePosition(wheel)
    if wheel == nil then return nil, nil, nil end

    if wheel.physics ~= nil and wheel.node ~= nil and wheel.physics.wheelShape ~= nil
        and getWheelShapeContactPointVector ~= nil then
        local okPoint, cx, cy, cz = pcall(getWheelShapeContactPointVector, wheel.node, wheel.physics.wheelShape)
        if okPoint and type(cx) == "number" and type(cy) == "number" and type(cz) == "number" then
            local okWorld, wx, wy, wz = pcall(localToWorld, wheel.node, cx, cy, cz)
            if okWorld and type(wx) == "number" and type(wy) == "number" and type(wz) == "number" then
                return wx, wy, wz
            end
        end
    end

    local node = wheel.repr or wheel.node
    if node ~= nil then
        local okPos, wx, wy, wz = pcall(getWorldTranslation, node)
        if okPos and type(wx) == "number" and type(wy) == "number" and type(wz) == "number" then
            local radius = wheel.physics ~= nil and safeNumber(wheel.physics.radius, 0) or 0
            return wx, wy - radius, wz
        end
    end

    return nil, nil, nil
end

local function rvWheelIsOnField(wheel)
    if wheel == nil then return false end

    local wx, wy, wz = rvGetWheelGroundSamplePosition(wheel)
    if wx ~= nil and FSDensityMapUtil ~= nil and FSDensityMapUtil.getFieldDataAtWorldPosition ~= nil then
        local okField, isOnField = pcall(FSDensityMapUtil.getFieldDataAtWorldPosition, wx, wy, wz)
        if okField and type(isOnField) == "boolean" then
            return isOnField
        end
    end

    return wheel.densityType ~= nil and wheel.densityType ~= 0
end

local function getWheelGroundInfo(wheel)
    if wheel == nil or wheel.physics == nil then
        return nil, nil, nil, nil, nil, nil, nil, nil
    end

    local p = wheel.physics
    local contact = p.contact

    -- IMPORTANT: use the same native classification inputs as GIANTS Wheels.
    -- FS25 WheelsUtil.getGroundType() is defined as:
    --   FIELD when isField is true
    --   ROAD when isRoad is true OR depth < 0.1
    --   HARD for depth 0.1..0.8
    --   SOFT for depth > 0.8
    -- GIANTS derives isRoad from (contact ~= WHEEL_GROUND_CONTACT).
    local isField = rvWheelIsOnField(wheel)
    local isRoad = false
    if Wheels ~= nil and Wheels.WHEEL_GROUND_CONTACT ~= nil and contact ~= nil then
        isRoad = contact ~= Wheels.WHEEL_GROUND_CONTACT
    elseif Vehicle ~= nil and Vehicle.WHEEL_GROUND_CONTACT ~= nil and contact ~= nil then
        isRoad = contact ~= Vehicle.WHEEL_GROUND_CONTACT
    elseif WheelContactType ~= nil and WheelContactType.GROUND ~= nil and contact ~= nil then
        isRoad = contact ~= WheelContactType.GROUND
    end

    local groundDepth = nil
    if wheel.lastColor ~= nil and type(wheel.lastColor[4]) == "number" then
        groundDepth = wheel.lastColor[4]
    elseif p.getGroundAttributes ~= nil then
        local ok, _, _, _, depth = pcall(p.getGroundAttributes, p)
        if ok and type(depth) == "number" then
            groundDepth = depth
        end
    end
    groundDepth = safeNumber(groundDepth, 0)

    local groundType = nil
    if WheelsUtil ~= nil and WheelsUtil.getGroundType ~= nil then
        local okGround, value = pcall(WheelsUtil.getGroundType, isField, isRoad, groundDepth)
        if okGround then
            groundType = value
        end
    end

    -- Native wheel contact status is kept separate from isRoad/groundType.
    local hasGroundContact = false
    if p.hasGroundContact ~= nil then
        hasGroundContact = p.hasGroundContact == true
    elseif wheel.hasGroundContact ~= nil then
        hasGroundContact = wheel.hasGroundContact == true
    elseif Vehicle ~= nil and Vehicle.WHEEL_GROUND_CONTACT ~= nil then
        hasGroundContact = contact == Vehicle.WHEEL_GROUND_CONTACT
            or (Vehicle.WHEEL_GROUND_HEIGHT_CONTACT ~= nil and contact == Vehicle.WHEEL_GROUND_HEIGHT_CONTACT)
    end

    -- FS25 can report terrain/height contact as a numeric contact value (for
    -- example contact=4) instead of WHEEL_GROUND_CONTACT. If WheelsUtil has
    -- already resolved a valid terrain ground type and a contact exists, this
    -- is still real wheel-ground contact. This is essential for SOFT terrain
    -- and prevents slip/wear from being limited to ROAD/HARD.
    if not hasGroundContact and contact ~= nil and groundType ~= nil and WheelsUtil ~= nil then
        local validTerrain = groundType == WheelsUtil.GROUND_FIELD
            or groundType == WheelsUtil.GROUND_ROAD
            or groundType == WheelsUtil.GROUND_HARD_TERRAIN
            or groundType == WheelsUtil.GROUND_SOFT_TERRAIN
        if validTerrain then
            hasGroundContact = true
        end
    end

    -- Wetness: official GIANTS ground wetness is authoritative. Rainfall stays
    -- separate and is never substituted for a valid native 0.0.
    local wetScale = nil
    local rainScale = 0
    local timeSinceLastRain = nil
    local temperature = nil
    if g_currentMission ~= nil and g_currentMission.environment ~= nil then
        local weather = g_currentMission.environment.weather
        if weather ~= nil then
            if weather.getGroundWetness ~= nil then
                local okWet, value = pcall(weather.getGroundWetness, weather)
                if okWet and type(value) == "number" and value == value then
                    wetScale = math.clamp(value, 0, 1)
                end
            end
            if weather.getRainFallScale ~= nil then
                local okRain, value = pcall(weather.getRainFallScale, weather)
                if okRain and type(value) == "number" and value == value then
                    rainScale = math.clamp(value, 0, 1)
                end
            end
            if weather.getTimeSinceLastRain ~= nil then
                local okTime, value = pcall(weather.getTimeSinceLastRain, weather)
                if okTime and type(value) == "number" and value == value then
                    timeSinceLastRain = value
                end
            end
            if weather.getCurrentTemperature ~= nil then
                local okTemp, value = pcall(weather.getCurrentTemperature, weather)
                if okTemp and type(value) == "number" and value == value then
                    temperature = value
                end
            end
        end
    end

    local wetSource = "NATIVE_GROUND_WETNESS"
    if wetScale == nil then
        wetScale = rainScale
        wetSource = "RAIN_FALLBACK"
    end

    -- Native snow contact/scale. Lying snow is additionally verified against
    -- the terrainDetailHeight height-type used by the base game.
    local hasSnowContact = nil
    if wheel.hasSnowContact ~= nil then
        hasSnowContact = wheel.hasSnowContact == true
    elseif p.hasSnowContact ~= nil then
        hasSnowContact = p.hasSnowContact == true
    end

    local nativeSnowScale = nil
    if type(p.snowScale) == "number" then
        nativeSnowScale = math.clamp(p.snowScale, 0, 1)
    elseif type(wheel.snowScale) == "number" then
        nativeSnowScale = math.clamp(wheel.snowScale, 0, 1)
    elseif hasSnowContact ~= nil then
        nativeSnowScale = hasSnowContact and 1 or 0
    end
    nativeSnowScale = safeNumber(nativeSnowScale, 0)

    local ownSnow, snowfall, ownTemperature, snowHeight, ownSnowState, snowHeightMethod, globalSnowHeight = getOwnSnowEnvironment(wheel)
    if temperature == nil then
        temperature = ownTemperature
    end

    local terrainSnowIndex, terrainSnow, terrainTypeIndex, terrainDensity, terrainStates, terrainChannels, terrainSnowSamples, densityHeight, densityDelta, terrainHeight, heightTypeIndex, heightTypeName, contactSkin, snowMethod, nativeHeightTypeChannels, nativeHeightTypeCandidates, densityTypeIndex, densityStateBits, descriptorHeightTypeIndex = getTerrainSnowInfo(wheel)
    if terrainSnow == true then
        ownSnow = 1
        ownSnowState = "LYING"
        if snowHeight <= 0 then
            snowHeightMethod = "NATIVE_HEIGHT_TYPE"
        end
    end

    -- A true terrain "mud" state is not exposed by WheelsUtil as a separate
    -- ground type. Do not confuse the native tireType "mud" with muddy ground:
    -- GIANTS uses "mud" as a valid/default tire type for wheels. We derive MUD
    -- only from native SOFT terrain + native wetness. The 0.2 threshold is the
    -- same threshold GIANTS uses for wet ground particle state.
    local isMudTerrain = false
    if groundType ~= nil and WheelsUtil ~= nil and WheelsUtil.GROUND_SOFT_TERRAIN ~= nil then
        isMudTerrain = groundType == WheelsUtil.GROUND_SOFT_TERRAIN and wetScale > 0.2 and ownSnow < 0.5
    end

    -- Native GIANTS tire type and current native tire-ground friction.
    local nativeTireType = getTireName(wheel)
    local nativeTireFriction = nil
    if WheelsUtil ~= nil and WheelsUtil.getTireFriction ~= nil
        and wheel.tireType ~= nil and groundType ~= nil then
        local okFriction, value = pcall(
            WheelsUtil.getTireFriction,
            wheel.tireType,
            groundType,
            wetScale,
            nativeSnowScale
        )
        if okFriction and type(value) == "number" and value == value then
            nativeTireFriction = value
        end
    end

    return groundType, wetScale, ownSnow, contact, groundDepth, hasSnowContact, isField, isRoad, terrainSnowIndex, terrainSnow, terrainTypeIndex, terrainDensity, terrainStates, terrainChannels, terrainSnowSamples, densityHeight, densityDelta, terrainHeight, heightTypeIndex, heightTypeName, contactSkin, snowMethod, nativeSnowScale, snowfall, temperature, snowHeight, ownSnowState, snowHeightMethod, globalSnowHeight, nativeTireType, nativeTireFriction, hasGroundContact, isMudTerrain, rainScale, timeSinceLastRain, wetSource, nativeHeightTypeChannels, nativeHeightTypeCandidates, densityTypeIndex, densityStateBits, descriptorHeightTypeIndex
end
local function getWheelSlip(wheel, vehicle)
    if wheel == nil or wheel.physics == nil or wheel.node == nil or wheel.physics.wheelShape == nil then
        return nil
    end

    local ok, slip = pcall(getWheelShapeSlip, wheel.node, wheel.physics.wheelShape)
    if ok and type(slip) == "number" and math.abs(slip) < math.huge then
        return math.abs(slip) * 100
    end

    return nil
end

local function isWheelPhysicallyRotating(wheel)
    if wheel == nil or wheel.physics == nil or wheel.node == nil or wheel.physics.wheelShape == nil then
        return false
    end

    if getWheelShapeAxleSpeed == nil then
        return false
    end

    local ok, angular = pcall(getWheelShapeAxleSpeed, wheel.node, wheel.physics.wheelShape)
    if not ok or type(angular) ~= "number" or angular ~= angular or math.abs(angular) >= math.huge then
        return false
    end

    local radius = safeNumber(wheel.physics.radius, 0)
    return math.abs(angular) * math.max(radius, 0) > 0.05
end


local function getWheelLoad(wheel)
    if wheel == nil or wheel.physics == nil or wheel.physics.getTireLoad == nil then
        return nil
    end

    local ok, load = pcall(wheel.physics.getTireLoad, wheel.physics)
    if ok and type(load) == "number" and math.abs(load) < math.huge then
        return load
    end

    return nil
end

local function getWheelDiameter(wheel)
    if wheel == nil or wheel.physics == nil then
        return nil
    end
    local radius = safeNumber(wheel.physics.radius, nil)
    if radius == nil then
        return nil
    end
    return radius * 2
end

local function getWheelWidth(wheel)
    if wheel == nil or wheel.physics == nil then
        return nil
    end

    local width = safeNumber(wheel.physics.width, nil)
    if width ~= nil and width > 0 then
        return width
    end

    width = safeNumber(wheel.physics.wheelShapeWidth, nil)
    if width ~= nil and width > 0 then
        return width
    end

    return nil
end

local function getWheelRestLoad(wheel)
    if wheel == nil or wheel.physics == nil then
        return nil
    end

    local restLoad = safeNumber(wheel.physics.restLoad, nil)
    if restLoad ~= nil and restLoad > 0 then
        return restLoad
    end

    return nil
end

local function getWheelPhysicalFactors(load, width, radius)
    local loadT = math.max(0.01, safeNumber(load, RV.PHYSICS_REFERENCE_LOAD_T))
    local widthM = math.max(0.01, safeNumber(width, RV.PHYSICS_REFERENCE_WIDTH_M))
    local radiusM = math.max(0.05, safeNumber(radius, RV.PHYSICS_REFERENCE_RADIUS_M))

    -- Neutral reference: 2.5 t tire load, 600 mm width, 750 mm radius.
    -- Load is sub-linear; narrower tires carry the same load over a smaller
    -- footprint; smaller radius means slightly more tread stress per distance.
    local loadFactor = math.pow(loadT / RV.PHYSICS_REFERENCE_LOAD_T, RV.PHYSICS_LOAD_EXPONENT)
    local widthFactor = math.pow(RV.PHYSICS_REFERENCE_WIDTH_M / widthM, RV.PHYSICS_WIDTH_EXPONENT)
    local radiusFactor = math.pow(RV.PHYSICS_REFERENCE_RADIUS_M / radiusM, RV.PHYSICS_RADIUS_EXPONENT)

    return loadFactor, widthFactor, radiusFactor, loadFactor * widthFactor * radiusFactor
end

local function getVehicleSpeedKmh(vehicle)
    if vehicle == nil then
        return 0
    end

    -- lastSpeedReal is the normal physics source. When an external AI driver
    -- owns the vehicle after the player leaves it, some AI/control paths can
    -- temporarily expose no useful lastSpeedReal value to a mod update.
    -- GIANTS' getLastSpeed() is the public kph accessor and remains valid for
    -- AI-controlled vehicles. Manual driving therefore keeps the exact same
    -- primary path; the fallback is only used when lastSpeedReal is zero.
    local speedReal = math.abs(safeNumber(vehicle.lastSpeedReal, 0))
    if speedReal > 0.000001 then
        return speedReal * 1000 * 3.6
    end

    if vehicle.getLastSpeed ~= nil then
        local ok, speedKmh = pcall(vehicle.getLastSpeed, vehicle, false)
        if ok and type(speedKmh) == "number" then
            return math.abs(speedKmh)
        end
    end

    return 0
end

local function getVehicleMotionDistanceM(vehicle, dtSec)
    if vehicle == nil then
        return 0
    end

    local lastMovedDistance = math.abs(safeNumber(vehicle.lastMovedDistance, 0))
    if lastMovedDistance > 0.000001 then
        return lastMovedDistance
    end

    return math.abs(safeNumber(vehicle.lastSpeedReal, 0)) * 1000 * dtSec
end

local function getVehicleIsAIActive(vehicle)
    if vehicle == nil then
        return false
    end

    -- Prefer GIANTS' own AI state when exposed by the runtime.
    if vehicle.getIsAIActive ~= nil then
        local ok, active = pcall(vehicle.getIsAIActive, vehicle)
        if ok and active == true then
            return true
        end
    end

    -- Generic fallback for vehicle types exposing the AI specialization state.
    local spec = vehicle.spec_aiVehicle
    if spec ~= nil then
        if spec.isActive == true or spec.active == true or spec.isRunning == true then
            return true
        end
    end

    return false
end

local function getPlayerFarmId()
    local mission = g_currentMission
    if mission == nil or mission.getFarmId == nil then
        return nil
    end

    local ok, farmId = pcall(mission.getFarmId, mission)
    if ok and type(farmId) == "number" and farmId ~= FarmManager.SPECTATOR_FARM_ID then
        return farmId
    end

    return nil
end

local function getVehiclePropertyStateSafe(vehicle)
    if vehicle == nil then return nil end
    if vehicle.getPropertyState ~= nil then
        local ok, value = pcall(vehicle.getPropertyState, vehicle)
        if ok then return value end
    end
    return vehicle.propertyState
end

local function getVehicleOwnerFarmIdSafe(vehicle)
    if vehicle == nil then return nil end
    if vehicle.getOwnerFarmId ~= nil then
        local ok, value = pcall(vehicle.getOwnerFarmId, vehicle)
        if ok and type(value) == "number" then return value end
    end
    if type(vehicle.ownerFarmId) == "number" then
        return vehicle.ownerFarmId
    end
    return nil
end

local function isMissionVehicleState(vehicle, propertyState)
    if VehiclePropertyState ~= nil and VehiclePropertyState.MISSION ~= nil
        and propertyState == VehiclePropertyState.MISSION then
        return true
    end
    -- GIANTS writes activeMissionId for mission-bound vehicles. Keep this as
    -- a second, explicit guard so a mission vehicle can never enter OWN-WEAR
    -- even when a mod temporarily exposes an unexpected property state.
    return vehicle ~= nil and vehicle.activeMissionId ~= nil
end

local function hasMissionVehicleInAttacherChain(vehicle)
    if vehicle == nil then return false end
    local current = vehicle
    local visited = {}
    for _ = 1, 16 do
        if current == nil or visited[current] then break end
        visited[current] = true
        local propertyState = getVehiclePropertyStateSafe(current)
        if isMissionVehicleState(current, propertyState) then
            return true
        end
        if type(current.getAttacherVehicle) ~= "function" then break end
        local ok, parent = pcall(current.getAttacherVehicle, current)
        if not ok or parent == nil then break end
        current = parent
    end
    return false
end

local function isRelevantPlayerVehicle(vehicle)
    if vehicle == nil or rvIsExplicitlyExcludedVehicle(vehicle) then
        return false
    end

    local playerFarmId = getPlayerFarmId()
    if playerFarmId == nil then
        return false
    end

    local ownerFarmId = getVehicleOwnerFarmIdSafe(vehicle)
    if ownerFarmId == nil or ownerFarmId ~= playerFarmId then
        return false
    end

    local propertyState = getVehiclePropertyStateSafe(vehicle)
    if isMissionVehicleState(vehicle, propertyState) then
        return false
    end

    -- TEST2.3.136: mission-provided trailers/implements can expose OWNED/LEASED
    -- and the player's farm id even though their towing root is mission-bound.
    -- Walk the attacher chain and fail closed when any parent/root belongs to
    -- an active mission. This fixes mission trailers accumulating DIST/SLIP/TIME.
    if hasMissionVehicleInAttacherChain(vehicle) then
        return false
    end

    -- Runtime OWN-WEAR is restricted to the current player's farm. GIANTS'
    -- normal shop flow uses OWNED for purchases and LEASED for leased/rented
    -- farm vehicles. Unknown states are not accepted here: fail closed rather
    -- than accidentally evaluating map/shop/foreign objects.
    if VehiclePropertyState ~= nil then
        local owned = VehiclePropertyState.OWNED
        local leased = VehiclePropertyState.LEASED
        if propertyState ~= owned and propertyState ~= leased then
            return false
        end
    end

    return true
end

-- TEST0.2.2.28: explicit AI/driver-assistance recognition.
-- Courseplay and AutoDrive control player-owned vehicles; their wear must use
-- the exact same movement/wear calculation as manual driving. This helper only
-- identifies the active driver source. It does not change the wear formula.
local function getAutomatedDriverSource(vehicle)
    if vehicle == nil then
        return nil
    end

    -- Courseplay exposes getIsCpActive() on its root vehicle.
    local root = vehicle.getRootVehicle ~= nil and vehicle:getRootVehicle() or vehicle
    if root ~= nil and root.getIsCpActive ~= nil then
        local ok, active = pcall(root.getIsCpActive, root)
        if ok and active == true then
            return "COURSEPLAY"
        end
    end

    -- AutoDrive keeps its active state in vehicle.ad.stateModule.
    if root ~= nil and root.ad ~= nil and root.ad.stateModule ~= nil
            and root.ad.stateModule.isActive ~= nil then
        local ok, active = pcall(root.ad.stateModule.isActive, root.ad.stateModule)
        if ok and active == true then
            return "AUTODRIVE"
        end
    end

    -- GIANTS helper / AI worker.
    if root ~= nil and root.getIsAIActive ~= nil then
        local ok, active = pcall(root.getIsAIActive, root)
        if ok and active == true then
            return "GIANTS_AI"
        end
    end

    return nil
end

local function getIsMotorizedObject(vehicle)
    if vehicle == nil or vehicle.getIsMotorized == nil then
        return false
    end
    local ok, motorized = pcall(vehicle.getIsMotorized, vehicle)
    return ok and motorized == true
end

local function getAttacherVehicleSafe(vehicle)
    if vehicle == nil or vehicle.getAttacherVehicle == nil then
        return nil
    end
    local ok, parent = pcall(vehicle.getAttacherVehicle, vehicle)
    if ok then
        return parent
    end
    return nil
end

-- Resolve the moving motorized root for an attached trailer/implement. This is
-- only a motion reference; the wear state and wheel manifest remain attached
-- to the trailer/implement object itself.
local function getMotorizedMotionRoot(vehicle)
    local current = vehicle
    local visited = {}
    for _ = 1, 16 do
        if current == nil or visited[current] then
            return nil
        end
        visited[current] = true
        if getIsMotorizedObject(current) then
            return current
        end
        current = getAttacherVehicleSafe(current)
    end
    return nil
end

local function refreshOwnedMotorizedVehicleCache(now)
    if now - lastVehicleScanTime < RV.VEHICLE_SCAN_INTERVAL_MS then
        return
    end

    lastVehicleScanTime = now
    table.clear(ownedMotorizedVehicleCache)
    table.clear(ownedAttachedImplementCache)

    local mission = g_currentMission
    if mission == nil or mission.vehicles == nil then
        return
    end

    -- Ownership is the first broad filter. Motorized objects enter the existing
    -- vehicle path. Non-motorized objects are considered only when they are
    -- actually attached to a moving motorized root and have a wheel manifest.
    for _, vehicle in pairs(mission.vehicles) do
        if isRelevantPlayerVehicle(vehicle) then
            if getIsMotorizedObject(vehicle) then
                ownedMotorizedVehicleCache[#ownedMotorizedVehicleCache + 1] = vehicle
            else
                local parent = getAttacherVehicleSafe(vehicle)
                local root = getMotorizedMotionRoot(vehicle)
                if parent ~= nil and root ~= nil then
                    ownedAttachedImplementCache[#ownedAttachedImplementCache + 1] = vehicle
                end
            end
        end
    end
end

local function getMovingMissionVehicles()
    local result = {}
    local now = g_currentMission ~= nil and safeNumber(g_currentMission.time, 0) or 0
    refreshOwnedMotorizedVehicleCache(now)

    for _, vehicle in ipairs(ownedMotorizedVehicleCache) do
        local speedKmh = getVehicleSpeedKmh(vehicle)
        local aiSource = getAutomatedDriverSource(vehicle)

        -- TEST0.2.2.78: activity is tracked per vehicle, not per
        -- currentVehicle. Once a player-owned vehicle has entered the wear
        -- processing set because it is moving, player-controlled, or driven
        -- by AD/CP/GIANTS-AI, changing to another vehicle must not remove it.
        if aiSource ~= nil then
            aiTrackedVehicles[vehicle] = aiSource
            activeWearVehicles[vehicle] = true
        elseif speedKmh > 0.05 or vehicle == RV.currentVehicle then
            activeWearVehicles[vehicle] = true
        elseif speedKmh <= 0.05 and vehicle ~= RV.currentVehicle then
            -- No driver, no movement, no current player control: this vehicle
            -- no longer needs a live wear update. Its persistent wear state
            -- remains in vehicleWearStates.
            aiTrackedVehicles[vehicle] = nil
            activeWearVehicles[vehicle] = nil
        end

        if activeWearVehicles[vehicle] == true then
            result[#result + 1] = vehicle
        end
    end

    return result
end

local function getMovingAttachedImplements()
    local result = {}
    for _, implement in ipairs(ownedAttachedImplementCache) do
        local root = getMotorizedMotionRoot(implement)
        if root ~= nil then
            local speedKmh = getVehicleSpeedKmh(root)
            if speedKmh > 0.05 then
                result[#result + 1] = {object = implement, root = root, speedKmh = speedKmh}
            end
        end
    end
    return result
end

RV.getMovingAttachedImplements = getMovingAttachedImplements

-- TEST0.2.2.21: HUD recognition must not depend on movement.
-- Wear processing still uses getMovingAttachedImplements(); this display path
-- lists currently attached objects even while the combination is stationary.
local function getAttachedImplementsForDisplay(vehicleOverride)
    local result = {}
    local seen = {}
    local function addObject(object, root)
        if object == nil or seen[object] then return end
        if object == RV.currentVehicle then return end
        local parent = getAttacherVehicleSafe(object)
        local motionRoot = root or getMotorizedMotionRoot(object)
        if parent == nil and motionRoot == nil then return end
        seen[object] = true
        local speedKmh = motionRoot ~= nil and getVehicleSpeedKmh(motionRoot) or 0
        result[#result + 1] = {object = object, root = motionRoot, speedKmh = speedKmh}
    end

    -- Primary source: the currently controlled vehicle's native attachment list.
    local current = vehicleOverride or RV.currentVehicle
    if current ~= nil and current.getAttachedImplements ~= nil then
        local ok, list = pcall(current.getAttachedImplements, current)
        if ok and type(list) == "table" then
            for _, item in pairs(list) do
                local object = item
                if type(item) == "table" then
                    object = item.object or item.implement or item.vehicle or item.attachedVehicle
                end
                addObject(object, current)
            end
        end
    end

    -- Fallback: already maintained attached-object cache. Unlike the movement
    -- function, this deliberately does not require root speed > 0.05 km/h.
    refreshOwnedMotorizedVehicleCache(g_currentMission ~= nil and safeNumber(g_currentMission.time, 0) or 0)
    for _, object in ipairs(ownedAttachedImplementCache) do
        addObject(object, getMotorizedMotionRoot(object))
    end

    return result
end
RV.getAttachedImplementsForDisplay = getAttachedImplementsForDisplay

-- Public authoritative read bridge for the HUD. The HUD must pass the exact
-- vehicle it is displaying; never substitute RV.currentVehicle here.
function RV:getOwnWearPercentForHUD(vehicle)
    if vehicle == nil then return nil end
    if type(self.getVehicleWearPercent) == "function" then
        local ok, value = pcall(self.getVehicleWearPercent, vehicle)
        if ok and type(value) == "number" then
            return math.max(0, math.min(100, value))
        end
    end
    return nil
end


local function getVehicleMass(vehicle)
    if vehicle == nil then
        return nil
    end

    if vehicle.getTotalMass ~= nil then
        -- Same first mass query as EnhancedVehicle HUD:
        -- self.vehicle:getTotalMass(true)
        local ok, mass = pcall(vehicle.getTotalMass, vehicle, true)
        if ok and type(mass) == "number" then
            return mass
        end
    end

    if vehicle.getMass ~= nil then
        local ok, mass = pcall(vehicle.getMass, vehicle)
        if ok and type(mass) == "number" then
            return mass
        end
    end

    return nil
end

local function buildManifest(vehicle)
    local manifest = {
        wheels = {},
        wheelUnits = {},
        crawlers = {},
        axleUnits = {},
        totalWheelCount = 0,
        normalWheelCount = 0,
        crawlerWheelCount = 0,
        axleCount = 0,
        crawlerCount = 0
    }

    if vehicle == nil or vehicle.spec_wheels == nil or vehicle.spec_wheels.wheels == nil then
        return manifest
    end

    local allWheels = vehicle.spec_wheels.wheels
    local assignedCrawler = {}

    -- ================================================================
    -- Phase 1: resolve Crawler objects first.
    -- This is the same structural principle as the proven HUD:
    -- Crawler wheels are removed from the normal wheel pool.
    -- ================================================================
    if vehicle.spec_crawlers ~= nil and vehicle.spec_crawlers.crawlers ~= nil then
        for crawlerIndex, crawler in ipairs(vehicle.spec_crawlers.crawlers) do
            local members = getCrawlerMembers(vehicle, crawler, allWheels)
            local x, y, z = getCrawlerLocalPosition(vehicle, crawler)
            -- TEST0.1.0.52: resolve crawler type defensively inline.
            -- The previous diagnostic build could fail here in the live runtime
            -- although the helper existed in source. Do not let the temporary
            -- load test depend on that optional classifier.
            local crawlerType, typeSource = "RUBBER_TRACK", "GENERIC_CRAWLER_DEFAULT"
            local vehicleName = string.lower(tostring(vehicle.configFileName or vehicle.xmlFileName or vehicle.typeName or ""))
            if string.find(vehicleName, "leitwolf", 1, true) ~= nil then
                crawlerType, typeSource = "CRAWLER_STEEL", "SPECIAL_LEITWOLF"
            end

            local unit = {
                index = crawlerIndex,
                side = crawler.isLeft == true and "LEFT" or "RIGHT",
                crawler = crawler,
                wheels = members,
                wheelCount = #members,
                x = x,
                y = y,
                z = z,
                type = crawlerType,
                typeSource = typeSource,
                movedDistance = safeNumber(crawler.movedDistance, 0)
            }

            for _, wheel in ipairs(members) do
                assignedCrawler[wheel] = true
                if wheel.wheelIndex ~= nil then
                    assignedCrawler[wheel.wheelIndex] = true
                end
            end

            manifest.crawlers[#manifest.crawlers + 1] = unit
        end
    end

    -- Phase 2: normal wheels only.
    local normalEntries = {}
    for index, wheel in pairs(allWheels) do
        local isCrawler = assignedCrawler[wheel] or assignedCrawler[index]
        if not isCrawler and wheel ~= nil and wheel.wheelIndex ~= nil then
            isCrawler = assignedCrawler[wheel.wheelIndex]
        end

        if not isCrawler and isCrawlerTire(wheel) then
            isCrawler = true
        end

        if not isCrawler and wheel ~= nil and wheel.repr ~= nil then
            local _, _, z = getWheelLocalPosition(vehicle, wheel)
            if z ~= nil then
                normalEntries[#normalEntries + 1] = {
                    wheel = wheel,
                    index = index,
                    z = z
                }
            end
        end
    end

    table.sort(normalEntries, function(a, b)
        return (a.z or 0) > (b.z or 0)
    end)

    -- First use explicit GIANTS WheelAxle links.
    local normalByObject = {}
    for _, entry in ipairs(normalEntries) do
        normalByObject[entry.wheel] = entry
    end

    local consumed = {}
    local wheelAxles = vehicle.wheelAxles
    if wheelAxles == nil and vehicle.spec_wheels ~= nil then
        wheelAxles = vehicle.spec_wheels.wheelAxles
    end

    if wheelAxles ~= nil then
        for _, axle in pairs(wheelAxles) do
            local w1, w2 = axle.wheel1, axle.wheel2
            local e1, e2 = normalByObject[w1], normalByObject[w2]

            if e1 ~= nil and e2 ~= nil then
                local unit = {
                    index = #manifest.wheelUnits + 1,
                    kind = "WHEEL_AXLE",
                    wheels = {w1, w2},
                    z = ((e1.z or 0) + (e2.z or 0)) * 0.5
                }

                manifest.wheelUnits[#manifest.wheelUnits + 1] = unit
                consumed[e1] = true
                consumed[e2] = true
            end
        end
    end

    -- Remaining wheels are grouped by longitudinal position using the same
    -- wheel-size-derived tolerance principle as the proven HUD.
    local remaining = {}
    for _, entry in ipairs(normalEntries) do
        if not consumed[entry] then
            remaining[#remaining + 1] = entry
        end
    end

    for _, entry in ipairs(remaining) do
        local wheel = entry.wheel
        local radius = wheel.physics ~= nil and safeNumber(wheel.physics.radius, 0.4) or 0.4

        local best = nil
        local bestDistance = math.huge

        for _, unit in ipairs(manifest.wheelUnits) do
            if unit.kind == "WHEEL_PLANE" then
                local distance = math.abs((unit.z or 0) - entry.z)
                local meanRadius = unit.meanRadius or radius
                local tolerance = math.max(0.08, 0.25 * ((meanRadius + radius) * 0.5))

                if distance <= tolerance and distance < bestDistance then
                    best = unit
                    bestDistance = distance
                end
            end
        end

        if best == nil then
            best = {
                index = #manifest.wheelUnits + 1,
                kind = "WHEEL_PLANE",
                wheels = {},
                z = entry.z,
                meanRadius = radius
            }
            manifest.wheelUnits[#manifest.wheelUnits + 1] = best
        end

        best.wheels[#best.wheels + 1] = wheel
        local count = #best.wheels
        best.z = best.z + ((entry.z - best.z) / count)
        best.meanRadius = best.meanRadius + ((radius - best.meanRadius) / count)
    end

    table.sort(manifest.wheelUnits, function(a, b)
        return (a.z or 0) > (b.z or 0)
    end)

    -- Normalize axle indices after sorting.
    for index, unit in ipairs(manifest.wheelUnits) do
        unit.index = index
    end

    -- Build a complete physical unit list for diagnostics.
    for _, unit in ipairs(manifest.wheelUnits) do
        for _, wheel in ipairs(unit.wheels) do
            manifest.wheels[#manifest.wheels + 1] = wheel
        end
    end

    for _, crawler in ipairs(manifest.crawlers) do
        for _, wheel in ipairs(crawler.wheels) do
            manifest.wheels[#manifest.wheels + 1] = wheel
        end
    end

    manifest.totalWheelCount = #manifest.wheels
    manifest.normalWheelCount = #manifest.wheels - 0

    for _, crawler in ipairs(manifest.crawlers) do
        manifest.crawlerWheelCount = manifest.crawlerWheelCount + #crawler.wheels
    end

    manifest.normalWheelCount = manifest.totalWheelCount - manifest.crawlerWheelCount
    manifest.crawlerCount = #manifest.crawlers
    manifest.axleCount = #manifest.wheelUnits

    -- A simple normalized axle list used only for diagnostics.
    for _, unit in ipairs(manifest.wheelUnits) do
        manifest.axleUnits[#manifest.axleUnits + 1] = unit
    end

    -- Assign one stable structural chassis type to the complete running gear.
    -- The first sighting creates a new type automatically; later vehicles with
    -- the identical structural signature reuse the same type.
    local chassisTypeId, chassisTypeEntry = rvRegisterChassisType(vehicle, manifest)
    manifest.chassisTypeId = chassisTypeId
    manifest.chassisType = chassisTypeEntry

    for _, crawlerUnit in ipairs(manifest.crawlers) do
        crawlerUnit.chassisTypeId = chassisTypeId
        crawlerUnit.chassisType = chassisTypeEntry
    end

    return manifest
end

local function getOrBuildManifest(vehicle)
    local cached = manifestCache[vehicle]
    if cached ~= nil then
        return cached
    end

    local ok, manifest = pcall(buildManifest, vehicle)
    if not ok or manifest == nil then
        return nil
    end
    manifestCache[vehicle] = manifest
    return manifest
end

-- ============================================================================
-- REIFENVERSCHLEISS-ERKENNUNG
-- Independent from the chassis/axis/slip recognition. Crawler wheels are
-- physical reference wheels for the chassis/slip path, but are NOT tire-wear
-- objects. A crawler itself is one wear object (the actual band).
-- ============================================================================
local function buildTireWearManifest(vehicle)
    local result = {wheels = {}, tracks = {}, wheelCount = 0, trackCount = 0, totalWearObjectCount = 0}
    if vehicle == nil or vehicle.spec_wheels == nil or vehicle.spec_wheels.wheels == nil then
        return result
    end

    local vehicleName = string.lower(tostring(vehicle.configFileName or vehicle.xmlFileName or vehicle.typeName or ""))
    local isHoverWearSpecial = string.find(vehicleName, "jacto_hover_500", 1, true) ~= nil
        or string.find(vehicleName, "hover_500", 1, true) ~= nil
        or string.find(vehicleName, "hover500", 1, true) ~= nil

    local allWheels = vehicle.spec_wheels.wheels
    local crawlerAssigned = {}

    if vehicle.spec_crawlers ~= nil and vehicle.spec_crawlers.crawlers ~= nil then
        for crawlerIndex, crawler in ipairs(vehicle.spec_crawlers.crawlers) do
            local members = getCrawlerMembers(vehicle, crawler, allWheels)
            for _, wheel in ipairs(members) do
                crawlerAssigned[wheel] = true
                if wheel.wheelIndex ~= nil then crawlerAssigned[wheel.wheelIndex] = true end
            end
            local x, y, z = getCrawlerLocalPosition(vehicle, crawler)
            local side = crawler.isLeft == true and "LEFT" or "RIGHT"
            local signature = rvMakeCrawlerSignature(vehicle, crawler, members)
            local crawlerType = classifyCrawler(vehicle, crawler)
            local wearRunningGearType = crawlerType == "CRAWLER_STEEL" and "STEEL_TRACK" or "RUBBER_TRACK"
            result.tracks[#result.tracks + 1] = {
                index = crawlerIndex, side = side, crawler = crawler,
                referenceWheels = members, wheelCount = #members,
                wearRunningGearType = wearRunningGearType,
                leitwolfRollerFallback = string.find(vehicleName, "leitwolf", 1, true) ~= nil,
                x = x, y = y, z = z, signature = signature,
                key = string.format("TRACK|%s|%s", side, signature)
            }
        end
    end

    local hoverSkippedHelperWheels = 0
    for _, wheel in pairs(allWheels) do
        local isCrawler = crawlerAssigned[wheel] or (wheel ~= nil and crawlerAssigned[wheel.wheelIndex])
        if not isCrawler and wheel ~= nil and wheel.wheelIndex ~= nil and not isCrawlerTire(wheel) then
            -- TEST2.3.112 Hover special path: the mod exposes five tiny 0.085 m
            -- technical/helper wheels (W5-W9). They never represent the visible
            -- crawler tyre/track and diluted the vehicle OWN-WEAR average to ~30%
            -- although both actual crawler tracks were already at 100%. For Hover
            -- only, the two crawler tracks are therefore the authoritative wear objects.
            if isHoverWearSpecial then
                hoverSkippedHelperWheels = hoverSkippedHelperWheels + 1
            else
                result.wheels[#result.wheels + 1] = wheel
            end
        end
    end
    table.sort(result.wheels, function(a,b) return (a.wheelIndex or 0) < (b.wheelIndex or 0) end)
    table.sort(result.tracks, function(a,b) return (a.index or 0) < (b.index or 0) end)
    result.wheelCount = #result.wheels
    result.trackCount = #result.tracks
    result.totalWearObjectCount = result.wheelCount + result.trackCount
    return result
end

local function getOrBuildTireWearManifest(vehicle)
    local manifest = getOrBuildManifest(vehicle)
    if manifest.tireWearManifest == nil then
        manifest.tireWearManifest = buildTireWearManifest(vehicle)
        for _, track in ipairs(manifest.tireWearManifest.tracks) do
        end
    end
    return manifest.tireWearManifest
end

local getDiagnosticSlip

local function primitiveValue(v)
    local t = type(v)
    if t == "string" or t == "number" or t == "boolean" then
        return tostring(v)
    end
    if v == nil then
        return "nil"
    end
    return "<" .. t .. ">"
end

local function wheelDiagnostic(wheel, vehicle)
    local groundType, wetScale, snowScale, contact, groundDepth, hasSnowContact, isField, isRoad, terrainSnowIndex, terrainSnow, terrainTypeIndex, terrainDensity, terrainStates, terrainChannels, terrainSnowSamples, densityHeight, densityDelta, terrainHeight, heightTypeIndex, heightTypeName, contactSkin, snowMethod, nativeSnowScale, snowfall, temperature, snowHeight, ownSnowState, snowHeightMethod, globalSnowHeight, nativeTireType, nativeTireFriction, hasGroundContact, isMudTerrain, rainScale, timeSinceLastRain, wetSource, nativeHeightTypeChannels, nativeHeightTypeCandidates, densityTypeIndex, densityStateBits, descriptorHeightTypeIndex = getWheelGroundInfo(wheel)
    local load = getWheelLoad(wheel)
    local rawSlip = getWheelSlip(wheel, vehicle)
    local vehicleState = getVehicleWearState(vehicle)
    local slip, wheelRotation, slipStartupBlocked = getDiagnosticSlip(vehicle, wheel, vehicleState, hasGroundContact)
    local width = getWheelWidth(wheel)
    local restLoad = getWheelRestLoad(wheel)
    local radius = wheel.physics ~= nil and safeNumber(wheel.physics.radius, nil) or nil
    local loadFactor, widthFactor, radiusFactor, physicalFactor = getWheelPhysicalFactors(load, width, radius)

    local x, y, z = getWheelLocalPosition(vehicle, wheel)

    return {
        index = wheel.wheelIndex,
        driveMode = wheel.driveMode,
        wheelAxle = wheel.wheelAxle,
        isMotorized = wheel.isMotorized,
        tire = getTireName(wheel),
        nativeTireType = nativeTireType,
        nativeTireFriction = nativeTireFriction,
        crawler = isCrawlerTire(wheel),
        wearRunningGearType = getWheelWearRunningGearType(wheel),
        driven = getTractionWheels(vehicle)[wheel.wheelIndex] == true,
        load = load,
        restLoad = restLoad,
        slip = slip,
        rawSlip = rawSlip,
        wheelRotation = wheelRotation,
        slipStartupBlocked = slipStartupBlocked,
        width = width,
        loadFactor = loadFactor,
        widthFactor = widthFactor,
        radiusFactor = radiusFactor,
        physicalFactor = physicalFactor,
        contact = contact,
        hasGroundContact = hasGroundContact,
        groundType = groundType,
        isMudTerrain = isMudTerrain,
        wetScale = wetScale,
        rainScale = rainScale,
        timeSinceLastRain = timeSinceLastRain,
        wetSource = wetSource,
        snowScale = snowScale,
        nativeSnowScale = nativeSnowScale,
        snowfall = snowfall,
        snowTemperature = temperature,
        snowHeight = snowHeight,
        ownSnowState = ownSnowState,
        snowHeightMethod = snowHeightMethod,
        globalSnowHeight = globalSnowHeight,
        snowProfile = profileName,
        ownSnowSlipFactor = ownSnowSlipFactor,
        ownSnowGripFactor = ownSnowGripFactor,
        ownSnowWearFactor = ownSnowWearFactor,
        groundDepth = groundDepth,
        hasSnowContact = hasSnowContact,
        isField = isField,
        isRoad = isRoad,
        terrainSnowIndex = terrainSnowIndex,
        terrainSnow = terrainSnow,
        terrainTypeIndex = terrainTypeIndex,
        terrainDensity = terrainDensity,
        terrainStates = terrainStates,
        terrainChannels = terrainChannels,
        terrainSnowSamples = terrainSnowSamples,
        densityHeight = densityHeight,
        densityDelta = densityDelta,
        terrainHeight = terrainHeight,
        heightTypeIndex = heightTypeIndex,
        heightTypeName = heightTypeName,
        nativeHeightTypeChannels = nativeHeightTypeChannels,
        nativeHeightTypeCandidates = nativeHeightTypeCandidates,
        densityTypeIndex = densityTypeIndex,
        densityStateBits = densityStateBits,
        descriptorHeightTypeIndex = descriptorHeightTypeIndex,
        contactSkin = contactSkin,
        snowMethod = snowMethod,
        radius = radius,
        diameter = getWheelDiameter(wheel),
        x = x,
        y = y,
        z = z
    }
end

local function groundName(value)
    if value == nil then return "?" end
    if WheelsUtil ~= nil then
        if value == WheelsUtil.GROUND_ROAD then return "ROAD" end
        if value == WheelsUtil.GROUND_FIELD then return "FIELD" end
        if value == WheelsUtil.GROUND_HARD_TERRAIN then return "HARD" end
        if value == WheelsUtil.GROUND_SOFT_TERRAIN then return "SOFT" end
    end
    return tostring(value)
end

local function contactName(value)
    if value == nil then return "?" end

    if Vehicle ~= nil then
        if value == Vehicle.WHEEL_NO_CONTACT then return "NONE" end
        if value == Vehicle.WHEEL_GROUND_CONTACT then return "GROUND" end
        if value == Vehicle.WHEEL_GROUND_HEIGHT_CONTACT then return "GROUND_HEIGHT" end
        if value == Vehicle.WHEEL_OBJ_CONTACT then return "OBJECT" end
    end

    if WheelContactType ~= nil then
        if WheelContactType.NONE ~= nil and value == WheelContactType.NONE then return "NONE" end
        if WheelContactType.GROUND ~= nil and value == WheelContactType.GROUND then return "GROUND" end
        if WheelContactType.OBJECT ~= nil and value == WheelContactType.OBJECT then return "OBJECT" end
    end

    return tostring(value)
end


-- ============================================================================
-- REALISTIC WEAR MODEL
-- ============================================================================
-- REALISTIC WEAR MODEL
--
-- The model deliberately keeps the two requested wear channels independent:
--
--   DISTANCE WEAR = driven distance + wheel load + ground + wetness/weather
--   SLIP WEAR     = slip distance + wheel load + ground + wetness/weather
--
-- No global "vehicle mass -> wear" multiplier is used. Attached mass therefore
-- influences the tire only through the actual dynamic wheel load measured by
-- GIANTS. This prevents double counting the trailer/implement mass.
--
-- The numerical coefficients below are conservative model coefficients, not
-- claimed laboratory constants. They are kept in one place so they can be
-- calibrated against the collected FS25 test logs without changing the data
-- pipeline.
-- ============================================================================
RV.WEAR_REFERENCE_DISTANCE_M = 100000       -- 100 km = 1.0 base wear; price reference is separate
RV.WEAR_MAX = 1
RV.WEAR_LOAD_EXPONENT = 1.25
RV.WEAR_LOAD_MIN_FACTOR = 0.50
RV.WEAR_LOAD_MAX_FACTOR = 3.00
RV.WEAR_SLIP_REFERENCE = 0.10               -- 10 % slip
RV.WEAR_SLIP_EXPONENT = 1.50
RV.WEAR_SLIP_COEFFICIENT = 0.20
RV.WEAR_SLIP_MIN_PERCENT = 1.0
RV.WEAR_SLIP_MAX_PERCENT = 100.0

-- TEST2.3.136: movement-time wear, calibrated at the agreed 1000 km reference.
-- TIME-WEAR is field-only: road and generic off-road/hard/soft terrain never
-- receive TIME-WEAR. Confirmed movement on a real field adds 7.5 points/hour.
-- After 30 seconds of confirmed active field movement, <=50 m (<=6 km/h avg)
-- raises TIME-WEAR smoothly up to 20 points/hour at 2 km/h. A non-tractor
-- carrier with an active front harvest attachment receives +5 points/hour.
RV.TIME_WEAR_MIN_SPEED_KMH = 2.0
RV.TIME_WEAR_CONFIRM_SEC = 2.0
RV.TIME_WEAR_WINDOW_SEC = 30.0
RV.TIME_WEAR_WINDOW_DISTANCE_M = 50.0
RV.TIME_WEAR_LOW_POINTS_PER_H_AT_1000 = 7.5
RV.TIME_WEAR_SLOW_MAX_POINTS_PER_H_AT_1000 = 20.0
RV.TIME_WEAR_HARVEST_BONUS_POINTS_PER_H_AT_1000 = 5.0
RV.TIME_WEAR_REFERENCE_KM = 1000.0


-- Longitudinal FORCE-WEAR, promoted from the validated development branch.
RV.FORCE_WEAR_MAX_RATE = 0.35
RV.FORCE_WEAR_RESPONSE_EXPONENT = 2.0
RV.FORCE_WEAR_LOAD_DEFORMATION_GAIN = 0.25
RV.FORCE_WEAR_LOAD_DEFORMATION_RANGE = 0.60
RV.FORCE_SLIP_FULL_FORCE_UNTIL_PERCENT = 20.0
RV.FORCE_SLIP_MIN_FORCE_AT_100_PERCENT = 0.20
RV.FORCE_SLIP_COUPLING_EXPONENT = 0.55
RV.FORCE_WEAR_PEAK_SLIP_SAMPLES = {0.05, 0.10, 0.15, 0.20, 0.30, 0.40, 0.60, 1.00}
RV.FORCE_DYNAMIC_ACTIVE_INTERVAL_MS = 50
RV.FORCE_DYNAMIC_IDLE_INTERVAL_MS = 250
RV.FORCE_DYNAMIC_MIN_DRIVE_DEMAND = 0.02
RV.FORCE_DYNAMIC_MIN_ROOT_TORQUE = 0.001
RV.FORCE_STATIONARY_EQUIVALENT_SPEED_KMH = 1.0
RV.TRACK_DIFF_FORCE_MIN_APPLIED_TORQUE = 0.001
RV.TRACK_DIFF_FORCE_MIN_GEAR_RATIO = 0.001
RV.TORQUE_STRESS_REFERENCE_NM = 1850.0
RV.TORQUE_STRESS_REFERENCE_CAPACITY = 2.64
RV.TORQUE_STRESS_REFERENCE_BONUS = 0.25
RV.TORQUE_STRESS_RESPONSE_EXPONENT = 0.55
RV.TORQUE_STRESS_MIN_CAPACITY = 0.10

-- TEST0.2.0.107: selectable target tire/running-gear lifetime.
-- The proven 100 km wear calibration remains the fixed base. The selected
-- reference scales the complete wear rate without changing the underlying
-- DIST-WEAR / SLIP-WEAR model.
local function rvGetWearReferenceRateFactor()
    if RPReferenceSettings ~= nil and RPReferenceSettings.getWearReferenceRateFactor ~= nil then
        local ok, factor = pcall(RPReferenceSettings.getWearReferenceRateFactor)
        if ok and type(factor) == "number" and factor > 0 and factor < math.huge then
            return factor
        end
    end
    return 1.0
end

-- TEST2.3.94: running-gear-specific OWN-WEAR ground matrix.
-- Order/meaning agreed for the wear model:
--   STREET      = road/highway tire
--   OFFROAD     = tractor/agricultural/off-road tire
--   RUBBER_TRACK= rubber crawler/band
--   STEEL_TRACK = metal/steel crawler chain
-- SOFT/MUD remain at the proven .93 base values for all four types.
RV.GROUND_DISTANCE_FACTORS = {
    STREET       = {ROAD=1.00, FIELD=1.15, HARD=1.05, SOFT=0.90, MUD=0.90},
    OFFROAD      = {ROAD=1.10, FIELD=1.05, HARD=1.10, SOFT=0.90, MUD=0.90},
    RUBBER_TRACK = {ROAD=1.20, FIELD=1.00, HARD=1.05, SOFT=0.90, MUD=0.90},
    STEEL_TRACK  = {ROAD=1.50, FIELD=0.90, HARD=1.00, SOFT=0.90, MUD=0.90}
}

RV.GROUND_SLIP_FACTORS = {
    STREET       = {ROAD=1.20, FIELD=1.50, HARD=1.10, SOFT=0.75, MUD=0.75},
    OFFROAD      = {ROAD=1.30, FIELD=1.10, HARD=1.20, SOFT=0.75, MUD=0.75},
    RUBBER_TRACK = {ROAD=1.45, FIELD=1.00, HARD=1.35, SOFT=0.75, MUD=0.75},
    STEEL_TRACK  = {ROAD=1.60, FIELD=0.90, HARD=1.10, SOFT=0.75, MUD=0.75}
}

-- Weather is a REPLACEMENT state, never a stacked multiplier:
-- dry -> wet -> active rain -> snow. Only the strongest current state applies.
RV.WEATHER_WET_FACTOR = 0.80
RV.WEATHER_RAIN_FACTOR = 0.70
RV.WEATHER_SNOW_FACTOR = 0.60

local function clampFinite(value, minValue, maxValue, fallback)
    value = safeNumber(value, fallback)
    if value == nil then
        value = fallback
    end
    return math.clamp(value, minValue, maxValue)
end

local function getGroundWearClass(d)
    if d == nil then
        return "ROAD"
    end
    if d.isField == true then
        return "FIELD"
    end
    if d.isMudTerrain == true then
        return "MUD"
    end

    local name = string.upper(tostring(groundName(d.groundType) or ""))
    if string.find(name, "SOFT", 1, true) ~= nil then
        return "SOFT"
    end
    if string.find(name, "HARD", 1, true) ~= nil then
        return "HARD"
    end
    if string.find(name, "ROAD", 1, true) ~= nil then
        return "ROAD"
    end
    return "HARD"
end

local function rvGetSelectedReferenceKm()
    if RPReferenceSettings ~= nil and RPReferenceSettings.getReferenceKm ~= nil then
        local ok, km = pcall(RPReferenceSettings.getReferenceKm)
        if ok and type(km) == "number" and km > 0 and km < math.huge then
            return km
        end
    end
    return RV.TIME_WEAR_REFERENCE_KM
end

local function rvTimeWearNormalizedPerHour(pointsPerHourAt1000)
    local selectedKm = math.max(1, rvGetSelectedReferenceKm())
    local scaledPoints = safeNumber(pointsPerHourAt1000, 0) * (RV.TIME_WEAR_REFERENCE_KM / selectedKm)
    return scaledPoints / 1000.0
end

local function rvIsTractorByStoreCategory(vehicle)
    if vehicle == nil or g_storeManager == nil or g_storeManager.getItemByXMLFilename == nil then return false end
    local filename = vehicle.configFileName
    if filename == nil then return false end
    local ok, item = pcall(g_storeManager.getItemByXMLFilename, g_storeManager, filename)
    if not ok or item == nil then return false end
    for _, name in ipairs(item.categoryNames or {}) do
        local lower = string.lower(tostring(name or ""))
        if string.find(lower, "tractor", 1, true) ~= nil then
            return true
        end
    end
    return false
end

local function rvIsHarvestAttachmentObject(object)
    if object == nil then return false end
    return object.spec_cutter ~= nil
        or object.spec_pickup ~= nil
        or object.spec_fruitPreparer ~= nil
        or object.spec_vineCutter ~= nil
        or object.spec_extendedCombine ~= nil
end

local function rvIsTurnedOnSafe(object)
    if object == nil then return false end
    if type(object.getIsTurnedOn) == "function" then
        local ok, value = pcall(object.getIsTurnedOn, object)
        if ok and value == true then return true end
    end
    local spec = object.spec_turnOnVehicle
    return spec ~= nil and spec.isTurnedOn == true
end

local function rvIsFrontAttachment(carrier, object)
    if carrier == nil or object == nil or carrier.rootNode == nil or object.rootNode == nil or localToLocal == nil then
        return false
    end
    local ok, _, _, z = pcall(localToLocal, object.rootNode, carrier.rootNode, 0, 0, 0)
    return ok and type(z) == "number" and z > 0.25
end

local function rvHasActiveFrontHarvestAttachment(vehicle)
    if vehicle == nil or rvIsTractorByStoreCategory(vehicle) then return false end
    if type(vehicle.getAttachedImplements) ~= "function" then return false end
    local ok, implements = pcall(vehicle.getAttachedImplements, vehicle)
    if not ok or type(implements) ~= "table" then return false end
    for _, implement in pairs(implements) do
        local object = implement ~= nil and implement.object or nil
        if object ~= nil and rvIsFrontAttachment(vehicle, object) and rvIsHarvestAttachmentObject(object) then
            -- Many GIANTS cutters/pickups are driven by the carrier's Combine/TurnOnVehicle
            -- state instead of exposing their own independent turned-on state. Accept either
            -- side so a rotating/activated header is detected without requiring crop processing.
            if rvIsTurnedOnSafe(object) or rvIsTurnedOnSafe(vehicle) then
                return true
            end
        end
    end
    return false
end

local function rvWearManifestIsOnField(manifest)
    if manifest == nil then return false end
    local wearManifest = manifest.tireWearManifest
    if wearManifest == nil then return false end

    for _, wheel in ipairs(wearManifest.wheels or {}) do
        if rvWheelIsOnField(wheel) then
            return true
        end
    end
    for _, track in ipairs(wearManifest.tracks or {}) do
        for _, wheel in ipairs(track.referenceWheels or {}) do
            if rvWheelIsOnField(wheel) then
                return true
            end
        end
    end
    return false
end

local function rvUpdateTimeWearContext(vehicle, vehicleState, distanceM, speedKmh, dtSec, passiveImplement, manifest)
    local context = {active=false, ratePointsPerHourAt1000=RV.TIME_WEAR_LOW_POINTS_PER_H_AT_1000, avgSpeedKmh=0, harvestBoost=false, isField=false}
    if vehicleState == nil or dtSec <= 0 then return context end

    local isField = rvWearManifestIsOnField(manifest)
    context.isField = isField
    if not isField then
        -- TIME-WEAR is intentionally field-only. Leaving the field also resets
        -- the movement confirmation/window so road/off-road travel cannot prime
        -- a later slow-work factor before the wheels actually re-enter a field.
        vehicleState.timeWearMoveConfirmSec = 0
        vehicleState.timeWearWindowSec = 0
        vehicleState.timeWearWindowDistanceM = 0
        vehicleState.timeWearWindowAvgSpeedKmh = 0
        vehicleState.timeWearRatePointsPerHourAt1000 = RV.TIME_WEAR_LOW_POINTS_PER_H_AT_1000
        vehicleState.timeWearHarvestBoostActive = false
        return context
    end

    local speed = math.abs(safeNumber(speedKmh, 0))
    local moved = math.max(0, safeNumber(distanceM, 0))
    if speed >= RV.TIME_WEAR_MIN_SPEED_KMH then
        vehicleState.timeWearMoveConfirmSec = safeNumber(vehicleState.timeWearMoveConfirmSec, 0) + dtSec
    else
        vehicleState.timeWearMoveConfirmSec = 0
    end

    if safeNumber(vehicleState.timeWearMoveConfirmSec, 0) < RV.TIME_WEAR_CONFIRM_SEC then
        return context
    end

    context.active = true
    vehicleState.timeWearWindowSec = safeNumber(vehicleState.timeWearWindowSec, 0) + dtSec
    vehicleState.timeWearWindowDistanceM = safeNumber(vehicleState.timeWearWindowDistanceM, 0) + moved

    if vehicleState.timeWearWindowSec >= RV.TIME_WEAR_WINDOW_SEC then
        local avgSpeed = vehicleState.timeWearWindowSec > 0
            and (vehicleState.timeWearWindowDistanceM / vehicleState.timeWearWindowSec) * 3.6
            or 0
        vehicleState.timeWearWindowAvgSpeedKmh = avgSpeed

        local rate = RV.TIME_WEAR_LOW_POINTS_PER_H_AT_1000
        if vehicleState.timeWearWindowDistanceM <= RV.TIME_WEAR_WINDOW_DISTANCE_M then
            local alpha = math.clamp((6.0 - avgSpeed) / (6.0 - RV.TIME_WEAR_MIN_SPEED_KMH), 0, 1)
            rate = RV.TIME_WEAR_LOW_POINTS_PER_H_AT_1000
                + (RV.TIME_WEAR_SLOW_MAX_POINTS_PER_H_AT_1000 - RV.TIME_WEAR_LOW_POINTS_PER_H_AT_1000) * alpha
        end
        vehicleState.timeWearRatePointsPerHourAt1000 = rate
        vehicleState.timeWearWindowSec = 0
        vehicleState.timeWearWindowDistanceM = 0
    end

    context.ratePointsPerHourAt1000 = safeNumber(vehicleState.timeWearRatePointsPerHourAt1000, RV.TIME_WEAR_LOW_POINTS_PER_H_AT_1000)
    context.avgSpeedKmh = safeNumber(vehicleState.timeWearWindowAvgSpeedKmh, speed)
    if passiveImplement ~= true and rvHasActiveFrontHarvestAttachment(vehicle) then
        context.harvestBoost = true
        context.ratePointsPerHourAt1000 = context.ratePointsPerHourAt1000 + RV.TIME_WEAR_HARVEST_BONUS_POINTS_PER_H_AT_1000
    end
    vehicleState.timeWearHarvestBoostActive = context.harvestBoost
    return context
end

local function getLoadFactor(d)
    local load = safeNumber(d ~= nil and d.load or nil, nil)
    local reference = safeNumber(d ~= nil and d.restLoad or nil, nil)

    if load == nil or reference == nil or load <= 0 or reference <= 0 then
        return 1.0
    end

    local ratio = load / reference
    return clampFinite(math.pow(math.max(0.01, ratio), RV.WEAR_LOAD_EXPONENT),
        RV.WEAR_LOAD_MIN_FACTOR, RV.WEAR_LOAD_MAX_FACTOR, 1.0)
end

local function getWearRunningGearType(d)
    local t = d ~= nil and tostring(d.wearRunningGearType or "") or ""
    if t == "STREET" or t == "OFFROAD" or t == "RUBBER_TRACK" or t == "STEEL_TRACK" then
        return t
    end
    -- Normal wheels that are not explicitly road tires belong to the
    -- tractor/off-road class. This keeps unknown agricultural tire names out
    -- of the road-tire penalty class.
    return "OFFROAD"
end

local function getWeatherWearFactor(d, runningGearType, groundClass)
    if d == nil then return 1.0, "DRY" end

    -- Priority is intentional and exclusive: snow replaces rain, rain replaces
    -- wetness. No double multiplication of wet+rain+snow is allowed.
    if d.terrainSnow == true or safeNumber(d.snowScale, 0) > 0.5 then
        return RV.WEATHER_SNOW_FACTOR, "SNOW"
    end

    local rain = clampFinite(d.rainScale, 0, 1, 0)
    if rain > 0.001 then
        -- Steel/metal crawler chains on ROAD do not receive the weather wear
        -- reduction from rain; agreed factor stays 1.0.
        if runningGearType == "STEEL_TRACK" and groundClass == "ROAD" then
            return 1.0, "RAIN_STEEL_ROAD"
        end
        return RV.WEATHER_RAIN_FACTOR, "RAIN"
    end

    local wet = clampFinite(d.wetScale, 0, 1, 0)
    if wet > 0.001 then
        -- Same rule for merely wet asphalt with a metal/steel crawler chain.
        if runningGearType == "STEEL_TRACK" and groundClass == "ROAD" then
            return 1.0, "WET_STEEL_ROAD"
        end
        return RV.WEATHER_WET_FACTOR, "WET"
    end

    return 1.0, "DRY"
end

local function getDistanceGroundFactor(d)
    local class = getGroundWearClass(d)
    local runningGearType = getWearRunningGearType(d)
    local tableForType = RV.GROUND_DISTANCE_FACTORS[runningGearType] or RV.GROUND_DISTANCE_FACTORS.OFFROAD
    local base = tableForType[class] or 1.0
    local weatherFactor, weatherClass = getWeatherWearFactor(d, runningGearType, class)
    local factor = base * weatherFactor

    return clampFinite(factor, 0.40, 1.60, 1.0), class, runningGearType, weatherClass
end

local function getSlipGroundFactor(d)
    local class = getGroundWearClass(d)
    local runningGearType = getWearRunningGearType(d)
    local tableForType = RV.GROUND_SLIP_FACTORS[runningGearType] or RV.GROUND_SLIP_FACTORS.OFFROAD
    local base = tableForType[class] or 1.0
    local weatherFactor, weatherClass = getWeatherWearFactor(d, runningGearType, class)
    local factor = base * weatherFactor

    return clampFinite(factor, 0.40, 1.80, 1.0), class, runningGearType, weatherClass
end

local function getSlipIntensity(slipPercent)
    local slip = clampFinite(slipPercent, 0, RV.WEAR_SLIP_MAX_PERCENT, 0) / 100
    if slip < RV.WEAR_SLIP_MIN_PERCENT / 100 then
        return 0
    end

    local normalized = slip / RV.WEAR_SLIP_REFERENCE
    return RV.WEAR_SLIP_COEFFICIENT * math.pow(normalized, RV.WEAR_SLIP_EXPONENT)
end


local function rvComputeLongitudinalTireForce(wheel, slipRatio, tireLoad)
    if wheel == nil or wheel.physics == nil or wheel.node == nil
        or wheel.physics.wheelShape == nil or wheel.physics.wheelShape == 0
        or computeWheelShapeTireForces == nil then
        return nil
    end
    local load = safeNumber(tireLoad, nil)
    if load == nil or load <= 0 then return nil end
    local ok, longForce = pcall(computeWheelShapeTireForces, wheel.node, wheel.physics.wheelShape,
        clampFinite(slipRatio, 0, 1.50, 0), 0, load)
    if ok and type(longForce) == "number" and longForce == longForce and math.abs(longForce) < math.huge then
        return math.abs(longForce)
    end
    return nil
end

local function rvGetMountedTireCountForTorque(wheel)
    if wheel == nil then return 0 end
    local visualWheels = wheel.visualWheels
    if type(visualWheels) == "table" then
        local count = 0
        for _, visualWheel in pairs(visualWheels) do
            if visualWheel ~= nil then count = count + 1 end
        end
        if count > 0 then return count end
    end
    return 1
end

local function rvGetTorqueWheelWidth(wheel)
    local width = rvGetStableWheelWidth(wheel)
    if width > 0 then return width end
    local physics = wheel ~= nil and wheel.physics or nil
    width = safeNumber(physics ~= nil and physics.wheelShapeWidth or nil, 0)
    return math.max(0, width)
end

local function rvGetTrackTorqueCapacity(track, vehicle)
    if track == nil then return 0, 0, 0 end
    local minZ, maxZ = math.huge, -math.huge
    local maxRadius, maxWidth = 0, 0
    local referenceCount = 0
    for _, wheel in ipairs(track.referenceWheels or {}) do
        if wheel ~= nil then referenceCount = referenceCount + 1 end
        local _, _, z = getWheelLocalPosition(vehicle, wheel)
        if type(z) == "number" then
            minZ = math.min(minZ, z)
            maxZ = math.max(maxZ, z)
        end
        maxRadius = math.max(maxRadius, rvGetStableWheelRadius(wheel))
        maxWidth = math.max(maxWidth, rvGetTorqueWheelWidth(wheel))
    end
    if referenceCount <= 0 then return 0, 0, 0 end
    local length = 0
    if minZ ~= math.huge and maxZ ~= -math.huge then
        length = math.max(0, maxZ - minZ) + maxRadius * 2
    end
    if length <= 0 and track.crawler ~= nil then length = math.max(0, safeNumber(track.crawler.length, 0)) end
    if maxWidth <= 0 and track.crawler ~= nil then maxWidth = math.max(0, safeNumber(track.crawler.width, 0)) end
    if length <= 0 or maxWidth <= 0 then return 0, length, maxWidth end
    return length * maxWidth, length, maxWidth
end

local rvTorqueCapacityCache = setmetatable({}, {__mode = "k"})
local rvTorqueStressCache = setmetatable({}, {__mode = "k"})
local rvDifferentialWheelShareCache = setmetatable({}, {__mode = "k"})

local function rvGetVehicleTorqueCapacity(vehicle)
    if vehicle == nil then
        return {capacity=RV.TORQUE_STRESS_REFERENCE_CAPACITY, tireInstances=0, trackCount=0}
    end
    local cached = rvTorqueCapacityCache[vehicle]
    if cached ~= nil then return cached end
    local wearManifest = getOrBuildTireWearManifest(vehicle)
    local traction = getTractionWheels(vehicle)
    local capacity, tireInstances, trackCount = 0, 0, 0
    if wearManifest ~= nil then
        for _, wheel in ipairs(wearManifest.wheels or {}) do
            local wheelIndex = wheel ~= nil and wheel.wheelIndex or nil
            if wheelIndex ~= nil and traction[wheelIndex] == true then
                local radius = rvGetStableWheelRadius(wheel)
                local width = rvGetTorqueWheelWidth(wheel)
                local mountedCount = rvGetMountedTireCountForTorque(wheel)
                if radius > 0 and width > 0 and mountedCount > 0 then
                    capacity = capacity + radius * width * mountedCount
                    tireInstances = tireInstances + mountedCount
                end
            end
        end
        for _, track in ipairs(wearManifest.tracks or {}) do
            local trackCapacity = rvGetTrackTorqueCapacity(track, vehicle)
            if trackCapacity > 0 then
                capacity = capacity + trackCapacity
                trackCount = trackCount + 1
            end
        end
    end
    if capacity < RV.TORQUE_STRESS_MIN_CAPACITY then capacity = RV.TORQUE_STRESS_REFERENCE_CAPACITY end
    cached = {capacity=capacity, tireInstances=tireInstances, trackCount=trackCount}
    rvTorqueCapacityCache[vehicle] = cached
    return cached
end

local function rvReadCurrentAppliedMotorTorqueNm(vehicle)
    local spec = vehicle ~= nil and vehicle.spec_motorized or nil
    local motor = spec ~= nil and spec.motor or nil
    if motor == nil then return 0, 0, "NONE" end
    local raw = nil
    if motor.getMotorAppliedTorque ~= nil then
        local ok, value = pcall(motor.getMotorAppliedTorque, motor)
        if ok then raw = safeNumber(value, nil) end
    end
    if raw == nil then raw = safeNumber(motor.motorAppliedTorque, 0) end
    raw = math.abs(safeNumber(raw, 0))
    local source = "GIANTS"
    if raw <= RV.TRACK_DIFF_FORCE_MIN_APPLIED_TORQUE then
        local demand = math.abs(safeNumber(vehicle.wheelsUtilSmoothedAcceleratorPedal, 0))
        if demand <= RV.FORCE_DYNAMIC_MIN_DRIVE_DEMAND and vehicle.spec_drivable ~= nil then
            local d = vehicle.spec_drivable
            demand = math.max(demand, math.abs(safeNumber(d.axisForward, 0)))
            if d.lastInputValues ~= nil then
                demand = math.max(demand, math.abs(safeNumber(d.lastInputValues.axisAccelerate, 0)))
            end
        end
        if demand > RV.FORCE_DYNAMIC_MIN_DRIVE_DEMAND and motor.getTorque ~= nil then
            local ok, value = pcall(motor.getTorque, motor, math.clamp(demand, 0, 1))
            if ok and safeNumber(value, 0) > 0 then
                raw = math.abs(safeNumber(value, 0))
                source = "RPM_CURVE"
            end
        end
    end
    local torqueNm = raw < 100 and raw * 1000 or raw
    return math.max(0, safeNumber(torqueNm, 0)), raw, source
end

local function rvGetVehicleTorqueStress(vehicle)
    if vehicle == nil then
        return {factor=1.0, stressIndex=0, torqueNm=0, capacity=0, source="NONE"}
    end
    local nowMs = g_currentMission ~= nil and safeNumber(g_currentMission.time, 0) or 0
    local cached = rvTorqueStressCache[vehicle]
    if cached ~= nil and nowMs >= safeNumber(cached.timeMs, -math.huge)
        and nowMs - safeNumber(cached.timeMs, 0) < RV.FORCE_DYNAMIC_ACTIVE_INTERVAL_MS then
        return cached
    end
    local torqueNm, rawTorque, source = rvReadCurrentAppliedMotorTorqueNm(vehicle)
    local cap = rvGetVehicleTorqueCapacity(vehicle)
    local capacity = math.max(RV.TORQUE_STRESS_MIN_CAPACITY, safeNumber(cap.capacity, RV.TORQUE_STRESS_REFERENCE_CAPACITY))
    local stressIndex = (torqueNm / RV.TORQUE_STRESS_REFERENCE_NM)
        * (RV.TORQUE_STRESS_REFERENCE_CAPACITY / capacity)
    stressIndex = math.max(0, safeNumber(stressIndex, 0))
    local response = math.pow(stressIndex, RV.TORQUE_STRESS_RESPONSE_EXPONENT)
    local factor = 1.0 + RV.TORQUE_STRESS_REFERENCE_BONUS * response
    factor = math.clamp(safeNumber(factor, 1), 1.0, 5.0)
    local result = {factor=factor, stressIndex=stressIndex, torqueNm=torqueNm, rawTorque=rawTorque,
        capacity=capacity, source=source, timeMs=nowMs}
    rvTorqueStressCache[vehicle] = result
    return result
end

local function rvGetForceSlipSeparationFactor(slipPercent)
    local slip = clampFinite(slipPercent, 0, 100, 0)
    local fullUntil = math.clamp(safeNumber(RV.FORCE_SLIP_FULL_FORCE_UNTIL_PERCENT, 20), 0, 99.9)
    if slip <= fullUntil then return 1.0 end
    local t = math.clamp((slip - fullUntil) / math.max(0.001, 100.0 - fullUntil), 0, 1)
    local shaped = math.pow(t, math.max(0.05, safeNumber(RV.FORCE_SLIP_COUPLING_EXPONENT, 0.55)))
    local minimum = math.clamp(safeNumber(RV.FORCE_SLIP_MIN_FORCE_AT_100_PERCENT, 0.20), 0, 1)
    return math.clamp(1.0 - (1.0 - minimum) * shaped, minimum, 1.0)
end

local function rvGetForceWearRate(utilization, load, restLoad, slipPercent)
    local rawU = math.max(0, safeNumber(utilization, 0))
    local slipForceCap = rvGetForceSlipSeparationFactor(slipPercent)
    local effectiveU = math.min(rawU, slipForceCap, 1.0)
    local curve = math.pow(effectiveU, math.max(0.25, safeNumber(RV.FORCE_WEAR_RESPONSE_EXPONENT, 2.0)))
    local loadRatio = 1.0
    if safeNumber(restLoad, 0) > 0 and safeNumber(load, 0) > 0 then
        loadRatio = safeNumber(load, 0) / safeNumber(restLoad, 1)
    end
    local deformation = 1.0 + RV.FORCE_WEAR_LOAD_DEFORMATION_GAIN
        * math.clamp(loadRatio - 1.0, 0, RV.FORCE_WEAR_LOAD_DEFORMATION_RANGE)
    local rate = RV.FORCE_WEAR_MAX_RATE * curve * deformation
    return math.max(0, safeNumber(rate, 0)), deformation, slipForceCap, effectiveU
end

local function rvGetDifferentialWheelShares(vehicle)
    if vehicle == nil then return nil end
    local cached = rvDifferentialWheelShareCache[vehicle]
    if cached ~= nil then return cached end
    local spec = vehicle.spec_motorized
    local differentials = spec ~= nil and spec.differentials or nil
    if type(differentials) ~= "table" or #differentials == 0 then return nil end
    local referenced = {}
    for _, differential in ipairs(differentials) do
        if differential ~= nil then
            if differential.diffIndex1IsWheel ~= true then
                local idx = safeNumber(differential.diffIndex1, nil)
                if idx ~= nil then referenced[idx + 1] = true end
            end
            if differential.diffIndex2IsWheel ~= true then
                local idx = safeNumber(differential.diffIndex2, nil)
                if idx ~= nil then referenced[idx + 1] = true end
            end
        end
    end
    local roots = {}
    for i=1,#differentials do if referenced[i] ~= true then roots[#roots + 1] = i end end
    if #roots ~= 1 then return nil end
    local wheelShares, visiting = {}, {}
    local valid = true
    local function distributeBranch(index, isWheel, share)
        if share <= 0 then return end
        if isWheel == true then
            local wheelIndex = safeNumber(index, nil)
            if wheelIndex ~= nil and wheelIndex >= 1 then
                wheelShares[wheelIndex] = safeNumber(wheelShares[wheelIndex], 0) + share
            else
                valid = false
            end
            return
        end
        local diffLuaIndex = safeNumber(index, nil)
        if diffLuaIndex == nil then valid = false return end
        diffLuaIndex = diffLuaIndex + 1
        local differential = differentials[diffLuaIndex]
        if differential == nil or visiting[diffLuaIndex] == true then valid = false return end
        visiting[diffLuaIndex] = true
        local ratio = clampFinite(differential.torqueRatio, 0, 1, 0.5)
        distributeBranch(differential.diffIndex1, differential.diffIndex1IsWheel == true, share * ratio)
        distributeBranch(differential.diffIndex2, differential.diffIndex2IsWheel == true, share * (1 - ratio))
        visiting[diffLuaIndex] = nil
    end
    local rootIndex = roots[1]
    local root = differentials[rootIndex]
    visiting[rootIndex] = true
    local rootRatio = clampFinite(root.torqueRatio, 0, 1, 0.5)
    distributeBranch(root.diffIndex1, root.diffIndex1IsWheel == true, rootRatio)
    distributeBranch(root.diffIndex2, root.diffIndex2IsWheel == true, 1 - rootRatio)
    visiting[rootIndex] = nil
    if not valid then return nil end
    local sum = 0
    for _, share in pairs(wheelShares) do sum = sum + math.max(0, safeNumber(share, 0)) end
    if sum <= 0.000001 then return nil end
    for wheelIndex, share in pairs(wheelShares) do
        wheelShares[wheelIndex] = math.max(0, safeNumber(share, 0)) / sum
    end
    local result = {shares=wheelShares, rootIndex=rootIndex, differentialCount=#differentials}
    rvDifferentialWheelShareCache[vehicle] = result
    return result
end

local function rvGetCurrentPhysicsWheelRadius(wheel)
    if wheel == nil then return 0 end
    local physics = wheel.physics
    local radius = safeNumber(physics ~= nil and physics.radius or nil, nil)
    if radius == nil or radius <= 0 then radius = safeNumber(wheel.radius, nil) end
    if radius == nil or radius <= 0 then radius = rvGetStableWheelRadius(wheel) end
    return math.max(0, safeNumber(radius, 0))
end

local function getWearKey(wheel)
    if wheel == nil then
        return nil
    end

    -- Persistenz-/HUD-kritisch: der Radschlüssel muss über Save/Load exakt
    -- dieselbe Tabellenform besitzen. Frühere TEST2.3.78-80 Stände speicherten
    -- numerische wheelIndex-Schlüssel als XML-String und luden sie als String
    -- zurück; getWheelWearState() suchte später aber wieder mit der Zahl.
    -- Ergebnis: Diagnose-/Save-Werte konnten vorhanden sein, während nach
    -- Reload neue 0-Werte unter einem zweiten Schlüssel entstanden. Ab 2_3_81
    -- ist der Schlüssel IMMER ein String.
    if wheel.wheelIndex ~= nil then
        return tostring(wheel.wheelIndex)
    end

    return tostring(wheel)
end

local function getWheelWearState(vehicleState, wheel)
    if vehicleState==nil or wheel==nil then return nil end
    local key=getWearKey(wheel); if key==nil then return nil end
    vehicleState.wheelWear=vehicleState.wheelWear or {}
    local state=vehicleState.wheelWear[key]

    -- Migration für bereits im laufenden Spiel angelegte alte numeric keys.
    -- Nicht kopieren, sondern verschieben, damit es keine Doppelzustände gibt.
    if state == nil and wheel.wheelIndex ~= nil then
        local numericKey = tonumber(wheel.wheelIndex)
        if numericKey ~= nil and vehicleState.wheelWear[numericKey] ~= nil then
            state = vehicleState.wheelWear[numericKey]
            vehicleState.wheelWear[numericKey] = nil
            vehicleState.wheelWear[key] = state
        end
    end

    if state==nil then
        state={value=0,distanceWear=0,slipWear=0,timeWear=0,forceWear=0,effectiveDistanceM=0,slipDistanceM=0,lastSlip=0,lastSlipWearPointsPerSecond=0,lastGroundClass="UNKNOWN",lastDistanceFactor=1,lastSlipFactor=1,lastLoadFactor=1,initialized=false,lastDistanceInputM=0,lastDtSec=0,lastSpeedKmh=0,lastLoadInput=0,lastRestLoadInput=0,lastSlipInput=0}
        vehicleState.wheelWear[key]=state
    end
    state.value=math.clamp(safeNumber(state.distanceWear,0)+safeNumber(state.slipWear,0)+safeNumber(state.timeWear,0)+safeNumber(state.forceWear,0),0,RV.WEAR_MAX)
    return state
end

local function getTrackWearState(vehicleState, track)
    if vehicleState == nil or track == nil then return nil end
    vehicleState.trackWear = vehicleState.trackWear or {}
    local key = track.key or string.format("TRACK|%s|%d", tostring(track.side or "?"), tonumber(track.index) or 0)
    local state = vehicleState.trackWear[key]
    if state == nil then
        state = {
            value = 0,
            distanceWear = 0, slipWear = 0, timeWear = 0, forceWear = 0, effectiveDistanceM = 0, slipDistanceM = 0,
            lastSlip = 0, lastSlipWearPointsPerSecond = 0,
            lastGroundClass = "UNKNOWN", lastDistanceFactor = 1, lastSlipFactor = 1, lastLoadFactor = 1,
            lastDistanceInputM = 0, lastDtSec = 0, lastSpeedKmh = 0, lastLoadInput = 0,
            lastRestLoadInput = 0, lastSlipInput = 0,
            lastCrawlerMovedDistance = nil, initialized = false
        }
        vehicleState.trackWear[key] = state
    end
    state.value = math.clamp(
        safeNumber(state.distanceWear, 0) + safeNumber(state.slipWear, 0) + safeNumber(state.timeWear, 0) + safeNumber(state.forceWear, 0),
        0, RV.WEAR_MAX
    )
    return state
end

local function getWearSlipTestPointsPerSecond(slip)
    -- FUNCTION TEST ONLY: deliberately visible values to prove that pure
    -- wheel spin produces wear even when vehicle distance is ~0.
    -- Values are wear-points per second on the 0..1000 test scale.
    local s = math.max(0, safeNumber(slip, 0))
    if s < 5 then return 0.00 end
    if s < 10 then return 0.05 end
    if s < 20 then return 0.15 end
    if s < 30 then return 0.30 end
    if s < 40 then return 0.50 end
    if s < 60 then return 0.80 end
    if s < 80 then return 1.20 end
    return 1.50
end

local function isMotorStartPhase(vehicle)
    -- Use the same GIANTS motor-start timing that the proven HUD logic uses.
    -- During this phase wheel-slip values may contain initialization peaks;
    -- absolutely no wear is allowed to pass this gate.
    if vehicle == nil or vehicle.spec_motorized == nil then
        return false, 0, 0
    end

    local spec = vehicle.spec_motorized
    local state = spec.motorState
    local motorStateStarting = MotorState ~= nil and MotorState.STARTING ~= nil and state == MotorState.STARTING

    local startTime = safeNumber(spec.motorStartTime, 0)
    local startDuration = safeNumber(spec.motorStartDuration, 0)

    if motorStateStarting then
        return true, math.max(0, startDuration), 0
    end

    if startTime > 0 and startDuration > 0 and g_time ~= nil then
        local elapsed = g_time - startTime
        if elapsed >= 0 and elapsed < startDuration then
            return true, startDuration, elapsed
        end
    end

    return false, startDuration, 0
end

local function isMotorRunning(vehicle)
    if vehicle == nil then
        return false
    end

    if vehicle.getIsMotorStarted ~= nil then
        local ok, started = pcall(vehicle.getIsMotorStarted, vehicle)
        if ok then
            return started == true
        end
    end

    local spec = vehicle.spec_motorized
    if spec == nil then
        return false
    end

    local state = spec.motorState
    if MotorState ~= nil then
        if MotorState.STARTING ~= nil and state == MotorState.STARTING then
            return false
        end
        if MotorState.STOPPED ~= nil and state == MotorState.STOPPED then
            return false
        end
        if MotorState.OFF ~= nil and state == MotorState.OFF then
            return false
        end
    end

    return state ~= nil
end


local function isWearGroundContact(contact)
    -- Wear requires real ground contact. A freely spinning wheel in the air
    -- may report very high slip, but that must never create tire wear.
    if contact == nil then
        return false
    end

    if Vehicle ~= nil then
        if Vehicle.WHEEL_GROUND_CONTACT ~= nil and contact == Vehicle.WHEEL_GROUND_CONTACT then
            return true
        end
        if Vehicle.WHEEL_GROUND_HEIGHT_CONTACT ~= nil and contact == Vehicle.WHEEL_GROUND_HEIGHT_CONTACT then
            return true
        end
    end

    if WheelContactType ~= nil and WheelContactType.GROUND ~= nil and contact == WheelContactType.GROUND then
        return true
    end

    return false
end

getDiagnosticSlip = function(vehicle, wheel, vehicleState, hasGroundContact)
    local rawSlip = getWheelSlip(wheel, vehicle)
    if rawSlip == nil then
        return 0, false, true
    end

    local startupBlocked = isMotorStartPhase(vehicle)
    local rotating = isWheelPhysicallyRotating(wheel)
    local groundContact = hasGroundContact == true

    -- True standstill/raw-slip gate:
    -- After READY, inertia/braking slip must remain valid while the vehicle is
    -- still moving, even with zero throttle and completely locked wheels.
    -- Only discard a remaining GIANTS raw-slip value when ALL standstill
    -- conditions are true at the same time: no vehicle movement, no physical
    -- wheel/crawler rotation and no drive input. This restores the confirmed
    -- braking/inertia-slip behavior while still blocking the stale ~20%
    -- raw-slip value at a real standstill.
    local speedKmh = getVehicleSpeedKmh(vehicle)
    local driveInput = 0
    local spec = vehicle ~= nil and vehicle.spec_drivable or nil
    if spec ~= nil and spec.lastInputValues ~= nil then
        driveInput = safeNumber(spec.lastInputValues.axisAccelerate, 0)
    end
    local vehicleStopped = math.abs(safeNumber(speedKmh, 0)) <= 0.05
    local noDriveInput = math.abs(driveInput) <= 0.02
    if vehicleStopped and noDriveInput and not rotating then
        return 0, false, startupBlocked
    end
    if hasGroundContact == nil then
        local _, _, _, contact = getWheelGroundInfo(wheel)
        groundContact = isWearGroundContact(contact)
    end

    -- Startup/READY protection remains, but wheel rotation is deliberately NOT
    -- a permanent prerequisite. Once the vehicle is READY, moving and grounded
    -- wheels are eligible for slip evaluation even when the wheel rotation is
    -- very low or zero. This covers braking, wheel lock and heavy steering
    -- inertia instead of misclassifying them as 0% slip.
    if startupBlocked or vehicleState == nil or vehicleState.ready ~= true or not groundContact then
        return 0, rotating, startupBlocked
    end

    return rawSlip, rotating, false
end

local function updateVehicleWearReady(vehicle, vehicleState, dtSec)
    if vehicleState == nil then
        return false, true
    end

    local startPhase = isMotorStartPhase(vehicle)
    local motorRunning = isMotorRunning(vehicle)

    if startPhase or not motorRunning then
        vehicleState.ready = false
        vehicleState.readySince = 0
        return false, startPhase
    end

    -- First valid post-start sample is only used to establish the READY state.
    -- No wear is generated on that sample. This mirrors the proven HUD chain:
    -- raw physics values may exist, but calculations remain blocked until READY.
    if vehicleState.ready ~= true then
        vehicleState.ready = true
        vehicleState.readySince = safeNumber(g_time, 0)
        if ReifenVerschleissWegfahrsperre ~= nil and ReifenVerschleissWegfahrsperre.setReady ~= nil then
            ReifenVerschleissWegfahrsperre.setReady(vehicle)
        end
        return false, false
    end

    return true, false
end

-- ============================================================================
-- WEAR RESET / OWN WEAR
-- TEST0.2.0.26: reset path remains unchanged; visual refresh is handled by RVV.
-- Native workshop actions are independent of the custom wear calculation.
-- The custom reset clears only the mod-owned DIST-/SLIP-/TOTAL-Wear state.
-- ============================================================================
local function resetVehicleWearState(vehicle, reason)
    if vehicle == nil or not isRelevantPlayerVehicle(vehicle) then
        return false
    end

    local state = getVehicleWearState(vehicle)
    if state == nil then
        return false
    end

    state.totalDistanceWear = 0
    state.totalSlipWear = 0
    state.totalTimeWear = 0
    state.totalForceWear = 0
    state.totalWear = 0
    state.totalEffectiveWearDistanceM = 0
    state.ready = false
    state.readySince = 0
    state.timeWearMoveConfirmSec = 0
    state.timeWearWindowSec = 0
    state.timeWearWindowDistanceM = 0
    state.timeWearRatePointsPerHourAt1000 = RV.TIME_WEAR_LOW_POINTS_PER_H_AT_1000
    state.timeWearWindowAvgSpeedKmh = 0
    state.timeWearHarvestBoostActive = false
    state.lastReadyLog = false
    state.slipDisplayReady = false
    state.slipDisplayLast = {}
    state.slipDisplayRotation = {}
    state.slipDisplayBlocked = true

    for _, wheelState in pairs(state.wheelWear or {}) do
        wheelState.value = 0
        wheelState.distanceWear = 0
        wheelState.slipWear = 0
        wheelState.timeWear = 0
        wheelState.forceWear = 0
        wheelState.effectiveDistanceM = 0
        wheelState.slipDistanceM = 0
        wheelState.lastSlip = 0
        wheelState.lastSlipWearPointsPerSecond = 0
        wheelState.lastGroundClass = "RESET"
        wheelState.lastDistanceFactor = 1
        wheelState.lastSlipFactor = 1
        wheelState.lastLoadFactor = 1
        wheelState.lastDistanceInputM = 0
        wheelState.lastDtSec = 0
        wheelState.lastSpeedKmh = 0
        wheelState.lastLoadInput = 0
        wheelState.lastRestLoadInput = 0
        wheelState.lastSlipInput = 0
        wheelState.initialized = false
    end

    for _, trackState in pairs(state.trackWear or {}) do
        trackState.value = 0
        trackState.distanceWear = 0
        trackState.slipWear = 0
        trackState.timeWear = 0
        trackState.forceWear = 0
        trackState.effectiveDistanceM = 0
        trackState.slipDistanceM = 0
        trackState.lastSlip = 0
        trackState.lastSlipWearPointsPerSecond = 0
        trackState.lastGroundClass = "RESET"
        trackState.lastDistanceFactor = 1
        trackState.lastSlipFactor = 1
        trackState.lastLoadFactor = 1
        trackState.lastCrawlerMovedDistance = nil
        trackState.initialized = false
    end

    if ReifenVerschleissVisual ~= nil and ReifenVerschleissVisual.resetVehicleWearVisuals ~= nil then
        local ok, err = pcall(ReifenVerschleissVisual.resetVehicleWearVisuals, vehicle)
    end

    return true
end

function ReifenVerschleissCore:onVehicleRepaired(vehicle)
    if vehicle ~= nil then
        self:resetVehicleWear(vehicle, "WORKSHOP-REPAIR")
    end
end

function ReifenVerschleissCore:onVehicleRepainted(vehicle)
    if vehicle ~= nil then
        self:resetVehicleWear(vehicle, "WORKSHOP-REPAINT")
    end
end

function ReifenVerschleissCore.resetVehicleCustomWearState(vehicle, reason)
    if vehicle == nil or not isRelevantPlayerVehicle(vehicle) then
        return false
    end

    local state = getVehicleWearState(vehicle)
    if state == nil then
        return false
    end

    -- Client-side mirror of the authoritative workshop reset.  The custom
    -- per-wheel wear is not a GIANTS network field, so the receiving client
    -- must clear its local wheel states as well.  Do NOT touch native GIANTS
    -- Wear here; the server event already owns that operation.
    state.workshopReplacementReset = true
    state.totalDistanceWear = 0
    state.totalSlipWear = 0
    state.totalTimeWear = 0
    state.totalForceWear = 0
    state.totalWear = 0
    state.totalEffectiveWearDistanceM = 0
    state.ready = false
    state.readySince = 0
    state.timeWearMoveConfirmSec = 0
    state.timeWearWindowSec = 0
    state.timeWearWindowDistanceM = 0
    state.timeWearRatePointsPerHourAt1000 = RV.TIME_WEAR_LOW_POINTS_PER_H_AT_1000
    state.timeWearWindowAvgSpeedKmh = 0
    state.timeWearHarvestBoostActive = false
    state.lastReadyLog = false
    state.slipDisplayReady = false
    state.slipDisplayLast = {}
    state.slipDisplayRotation = {}
    state.slipDisplayBlocked = true

    for _, wheelState in pairs(state.wheelWear or {}) do
        wheelState.value = 0
        wheelState.distanceWear = 0
        wheelState.slipWear = 0
        wheelState.timeWear = 0
        wheelState.forceWear = 0
        wheelState.effectiveDistanceM = 0
        wheelState.slipDistanceM = 0
        wheelState.lastSlip = 0
        wheelState.lastSlipWearPointsPerSecond = 0
        wheelState.lastGroundClass = "RESET"
        wheelState.lastDistanceFactor = 1
        wheelState.lastSlipFactor = 1
        wheelState.lastLoadFactor = 1
        wheelState.lastDistanceInputM = 0
        wheelState.lastDtSec = 0
        wheelState.lastSpeedKmh = 0
        wheelState.lastLoadInput = 0
        wheelState.lastRestLoadInput = 0
        wheelState.lastSlipInput = 0
        wheelState.initialized = false
    end

    for _, trackState in pairs(state.trackWear or {}) do
        trackState.value=0; trackState.forceZeroWear=true
        trackState.distanceWear=0; trackState.slipWear=0; trackState.timeWear=0; trackState.forceWear=0; trackState.effectiveDistanceM=0; trackState.slipDistanceM=0
        trackState.lastSlip=0; trackState.lastSlipWearPointsPerSecond=0
        trackState.lastCrawlerMovedDistance=nil; trackState.initialized=false
        trackState.rollerWear=0; trackState.rollerDistanceM=0
    end

    return true
end

-- Public read-only bridge for the visual layer. It returns the track's own
-- tire-wear value, never the internal crawler-wheel states.
function ReifenVerschleissCore.getCrawlerWearValue(vehicle, crawler)
    if vehicle == nil or crawler == nil then
        return 0
    end

    -- IMPORTANT: This bridge is for the TRACK VISUAL only.
    -- The shader expects only the own track wear (0=new -> 1=fully worn).
    -- Use only mod-owned DIST-WEAR + SLIP-WEAR + TIME-WEAR.
    local wm = getOrBuildTireWearManifest(vehicle)
    local state = getVehicleWearState(vehicle)

    for _, track in ipairs(wm.tracks or {}) do
        if track.crawler == crawler then
            local st = getTrackWearState(state, track)
            if st ~= nil then
                local ownWear = safeNumber(st.distanceWear, 0) + safeNumber(st.slipWear, 0) + safeNumber(st.timeWear, 0) + safeNumber(st.forceWear, 0)
                return math.clamp(ownWear, 0, RV.WEAR_MAX)
            end
        end
    end

    return 0
end

function ReifenVerschleissCore.hasOwnWearObjects(vehicle)
    if vehicle == nil then return false end
    local wearManifest = getOrBuildTireWearManifest(vehicle)
    if wearManifest == nil then return false end
    -- Use the dedicated tire-wear manifest. The chassis manifest uses
    -- totalWheelCount/crawlerCount; the tire-wear manifest uses wheelCount/trackCount.
    return (safeNumber(wearManifest.wheelCount, 0) + safeNumber(wearManifest.trackCount, 0)) > 0
end

function ReifenVerschleissCore.getVehicleWearPercent(vehicle)
    local wear01 = ReifenVerschleissCore.getOwnWear01ForHUD(vehicle)
    return wear01 ~= nil and wear01 * 100 or 0
end

function ReifenVerschleissCore.getWheelWearValue(vehicle, wheel)
    if vehicle == nil or wheel == nil then
        return nil
    end

    local vehicleState = getVehicleWearState(vehicle)
    local state = getWheelWearState(vehicleState, wheel)
    if state == nil then
        return nil
    end

    return math.clamp(safeNumber(state.value, 0), 0, RV.WEAR_MAX)
end

-- ============================================================================
-- TEST0.2.0.69: explicit drive-state gates for wear generation.
--
-- DIST-WEAR is allowed only when the vehicle really travels AND the wheel/
-- crawler reference wheel is physically rotating.
-- SLIP-WEAR is independent from vehicle travel: it may occur at 0 km/h when
-- the driver applies throttle, the wheel/crawler reference wheel rotates and
-- the wheel has real ground contact. This covers a vehicle pushing against an
-- obstacle without allowing stationary engine/physics noise to create wear.
-- ============================================================================
local RV_WEAR_MOVEMENT_EPSILON_M = 0.0005
local RV_WEAR_SPEED_EPSILON_KMH = 0.05
local RV_WEAR_DRIVE_INPUT_EPSILON = 0.02

local function getDriveInput(vehicle)
    if vehicle == nil then return 0 end

    local smoothed = safeNumber(vehicle.wheelsUtilSmoothedAcceleratorPedal, nil)
    if smoothed ~= nil and math.abs(smoothed) > 0.001 then
        return smoothed
    end

    local spec = vehicle.spec_drivable
    if spec ~= nil then
        if spec.lastInputValues ~= nil then
            local input = safeNumber(spec.lastInputValues.axisAccelerate, nil)
            if input ~= nil and math.abs(input) > 0.001 then return input end
        end
        local input = safeNumber(spec.axisForward, nil)
        if input ~= nil and math.abs(input) > 0.001 then return input end
    end

    local motor = vehicle.spec_motorized ~= nil and vehicle.spec_motorized.motor or nil
    if motor ~= nil then
        local lastAccelerator = safeNumber(motor.lastAcceleratorPedal, nil)
        if lastAccelerator ~= nil and math.abs(lastAccelerator) > 0.001 then
            return lastAccelerator
        end
    end
    return 0
end

local function getWheelRotationState(wheel)
    return isWheelPhysicallyRotating(wheel)
end

local function getTrackRotationState(track)
    if track == nil then
        return false
    end

    for _, wheel in ipairs(track.referenceWheels or {}) do
        if getWheelRotationState(wheel) then
            return true
        end
    end

    return false
end

local function getWearDriveGates(vehicle, distanceM, speedKmh, rotating)
    local driveInput = getDriveInput(vehicle)
    local hasMovement = math.max(0, safeNumber(distanceM, 0)) > RV_WEAR_MOVEMENT_EPSILON_M
        and math.abs(safeNumber(speedKmh, 0)) > RV_WEAR_SPEED_EPSILON_KMH
    local hasRotation = rotating == true
    local hasDriveDemand = math.abs(safeNumber(driveInput, 0)) > RV_WEAR_DRIVE_INPUT_EPSILON

    return {
        driveInput = driveInput,
        hasMovement = hasMovement,
        hasRotation = hasRotation,
        hasDriveDemand = hasDriveDemand,
        allowDistanceWear = hasMovement and hasRotation,
        allowSlipWear = hasMovement or (hasDriveDemand and hasRotation)
    }
end


local rvDynamicDriveCache = setmetatable({}, {__mode = "k"})
local rvFallbackWheelShareCache = setmetatable({}, {__mode = "k"})
local rvDynamicWheelForceCache = setmetatable({}, {__mode = "k"})

local function rvGetWheelDriveShares(vehicle)
    local diff = rvGetDifferentialWheelShares(vehicle)
    if diff ~= nil and type(diff.shares) == "table" then return diff.shares end
    local cached = rvFallbackWheelShareCache[vehicle]
    if cached ~= nil then return cached end
    local traction = getTractionWheels(vehicle)
    local wheels = vehicle ~= nil and vehicle.spec_wheels ~= nil and vehicle.spec_wheels.wheels or nil
    local count = 0
    if type(wheels) == "table" then
        for _, wheel in ipairs(wheels) do
            local wi = wheel ~= nil and wheel.wheelIndex or nil
            if wi ~= nil and traction[wi] == true then count = count + 1 end
        end
    end
    local shares = {}
    if count > 0 and type(wheels) == "table" then
        local equal = 1 / count
        for _, wheel in ipairs(wheels) do
            local wi = wheel ~= nil and wheel.wheelIndex or nil
            if wi ~= nil and traction[wi] == true then shares[wi] = equal end
        end
    end
    rvFallbackWheelShareCache[vehicle] = shares
    return shares
end

local function rvGetDynamicDriveSnapshot(vehicle)
    if vehicle == nil then
        return {active=false,driveDemand=0,appliedTorque=0,gearRatio=0,rootTorque=0,rpm=0,source="NONE",sampleId=0}
    end
    local nowMs = g_currentMission ~= nil and safeNumber(g_currentMission.time,0) or 0
    local quickDemand = math.abs(safeNumber(getDriveInput(vehicle),0))
    local cached = rvDynamicDriveCache[vehicle]
    if cached ~= nil then
        local interval = safeNumber(cached.intervalMs, RV.FORCE_DYNAMIC_ACTIVE_INTERVAL_MS)
        local age = nowMs - safeNumber(cached.timeMs, -math.huge)
        if age >= 0 and age < interval
            and not (cached.active ~= true and quickDemand > RV.FORCE_DYNAMIC_MIN_DRIVE_DEMAND) then
            return cached
        end
    end
    local spec = vehicle.spec_motorized
    local motor = spec ~= nil and spec.motor or nil
    if motor == nil then
        local result = {active=false,driveDemand=quickDemand,appliedTorque=0,gearRatio=0,rootTorque=0,rpm=0,
            source="NONE",sampleId=(cached ~= nil and safeNumber(cached.sampleId,0) or 0)+1,timeMs=nowMs,
            intervalMs=RV.FORCE_DYNAMIC_IDLE_INTERVAL_MS}
        rvDynamicDriveCache[vehicle] = result
        return result
    end
    local function readGetter(name, field, fallback)
        local fn = motor[name]
        if fn ~= nil then
            local ok, value = pcall(fn, motor)
            if ok and safeNumber(value,nil) ~= nil then return safeNumber(value,fallback) end
        end
        return safeNumber(motor[field], fallback)
    end
    local applied = math.abs(readGetter("getMotorAppliedTorque", "motorAppliedTorque", 0))
    local available = math.abs(readGetter("getMotorAvailableTorque", "motorAvailableTorque", 0))
    local gearRatio = math.abs(readGetter("getGearRatio", "gearRatio", 0))
    local rotSpeed = math.abs(readGetter("getMotorRotSpeed", "motorRotSpeed", 0))
    local rpm = rotSpeed * 30 / math.pi
    local driveDemand = quickDemand
    local source = "GIANTS"
    if applied <= RV.TRACK_DIFF_FORCE_MIN_APPLIED_TORQUE
        and driveDemand > RV.FORCE_DYNAMIC_MIN_DRIVE_DEMAND then
        if motor.getTorque ~= nil then
            local ok, estimated = pcall(motor.getTorque, motor, math.clamp(driveDemand,0,1))
            if ok and safeNumber(estimated,0) > 0 then
                applied = math.abs(safeNumber(estimated,0))
                source = "RPM_CURVE"
            end
        elseif available > 0 then
            applied = available * math.clamp(driveDemand,0,1)
            source = "AVAILABLE"
        end
    end
    local rootTorque = 0
    if applied > RV.TRACK_DIFF_FORCE_MIN_APPLIED_TORQUE
        and gearRatio > RV.TRACK_DIFF_FORCE_MIN_GEAR_RATIO then
        rootTorque = applied * gearRatio
    end
    local speedKmh = math.abs(getVehicleSpeedKmh(vehicle))
    local active = rootTorque > RV.FORCE_DYNAMIC_MIN_ROOT_TORQUE
        and (driveDemand > RV.FORCE_DYNAMIC_MIN_DRIVE_DEMAND or speedKmh > RV_WEAR_SPEED_EPSILON_KMH)
    local result = {active=active,driveDemand=driveDemand,appliedTorque=applied,gearRatio=gearRatio,
        rootTorque=rootTorque,rpm=rpm,source=source,sampleId=(cached ~= nil and safeNumber(cached.sampleId,0) or 0)+1,
        timeMs=nowMs,intervalMs=active and RV.FORCE_DYNAMIC_ACTIVE_INTERVAL_MS or RV.FORCE_DYNAMIC_IDLE_INTERVAL_MS}
    rvDynamicDriveCache[vehicle] = result
    return result
end

local function rvGetDynamicWheelTorqueForceMetrics(wheel, vehicle, d, allowTrackReference)
    if wheel == nil or vehicle == nil or d == nil or d.hasGroundContact ~= true then
        return 0,0,0,0,false,nil
    end
    if d.driven ~= true and allowTrackReference ~= true then return 0,0,0,0,false,nil end
    local snapshot = rvGetDynamicDriveSnapshot(vehicle)
    if snapshot.active ~= true then return 0,0,0,0,false,snapshot end
    local cache = rvDynamicWheelForceCache[wheel]
    if cache ~= nil and cache.vehicle == vehicle and cache.sampleId == snapshot.sampleId then
        return cache.driveForce, cache.peakForce, cache.utilization, cache.rate, cache.active, snapshot
    end
    local shares = rvGetWheelDriveShares(vehicle)
    local wheelIndex = wheel.wheelIndex
    local share = wheelIndex ~= nil and math.max(0, safeNumber(shares[wheelIndex],0)) or 0
    local radius = rvGetCurrentPhysicsWheelRadius(wheel)
    local load = math.max(0, safeNumber(d.load,0))
    local driveForce = 0
    if share > 0 and radius > 0.01 then driveForce = (snapshot.rootTorque * share) / radius end
    local peakForce = 0
    if load > 0 and driveForce > 0 then
        for _, sampleSlip in ipairs(RV.FORCE_WEAR_PEAK_SLIP_SAMPLES) do
            local f = rvComputeLongitudinalTireForce(wheel, sampleSlip, load)
            if f ~= nil then peakForce = math.max(peakForce, f) end
        end
    end
    local rawUtilization = peakForce > 0.000001 and math.max(0, driveForce/peakForce) or 0
    local rate, _, _, utilization = rvGetForceWearRate(rawUtilization, d.load, d.restLoad, d.slip)
    local active = snapshot.active == true and share > 0 and driveForce > 0 and peakForce > 0
    cache = {vehicle=vehicle,sampleId=snapshot.sampleId,driveForce=driveForce,peakForce=peakForce,
        utilization=utilization,rate=rate,active=active}
    rvDynamicWheelForceCache[wheel] = cache
    return driveForce, peakForce, utilization, rate, active, snapshot
end

local function rvGetDynamicTrackTorqueForceMetrics(track, vehicle)
    if track == nil or vehicle == nil then return 0,0,0,0,false,nil end
    local driveTotal, peakTotal = 0,0
    local loadTotal, restTotal, slipTotal, counted = 0,0,0,0
    local shareTotal = 0
    local snapshot = rvGetDynamicDriveSnapshot(vehicle)
    local shares = rvGetWheelDriveShares(vehicle)
    for _, wheel in ipairs(track.referenceWheels or {}) do
        local d = wheelDiagnostic(wheel, vehicle)
        if d ~= nil and d.hasGroundContact == true then
            local driveForce, peakForce = rvGetDynamicWheelTorqueForceMetrics(wheel, vehicle, d, true)
            local wi = wheel.wheelIndex
            local share = wi ~= nil and math.max(0, safeNumber(shares[wi],0)) or 0
            if peakForce > 0 then
                driveTotal = driveTotal + math.max(0,driveForce)
                peakTotal = peakTotal + math.max(0,peakForce)
                loadTotal = loadTotal + math.max(0,safeNumber(d.load,0))
                restTotal = restTotal + math.max(0,safeNumber(d.restLoad,0))
                slipTotal = slipTotal + math.max(0,safeNumber(d.slip,0))
                shareTotal = shareTotal + share
                counted = counted + 1
            end
        end
    end
    if counted <= 0 or peakTotal <= 0 then return driveTotal,peakTotal,0,0,false,snapshot end
    local avgSlip = slipTotal/counted
    local rawUtilization = math.max(0, driveTotal/peakTotal)
    local rate, _, _, utilization = rvGetForceWearRate(rawUtilization,
        loadTotal/counted, restTotal > 0 and restTotal/counted or 0, avgSlip)
    local active = snapshot.active == true and shareTotal > 0 and driveTotal > 0
    return driveTotal,peakTotal,utilization,rate,active,snapshot
end

local function rvGetForceWearDistanceM(distanceM, speedKmh, dtSec, forceActive, driveDemand)
    local realDistance = math.max(0, safeNumber(distanceM,0))
    if realDistance > RV_WEAR_MOVEMENT_EPSILON_M then return realDistance end
    if forceActive == true
        and math.abs(safeNumber(speedKmh,0)) <= RV_WEAR_SPEED_EPSILON_KMH
        and math.abs(safeNumber(driveDemand,0)) > RV.FORCE_DYNAMIC_MIN_DRIVE_DEMAND then
        return (math.max(0, safeNumber(RV.FORCE_STATIONARY_EQUIVALENT_SPEED_KMH,1.0)) / 3.6)
            * math.max(0,safeNumber(dtSec,0))
    end
    return 0
end

local function updateWheelWear(wheel, vehicle, vehicleState, distanceM, speedKmh, dtSec, driveGates, passiveImplement, timeContext)
    if wheel == nil or dtSec <= 0 or vehicleState == nil then return nil end
    local state = getWheelWearState(vehicleState, wheel)
    if state == nil then return nil end
    local d = wheelDiagnostic(wheel, vehicle)
    if d.hasGroundContact ~= true then
        state.lastSlip = safeNumber(d.slip, 0)
        state.lastSlipWearPointsPerSecond = 0
        return state
    end
    local loadFactor = getLoadFactor(d)
    local distanceGroundFactor, distanceClass, runningGearType, distanceWeatherClass = getDistanceGroundFactor(d)
    local slipGroundFactor, slipClass, _, slipWeatherClass = getSlipGroundFactor(d)
    local rotating = getWheelRotationState(wheel)
    if d.wheelRotation == true then rotating = true end
    driveGates = driveGates or getWearDriveGates(vehicle, distanceM, speedKmh, rotating)
    if passiveImplement == true then
        driveGates.allowDistanceWear = math.max(0, safeNumber(distanceM, 0)) > RV_WEAR_MOVEMENT_EPSILON_M
            and math.abs(safeNumber(speedKmh, 0)) > RV_WEAR_SPEED_EPSILON_KMH
        driveGates.allowSlipWear = false
        driveGates.driveInput = 0
    end
    local wearReferenceRateFactor = rvGetWearReferenceRateFactor()
    local baseDistanceWear = driveGates.allowDistanceWear
        and (math.max(0, distanceM) / RV.WEAR_REFERENCE_DISTANCE_M) or 0
    local distanceIncrement = baseDistanceWear * loadFactor * distanceGroundFactor * wearReferenceRateFactor
    local slip = clampFinite(d.slip, 0, RV.WEAR_SLIP_MAX_PERCENT, 0) / 100
    local slipDistanceM = math.max(0, distanceM) * slip
    local slipIntensity = getSlipIntensity(d.slip)
    local slipIncrement = 0
    if slipIntensity > 0 and driveGates.allowSlipWear then
        slipIncrement = (slipDistanceM / RV.WEAR_REFERENCE_DISTANCE_M)
            * loadFactor * slipGroundFactor * slipIntensity * wearReferenceRateFactor
        if distanceM <= RV_WEAR_MOVEMENT_EPSILON_M and speedKmh <= RV_WEAR_SPEED_EPSILON_KMH then
            slipIncrement = (math.min(slipIntensity, 0.75) * dtSec) / 3600
                * loadFactor * slipGroundFactor * wearReferenceRateFactor
        end
    end
    local _, _, _, forceWearRate, forceActive, forceSnapshot =
        rvGetDynamicWheelTorqueForceMetrics(wheel, vehicle, d, false)
    local torqueStress = rvGetVehicleTorqueStress(vehicle)
    local effectiveForceWearRate = math.max(0, safeNumber(forceWearRate,0) * safeNumber(torqueStress.factor,1.0))
    local forceIncrement = 0
    local forceDistanceM = rvGetForceWearDistanceM(distanceM, speedKmh, dtSec, forceActive,
        forceSnapshot ~= nil and forceSnapshot.driveDemand or driveGates.driveInput)
    if passiveImplement ~= true and d.driven == true and forceActive == true
        and forceDistanceM > 0 and effectiveForceWearRate > 0 then
        forceIncrement = (forceDistanceM / RV.WEAR_REFERENCE_DISTANCE_M)
            * effectiveForceWearRate * wearReferenceRateFactor
    end
    local timeIncrement = 0
    if timeContext ~= nil and timeContext.active == true and distanceClass ~= "ROAD" then
        timeIncrement = rvTimeWearNormalizedPerHour(timeContext.ratePointsPerHourAt1000) * (dtSec / 3600)
    end
    state.distanceWear = math.clamp(state.distanceWear + distanceIncrement, 0, RV.WEAR_MAX)
    state.slipWear = math.clamp(state.slipWear + slipIncrement, 0, RV.WEAR_MAX)
    state.timeWear = math.clamp(safeNumber(state.timeWear, 0) + timeIncrement, 0, RV.WEAR_MAX)
    state.forceWear = math.clamp(safeNumber(state.forceWear, 0) + forceIncrement, 0, RV.WEAR_MAX)
    state.effectiveDistanceM = state.effectiveDistanceM + distanceIncrement * RV.WEAR_REFERENCE_DISTANCE_M
    state.slipDistanceM = state.slipDistanceM + slipDistanceM
    state.value = math.clamp(state.distanceWear + state.slipWear + safeNumber(state.timeWear,0) + safeNumber(state.forceWear,0), 0, RV.WEAR_MAX)
    state.lastSlip = safeNumber(d.slip, 0)
    state.lastSlipWearPointsPerSecond = slipIncrement / dtSec * 1000
    state.lastTimeWearPointsPerHour = timeContext ~= nil and safeNumber(timeContext.ratePointsPerHourAt1000, 0) or 0
    state.lastGroundClass = distanceClass or slipClass or "UNKNOWN"
    state.lastWearRunningGearType = runningGearType or "UNKNOWN"
    state.lastWeatherClass = distanceWeatherClass or slipWeatherClass or "DRY"
    state.lastDistanceFactor = distanceGroundFactor
    state.lastSlipFactor = slipGroundFactor
    state.lastLoadFactor = loadFactor
    state.lastDistanceInputM = math.max(0, distanceM)
    state.lastDtSec = dtSec
    state.lastSpeedKmh = speedKmh
    state.lastLoadInput = safeNumber(d.load, 0)
    state.lastRestLoadInput = safeNumber(d.restLoad, 0)
    state.lastSlipInput = safeNumber(d.slip, 0)
    state.lastDriveInput = safeNumber(driveGates.driveInput, 0)
    state.lastWheelRotation = rotating == true
    state.allowDistanceWear = driveGates.allowDistanceWear == true
    state.allowSlipWear = driveGates.allowSlipWear == true
    state.initialized = true
    return state
end

local getAverageWear
local getAverageEffectiveWearDistance

-- TEST2.3.97: crawler roller wear. The existing crawler/running-gear
-- recognition remains authoritative. This second stage only classifies the
-- rotating parts INSIDE an already recognised crawler. GIANTS exposes these
-- parts as crawler.rotatingParts with node/radius/speedScale. The largest
-- rotating part is treated as drive/idler sprocket and excluded; smaller
-- rotating parts are the rubber-coated road rollers. If the structure is
-- ambiguous (fewer than two radii or no clear size difference), roller wear
-- stays data-only and no visual node is guessed.
RV.ROLLER_LIFETIME_FACTOR_MIN = 1.70
RV.ROLLER_LIFETIME_FACTOR_MAX = 2.50

local function rvEnsureRollerState(state)
    if state == nil then return nil end
    if safeNumber(state.rollerLifetimeFactor, 0) <= 0 then
        local r = math.random()
        state.rollerLifetimeFactor = RV.ROLLER_LIFETIME_FACTOR_MIN + r * (RV.ROLLER_LIFETIME_FACTOR_MAX - RV.ROLLER_LIFETIME_FACTOR_MIN)
    end
    state.rollerWear = clampFinite(state.rollerWear, 0, RV.WEAR_MAX, 0)
    state.rollerDistanceM = math.max(0, safeNumber(state.rollerDistanceM, 0))
    return state
end

local function rvClassifyCrawlerRollers(track)
    if track == nil or track.crawler == nil then return nil end
    if track.rollerClassification ~= nil then return track.rollerClassification end
    local parts = track.crawler.rotatingParts
    local result = {rollers={}, excluded={}, confident=false, reason="NO_ROTATING_PARTS"}
    if type(parts) ~= "table" or #parts < 2 then
        if track.leitwolfRollerFallback == true
            and type(track.referenceWheels) == "table"
            and #track.referenceWheels > 0 then
            result.reason = "SPECIAL_LEITWOLF_REFERENCE_WHEELS"
            for index, wheel in ipairs(track.referenceWheels) do
                table.insert(result.rollers, {
                    index = index,
                    node = wheel ~= nil and (wheel.node or wheel.driveNode or wheel.repr) or nil,
                    radius = safeNumber(wheel ~= nil and wheel.radius or nil, 0),
                    referenceWheel = wheel
                })
            end
            result.confident = #result.rollers > 0
            track.rollerClassification = result
            if result.confident and track.rollerClassificationLogged ~= true then
                track.rollerClassificationLogged = true
            end
            return result
        end
        track.rollerClassification = result
        return result
    end
    local maxRadius, minRadius = 0, math.huge
    for _, part in ipairs(parts) do
        local radius = safeNumber(part ~= nil and part.radius or nil, 0)
        if radius > 0 then maxRadius=math.max(maxRadius,radius); minRadius=math.min(minRadius,radius) end
    end
    if maxRadius <= 0 or minRadius == math.huge or maxRadius < minRadius * 1.20 then
        result.reason="AMBIGUOUS_RADII"
        track.rollerClassification=result
        return result
    end
    -- Exclude every part in the largest-radius sprocket/idler class. This is
    -- safer than assuming a fixed XML index and works for left/right variants.
    local sprocketThreshold = maxRadius * 0.90
    for index, part in ipairs(parts) do
        local radius=safeNumber(part ~= nil and part.radius or nil,0)
        local entry={index=index,node=part ~= nil and part.node or nil,radius=radius}
        if radius > 0 and radius < sprocketThreshold then
            table.insert(result.rollers,entry)
        else
            table.insert(result.excluded,entry)
        end
    end
    result.confident=#result.rollers>0 and #result.excluded>0
    result.reason=result.confident and "RADIUS_GROUP" or "NO_SAFE_GROUP"
    track.rollerClassification=result
    if result.confident and track.rollerClassificationLogged ~= true then
        track.rollerClassificationLogged=true
    end
    return result
end

local function rvUpdateRollerWear(track, state, trackDistanceM, driveGates)
    state=rvEnsureRollerState(state)
    if state == nil then return end
    local classification=rvClassifyCrawlerRollers(track)
    state.rollerDetected = classification ~= nil and classification.confident == true
    state.rollerCount = classification ~= nil and #classification.rollers or 0
    -- Pure mileage only: no ground, slip, load, wetness, rain, snow or speed
    -- factor. The global lifetime reference still scales kilometres exactly as
    -- it does for the rest of the selected wear lifetime setting.
    if driveGates ~= nil and driveGates.allowDistanceWear == true and trackDistanceM > 0 then
        local factor=math.max(RV.ROLLER_LIFETIME_FACTOR_MIN, safeNumber(state.rollerLifetimeFactor,RV.ROLLER_LIFETIME_FACTOR_MIN))
        local inc=(trackDistanceM / RV.WEAR_REFERENCE_DISTANCE_M) * rvGetWearReferenceRateFactor() / factor
        state.rollerWear=math.clamp(state.rollerWear+inc,0,RV.WEAR_MAX)
        state.rollerDistanceM=state.rollerDistanceM+trackDistanceM
    end
end

local function updateTrackWear(track, vehicle, vehicleState, distanceM, speedKmh, dtSec, driveGates, passiveImplement, timeContext)
    if track == nil or vehicleState == nil or dtSec <= 0 then return nil end
    local state = getTrackWearState(vehicleState, track)
    if state == nil then return nil end
    local sumLoad, sumRest, sumSlip, count = 0, 0, 0, 0
    for _, wheel in ipairs(track.referenceWheels or {}) do
        local d = wheelDiagnostic(wheel, vehicle)
        if d ~= nil and d.hasGroundContact == true then
            sumLoad = sumLoad + safeNumber(d.load,0)
            sumRest = sumRest + safeNumber(d.restLoad,0)
            sumSlip = sumSlip + safeNumber(d.slip,0)
            count = count + 1
        end
    end
    local hasLocalTrackContact = count > 0
    local d = {
        load = hasLocalTrackContact and (sumLoad/count) or 0,
        restLoad = hasLocalTrackContact and (sumRest/count) or 0,
        slip = hasLocalTrackContact and (sumSlip/count) or 0,
        groundType = nil, isField = false, isMudTerrain = false, wetScale = 0, rainScale = 0,
        snowScale = 0, terrainSnow = false,
        wearRunningGearType = track.wearRunningGearType or "RUBBER_TRACK"
    }
    if hasLocalTrackContact then
        for _, wheel in ipairs(track.referenceWheels or {}) do
            local wd = wheelDiagnostic(wheel, vehicle)
            if wd ~= nil and wd.hasGroundContact == true then
                for k,v in pairs(wd) do d[k] = v end
                d.load = sumLoad/count; d.restLoad = sumRest/count; d.slip = sumSlip/count
                d.wearRunningGearType = track.wearRunningGearType or "RUBBER_TRACK"
                break
            end
        end
    end
    local loadFactor = getLoadFactor(d)
    local distanceGroundFactor, distanceClass, runningGearType, distanceWeatherClass = getDistanceGroundFactor(d)
    local slipGroundFactor, slipClass, _, slipWeatherClass = getSlipGroundFactor(d)
    local rotating = getTrackRotationState(track)
    driveGates = driveGates or getWearDriveGates(vehicle, distanceM, speedKmh, rotating)
    if passiveImplement == true then
        driveGates.allowSlipWear = false
        driveGates.driveInput = 0
    end
    local trackDistanceM = math.max(0, safeNumber(distanceM,0))
    local moved = track.crawler ~= nil and tonumber(track.crawler.movedDistance) or nil
    if moved ~= nil then
        if state.lastCrawlerMovedDistance ~= nil then
            local delta = moved - state.lastCrawlerMovedDistance
            if delta > 0.001 then trackDistanceM = delta end
        end
        state.lastCrawlerMovedDistance = moved
    end
    local wearReferenceRateFactor = rvGetWearReferenceRateFactor()
    local distanceIncrement = hasLocalTrackContact and driveGates.allowDistanceWear
        and ((trackDistanceM / RV.WEAR_REFERENCE_DISTANCE_M) * loadFactor * distanceGroundFactor * wearReferenceRateFactor) or 0
    local slip = clampFinite(d.slip,0,RV.WEAR_SLIP_MAX_PERCENT,0)/100
    local slipDistanceM = trackDistanceM * slip
    local intensity = getSlipIntensity(d.slip)
    local slipIncrement = 0
    if hasLocalTrackContact and intensity > 0 and driveGates.allowSlipWear then
        slipIncrement = (slipDistanceM / RV.WEAR_REFERENCE_DISTANCE_M) * loadFactor * slipGroundFactor * intensity * wearReferenceRateFactor
        if trackDistanceM <= RV_WEAR_MOVEMENT_EPSILON_M and speedKmh <= RV_WEAR_SPEED_EPSILON_KMH then
            slipIncrement = (math.min(intensity,0.75)*dtSec)/3600 * loadFactor * slipGroundFactor * wearReferenceRateFactor
        end
    end
    local _, _, _, forceWearRate, forceActive, forceSnapshot = rvGetDynamicTrackTorqueForceMetrics(track, vehicle)
    local torqueStress = rvGetVehicleTorqueStress(vehicle)
    local effectiveForceWearRate = math.max(0, safeNumber(forceWearRate,0) * safeNumber(torqueStress.factor,1.0))
    local forceIncrement = 0
    local forceDistanceM = rvGetForceWearDistanceM(trackDistanceM, speedKmh, dtSec, forceActive,
        forceSnapshot ~= nil and forceSnapshot.driveDemand or driveGates.driveInput)
    if passiveImplement ~= true and forceActive == true and forceDistanceM > 0 and effectiveForceWearRate > 0 then
        forceIncrement = (forceDistanceM / RV.WEAR_REFERENCE_DISTANCE_M) * effectiveForceWearRate * wearReferenceRateFactor
    end
    local timeIncrement = 0
    if hasLocalTrackContact and timeContext ~= nil and timeContext.active == true and distanceClass ~= "ROAD" then
        timeIncrement = rvTimeWearNormalizedPerHour(timeContext.ratePointsPerHourAt1000) * (dtSec / 3600)
    end
    state.distanceWear = math.clamp(state.distanceWear+distanceIncrement,0,RV.WEAR_MAX)
    state.slipWear = math.clamp(state.slipWear+slipIncrement,0,RV.WEAR_MAX)
    state.timeWear = math.clamp(safeNumber(state.timeWear,0)+timeIncrement,0,RV.WEAR_MAX)
    state.forceWear = math.clamp(safeNumber(state.forceWear,0)+forceIncrement,0,RV.WEAR_MAX)
    state.effectiveDistanceM = state.effectiveDistanceM + distanceIncrement*RV.WEAR_REFERENCE_DISTANCE_M
    state.slipDistanceM = state.slipDistanceM + slipDistanceM
    state.value = math.clamp(state.distanceWear+state.slipWear+safeNumber(state.timeWear,0)+safeNumber(state.forceWear,0),0,RV.WEAR_MAX)
    state.lastSlip = safeNumber(d.slip,0)
    state.lastSlipWearPointsPerSecond = slipIncrement/dtSec*1000
    state.lastTimeWearPointsPerHour = timeContext ~= nil and safeNumber(timeContext.ratePointsPerHourAt1000,0) or 0
    state.lastGroundClass = distanceClass or slipClass or "UNKNOWN"
    state.lastWearRunningGearType = runningGearType or "UNKNOWN"
    state.lastWeatherClass = distanceWeatherClass or slipWeatherClass or "DRY"
    state.lastDistanceFactor = distanceGroundFactor
    state.lastSlipFactor = slipGroundFactor
    state.lastLoadFactor = loadFactor
    state.lastDistanceInputM = trackDistanceM
    state.lastDriveInput = safeNumber(driveGates.driveInput, 0)
    state.lastWheelRotation = rotating == true
    state.allowDistanceWear = driveGates.allowDistanceWear == true
    state.allowSlipWear = driveGates.allowSlipWear == true
    state.lastDtSec = dtSec
    state.lastSpeedKmh = speedKmh
    state.lastLoadInput = safeNumber(d.load,0)
    state.lastRestLoadInput = safeNumber(d.restLoad,0)
    state.lastSlipInput = safeNumber(d.slip,0)
    state.initialized = true
    rvUpdateRollerWear(track, state, trackDistanceM, driveGates)
    return state
end

local function getWearManifest(manifest)
    return manifest ~= nil and manifest.tireWearManifest or {wheels={}, tracks={}, wheelCount=0, trackCount=0, totalWearObjectCount=0}
end

local function updateWear(vehicle, manifest, distanceM, speedKmh, dtSec, vehicleState, passiveImplement)
    if dtSec <= 0 or manifest == nil or vehicleState == nil then return end
    local ready = true
    if passiveImplement ~= true then
        ready = updateVehicleWearReady(vehicle, vehicleState, dtSec)
        if not ready then return end
    end
    local timeContext = rvUpdateTimeWearContext(vehicle, vehicleState, distanceM, speedKmh, dtSec, passiveImplement, manifest)
    local wheelCount = 0
    local totalDistanceIncrement, totalSlipIncrement, totalTimeIncrement, totalForceIncrement = 0,0,0,0
    local function processWheel(wheel)
        local before = getWheelWearState(vehicleState, wheel)
        local oldDistance = before ~= nil and safeNumber(before.distanceWear,0) or 0
        local oldSlip = before ~= nil and safeNumber(before.slipWear,0) or 0
        local oldTime = before ~= nil and safeNumber(before.timeWear,0) or 0
        local oldForce = before ~= nil and safeNumber(before.forceWear,0) or 0
        local state = updateWheelWear(wheel, vehicle, vehicleState, distanceM, speedKmh, dtSec, nil, passiveImplement, timeContext)
        if state ~= nil then
            wheelCount = wheelCount + 1
            totalDistanceIncrement = totalDistanceIncrement + math.max(0, safeNumber(state.distanceWear,0)-oldDistance)
            totalSlipIncrement = totalSlipIncrement + math.max(0, safeNumber(state.slipWear,0)-oldSlip)
            totalTimeIncrement = totalTimeIncrement + math.max(0, safeNumber(state.timeWear,0)-oldTime)
            totalForceIncrement = totalForceIncrement + math.max(0, safeNumber(state.forceWear,0)-oldForce)
        end
    end
    local wearManifest = getWearManifest(manifest)
    for _, wheel in ipairs(wearManifest.wheels or {}) do processWheel(wheel) end
    for _, track in ipairs(wearManifest.tracks or {}) do
        local before = getTrackWearState(vehicleState, track)
        local oldDistance = before ~= nil and safeNumber(before.distanceWear,0) or 0
        local oldSlip = before ~= nil and safeNumber(before.slipWear,0) or 0
        local oldTime = before ~= nil and safeNumber(before.timeWear,0) or 0
        local oldForce = before ~= nil and safeNumber(before.forceWear,0) or 0
        local st = updateTrackWear(track, vehicle, vehicleState, distanceM, speedKmh, dtSec, nil, passiveImplement, timeContext)
        if st ~= nil then
            wheelCount = wheelCount + 1
            totalDistanceIncrement = totalDistanceIncrement + math.max(0, safeNumber(st.distanceWear,0)-oldDistance)
            totalSlipIncrement = totalSlipIncrement + math.max(0, safeNumber(st.slipWear,0)-oldSlip)
            totalTimeIncrement = totalTimeIncrement + math.max(0, safeNumber(st.timeWear,0)-oldTime)
            totalForceIncrement = totalForceIncrement + math.max(0, safeNumber(st.forceWear,0)-oldForce)
        end
    end
    vehicleState.totalDistanceWear = math.max(0, safeNumber(vehicleState.totalDistanceWear,0)+totalDistanceIncrement)
    vehicleState.totalSlipWear = math.max(0, safeNumber(vehicleState.totalSlipWear,0)+totalSlipIncrement)
    vehicleState.totalTimeWear = math.max(0, safeNumber(vehicleState.totalTimeWear,0)+totalTimeIncrement)
    vehicleState.totalForceWear = math.max(0, safeNumber(vehicleState.totalForceWear,0)+totalForceIncrement)
    vehicleState.totalWear = getAverageWear(manifest, vehicleState)
    vehicleState.totalEffectiveWearDistanceM = getAverageEffectiveWearDistance(manifest, vehicleState)
    vehicleState.lastWheelCount = wheelCount
end

local function getAverageWearComponents(manifest, vehicleState)
    local distanceSum, slipSum, timeSum, forceSum, count = 0,0,0,0,0
    if manifest == nil or vehicleState == nil then return 0,0,0,0,0 end
    local wm=getWearManifest(manifest)
    for _,wheel in ipairs(wm.wheels or {}) do
        local st=getWheelWearState(vehicleState,wheel)
        if st~=nil then
            distanceSum=distanceSum+safeNumber(st.distanceWear,0)
            slipSum=slipSum+safeNumber(st.slipWear,0)
            timeSum=timeSum+safeNumber(st.timeWear,0)
            forceSum=forceSum+safeNumber(st.forceWear,0)
            count=count+1
        end
    end
    for _,track in ipairs(wm.tracks or {}) do
        local st=getTrackWearState(vehicleState,track)
        if st~=nil then
            distanceSum=distanceSum+safeNumber(st.distanceWear,0)
            slipSum=slipSum+safeNumber(st.slipWear,0)
            timeSum=timeSum+safeNumber(st.timeWear,0)
            forceSum=forceSum+safeNumber(st.forceWear,0)
            count=count+1
        end
    end
    return count>0 and distanceSum/count or 0, count>0 and slipSum/count or 0,
        count>0 and timeSum/count or 0, count>0 and forceSum/count or 0, count
end

getAverageEffectiveWearDistance = function(manifest, vehicleState)
    local sum,count=0,0
    if manifest==nil or vehicleState==nil then return 0 end
    local wm=getWearManifest(manifest)
    for _,wheel in ipairs(wm.wheels or {}) do local st=getWheelWearState(vehicleState,wheel); if st~=nil then sum=sum+safeNumber(st.effectiveDistanceM,0); count=count+1 end end
    for _,track in ipairs(wm.tracks or {}) do local st=getTrackWearState(vehicleState,track); if st~=nil then sum=sum+safeNumber(st.effectiveDistanceM,0); count=count+1 end end
    return count>0 and sum/count or 0
end

getAverageWear = function(manifest, vehicleState)
    local sum,count=0,0
    if manifest==nil or vehicleState==nil then return 0 end
    local function add(st)
        if st~=nil then sum=sum+math.clamp(safeNumber(st.distanceWear,0)+safeNumber(st.slipWear,0)+safeNumber(st.timeWear,0)+safeNumber(st.forceWear,0),0,RV.WEAR_MAX); count=count+1 end
    end
    local wm=getWearManifest(manifest)
    for _,wheel in ipairs(wm.wheels or {}) do add(getWheelWearState(vehicleState,wheel)) end
    for _,track in ipairs(wm.tracks or {}) do add(getTrackWearState(vehicleState,track)) end
    return count>0 and sum/count or 0
end

local function getAverageOwnWear(manifest, vehicleState)
    local sum,count=0,0
    if manifest==nil or vehicleState==nil then return 0 end
    local wm=getWearManifest(manifest)
    for _,wheel in ipairs(wm.wheels or {}) do local st=getWheelWearState(vehicleState,wheel); if st~=nil then sum=sum+math.clamp(safeNumber(st.distanceWear,0)+safeNumber(st.slipWear,0)+safeNumber(st.timeWear,0)+safeNumber(st.forceWear,0),0,RV.WEAR_MAX); count=count+1 end end
    for _,track in ipairs(wm.tracks or {}) do local st=getTrackWearState(vehicleState,track); if st~=nil then sum=sum+math.clamp(safeNumber(st.distanceWear,0)+safeNumber(st.slipWear,0)+safeNumber(st.timeWear,0)+safeNumber(st.forceWear,0),0,RV.WEAR_MAX); count=count+1 end end
    return count>0 and sum/count or 0
end

-- TEST2.3.128:
-- IMPORTANT LUA SCOPE FIX.
-- This workshop block must live AFTER all local helper definitions it calls.
-- In .127 it was placed too early, so rvClassifyCrawlerRollers,
-- rvEnsureRollerState and getAverageOwnWear resolved as nil at runtime.
local function rvWorkshopResetRollers(vehicle,state)
    local wm=getOrBuildTireWearManifest(vehicle)
    if wm==nil then return 0 end
    local n=0
    for _,track in ipairs(wm.tracks or {}) do
        local st=getTrackWearState(state,track)
        local c=rvClassifyCrawlerRollers(track)
        if st~=nil then
            rvEnsureRollerState(st)
            local detected = c~=nil and c.confident==true and #(c.rollers or {})>0
            if detected or safeNumber(st.rollerCount,0)>0 or st.rollerDetected==true then
                local before=safeNumber(st.rollerWear,0)
                st.rollerWear=0
                st.rollerDistanceM=0
                st.rollerDetected=detected or st.rollerDetected==true
                st.rollerCount=detected and #(c.rollers or {}) or math.max(0,math.floor(safeNumber(st.rollerCount,0)))
                n=n+math.max(1,st.rollerCount)
            end
        end
    end
    return n
end

local function rvWorkshopResetWheels(vehicle,state)
    local wm=getOrBuildTireWearManifest(vehicle)
    if wm==nil then return 0 end
    local n=0
    for _,wheel in ipairs(wm.wheels or {}) do
        local st=getWheelWearState(state,wheel)
        if st~=nil then
            local before=safeNumber(st.distanceWear,0)+safeNumber(st.slipWear,0)+safeNumber(st.timeWear,0)+safeNumber(st.forceWear,0)
            st.value=0
            st.distanceWear=0
            st.slipWear=0
            st.timeWear=0
            st.forceWear=0
            st.effectiveDistanceM=0
            st.slipDistanceM=0
            st.lastSlip=0
            st.lastSlipWearPointsPerSecond=0
            st.lastGroundClass="WORKSHOP-WHEEL-RESET"
            st.lastDistanceFactor=1
            st.lastSlipFactor=1
            st.lastLoadFactor=1
            st.lastDistanceInputM=0
            st.lastDtSec=0
            st.lastSpeedKmh=0
            st.lastLoadInput=0
            st.lastRestLoadInput=0
            st.lastSlipInput=0
            st.initialized=false
            n=n+1
        end
    end
    return n
end

local function rvWorkshopResetTracks(vehicle,state)
    local wm=getOrBuildTireWearManifest(vehicle); if wm==nil then return 0 end
    local n=0
    for _,track in ipairs(wm.tracks or {}) do
        local st=getTrackWearState(state,track)
        if st~=nil then
            st.value=0; st.distanceWear=0; st.slipWear=0; st.timeWear=0; st.forceWear=0
            st.effectiveDistanceM=0; st.slipDistanceM=0
            st.lastSlip=0; st.lastSlipWearPointsPerSecond=0
            st.lastCrawlerMovedDistance=nil; st.initialized=false; n=n+1
        end
    end
    return n
end

function ReifenVerschleissCore.resetRunningGearWorkshop(vehicle,mode,reason)
    if vehicle==nil or not isRelevantPlayerVehicle(vehicle) then return false end
    local state=getVehicleWearState(vehicle); if state==nil then return false end
    mode=tostring(mode or "ALL")
    if mode=="ALL" then
        local ok=resetVehicleWearState(vehicle,reason or "RP-WORKSHOP-ALL")
        if ok~=true then return false end
        state=getVehicleWearState(vehicle); rvWorkshopResetRollers(vehicle,state)
        return true
    end
    local n=0
    if mode=="WHEELS" then
        n=rvWorkshopResetWheels(vehicle,state)
    elseif mode=="ROLLERS" then
        n=rvWorkshopResetRollers(vehicle,state)
    elseif mode=="TRACKS" then
        n=rvWorkshopResetTracks(vehicle,state)
    end
    if n<=0 then return false end
    local manifest=getOrBuildManifest(vehicle)
    if manifest~=nil then
        manifest.tireWearManifest=getOrBuildTireWearManifest(vehicle)
        state.totalWear=math.clamp(getAverageOwnWear(manifest,state),0,RV.WEAR_MAX)
    end
    if (mode=="TRACKS" or mode=="WHEELS") and ReifenVerschleissVisual~=nil
        and ReifenVerschleissVisual.refreshVehicleWearVisualsImmediate~=nil then
        -- Refresh from the remaining OWN-WEAR states. This resets the selected
        -- component visually while preserving the untouched component states.
        pcall(ReifenVerschleissVisual.refreshVehicleWearVisualsImmediate,vehicle)
    end
    if ReifenVerschleissCore.publishHudSnapshot~=nil then
        pcall(ReifenVerschleissCore.publishHudSnapshot)
    end
    return true
end

function ReifenVerschleissCore.resetVehicleWear(vehicle, reason)
    return resetVehicleWearState(vehicle, reason)
end



-- ============================================================================
-- OWN-WEAR SAVEGAME PERSISTENCE (vehicles.xml, no sidecar)
--
-- The data is written into the exact GIANTS vehicle node that already belongs
-- to the concrete vehicle/trailer/implement. This removes the former
-- tempsavegame/sidecar timing problem and also removes the need to match a
-- second file back to a vehicle by runtime ids.
-- ============================================================================
local RV_SAVE_BASE_SUFFIX = ".reifenVerschleiss"

local function readSavedWearStateFromVehicleSavegame(savegame)
    if savegame == nil or savegame.xmlFile == nil or savegame.key == nil then
        return nil
    end

    local xmlFile = savegame.xmlFile
    local baseKey = savegame.key .. RV_SAVE_BASE_SUFFIX
    if not xmlFile:hasProperty(baseKey) then
        return nil
    end

    local saved = {
        totalDistanceWear = xmlFile:getValue(baseKey .. "#totalDistanceWear", 0),
        totalSlipWear = xmlFile:getValue(baseKey .. "#totalSlipWear", 0),
        totalTimeWear = xmlFile:getValue(baseKey .. "#totalTimeWear", 0),
        totalForceWear = xmlFile:getValue(baseKey .. "#totalForceWear", 0),
        totalWear = xmlFile:getValue(baseKey .. "#totalWear", 0),
        totalEffectiveWearDistanceM = xmlFile:getValue(baseKey .. "#totalEffectiveWearDistanceM", 0),
        wheels = {},
        tracks = {},
        tracksByIndex = {},
        trackList = {}
    }

    for _, wheelKey in xmlFile:iterator(baseKey .. ".wheel") do
        local key = xmlFile:getValue(wheelKey .. "#key")
        if key ~= nil then
            local distanceWear = xmlFile:getValue(wheelKey .. "#distanceWear", 0)
            local slipWear = xmlFile:getValue(wheelKey .. "#slipWear", 0)
            local timeWear = xmlFile:getValue(wheelKey .. "#timeWear", 0)
            local forceWear = xmlFile:getValue(wheelKey .. "#forceWear")

            -- 1.2.2.64 registered #forceWear in the savegame schema but did
            -- not actually write it. Preserve the wear already visible in
            -- those saves by reconstructing the missing per-wheel FORCE share
            -- from the stored totalWear. From 1.2.2.65 onward #forceWear is
            -- written explicitly, so this path is legacy migration only.
            if forceWear == nil then
                local totalWear = xmlFile:getValue(wheelKey .. "#totalWear")
                if totalWear ~= nil then
                    forceWear = math.max(0, safeNumber(totalWear, 0) - safeNumber(distanceWear, 0) - safeNumber(slipWear, 0) - safeNumber(timeWear, 0))
                else
                    forceWear = 0
                end
            end

            saved.wheels[tostring(key)] = {
                distanceWear = distanceWear,
                slipWear = slipWear,
                timeWear = timeWear,
                forceWear = forceWear,
                effectiveDistanceM = xmlFile:getValue(wheelKey .. "#effectiveDistanceM", 0),
                slipDistanceM = xmlFile:getValue(wheelKey .. "#slipDistanceM", 0),
                lastSlip = xmlFile:getValue(wheelKey .. "#lastSlip", 0),
                lastSlipWearPointsPerSecond = xmlFile:getValue(wheelKey .. "#lastSlipWearPointsPerSecond", 0),
                lastGroundClass = xmlFile:getValue(wheelKey .. "#lastGroundClass", "UNKNOWN"),
                lastDistanceFactor = xmlFile:getValue(wheelKey .. "#lastDistanceFactor", 1),
                lastSlipFactor = xmlFile:getValue(wheelKey .. "#lastSlipFactor", 1),
                lastLoadFactor = xmlFile:getValue(wheelKey .. "#lastLoadFactor", 1)
            }
        end
    end

    local trackSequence = 0
    for _, trackKey in xmlFile:iterator(baseKey .. ".track") do
        trackSequence = trackSequence + 1
        local key = xmlFile:getValue(trackKey .. "#key")
        local savedIndex = xmlFile:getValue(trackKey .. "#index")
        local distanceWear = xmlFile:getValue(trackKey .. "#distanceWear", 0)
        local slipWear = xmlFile:getValue(trackKey .. "#slipWear", 0)
        local timeWear = xmlFile:getValue(trackKey .. "#timeWear", 0)
        local forceWear = xmlFile:getValue(trackKey .. "#forceWear")
        if forceWear == nil then
            local totalWear = xmlFile:getValue(trackKey .. "#totalWear")
            if totalWear ~= nil then
                forceWear = math.max(0, safeNumber(totalWear, 0) - safeNumber(distanceWear, 0) - safeNumber(slipWear, 0) - safeNumber(timeWear, 0))
            else
                forceWear = 0
            end
        end

        local entry = {
            index = savedIndex,
            side = xmlFile:getValue(trackKey .. "#side"),
            distanceWear = distanceWear,
            slipWear = slipWear,
            timeWear = timeWear,
            forceWear = forceWear,
            effectiveDistanceM = xmlFile:getValue(trackKey .. "#effectiveDistanceM", 0),
            slipDistanceM = xmlFile:getValue(trackKey .. "#slipDistanceM", 0),
            lastSlip = xmlFile:getValue(trackKey .. "#lastSlip", 0),
            lastSlipWearPointsPerSecond = xmlFile:getValue(trackKey .. "#lastSlipWearPointsPerSecond", 0),
            lastGroundClass = xmlFile:getValue(trackKey .. "#lastGroundClass", "UNKNOWN"),
            lastDistanceFactor = xmlFile:getValue(trackKey .. "#lastDistanceFactor", 1),
            lastSlipFactor = xmlFile:getValue(trackKey .. "#lastSlipFactor", 1),
            rollerWear = xmlFile:getValue(trackKey .. "#rollerWear", 0),
            rollerLifetimeFactor = xmlFile:getValue(trackKey .. "#rollerLifetimeFactor", 0),
            rollerDistanceM = xmlFile:getValue(trackKey .. "#rollerDistanceM", 0),
            lastLoadFactor = xmlFile:getValue(trackKey .. "#lastLoadFactor", 1)
        }
        if key ~= nil then
            saved.tracks[tostring(key)] = entry
        end
        if type(savedIndex) == "number" then
            saved.tracksByIndex[math.floor(savedIndex)] = entry
        end
        saved.trackList[trackSequence] = entry
    end

    return saved
end

function ReifenVerschleissCore.captureVehicleWearSavegame(vehicle, savegame)
    if vehicle == nil then return end
    capturedVehicleWearSavegame[vehicle] = true
    pendingSavedWearStates[vehicle] = readSavedWearStateFromVehicleSavegame(savegame)
end

local function applyPendingSavedState(vehicle, state)
    if vehicle == nil or state == nil or state.loadedFromSavegame then return false end

    -- The persistence specialization captures the concrete vehicle savegame
    -- node during its native onLoad(savegame) event. Never finalize before
    -- that native specialization callback has run.
    if capturedVehicleWearSavegame[vehicle] ~= true then
        return false
    end

    local saved = pendingSavedWearStates[vehicle]
    if saved == nil then
        state.loadedFromSavegame = true
        return true
    end

    state.totalDistanceWear = clampFinite(saved.totalDistanceWear, 0, RV.WEAR_MAX * 10, 0)
    state.totalSlipWear = clampFinite(saved.totalSlipWear, 0, RV.WEAR_MAX * 10, 0)
    state.totalTimeWear = clampFinite(saved.totalTimeWear, 0, RV.WEAR_MAX * 10, 0)
    state.totalForceWear = clampFinite(saved.totalForceWear, 0, RV.WEAR_MAX * 10, 0)
    state.totalWear = clampFinite(saved.totalWear, 0, RV.WEAR_MAX, 0)
    state.totalEffectiveWearDistanceM = math.max(0, safeNumber(saved.totalEffectiveWearDistanceM, 0))

    state.wheelWear = {}
    for wheelKey, savedWheel in pairs(saved.wheels or {}) do
        local d = clampFinite(savedWheel.distanceWear, 0, RV.WEAR_MAX, 0)
        local sl = clampFinite(savedWheel.slipWear, 0, RV.WEAR_MAX, 0)
        local tw = clampFinite(savedWheel.timeWear, 0, RV.WEAR_MAX, 0)
        local fw = clampFinite(savedWheel.forceWear, 0, RV.WEAR_MAX, 0)
        state.wheelWear[tostring(wheelKey)] = {
            value = math.clamp(d + sl + tw + fw, 0, RV.WEAR_MAX),
            distanceWear = d, slipWear = sl, timeWear = tw, forceWear = fw,
            effectiveDistanceM = math.max(0, safeNumber(savedWheel.effectiveDistanceM, 0)),
            slipDistanceM = math.max(0, safeNumber(savedWheel.slipDistanceM, 0)),
            lastSlip = clampFinite(savedWheel.lastSlip, 0, 100, 0),
            lastSlipWearPointsPerSecond = math.max(0, safeNumber(savedWheel.lastSlipWearPointsPerSecond, 0)),
            lastGroundClass = tostring(savedWheel.lastGroundClass or "UNKNOWN"),
            lastDistanceFactor = safeNumber(savedWheel.lastDistanceFactor, 1),
            lastSlipFactor = safeNumber(savedWheel.lastSlipFactor, 1),
            lastLoadFactor = safeNumber(savedWheel.lastLoadFactor, 1),
            initialized = true
        }
    end

    -- Tracks are the persistence unit for both rubber crawlers and metal/steel
    -- crawler running gear. Runtime track.key contains geometry/position data
    -- and is deliberately NOT used as the persistent identity anymore because
    -- those positions can differ after a reload. Persistence maps by the
    -- stable crawler order/index from spec_crawlers.crawlers. For savegames
    -- created by TEST2.3.90, where #index did not exist yet, the XML sequence
    -- is used as a compatibility fallback.
    state.trackWear = {}
    local currentWearManifest = getOrBuildTireWearManifest(vehicle)
    for sequence, track in ipairs((currentWearManifest and currentWearManifest.tracks) or {}) do
        local currentIndex = math.floor(safeNumber(track.index, sequence))
        local savedTrack = (saved.tracksByIndex or {})[currentIndex]
        if savedTrack == nil and track.key ~= nil then
            savedTrack = (saved.tracks or {})[tostring(track.key)]
        end
        if savedTrack == nil then
            savedTrack = (saved.trackList or {})[sequence]
        end

        if savedTrack ~= nil then
            local d = clampFinite(savedTrack.distanceWear, 0, RV.WEAR_MAX, 0)
            local sl = clampFinite(savedTrack.slipWear, 0, RV.WEAR_MAX, 0)
            local tw = clampFinite(savedTrack.timeWear, 0, RV.WEAR_MAX, 0)
            local fw = clampFinite(savedTrack.forceWear, 0, RV.WEAR_MAX, 0)
            local runtimeKey = track.key or string.format("TRACK|%s|%d", tostring(track.side or "?"), currentIndex)
            state.trackWear[runtimeKey] = {
                value = math.clamp(d + sl + tw + fw, 0, RV.WEAR_MAX),
                distanceWear = d, slipWear = sl, timeWear = tw, forceWear = fw,
                effectiveDistanceM = math.max(0, safeNumber(savedTrack.effectiveDistanceM, 0)),
                slipDistanceM = math.max(0, safeNumber(savedTrack.slipDistanceM, 0)),
                lastSlip = clampFinite(savedTrack.lastSlip, 0, 100, 0),
                lastSlipWearPointsPerSecond = math.max(0, safeNumber(savedTrack.lastSlipWearPointsPerSecond, 0)),
                lastGroundClass = tostring(savedTrack.lastGroundClass or "UNKNOWN"),
                lastDistanceFactor = safeNumber(savedTrack.lastDistanceFactor, 1),
                lastSlipFactor = safeNumber(savedTrack.lastSlipFactor, 1),
                lastLoadFactor = safeNumber(savedTrack.lastLoadFactor, 1),
                rollerWear = clampFinite(savedTrack.rollerWear, 0, RV.WEAR_MAX, 0),
                rollerLifetimeFactor = clampFinite(savedTrack.rollerLifetimeFactor, RV.ROLLER_LIFETIME_FACTOR_MIN, RV.ROLLER_LIFETIME_FACTOR_MAX, 0),
                rollerDistanceM = math.max(0, safeNumber(savedTrack.rollerDistanceM, 0)),
                lastCrawlerMovedDistance = nil,
                initialized = true
            }
        end
    end

    pendingSavedWearStates[vehicle] = nil
    state.loadedFromSavegame = true

    local wheelCount, trackCount = 0, 0
    for _ in pairs(saved.wheels or {}) do wheelCount = wheelCount + 1 end
    for _ in pairs(saved.tracks or {}) do trackCount = trackCount + 1 end
    return true
end

local function writeWearStateValues(xmlFile, key, st)
    xmlFile:setValue(key .. "#distanceWear", safeNumber(st.distanceWear, 0))
    xmlFile:setValue(key .. "#slipWear", safeNumber(st.slipWear, 0))
    xmlFile:setValue(key .. "#timeWear", safeNumber(st.timeWear, 0))
    xmlFile:setValue(key .. "#forceWear", safeNumber(st.forceWear, 0))
    xmlFile:setValue(key .. "#totalWear", math.clamp(safeNumber(st.distanceWear, 0) + safeNumber(st.slipWear, 0) + safeNumber(st.timeWear, 0) + safeNumber(st.forceWear, 0), 0, RV.WEAR_MAX))
    xmlFile:setValue(key .. "#effectiveDistanceM", safeNumber(st.effectiveDistanceM, 0))
    xmlFile:setValue(key .. "#slipDistanceM", safeNumber(st.slipDistanceM, 0))
    xmlFile:setValue(key .. "#lastSlip", safeNumber(st.lastSlip, 0))
    xmlFile:setValue(key .. "#lastSlipWearPointsPerSecond", safeNumber(st.lastSlipWearPointsPerSecond, 0))
    xmlFile:setValue(key .. "#lastGroundClass", tostring(st.lastGroundClass or "UNKNOWN"))
    xmlFile:setValue(key .. "#lastDistanceFactor", safeNumber(st.lastDistanceFactor, 1))
    xmlFile:setValue(key .. "#lastSlipFactor", safeNumber(st.lastSlipFactor, 1))
    xmlFile:setValue(key .. "#lastLoadFactor", safeNumber(st.lastLoadFactor, 1))
end

local function isOwnedFarmVehicleForPersistence(vehicle)
    if vehicle == nil or vehicle.isDeleted == true or vehicle.isDeleting == true then
        return false, "INVALID"
    end
    if rvIsExplicitlyExcludedVehicle(vehicle) then
        return false, "EXCLUDED_INCOMPATIBLE"
    end

    -- Persist only vehicles that are demonstrably assigned to the CURRENT
    -- player's farm. This is the primary ownership proof and mirrors GIANTS'
    -- own garage/selling-point ownership check (ownerFarmId == playerFarmId).
    -- The test happens before any wear manifest/state is built, so foreign/map
    -- vehicles are not evaluated by the OWN-WEAR persistence code.
    local playerFarmId = getPlayerFarmId()
    if type(playerFarmId) ~= "number" then
        return false, "NO_PLAYER_FARM"
    end

    local ownerFarmId = getVehicleOwnerFarmIdSafe(vehicle)
    if type(ownerFarmId) ~= "number" or ownerFarmId ~= playerFarmId then
        return false, "FOREIGN_OR_UNOWNED_FARM"
    end

    local propertyState = getVehiclePropertyStateSafe(vehicle)
    if isMissionVehicleState(vehicle, propertyState) then
        return false, "MISSION"
    end
    if hasMissionVehicleInAttacherChain(vehicle) then
        return false, "MISSION_ATTACHER_CHAIN"
    end

    -- GIANTS BuyVehicleData uses OWNED for purchases and LEASED for normal
    -- leased/rented farm vehicles. Both are part of the user's farm fleet and
    -- therefore must persist. Everything else fails closed.
    if VehiclePropertyState ~= nil then
        local ownedState = VehiclePropertyState.OWNED
        local leasedState = VehiclePropertyState.LEASED
        if propertyState == ownedState then
            return true, string.format("OWNED_FARM_%d", ownerFarmId)
        end
        if propertyState == leasedState then
            return true, string.format("LEASED_FARM_%d", ownerFarmId)
        end
        return false, string.format("UNSUPPORTED_PROPERTY_STATE_%s", tostring(propertyState))
    end

    -- Defensive fallback for an environment where the enum is unavailable:
    -- exact farm ownership is still known, but mission-bound objects were
    -- already rejected above.
    return true, string.format("FARM_%d", ownerFarmId)
end

function ReifenVerschleissCore.saveVehicleWearToSavegame(vehicle, xmlFile, vehicleKey)
    if vehicle == nil or xmlFile == nil or vehicleKey == nil then return end

    local persist, persistReason = isOwnedFarmVehicleForPersistence(vehicle)
    if not persist then
        return
    end

    local wearManifest = getOrBuildTireWearManifest(vehicle)
    if wearManifest == nil or safeNumber(wearManifest.totalWearObjectCount, 0) <= 0 then
        return
    end

    local state = getVehicleWearState(vehicle)
    if state == nil then return end
    applyPendingSavedState(vehicle, state)

    local manifest = getOrBuildManifest(vehicle)
    if manifest == nil then return end
    manifest.tireWearManifest = wearManifest
    state.totalWear = getAverageOwnWear(manifest, state)
    state.totalEffectiveWearDistanceM = getAverageEffectiveWearDistance(manifest, state)

    local baseKey = vehicleKey .. RV_SAVE_BASE_SUFFIX
    xmlFile:setValue(baseKey .. "#version", RV.SAVE_SCHEMA_VERSION)
    xmlFile:setValue(baseKey .. "#totalDistanceWear", safeNumber(state.totalDistanceWear, 0))
    xmlFile:setValue(baseKey .. "#totalSlipWear", safeNumber(state.totalSlipWear, 0))
    xmlFile:setValue(baseKey .. "#totalTimeWear", safeNumber(state.totalTimeWear, 0))
    xmlFile:setValue(baseKey .. "#totalForceWear", safeNumber(state.totalForceWear, 0))
    xmlFile:setValue(baseKey .. "#totalWear", safeNumber(state.totalWear, 0))
    xmlFile:setValue(baseKey .. "#totalEffectiveWearDistanceM", safeNumber(state.totalEffectiveWearDistanceM, 0))

    -- Save in manifest order, not hash-table order. Every concrete wheel gets
    -- exactly one record with its runtime/persistence key.
    local wheelCount = 0
    for _, wheel in ipairs(wearManifest.wheels or {}) do
        local st = getWheelWearState(state, wheel)
        local wearKey = getWearKey(wheel)
        if st ~= nil and wearKey ~= nil then
            local key = string.format("%s.wheel(%d)", baseKey, wheelCount)
            xmlFile:setValue(key .. "#key", tostring(wearKey))
            writeWearStateValues(xmlFile, key, st)
            wheelCount = wheelCount + 1
        end
    end

    -- Rubber tracks and metal/steel crawler running gear are both represented
    -- by the track entries of the tire-wear manifest and are persisted here.
    local trackCount = 0
    for sequence, track in ipairs(wearManifest.tracks or {}) do
        local st = getTrackWearState(state, track)
        if st ~= nil then
            local stableIndex = math.floor(safeNumber(track.index, sequence))
            local key = string.format("%s.track(%d)", baseKey, trackCount)
            xmlFile:setValue(key .. "#key", string.format("TRACK_INDEX|%d", stableIndex))
            xmlFile:setValue(key .. "#index", stableIndex)
            xmlFile:setValue(key .. "#side", tostring(track.side or "UNKNOWN"))
            writeWearStateValues(xmlFile, key, st)
            rvEnsureRollerState(st)
            xmlFile:setValue(key .. "#rollerWear", safeNumber(st.rollerWear, 0))
            xmlFile:setValue(key .. "#rollerLifetimeFactor", safeNumber(st.rollerLifetimeFactor, 0))
            xmlFile:setValue(key .. "#rollerDistanceM", safeNumber(st.rollerDistanceM, 0))
            trackCount = trackCount + 1
        end
    end

end

function ReifenVerschleissCore.applyCapturedVehicleWearSavegame(vehicle)
    if vehicle == nil then return false end
    local state = getVehicleWearState(vehicle)
    if state == nil then return false end
    return applyPendingSavedState(vehicle, state)
end

-- ============================================================================
-- DIRECT HUD PUBLICATION
-- ============================================================================
local function rvWriteHudSnapshot(target, valid, wear01, attachedCount, attachedWear01)
    if target == nil then return end
    target._FS25_RV_OWN_WEAR_VALID = valid == true
    target._FS25_RV_OWN_WEAR01 = math.clamp(safeNumber(wear01, 0), 0, RV.WEAR_MAX)
    target._FS25_RV_ATTACHED_WEAR_COUNT = math.max(0, math.floor(safeNumber(attachedCount, 0)))
    target._FS25_RV_ATTACHED_WEAR01 = math.clamp(safeNumber(attachedWear01, 0), 0, RV.WEAR_MAX)
end

-- TEST2.3.119: read-only running-gear HUD bridge.
-- This never changes wear. It only publishes the already existing OWN-WEAR
-- states so Lights Symbol HUD can render tire / rubber-track / steel-track
-- symbols in the same slot. For track and roller groups the HIGHEST value
-- is deliberately used: one critically worn component must never disappear
-- inside an average.
local function rvGetWheelOnlyHudState(vehicle)
    local result = {valid=false, wear01=0, count=0}
    if vehicle == nil then return result end
    local wm = getOrBuildTireWearManifest(vehicle)
    local state = getVehicleWearState(vehicle)
    if wm == nil or state == nil then return result end
    applyPendingSavedState(vehicle, state)

    for _, wheel in ipairs(wm.wheels or {}) do
        local st = getWheelWearState(state, wheel)
        if st ~= nil then
            result.valid = true
            result.count = result.count + 1
            result.wear01 = math.max(result.wear01, math.clamp(
                safeNumber(st.distanceWear,0) + safeNumber(st.slipWear,0) + safeNumber(st.timeWear,0) + safeNumber(st.forceWear,0),
                0, RV.WEAR_MAX))
        end
    end
    return result
end

local function rvGetRunningGearHudState(vehicle)
    local result = {
        kind = "TIRE",
        trackValid = false,
        trackWear01 = 0,
        rollerValid = false,
        rollerWear01 = 0
    }
    if vehicle == nil then return result end

    local wearManifest = getOrBuildTireWearManifest(vehicle)
    if wearManifest == nil or wearManifest.tracks == nil or #wearManifest.tracks <= 0 then
        return result
    end

    local state = getVehicleWearState(vehicle)
    if state == nil then return result end
    applyPendingSavedState(vehicle, state)

    result.kind = "RUBBER_TRACK"
    result.trackValid = true

    for _, track in ipairs(wearManifest.tracks) do
        if track.wearRunningGearType == "STEEL_TRACK" then
            result.kind = "STEEL_TRACK"
        end

        local trackState = getTrackWearState(state, track)
        if trackState ~= nil then
            local ownTrackWear = math.clamp(
                safeNumber(trackState.distanceWear, 0) + safeNumber(trackState.slipWear, 0) + safeNumber(trackState.timeWear, 0) + safeNumber(trackState.forceWear, 0),
                0, RV.WEAR_MAX
            )
            result.trackWear01 = math.max(result.trackWear01, ownTrackWear)

            rvEnsureRollerState(trackState)
            local classification = rvClassifyCrawlerRollers(track)
            if classification ~= nil
                and classification.confident == true
                and classification.rollers ~= nil
                and #classification.rollers > 0 then
                result.rollerValid = true
                result.rollerWear01 = math.max(
                    result.rollerWear01,
                    math.clamp(safeNumber(trackState.rollerWear, 0), 0, RV.WEAR_MAX)
                )
            end
        end
    end

    return result
end

local function rvWriteWheelHudSnapshot(target, prefix, ws)
    if target == nil or ws == nil then return end
    prefix = prefix or "_FS25_RV"
    target[prefix .. "_WHEEL_WEAR_VALID"] = ws.valid == true
    target[prefix .. "_WHEEL_WEAR01"] = math.clamp(safeNumber(ws.wear01,0),0,RV.WEAR_MAX)
    target[prefix .. "_WHEEL_COUNT"] = math.max(0,math.floor(safeNumber(ws.count,0)))
end

local function rvWriteRunningGearHudSnapshot(target, prefix, rg)
    if target == nil or rg == nil then return end
    prefix = prefix or "_FS25_RV"
    target[prefix .. "_RUNNING_GEAR_KIND"] = tostring(rg.kind or "TIRE")
    target[prefix .. "_TRACK_WEAR_VALID"] = rg.trackValid == true
    target[prefix .. "_TRACK_WEAR01"] = math.clamp(safeNumber(rg.trackWear01, 0), 0, RV.WEAR_MAX)
    target[prefix .. "_ROLLER_WEAR_VALID"] = rg.rollerValid == true
    target[prefix .. "_ROLLER_WEAR01"] = math.clamp(safeNumber(rg.rollerWear01, 0), 0, RV.WEAR_MAX)
end

local function rvPublishHudSnapshot(self)
    local vehicle = self ~= nil and self.currentVehicle or nil
    if vehicle == nil then return end

    local state = getVehicleWearState(vehicle)
    local manifest = getOrBuildManifest(vehicle)
    local wearManifest = getOrBuildTireWearManifest(vehicle)
    local valid = state ~= nil and manifest ~= nil and wearManifest ~= nil
        and safeNumber(wearManifest.totalWearObjectCount, 0) > 0
    local wear01 = 0

    if valid then
        applyPendingSavedState(vehicle, state)
        manifest.tireWearManifest = wearManifest
        wear01 = math.clamp(getAverageOwnWear(manifest, state), 0, RV.WEAR_MAX)
        state.totalWear = wear01
    end

    local runningGear = rvGetRunningGearHudState(vehicle)
    local wheelHudState = rvGetWheelOnlyHudState(vehicle)

    local attachedCount = 0
    local attachedWear01 = 0
    local attachedRunningGear = {
        kind = "TIRE",
        trackValid = false,
        trackWear01 = 0,
        rollerValid = false,
        rollerWear01 = 0
    }

    for _, entry in ipairs(getAttachedImplementsForDisplay(vehicle)) do
        local object = entry ~= nil and entry.object or nil
        if object ~= nil and object ~= vehicle then
            local objectWearManifest = getOrBuildTireWearManifest(object)
            if objectWearManifest ~= nil and safeNumber(objectWearManifest.totalWearObjectCount, 0) > 0 then
                local objectState = getVehicleWearState(object)
                local objectManifest = getOrBuildManifest(object)
                if objectState ~= nil and objectManifest ~= nil then
                    applyPendingSavedState(object, objectState)
                    objectManifest.tireWearManifest = objectWearManifest
                    local objectWear01 = math.clamp(getAverageOwnWear(objectManifest, objectState), 0, RV.WEAR_MAX)
                    objectState.totalWear = objectWear01
                    attachedCount = attachedCount + 1
                    attachedWear01 = math.max(attachedWear01, objectWear01)

                    local objectRg = rvGetRunningGearHudState(object)
                    if objectRg.kind ~= "TIRE" then
                        if objectRg.kind == "STEEL_TRACK" then
                            attachedRunningGear.kind = "STEEL_TRACK"
                        elseif attachedRunningGear.kind == "TIRE" then
                            attachedRunningGear.kind = "RUBBER_TRACK"
                        end
                        attachedRunningGear.trackValid = attachedRunningGear.trackValid or objectRg.trackValid
                        attachedRunningGear.trackWear01 = math.max(attachedRunningGear.trackWear01, objectRg.trackWear01)
                        if objectRg.rollerValid then
                            attachedRunningGear.rollerValid = true
                            attachedRunningGear.rollerWear01 = math.max(attachedRunningGear.rollerWear01, objectRg.rollerWear01)
                        end
                    end
                end
            end
        end
    end

    rvWriteHudSnapshot(vehicle, valid, wear01, attachedCount, attachedWear01)
    rvWriteRunningGearHudSnapshot(vehicle, "_FS25_RV", runningGear)
    rvWriteWheelHudSnapshot(vehicle, "_FS25_RV", wheelHudState)
    rvWriteRunningGearHudSnapshot(vehicle, "_FS25_RV_ATTACHED", attachedRunningGear)

    local root = nil
    if type(vehicle.getRootVehicle) == "function" then
        local ok, value = pcall(vehicle.getRootVehicle, vehicle)
        if ok then root = value end
    elseif vehicle.rootVehicle ~= nil then
        root = vehicle.rootVehicle
    end
    if root ~= nil and root ~= vehicle then
        rvWriteHudSnapshot(root, valid, wear01, attachedCount, attachedWear01)
        rvWriteRunningGearHudSnapshot(root, "_FS25_RV", runningGear)
        rvWriteWheelHudSnapshot(root, "_FS25_RV", wheelHudState)
        rvWriteRunningGearHudSnapshot(root, "_FS25_RV_ATTACHED", attachedRunningGear)
    end

    local signature = string.format(
        "%s|%.6f|%s|%.6f|%.6f|%d|%.6f|%s|%.6f|%.6f",
        tostring(valid), wear01,
        tostring(runningGear.kind), runningGear.trackWear01, runningGear.rollerWear01,
        attachedCount, attachedWear01,
        tostring(attachedRunningGear.kind), attachedRunningGear.trackWear01, attachedRunningGear.rollerWear01
    )
    if self._rvHudSnapshotSignature ~= signature then
        self._rvHudSnapshotSignature = signature
    end
end

function ReifenVerschleissCore.publishHudSnapshot()
    rvPublishHudSnapshot(ReifenVerschleissCore)
end

-- TEST2.3.101: read-only roller wear bridge for the existing AutoDrive
-- cruise-cap hook. Only confidently detected RUBBER_TRACK crawlers qualify.
-- STEEL_TRACK is deliberately excluded.
function ReifenVerschleissCore.getRubberTrackRollerWear01ForSpeedMalus(vehicle)
    if vehicle == nil then return nil end
    local wearManifest = getOrBuildTireWearManifest(vehicle)
    if wearManifest == nil or wearManifest.tracks == nil then return nil end
    local state = getVehicleWearState(vehicle)
    if state == nil then return nil end
    applyPendingSavedState(vehicle, state)

    local maxWear = nil
    for _, track in ipairs(wearManifest.tracks) do
        if track.wearRunningGearType == "RUBBER_TRACK" then
            local trackState = getTrackWearState(state, track)
            if trackState ~= nil then
                rvEnsureRollerState(trackState)
                local classification = rvClassifyCrawlerRollers(track)
                if classification ~= nil and classification.confident == true and #classification.rollers > 0 then
                    local w = math.clamp(safeNumber(trackState.rollerWear, 0), 0, 1)
                    maxWear = maxWear == nil and w or math.max(maxWear, w)
                end
            end
        end
    end
    return maxWear
end

-- TEST2.3.124: read-only workshop component inventory.
function ReifenVerschleissCore.getRunningGearServiceInfo(vehicle)
    local r={trackCount=0,rubberTrackCount=0,steelTrackCount=0,rollerCount=0}
    if vehicle==nil then return r end
    local wm=getOrBuildTireWearManifest(vehicle)
    if wm==nil then return r end
    r.trackCount=#(wm.tracks or {})
    for _,track in ipairs(wm.tracks or {}) do
        if track.wearRunningGearType=="STEEL_TRACK" then r.steelTrackCount=r.steelTrackCount+1
        else r.rubberTrackCount=r.rubberTrackCount+1 end
        local c=rvClassifyCrawlerRollers(track)
        if c~=nil and c.confident==true then r.rollerCount=r.rollerCount+#(c.rollers or {}) end
    end
    return r
end

function ReifenVerschleissCore.getOwnWear01ForHUD(vehicle)
    if vehicle == nil then return nil end
    local wearManifest = getOrBuildTireWearManifest(vehicle)
    if wearManifest == nil or safeNumber(wearManifest.totalWearObjectCount, 0) <= 0 then
        return nil
    end
    local state = getVehicleWearState(vehicle)
    local manifest = getOrBuildManifest(vehicle)
    if state == nil or manifest == nil then return nil end
    applyPendingSavedState(vehicle, state)
    manifest.tireWearManifest = wearManifest
    local wear01 = math.clamp(getAverageOwnWear(manifest, state), 0, RV.WEAR_MAX)
    state.totalWear = wear01
    return wear01
end

-- Public read-only HUD bridge used by Lights Symbol HUD.
-- IMPORTANT: this reads the already authoritative OWN-WEAR state. It does not
-- use GIANTS gameWear and it does not create a second HUD-side wear model.
--
-- TEST2.3.82 intentionally avoids the 2.3.81 bridge's extra aggregate chain.
-- The compact diagnostic already keeps state.totalWear synchronized with the
-- concrete wheel/track states; loaded persistence also restores this field.
-- For safety we recompute it from the same OWN-WEAR wheel/track states here
-- only after the dedicated wear manifest is known to contain wear objects.
function ReifenVerschleissCore.getHudWearState(vehicle)
    local empty = {hasWearObjects=false, wearPercent=0, wear01=0, state="green", wheelCount=0, trackCount=0, totalWearObjectCount=0}
    if vehicle == nil then return empty end

    local state = getVehicleWearState(vehicle)
    local manifest = getOrBuildManifest(vehicle)
    if state == nil or manifest == nil then return empty end

    -- This function is declared after applyPendingSavedState, so this is a real
    -- local call (not a forward-reference to a nil global as happened in older
    -- public HUD helper code).
    applyPendingSavedState(vehicle, state)

    local wearManifest = getOrBuildTireWearManifest(vehicle)
    if wearManifest == nil then return empty end

    local wheelCount = safeNumber(wearManifest.wheelCount, 0)
    local trackCount = safeNumber(wearManifest.trackCount, 0)
    local objectCount = safeNumber(wearManifest.totalWearObjectCount, wheelCount + trackCount)
    if objectCount <= 0 then return empty end

    -- Same OWN-WEAR data used by the diagnostic: per-wheel/per-track
    -- DIST-WEAR + SLIP-WEAR. No GIANTS wear and no HUD-side calculation.
    manifest.tireWearManifest = wearManifest
    local wear01 = math.clamp(getAverageOwnWear(manifest, state), 0, RV.WEAR_MAX)
    state.totalWear = wear01

    local color = "green"
    if wear01 > 0.75 then
        color = "red"
    elseif wear01 > 0.50 then
        color = "yellow"
    end

    return {
        hasWearObjects=true,
        wearPercent=wear01 * 100,
        wear01=wear01,
        state=color,
        wheelCount=wheelCount,
        trackCount=trackCount,
        totalWearObjectCount=objectCount,
        vehicle=vehicle
    }
end

function ReifenVerschleissCore.getHudAttachedWearState(vehicle)
    local sourceVehicle = vehicle or RV.currentVehicle
    local result = {count=0, hasWearObjects=false, wearPercent=0, wear01=0, state="green", vehicle=sourceVehicle}
    if sourceVehicle == nil then return result end

    -- Exactly the same attachment list used by the compact diagnostic.
    local entries = getAttachedImplementsForDisplay(sourceVehicle)
    local maxWear01 = nil
    local count = 0
    local used = {}

    for _, entry in ipairs(entries or {}) do
        local object = type(entry) == "table" and entry.object or entry
        if object ~= nil and object ~= sourceVehicle and used[object] ~= true then
            used[object] = true
            local objectState = getVehicleWearState(object)
            local objectManifest = getOrBuildManifest(object)
            if objectState ~= nil and objectManifest ~= nil then
                applyPendingSavedState(object, objectState)
                local wearManifest = getOrBuildTireWearManifest(object)
                local wc = wearManifest ~= nil and safeNumber(wearManifest.wheelCount, 0) or 0
                local tc = wearManifest ~= nil and safeNumber(wearManifest.trackCount, 0) or 0
                if wc + tc > 0 then
                    objectManifest.tireWearManifest = wearManifest
                    local wear01 = math.clamp(getAverageOwnWear(objectManifest, objectState), 0, RV.WEAR_MAX)
                    objectState.totalWear = wear01
                    count = count + 1
                    if maxWear01 == nil or wear01 > maxWear01 then maxWear01 = wear01 end
                end
            end
        end
    end

    local wear01 = maxWear01 or 0
    local color = "green"
    if wear01 > 0.75 then color = "red"
    elseif wear01 > 0.50 then color = "yellow" end

    result.count = count
    result.hasWearObjects = count > 0
    result.wearPercent = wear01 * 100
    result.wear01 = wear01
    result.state = color
    return result
end

-- TEST0.2.0.76: Final vehicle-load visual synchronization.
-- This is deliberately separate from HUD/setControlledVehicle. It is called
-- after Vehicle:onFinishedLoading has raised all specialization onLoadFinished
-- events, so every vehicle (controlled or not) can consume its saved wear
-- state at the final native load boundary.
function RV:refreshVehicleWearVisualsAfterFinishedLoading(vehicle)
    if vehicle == nil then
        return false
    end

    local state = getVehicleWearState(vehicle)
    if state == nil then
        return false
    end

    -- Apply the already loaded persistent state exactly once. Do not create a
    -- second wear source and do not change the saved values here.
    applyPendingSavedState(vehicle, state)

    local manifest = getOrBuildManifest(vehicle)
    manifest.tireWearManifest = getOrBuildTireWearManifest(vehicle)
    state.totalWear = getAverageOwnWear(manifest, state)

    if ReifenVerschleissVisual == nil or ReifenVerschleissVisual.refreshVehicleWearVisualsImmediate == nil then
        return false
    end

    local ok, err = pcall(
        ReifenVerschleissVisual.refreshVehicleWearVisualsImmediate,
        vehicle
    )

    if not ok then
        return false
    end

    -- TEST2.3.92: some wheel/crawler render materials settle only after the
    -- final native load boundary. Retry the same visual-only worker briefly
    -- for this vehicle. This does not touch OWN-WEAR, persistence, physics or
    -- EWFS and replaces the accidental visual refresh previously caused by
    -- entering/leaving affected vehicles.
    if state.loadedFromSavegame == true
        and ReifenVerschleissVisual.queueLoadVisualRefresh ~= nil then
        ReifenVerschleissVisual.queueLoadVisualRefresh(vehicle)
    end

    return true
end

function RV.isVehicleManaged(vehicle)
    return vehicle ~= nil and vehicleWearStates[vehicle] ~= nil
end

function RV.isMotorStartPhase(vehicle)
    -- Shared motor-start gate for all ReifenVerschleiss systems.
    -- Uses the same proven starting-phase calculation as slip evaluation,
    -- including the vehicle-specific GIANTS motorStartDuration.
    return isMotorStartPhase(vehicle)
end

function RV.isVehicleReady(vehicle)
    local state = vehicle ~= nil and vehicleWearStates[vehicle] or nil
    return state ~= nil and state.ready == true
end

function RV.setVehicleWFSReady(vehicle)
    local state = vehicle ~= nil and vehicleWearStates[vehicle] or nil
    if state ~= nil then
        state.ready = true
        state.readySince = safeNumber(g_time, 0)
    end
end

function RV.resetVehicleWFS(vehicle)
    local state = vehicle ~= nil and vehicleWearStates[vehicle] or nil
    if state ~= nil then
        state.ready = false
        state.readySince = 0
        state.slipDisplayReady = false
        state.slipDisplayBlocked = true
    end
end

function RV:setVehicle(vehicle)
    if rvIsExplicitlyExcludedVehicle(vehicle) then
        vehicle = nil
    end

    -- TEST0.2.2.77: keep our own active vehicle reference when the HUD
    -- clears GIANTS' controlled vehicle after the player leaves the cab.
    -- Do not require speed or AI at this exact callback: the transition from
    -- player control to AD/CP/GIANTS AI can briefly report both as inactive.
    -- A newly controlled vehicle replaces this reference through this function.
    -- This does NOT modify GIANTS' controlledVehicle/isControlled state.
    if vehicle == nil and self.currentVehicle ~= nil then
        activeVehicleHeld = true
        return
    end

    if vehicle == self.currentVehicle then
        return
    end

    local previousVehicle = self.currentVehicle
    self.currentVehicle = vehicle
    activeVehicleHeld = vehicle ~= nil

    self.manifest = nil
    if vehicle ~= nil then
        self.manifest = getOrBuildManifest(vehicle)
        self.manifest.tireWearManifest = getOrBuildTireWearManifest(vehicle)
        self.tireWearManifest = self.manifest.tireWearManifest

        local vehicleState = getVehicleWearState(vehicle)
        applyPendingSavedState(vehicle, vehicleState)
        self.wear = vehicleState.wear
        self.totalEffectiveWearDistanceM = vehicleState.totalEffectiveWearDistanceM
        self.lastSpeedKmh = vehicleState.lastSpeedKmh
        self.lastVehicleForMotion = vehicle
        vehicleState.ready = false
        vehicleState.readySince = 0

        vehicleState.totalWear = getAverageWear(self.manifest, vehicleState)

        -- The saved wear value is already authoritative here. Force the existing
        -- wheel/track visual workers to consume it immediately; do not alter the
        -- wear value or calculation state.
        if ReifenVerschleissVisual ~= nil and ReifenVerschleissVisual.refreshVehicleWearVisualsImmediate ~= nil then
            local okVisual, errVisual = pcall(
                ReifenVerschleissVisual.refreshVehicleWearVisualsImmediate,
                vehicle
            )
        end

        self.vehicleSerial = self.vehicleSerial + 1
        rvPublishHudSnapshot(self)
    end
end



-- TEST2_3_40: autonomous-driver bridge. AD/CP/GIANTS provide only the
-- activation state; the concrete Vehicle instance arrives from the native
-- Motorized:onUpdate lifecycle. The existing wear engine remains unchanged.
function RV:processAutomatedVehicleUpdate(vehicle, dt)
    if vehicle == nil or vehicle == self.currentVehicle then
        return
    end
    if not isRelevantPlayerVehicle(vehicle) then
        return
    end

    local aiSource = getAutomatedDriverSource(vehicle)
    if aiSource == nil then
        return
    end

    local dtSec = math.max(0, safeNumber(dt, 0)) / 1000
    if dtSec <= 0 then
        return
    end

    local state = getVehicleWearState(vehicle)
    if state == nil then
        return
    end

    applyPendingSavedState(vehicle, state)

    local speedKmh = getVehicleSpeedKmh(vehicle)
    local distanceM = getVehicleMotionDistanceM(vehicle, dtSec)

    -- Primary input remains GIANTS' own movement data. If this background
    -- instance exposes no movement accumulator, measure the actual transform
    -- delta of this same Vehicle instance. This is measurement, not route/path
    -- reconstruction by AD, CP or our mod.
    if distanceM <= 0.000001 then
        distanceM = updateGpsDistance(state, vehicle)
    else
        updateGpsDistance(state, vehicle)
    end

    local manifest = getOrBuildManifest(vehicle)
    manifest.tireWearManifest = getOrBuildTireWearManifest(vehicle)
    updateWear(vehicle, manifest, distanceM, speedKmh, dtSec, state)
    state.lastSpeedKmh = speedKmh

    state.totalWear = getAverageOwnWear(manifest, state)

end

function RV:update(dt)
    local dtMs = math.max(0, safeNumber(dt, 0))
    local dtSec = dtMs / 1000
    if dtSec <= 0 then
        return
    end

    -- TEST0.2.2.89:
    -- Keep the proven TEST0.2.2.77 currentVehicle path intact. Automated
    -- vehicles are NOT processed through the complete wear path every frame.
    -- Instead, owned AD/CP/GIANTS-AI vehicles are sampled every 300 ms and
    -- their real world-position delta is passed into the existing wear code.
    aiWearAccumulatorMs = aiWearAccumulatorMs + dtMs
    local processAIVehicles = false -- TEST2_3_40: autonomous vehicles enter through Motorized:onUpdate
    if processAIVehicles then
        aiWearAccumulatorMs = aiWearAccumulatorMs - RV.AI_WEAR_UPDATE_INTERVAL_MS
        if aiWearAccumulatorMs >= RV.AI_WEAR_UPDATE_INTERVAL_MS then
            aiWearAccumulatorMs = 0
        end
    end

    -- The scan itself remains throttled by VEHICLE_SCAN_INTERVAL_MS. It only
    -- discovers player-owned motorized vehicles and never processes them here.
    refreshOwnedMotorizedVehicleCache(g_currentMission ~= nil and safeNumber(g_currentMission.time, 0) or 0)

    local vehicles = {}
    local seenVehicles = {}

    -- Proven .77 behavior: the currently displayed/current vehicle is always
    -- processed, including while stationary, so HUD/slip behavior remains intact.
    if self.currentVehicle ~= nil and isRelevantPlayerVehicle(self.currentVehicle) then
        vehicles[#vehicles + 1] = self.currentVehicle
        seenVehicles[self.currentVehicle] = true
    end

    -- Discover/refresh automated-driver vehicles only on the 300 ms cadence.
    -- This is the ONLY path that adds parallel AI vehicles to this update.
    if processAIVehicles then
        for _, vehicle in ipairs(ownedMotorizedVehicleCache) do
            if vehicle ~= self.currentVehicle then
                local aiSource = getAutomatedDriverSource(vehicle)
                local speedKmh = getVehicleSpeedKmh(vehicle)
                if aiSource ~= nil then
                    aiTrackedVehicles[vehicle] = aiSource
                    activeWearVehicles[vehicle] = true
                elseif speedKmh <= 0.05 then
                    aiTrackedVehicles[vehicle] = nil
                    activeWearVehicles[vehicle] = nil
                end
            end
        end
    end

    -- Process each already registered automated vehicle only once per 300 ms.
    if processAIVehicles then
        for vehicle, active in pairs(activeWearVehicles) do
            if active == true and vehicle ~= self.currentVehicle and isRelevantPlayerVehicle(vehicle) then
                if aiTrackedVehicles[vehicle] ~= nil then
                    vehicles[#vehicles + 1] = vehicle
                    seenVehicles[vehicle] = true
                end
            else
                if vehicle ~= self.currentVehicle and not isRelevantPlayerVehicle(vehicle) then
                    activeWearVehicles[vehicle] = nil
                    aiTrackedVehicles[vehicle] = nil
                end
            end
        end
    end

    local activeVehicleProcessed = false

    for _, vehicle in ipairs(vehicles) do
        local state = getVehicleWearState(vehicle)
        if state ~= nil then
            applyPendingSavedState(vehicle, state)

            local oldWear = self.wear
            local oldTotal = self.totalEffectiveWearDistanceM

            self.wear = state.wear
            self.totalEffectiveWearDistanceM = state.totalEffectiveWearDistanceM

            local speedKmh = getVehicleSpeedKmh(vehicle)
            local aiSource = aiTrackedVehicles[vehicle]
            local distanceM
            local updateDtSec = dtSec

            if aiSource ~= nil and vehicle ~= self.currentVehicle then
                -- AI path: use actual world-position delta. This prevents
                -- lastMovedDistance/activeVehicle semantics from losing the
                -- distance driven after the player leaves the vehicle.
                distanceM = updateGpsDistance(state, vehicle)
                updateDtSec = RV.AI_WEAR_UPDATE_INTERVAL_MS / 1000
            else
                -- Proven normal/player path remains unchanged.
                distanceM = getVehicleMotionDistanceM(vehicle, dtSec)
                updateGpsDistance(state, vehicle)
            end


            local manifest = getOrBuildManifest(vehicle)
            manifest.tireWearManifest = getOrBuildTireWearManifest(vehicle)
            updateWear(vehicle, manifest, distanceM, speedKmh, updateDtSec, state)

            state.lastSpeedKmh = speedKmh
            self.totalEffectiveWearDistanceM = state.totalEffectiveWearDistanceM

                    state.totalWear = getAverageOwnWear(manifest, state)
        
            self.wear = oldWear
            self.totalEffectiveWearDistanceM = oldTotal

            if vehicle == self.currentVehicle then
                self.lastSpeedKmh = state.lastSpeedKmh
                self.wear = state.wear
                self.totalEffectiveWearDistanceM = state.totalEffectiveWearDistanceM
                activeVehicleProcessed = true
            end
        end
    end

    -- TEST0.2.2.23: passive tire wear for attached trailers/implements.
    -- The implement owns its own persistent wear state and wheel manifest.
    -- Keep the proven attachment path, but gate the actual wear update through
    -- the same player-farm/mission exclusion used for motorized vehicles.
    for _, entry in ipairs(getAttachedImplementsForDisplay()) do
        local implement = entry.object
        if entry.root ~= nil and entry.speedKmh > 0.05 and isRelevantPlayerVehicle(implement) then
            local root = entry.root
            local state = getVehicleWearState(implement)
            if state ~= nil then
                applyPendingSavedState(implement, state)

                local speedKmh = entry.speedKmh
                local distanceM = getVehicleMotionDistanceM(root, dtSec)
                updateGpsDistance(state, implement)

                local manifest = getOrBuildManifest(implement)
                manifest.tireWearManifest = getOrBuildTireWearManifest(implement)
                updateWear(implement, manifest, distanceM, speedKmh, dtSec, state, true)
                state.lastSpeedKmh = speedKmh

                            state.totalWear = getAverageOwnWear(manifest, state)

                if ReifenVerschleissVisual ~= nil and ReifenVerschleissVisual.refreshAttachedImplementVisuals ~= nil then
                    local okVisual, visualCount = pcall(
                        ReifenVerschleissVisual.refreshAttachedImplementVisuals,
                        implement
                    )
                end

            end
        end
    end

    if self.currentVehicle ~= nil and self.manifest ~= nil and not activeVehicleProcessed then
        local state = getVehicleWearState(self.currentVehicle)
        if state ~= nil then
            self.wear = state.wear
            self.lastSpeedKmh = state.lastSpeedKmh
            self.totalEffectiveWearDistanceM = state.totalEffectiveWearDistanceM
        end
    end

    rvPublishHudSnapshot(self)

end

function RV:draw()
    -- Release build: development HUD removed.
end
