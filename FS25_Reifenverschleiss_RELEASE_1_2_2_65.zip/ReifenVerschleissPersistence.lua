-- FS25_Reifenverschleiss - native vehicle specialization used only for
-- persistence of the already existing OWN-WEAR runtime state.
-- No wear calculation, EWFS, HUD, visual or attachment logic lives here.

ReifenVerschleissPersistence = {}

local function vehicleBaseKeyFromSpecializationKey(key)
    if type(key) ~= "string" then return nil end

    -- Vehicle:saveToXMLFile calls each specialization with
    -- "vehicles.vehicle(n).<specializationName>". The OWN-WEAR schema is kept
    -- deliberately version-independent at "vehicles.vehicle(n).reifenVerschleiss".
    local base = string.match(key, "^(vehicles%.vehicle%(%d+%))")
    return base
end

function ReifenVerschleissPersistence.prerequisitesPresent(specializations)
    -- Attach to all vehicle types. The diagnostic persistence writer itself
    -- exits immediately for objects without wheel/track wear objects.
    return true
end

function ReifenVerschleissPersistence.initSpecialization()
    local schema = Vehicle ~= nil and Vehicle.xmlSchemaSavegame or nil
    if schema == nil or XMLValueType == nil then
        Logging.error("[ReifenVerschleiss][SAVE] Persistence specialization could not access Vehicle.xmlSchemaSavegame")
        return
    end

    local base = "vehicles.vehicle(?).reifenVerschleiss"
    schema:register(XMLValueType.INT, base .. "#version", "Reifenverschleiss OWN-WEAR schema version")
    schema:register(XMLValueType.FLOAT, base .. "#totalDistanceWear", "Own total distance wear")
    schema:register(XMLValueType.FLOAT, base .. "#totalSlipWear", "Own total slip wear")
    schema:register(XMLValueType.FLOAT, base .. "#totalTimeWear", "Own total active-movement time wear")
    schema:register(XMLValueType.FLOAT, base .. "#totalForceWear", "Own total longitudinal force wear")
    schema:register(XMLValueType.FLOAT, base .. "#totalWear", "Own aggregate wear")
    schema:register(XMLValueType.FLOAT, base .. "#totalEffectiveWearDistanceM", "Own effective wear distance")

    for _, child in ipairs({"wheel(?)", "track(?)"}) do
        local key = base .. "." .. child
        schema:register(XMLValueType.STRING, key .. "#key", "Stable own-wear object key")
        if child == "track(?)" then
            schema:register(XMLValueType.INT, key .. "#index", "Stable crawler index")
            schema:register(XMLValueType.STRING, key .. "#side", "Crawler side")
            schema:register(XMLValueType.FLOAT, key .. "#rollerWear", "Crawler roller mileage wear")
            schema:register(XMLValueType.FLOAT, key .. "#rollerLifetimeFactor", "Persistent crawler roller lifetime factor")
            schema:register(XMLValueType.FLOAT, key .. "#rollerDistanceM", "Crawler roller travelled distance")
        end
        schema:register(XMLValueType.FLOAT, key .. "#distanceWear", "Own distance wear")
        schema:register(XMLValueType.FLOAT, key .. "#slipWear", "Own slip wear")
        schema:register(XMLValueType.FLOAT, key .. "#timeWear", "Own active-movement time wear")
        schema:register(XMLValueType.FLOAT, key .. "#forceWear", "Own longitudinal force wear")
        schema:register(XMLValueType.FLOAT, key .. "#totalWear", "Own total wear")
        schema:register(XMLValueType.FLOAT, key .. "#effectiveDistanceM", "Own effective distance")
        schema:register(XMLValueType.FLOAT, key .. "#slipDistanceM", "Own slip distance")
        schema:register(XMLValueType.FLOAT, key .. "#lastSlip", "Last slip percent")
        schema:register(XMLValueType.FLOAT, key .. "#lastSlipWearPointsPerSecond", "Last slip wear rate")
        schema:register(XMLValueType.STRING, key .. "#lastGroundClass", "Last ground class")
        schema:register(XMLValueType.FLOAT, key .. "#lastDistanceFactor", "Last distance factor")
        schema:register(XMLValueType.FLOAT, key .. "#lastSlipFactor", "Last slip factor")
        schema:register(XMLValueType.FLOAT, key .. "#lastLoadFactor", "Last load factor")
    end

end

function ReifenVerschleissPersistence.registerEventListeners(vehicleType)
    SpecializationUtil.registerEventListener(vehicleType, "onLoad", ReifenVerschleissPersistence)
    SpecializationUtil.registerEventListener(vehicleType, "onLoadFinished", ReifenVerschleissPersistence)
    SpecializationUtil.registerEventListener(vehicleType, "saveToXMLFile", ReifenVerschleissPersistence)
end

function ReifenVerschleissPersistence:onLoad(savegame)
    if ReifenVerschleissCore ~= nil
        and ReifenVerschleissCore.isVehicleExcluded ~= nil
        and ReifenVerschleissCore.isVehicleExcluded(self) then
        return
    end
    if ReifenVerschleissCore == nil or type(ReifenVerschleissCore.captureVehicleWearSavegame) ~= "function" then
        return
    end

    -- Capture only. The wear manifest is intentionally not built here because
    -- onLoad is earlier than the final wheel/crawler lifecycle. Restoration is
    -- applied at onLoadFinished, after the concrete vehicle is complete.
    local ok, err = pcall(ReifenVerschleissCore.captureVehicleWearSavegame, self, savegame)
    if not ok then
        Logging.error("[ReifenVerschleiss][SAVE] specialization onLoad capture failed for '%s': %s", tostring(self.configFileName or self.typeName), tostring(err))
    elseif savegame ~= nil then
    end
end

function ReifenVerschleissPersistence:onLoadFinished(savegame)
    if ReifenVerschleissCore ~= nil
        and ReifenVerschleissCore.isVehicleExcluded ~= nil
        and ReifenVerschleissCore.isVehicleExcluded(self) then
        return
    end
    if ReifenVerschleissCore == nil or type(ReifenVerschleissCore.applyCapturedVehicleWearSavegame) ~= "function" then
        return
    end

    local ok, applied = pcall(ReifenVerschleissCore.applyCapturedVehicleWearSavegame, self)
    if not ok then
        Logging.error("[ReifenVerschleiss][SAVE] specialization restore failed for '%s': %s", tostring(self.configFileName or self.typeName), tostring(applied))
    elseif applied == true then

        -- TEST2.3.93: the specialization restore event is the first boundary at
        -- which OWN-WEAR is demonstrably present on every affected vehicle.
        -- Tab-switching already proved that calling the existing visual worker
        -- after this point makes T9/Raptor consume the correct saved state.
        -- Do the same synchronization here without changing controlledVehicle,
        -- enter/leave state, camera, input, physics, EWFS or the wear values.
        if ReifenVerschleissVisual ~= nil and
           type(ReifenVerschleissVisual.refreshVehicleWearVisualsImmediate) == "function" then
            local okVisual, errVisual = pcall(
                ReifenVerschleissVisual.refreshVehicleWearVisualsImmediate,
                self
            )
            if not okVisual then
                Logging.error("[ReifenVerschleiss][VISUAL-RESTORE] immediate refresh failed for '%s': %s",
                    tostring(self.configFileName or self.typeName), tostring(errVisual))
            else
            end

            -- Keep the already existing .92 visual-only settling queue as a
            -- short safety net for asynchronously finalised crawler materials.
            -- Unlike .92, it is now armed from the proven persistence-restore
            -- boundary instead of relying on the generic Vehicle hook ordering.
            if type(ReifenVerschleissVisual.queueLoadVisualRefresh) == "function" then
                ReifenVerschleissVisual.queueLoadVisualRefresh(self)
            end
        end
    end
end

function ReifenVerschleissPersistence:saveToXMLFile(xmlFile, key, usedModNames)
    if ReifenVerschleissCore ~= nil
        and ReifenVerschleissCore.isVehicleExcluded ~= nil
        and ReifenVerschleissCore.isVehicleExcluded(self) then
        return
    end
    if ReifenVerschleissCore == nil or type(ReifenVerschleissCore.saveVehicleWearToSavegame) ~= "function" then
        return
    end

    local vehicleKey = vehicleBaseKeyFromSpecializationKey(key)
    if vehicleKey == nil then
        Logging.error("[ReifenVerschleiss][SAVE] specialization could not resolve vehicle base key from '%s'", tostring(key))
        return
    end

    local ok, err = pcall(ReifenVerschleissCore.saveVehicleWearToSavegame, self, xmlFile, vehicleKey)
    if not ok then
        Logging.error("[ReifenVerschleiss][SAVE] specialization write failed vehicle='%s' key='%s': %s", tostring(self.configFileName or self.typeName), tostring(vehicleKey), tostring(err))
    end
end
