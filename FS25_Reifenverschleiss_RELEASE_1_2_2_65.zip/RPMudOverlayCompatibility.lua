-- FS25_Reifenverschleiss - Mud overlay wear compatibility
-- TEST2_4_0_84_MUD_AMOUNT_WEAR_CAP_TEST
--
-- Protected base: TEST2_4_0_82.
-- IMPORTANT:
-- * no wheel radius changes
-- * no tire shader changes
-- * no mud-mesh scale/translation changes
-- * no MudSystemPhysics state changes
--
-- TEST2_4_0_83 proved that scaling the complete mudMesh radially is wrong:
-- even moderate tire wear moves the whole overlay shell inside the still
-- undeformed tire carcass/sidewall and the mud profile disappears.
--
-- 4_0_84 therefore leaves the GIANTS mud mesh geometry at its native transform
-- and only limits the *visible mud morph amount* ("mudAmount") according to
-- the remaining RP tread profile. GIANTS/Mud keep the real dirtAmount state.
-- This means:
--   clean/low dirt -> unchanged
--   full dirt + unworn tire -> unchanged (mudAmount up to 1.0)
--   worn tire -> mudAmount can no longer grow back to a full new-tire profile
--   100% wear -> small 18% mud layer remains visible instead of disappearing
--
-- GIANTS Washable uses mudAmount/prevMudAmount for wheel mud meshes. We only
-- post-process those shader parameters; nodeData.dirtAmount is never modified.

RPMudOverlayCompatibility = RPMudOverlayCompatibility or {}
local M = RPMudOverlayCompatibility

M.VERSION = "RELEASE_1_2_2_51_PERFORMANCE_CADENCE_TEST"
M.UPDATE_INTERVAL_SEC = 0.00
M.IDLE_FAR_UPDATE_INTERVAL_SEC = 1.00
M.OUT_OF_SIGHT_DISTANCE_M = 200.0
M.MIN_MUD_LAYER = 0.18
M._elapsed = 0
M._installed = false
M._last = setmetatable({}, {__mode="k"})
M._vehicleCadence = setmetatable({}, {__mode="k"})

-- TEST2_4_0_85: read-only runtime verification of the actual shader values.
-- The 4_0_84 cap behavior itself remains unchanged.

local function clamp01(v)
    v = tonumber(v) or 0
    if v < 0 then return 0 end
    if v > 1 then return 1 end
    return v
end


local function readShaderParameterSafe(node, name)
    if node == nil or node == 0 or getShaderParameter == nil then
        return nil, nil, nil, nil
    end

    local okHas, has = pcall(getHasShaderParameter, node, name)
    if not okHas or has ~= true then
        return nil, nil, nil, nil
    end

    local ok, x, y, z, w = pcall(getShaderParameter, node, name)
    if not ok then
        return nil, nil, nil, nil
    end
    return x, y, z, w
end

local function getWheelWear(vehicle, wheel)
    if ReifenVerschleissCore == nil
        or ReifenVerschleissCore.getWheelWearValue == nil then
        return 0
    end

    local ok, value = pcall(
        ReifenVerschleissCore.getWheelWearValue,
        vehicle,
        wheel
    )
    if not ok then return 0 end
    return clamp01(value)
end

local function isRoundRPWheel(wheel)
    if wheel == nil or type(wheel.visualWheels) ~= "table" then
        return false
    end

    for _, visualWheel in ipairs(wheel.visualWheels) do
        for _, visualPart in ipairs(visualWheel.visualParts or {}) do
            local isTire = false
            if visualPart ~= nil and visualPart.isa ~= nil and WheelVisualPartTire ~= nil then
                local ok, result = pcall(visualPart.isa, visualPart, WheelVisualPartTire)
                isTire = ok and result == true
            end
            if isTire and visualPart.rvEnabled == true then
                return true
            end
        end
    end
    return false
end

-- Mirror the normal RP low/mid wear progression used by the tire shader.
-- The visible tire already loses 1.35x of the raw wear depth before the
-- protected high-wear flattening takes over. We convert that to an allowed
-- mud-profile fraction, but retain a small floor so a fully worn tire can
-- still carry a visible film/clump layer.
local function getMudProfileCap(wear)
    wear = clamp01(wear)

    -- TEST2_4_0_89:
    -- More mud is allowed while usable tread still exists.
    -- Fully worn tires still get zero raised mud profile.
    --
    -- 0% wear   -> 100%
    -- 50% wear  -> 85%
    -- 75% wear  -> 45%
    -- 100% wear -> 0.5% residual mud

    if wear <= 0.50 then
        local t = wear / 0.50
        return 1.00 + (0.85 - 1.00) * t
    elseif wear <= 0.75 then
        local t = (wear - 0.50) / 0.25
        return 0.85 + (0.45 - 0.85) * t
    else
        local t = (wear - 0.75) / 0.25
        return 0.45 + (0.005 - 0.45) * t
    end
end

local function getMudVisualBoost(wear)
    wear = clamp01(wear)

    -- TEST2_4_0_94:
    -- The native MudSystem amount is visually too weak even on a fresh tire.
    -- Therefore the visible mudAmount receives a moderate base boost at 0 wear
    -- and an additional increase from 20% wear upward.
    --
    -- 0% wear   -> 1.20x
    -- 20% wear  -> 1.35x
    -- 50% wear  -> 1.65x
    -- 75% wear  -> 1.45x
    -- 100% wear -> 1.00x (the wear cap dominates here; 0.5% residual remains)

    if wear <= 0.20 then
        local t = wear / 0.20
        return 1.20 + (1.35 - 1.20) * t
    elseif wear <= 0.50 then
        local t = (wear - 0.20) / 0.30
        return 1.35 + (1.65 - 1.35) * t
    elseif wear <= 0.75 then
        local t = (wear - 0.50) / 0.25
        return 1.65 + (1.45 - 1.65) * t
    else
        local t = (wear - 0.75) / 0.25
        return 1.45 + (1.00 - 1.45) * t
    end
end

local function applyMudAmount(node, amount)
    if node == nil or node == 0 then return false end

    local okHas, has = pcall(getHasShaderParameter, node, "mudAmount")
    if not okHas or has ~= true then
        return false
    end

    amount = clamp01(amount)

    if g_animationManager ~= nil
        and g_animationManager.setPrevShaderParameter ~= nil then
        local ok = pcall(
            g_animationManager.setPrevShaderParameter,
            g_animationManager,
            node,
            "mudAmount",
            amount, 0, 0, 0,
            false,
            "prevMudAmount"
        )
        if ok then return true end
    end

    local ok1 = pcall(setShaderParameter, node, "mudAmount", amount, 0, 0, 0, false)
    local ok2 = true
    local okPrevHas, hasPrev = pcall(getHasShaderParameter, node, "prevMudAmount")
    if okPrevHas and hasPrev == true then
        ok2 = pcall(setShaderParameter, node, "prevMudAmount", amount, 0, 0, 0, false)
    end
    return ok1 and ok2
end

local function getVehicleSpeedKmh(vehicle)
    if vehicle == nil then return 0 end

    local speedReal = math.abs(tonumber(vehicle.lastSpeedReal) or 0)
    if speedReal > 0.000001 then
        return speedReal * 1000 * 3.6
    end

    if vehicle.getLastSpeed ~= nil then
        local ok, speedKmh = pcall(vehicle.getLastSpeed, vehicle, false)
        if ok and type(speedKmh) == "number" then
            return math.abs(speedKmh)
        end
    end
    return 0
end

local function isStationaryAndFarFromCamera(vehicle)
    if vehicle == nil then return false end
    if getVehicleSpeedKmh(vehicle) > 0.05 then return false end

    -- Conservative fallback: if GIANTS has not published a camera distance for
    -- this vehicle, keep the original every-frame ownership check.
    local distance = tonumber(vehicle.lastDistanceToCamera)
    return distance ~= nil and distance >= M.OUT_OF_SIGHT_DISTANCE_M
end

local function updateWheel(vehicle, wheel, wheelIndex)
    if vehicle == nil or wheel == nil or wheel.wheelMudMeshes == nil then
        return
    end
    if not isRoundRPWheel(wheel) then
        return
    end
    if vehicle.getWashableNodeByCustomIndex == nil then
        return
    end

    local okNode, nodeData = pcall(
        vehicle.getWashableNodeByCustomIndex,
        vehicle,
        wheel.wheelMudMeshes
    )
    if not okNode or type(nodeData) ~= "table"
        or type(nodeData.mudNodes) ~= "table" then
        return
    end

    local nativeAmount = clamp01(nodeData.dirtAmount or 0)
    local wear = getWheelWear(vehicle, wheel)
    local cap = getMudProfileCap(wear)
    local boost = getMudVisualBoost(wear)
    local boostedAmount = clamp01(nativeAmount * boost)
    local visibleAmount = math.min(boostedAmount, cap)

    for node, _ in pairs(nodeData.mudNodes) do

        -- TEST2_4_0_90:
        -- Do NOT trust a cached "last value". GIANTS/Washable can rewrite
        -- mudAmount after our previous write while the desired RP target
        -- itself has not changed. That was the exact failure in 84-89:
        -- at 100% wear target stayed 0, M._last stayed 0, but GIANTS had
        -- already rebuilt mudAmount to ~0.35 and we skipped the write.
        --
        -- Read the ACTUAL current shader value and reclaim final ownership
        -- after every mission update whenever it differs from our target.
        local actualMud = select(1, readShaderParameterSafe(node, "mudAmount"))
        local actualPrev = select(1, readShaderParameterSafe(node, "prevMudAmount"))
        local mudDiff = actualMud == nil or math.abs((tonumber(actualMud) or 0) - visibleAmount) > 0.001
        local prevDiff = actualPrev ~= nil and math.abs((tonumber(actualPrev) or 0) - visibleAmount) > 0.001

        if mudDiff or prevDiff then
            if applyMudAmount(node, visibleAmount) then
                M._last[node] = visibleAmount
            end
        else
            M._last[node] = visibleAmount
        end
    end
end

local function updateVehicle(vehicle)
    local wheels = vehicle ~= nil
        and vehicle.spec_wheels ~= nil
        and vehicle.spec_wheels.wheels or nil
    if type(wheels) ~= "table" then return end

    for wheelIndex, wheel in ipairs(wheels) do
        updateWheel(vehicle, wheel, wheelIndex)
    end
end

function M:refreshVehicleImmediate(vehicle)
    if vehicle == nil then return end
    updateVehicle(vehicle)
    self._vehicleCadence[vehicle] = 0
end

function M:update(dt)
    -- Keep per-frame shader ownership for moving or camera-relevant vehicles.
    -- Only vehicles that are BOTH stationary and >=200 m from the camera are
    -- reduced to 1 Hz. This preserves the proven TEST2_4_0_90 ownership path
    -- where it matters while removing the full-fleet idle hot loop.
    self._elapsed = 0

    local mission = g_currentMission
    local vehicles = mission ~= nil
        and mission.vehicleSystem ~= nil
        and mission.vehicleSystem.vehicles or nil
    if type(vehicles) ~= "table" then return end

    local dtSec = math.max(0, tonumber(dt) or 0) / 1000

    for _, vehicle in pairs(vehicles) do
        if vehicle ~= nil then
            local farIdle = isStationaryAndFarFromCamera(vehicle)
            if not farIdle then
                -- Original ownership behavior for all moving/near vehicles.
                updateVehicle(vehicle)
                self._vehicleCadence[vehicle] = 0
            else
                local elapsed = (tonumber(self._vehicleCadence[vehicle]) or M.IDLE_FAR_UPDATE_INTERVAL_SEC) + dtSec
                if elapsed >= M.IDLE_FAR_UPDATE_INTERVAL_SEC then
                    updateVehicle(vehicle)
                    elapsed = 0
                end
                self._vehicleCadence[vehicle] = elapsed
            end
        end
    end
end

function M:install()
    if self._installed then return true end
    if FSBaseMission == nil or FSBaseMission.update == nil
        or Utils == nil or Utils.appendedFunction == nil then
        return false
    end

    FSBaseMission.update = Utils.appendedFunction(
        FSBaseMission.update,
        function(_, dt)
            local ok, err = pcall(M.update, M, dt)
            if not ok and Logging ~= nil and Logging.error ~= nil then
                Logging.error("[ReifenVerschleiss][MUD] runtime error: %s", tostring(err))
            end
        end
    )

    self._installed = true
    return true
end

M:install()
