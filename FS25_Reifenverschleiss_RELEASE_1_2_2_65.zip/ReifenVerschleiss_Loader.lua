-- FS25_Reifenverschleiss
-- Runtime loader

local directory = g_currentModDirectory
local ReifenVerschleissInstance = nil
ReifenVerschleissVisualModDirectory = directory

source(Utils.getFilename("RPReifenWechselnEvent.lua", directory))
source(Utils.getFilename("ReifenVerschleissCore.lua", directory))
source(Utils.getFilename("ReifenVerschleissVisual.lua", directory))
source(Utils.getFilename("RPReferenceSettings.lua", directory))
source(Utils.getFilename("RPWorkshopButton.lua", directory))
source(Utils.getFilename("ReifenVerschleissWegfahrsperre.lua", directory))
source(Utils.getFilename("RPMudCompatibility.lua", directory))
source(Utils.getFilename("RPMudOverlayCompatibility.lua", directory))

-- TEST0.2.2.47: proven pre-update EWFS path retained.
-- Runs before AD/CP driver updates so ENGINE-OFF is locked before they can drive.
if FSBaseMission ~= nil and FSBaseMission.update ~= nil and ReifenVerschleissWegfahrsperre ~= nil then
    FSBaseMission.update = Utils.prependedFunction(FSBaseMission.update, function(_, dt)
        local ok, err = pcall(ReifenVerschleissWegfahrsperre.update, dt)
    end)
end

local function RV_initSettingUI()
    if RPReferenceSettings ~= nil then
        RPReferenceSettings.initUI()
    end
end

if InGameMenu ~= nil then
    InGameMenu.onMenuOpened =
        Utils.appendedFunction(InGameMenu.onMenuOpened, RV_initSettingUI)
end

-- OWN-WEAR persistence is implemented as a real GIANTS vehicle specialization.
-- The specialization itself is declared in modDesc.xml. It must be attached to
-- all vehicle types before TypeManager finalizes them so its native onLoad,
-- onLoadFinished and saveToXMLFile callbacks become part of every concrete
-- vehicle class. The persistence writer immediately ignores objects without
-- tire/track wear objects, and saves only OWNED farm property.
local RV_PERSISTENCE_SPEC_SHORT = "rvOwnWearPersistence"
local RV_PERSISTENCE_SPEC_FULL = tostring(g_currentModName) .. "." .. RV_PERSISTENCE_SPEC_SHORT
local rvPersistenceAttached = false

local function RV_attachPersistenceSpecialization(typeManager)
    -- TypeManager is shared by vehicles, placeables and other object types.
    -- GIANTS calls validateTypes() on each concrete manager. Do not compare
    -- against g_vehicleTypeManager here: during this early lifecycle the
    -- global can still differ/be unavailable even though 'self' already is
    -- the real vehicle TypeManager. The manager's own typeName is the stable
    -- discriminator (TypeManager.new("vehicle", ...)).
    if rvPersistenceAttached then
        return
    end
    if typeManager == nil or typeManager.typeName ~= "vehicle" then
        return
    end

    local specializationManager = typeManager.specializationManager or g_specializationManager
    if specializationManager == nil then
        Logging.error("[ReifenVerschleiss][SAVE] vehicle TypeManager has no specialization manager; OWN-WEAR persistence cannot attach")
        return
    end

    local attachName = nil
    if specializationManager:getSpecializationObjectByName(RV_PERSISTENCE_SPEC_FULL) ~= nil then
        attachName = RV_PERSISTENCE_SPEC_FULL
    elseif specializationManager:getSpecializationObjectByName(RV_PERSISTENCE_SPEC_SHORT) ~= nil then
        attachName = RV_PERSISTENCE_SPEC_SHORT
    end

    if attachName == nil then
        Logging.error("[ReifenVerschleiss][SAVE] persistence specialization unavailable full=%s short=%s", tostring(RV_PERSISTENCE_SPEC_FULL), tostring(RV_PERSISTENCE_SPEC_SHORT))
        return
    end

    local types = typeManager:getTypes() or {}
    local totalTypes = 0
    local attachedCount = 0
    local alreadyAttachedCount = 0
    local failedCount = 0

    for typeName, typeEntry in pairs(types) do
        totalTypes = totalTypes + 1
        local byName = typeEntry ~= nil and typeEntry.specializationsByName or nil
        if byName ~= nil and byName[attachName] ~= nil then
            alreadyAttachedCount = alreadyAttachedCount + 1
        else
            local ok = typeManager:addSpecialization(typeName, attachName)
            if ok == true then
                -- Hard verification: addSpecialization() is only considered
                -- successful if the concrete type entry now contains the spec.
                local verifyEntry = types[typeName]
                if verifyEntry ~= nil and verifyEntry.specializationsByName ~= nil and verifyEntry.specializationsByName[attachName] ~= nil then
                    attachedCount = attachedCount + 1
                else
                    failedCount = failedCount + 1
                    Logging.error("[ReifenVerschleiss][SAVE] persistence attach verification failed for vehicle type '%s'", tostring(typeName))
                end
            else
                failedCount = failedCount + 1
            end
        end
    end

    local activeCount = attachedCount + alreadyAttachedCount
    if totalTypes <= 0 or activeCount ~= totalTypes or failedCount > 0 then
        Logging.error("[ReifenVerschleiss][SAVE] persistence specialization attach INCOMPLETE total=%d active=%d new=%d existing=%d failed=%d spec=%s",
            totalTypes, activeCount, attachedCount, alreadyAttachedCount, failedCount, tostring(attachName))
        -- Do not latch success. If GIANTS invokes validation again, retry.
        return
    end

    rvPersistenceAttached = true
end

if TypeManager ~= nil and TypeManager.validateTypes ~= nil then
    -- GIANTS validates prerequisites from typeEntry.specializations immediately
    -- inside validateTypes(). Therefore the custom specialization must be in
    -- every vehicle type BEFORE the original validateTypes body runs.
    TypeManager.validateTypes = Utils.prependedFunction(TypeManager.validateTypes, RV_attachPersistenceSpecialization)
else
    Logging.error("[ReifenVerschleiss][SAVE] TypeManager.validateTypes unavailable; persistence specialization cannot attach")
end

if ReifenVerschleissVisual ~= nil then
    ReifenVerschleissVisual.MOD_DIRECTORY = directory
end

local rvFinishedLoadingHookInstalled = false

local function RV_installVehicleFinishedLoadingHook()
    if rvFinishedLoadingHookInstalled then
        return
    end

    if Vehicle == nil or Vehicle.onFinishedLoading == nil then
        return
    end

    Vehicle.onFinishedLoading = Utils.appendedFunction(
        Vehicle.onFinishedLoading,
        function(vehicle)
            if vehicle == nil or ReifenVerschleissCore == nil then
                return
            end

            -- TEST2.3.03: Ignore shop/menu preview vehicles. They are not live
            -- physics vehicles and must not trigger the full visual refresh.
            if vehicle.isAddedToPhysics ~= true then
                return
            end

            local ok, err = pcall(
                ReifenVerschleissCore.refreshVehicleWearVisualsAfterFinishedLoading,
                ReifenVerschleissCore,
                vehicle
            )
        end
    )

    rvFinishedLoadingHookInstalled = true
end

RV_installVehicleFinishedLoadingHook()

local function RV_loadedMission(mission)
    if mission == nil or mission.cancelLoading then
        return
    end

    if RPWorkshopButton ~= nil then
        RPWorkshopButton.install()
    end

    if mission.hud == nil or mission.hud.speedMeter == nil then
        return
    end

    if ReifenVerschleissInstance == nil then
        ReifenVerschleissInstance = ReifenVerschleissCore

        if ReifenVerschleissWegfahrsperre ~= nil then
            ReifenVerschleissWegfahrsperre.install()
        end


        mission.hud.drawControlledEntityHUD =
            Utils.appendedFunction(
                mission.hud.drawControlledEntityHUD,
                function(hud)
                    if ReifenVerschleissInstance ~= nil then
                        local ok, err = pcall(
                            ReifenVerschleissInstance.draw,
                            ReifenVerschleissInstance
                        )
                    end
                end
            )


        mission.hud.setControlledVehicle =
            Utils.appendedFunction(
                mission.hud.setControlledVehicle,
                function(_, vehicle)
                    if ReifenVerschleissInstance ~= nil then
                        local ok, err = pcall(
                            ReifenVerschleissInstance.setVehicle,
                            ReifenVerschleissInstance,
                            vehicle
                        )
                    end
                end
            )


        -- GIANTS publishes these messages after the native workshop action has
        -- completed. Using the message bus is safer than replacing the vehicle
        -- method itself: it also catches multiplayer/network repair events and
        -- repaint actions triggered by other compatible workshop systems.
        if g_messageCenter ~= nil and MessageType ~= nil and not ReifenVerschleissInstance._workshopMessageHooksInstalled then
            if MessageType.VEHICLE_REPAIRED ~= nil then
                g_messageCenter:subscribe(
                    MessageType.VEHICLE_REPAIRED,
                    ReifenVerschleissInstance.onVehicleRepaired,
                    ReifenVerschleissInstance
                )
            end

            if MessageType.VEHICLE_REPAINTED ~= nil then
                g_messageCenter:subscribe(
                    MessageType.VEHICLE_REPAINTED,
                    ReifenVerschleissInstance.onVehicleRepainted,
                    ReifenVerschleissInstance
                )
            end

            ReifenVerschleissInstance._workshopMessageHooksInstalled = true
        end

        -- Connect the verified own Snow model to the actual wheel friction.
        -- GIANTS calculates its native snow friction first; our conservative
        -- profile is then applied as an additional multiplier.
        if Wheels ~= nil and Wheels.updateWheelFriction ~= nil then
            Wheels.updateWheelFriction = Utils.appendedFunction(
                Wheels.updateWheelFriction,
                function(_, wheel)
                    if wheel ~= nil and ReifenVerschleissInstance ~= nil then
                        local ok, err = pcall(
                            ReifenVerschleissInstance.applySnowFriction,
                            wheel
                        )
                    end
                end
            )
        else
        end

        -- RELEASE PERFORMANCE CLEAN: apply the wear-dependent friction target
        -- directly, without the former diagnostic before/after probe hooks.
        if WheelPhysics ~= nil and WheelPhysics.updateFriction ~= nil and not WheelPhysics._rvWearTargetHookInstalled then
            WheelPhysics._rvWearTargetHookInstalled = true
            WheelPhysics.updateFriction = Utils.appendedFunction(
                WheelPhysics.updateFriction,
                function(physics)
                    if physics ~= nil and type(physics.frictionScale) == "number" and physics.frictionScale ~= 0 then
                        local wheel = physics.wheel
                        local vehicle = wheel ~= nil and wheel.vehicle or nil
                        local targetApplied = nil
                        if ReifenVerschleissInstance ~= nil and ReifenVerschleissInstance.getWearAppliedTarget ~= nil then
                            targetApplied = ReifenVerschleissInstance.getWearAppliedTarget(vehicle, wheel)
                        end
                        if type(targetApplied) == "number" then
                            physics.tireGroundFrictionCoeff = targetApplied / physics.frictionScale
                        end
                    end
                end
            )
        end
    end
end

-- TEST2_3_40: use GIANTS' existing Motorized per-vehicle update as the
-- integration point. We observe only; original Motorized.onUpdate remains
-- untouched and its return value is not altered.
local rvMotorizedUpdateHookInstalled = false

local function RV_installMotorizedUpdateHook()
    if rvMotorizedUpdateHookInstalled then
        return
    end

    if Motorized == nil or Motorized.onUpdate == nil then
        return
    end

    Motorized.onUpdate = Utils.appendedFunction(
        Motorized.onUpdate,
        function(vehicle, dt, isActiveForInput, isActiveForInputIgnoreSelection, isSelected)
            if ReifenVerschleissInstance == nil then
                return
            end

            local ok, err = pcall(
                ReifenVerschleissInstance.processAutomatedVehicleUpdate,
                ReifenVerschleissInstance,
                vehicle,
                dt
            )
        end
    )

    rvMotorizedUpdateHookInstalled = true
end

RV_installMotorizedUpdateHook()

local function RV_updateMission(self, dt)
    if ReifenVerschleissInstance == nil then
        return
    end

    -- Workshop tire replacement can target a vehicle that is not the
    -- currently controlled vehicle. Keep the short visual refresh queue alive
    -- independently of the controlledVehicle HUD source.
    if ReifenVerschleissVisual ~= nil and ReifenVerschleissVisual.updatePendingVisualResets ~= nil then
        local ok, err = pcall(
            ReifenVerschleissVisual.updatePendingVisualResets,
            dt
        )
    end

    if ReifenVerschleissVisual ~= nil and ReifenVerschleissVisual.updatePendingLoadVisualRefreshes ~= nil then
        local ok, err = pcall(
            ReifenVerschleissVisual.updatePendingLoadVisualRefreshes,
            dt
        )
    end

    -- The HUD setControlledVehicle hook is the authoritative vehicle source.
    -- Do NOT call setVehicle(nil) from the mission update path: in FS25 the
    -- mission controlledVehicle value can be temporarily nil while the HUD
    -- still owns the valid controlled vehicle. Clearing it here was the cause
    -- of TEST0.1.0.5 losing both the HUD diagnosis and distance accumulation.
    local ok, err = pcall(
        ReifenVerschleissInstance.update,
        ReifenVerschleissInstance,
        dt
    )

end

local function RV_unload()
    if ReifenVerschleissInstance ~= nil then
        if g_messageCenter ~= nil then
            g_messageCenter:unsubscribeAll(ReifenVerschleissInstance)
        end
        ReifenVerschleissInstance.currentVehicle = nil
        ReifenVerschleissInstance.manifest = nil
        ReifenVerschleissInstance = nil
    end
end

Mission00.loadMission00Finished =
    Utils.appendedFunction(Mission00.loadMission00Finished, RV_loadedMission)

FSBaseMission.update =
    Utils.appendedFunction(FSBaseMission.update, RV_updateMission)

FSBaseMission.delete =
    Utils.appendedFunction(FSBaseMission.delete, RV_unload)

