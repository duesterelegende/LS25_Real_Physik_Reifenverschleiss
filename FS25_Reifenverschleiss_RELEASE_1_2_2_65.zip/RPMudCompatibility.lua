-- FS25_Reifenverschleiss - MudSystemPhysics compatibility runtime
-- Release performance cleanup: development diagnostics removed.
-- Functional purpose is unchanged: RP owns the worn tire-pressure baseline
-- after Mud/GIANTS has completed its update, without overwriting Mud's native
-- pressure deformation result.

RPMudCompatibility = RPMudCompatibility or {}
local D = RPMudCompatibility

D.enabled = true
D.radiusCombinerEpsilon = 0.0005
D.finalOwnerHookInstalled = false
D.finalOwnerInProgress = false
D.finalOwnerFallbackMs = 0
D.finalOwnerFallbackDelayMs = 750

local function num(v)
    return type(v) == "number" and v == v and v or nil
end

function D:update(dt)
    if self.enabled ~= true then return end

    -- Sleeping/startup fleet safety: establish the worn pressure baseline even
    -- for vehicles that are not currently receiving their normal vehicle update.
    self.finalOwnerFallbackMs = (self.finalOwnerFallbackMs or 0) + (num(dt) or 0)
    if self.finalOwnerFallbackMs >= self.finalOwnerFallbackDelayMs then
        self.finalOwnerFallbackMs = 0
        local mission = g_currentMission
        local vehicles = mission ~= nil and mission.vehicleSystem ~= nil and mission.vehicleSystem.vehicles or nil
        if vehicles ~= nil then
            for _, fleetVehicle in pairs(vehicles) do
                if fleetVehicle ~= nil and fleetVehicle.spec_wheels ~= nil then
                    self:finalOwnerCommit(fleetVehicle)
                end
            end
        end
    end
end

function D:finalOwnerCommit(vehicle)
    if self.enabled ~= true then return end
    if vehicle == nil or vehicle.isDeleted == true or vehicle.isDeleting == true then return end
    if vehicle.spec_wheels == nil or vehicle.spec_wheels.wheels == nil then return end

    for _, wheel in ipairs(vehicle.spec_wheels.wheels) do
        local wp = wheel ~= nil and wheel.physics or nil
        local wearBase = wheel ~= nil and num(wheel.rvRoundPhysicalRadius) or nil
        local wearOriginal = wheel ~= nil and num(wheel.rvRoundOriginalPhysicsRadius) or nil
        local wear = wheel ~= nil and num(wheel.rvRoundPhysicalWear) or nil

        -- Round tires only. Crawler/track physics has no rvRoundPhysicalRadius.
        if wp ~= nil and wearBase ~= nil and wearOriginal ~= nil and wear ~= nil and wear > 0 then
            -- Mud's TirePressureSystem uses __tpOrigRadius as its pressure-radius
            -- input. RP changes only that baseline to the worn tire radius.
            wp.__tpOrigRadius = wearBase

            -- Keep RP's wear-only visual/base radius. Mud/GIANTS keep ownership
            -- of physics.radius/netInfo and therefore retain native deformation.
            local currentWheelRadius = num(wheel.radius)
            if currentWheelRadius == nil or math.abs(currentWheelRadius - wearBase) > self.radiusCombinerEpsilon then
                wheel.radius = wearBase
            end

            wheel.__rvFinalOwnerSeen = true
            wheel.__rvFinalOwnerLastTime = g_time
        end
    end
end

function D:installFinalOwnerHook()
    if self.finalOwnerHookInstalled == true then return end
    if SpecializationUtil == nil or SpecializationUtil.raiseEvent == nil
        or Utils == nil or Utils.appendedFunction == nil then
        return
    end

    local owner = self
    SpecializationUtil.raiseEvent = Utils.appendedFunction(
        SpecializationUtil.raiseEvent,
        function(object, eventName, ...)
            -- Vehicle:update raises onUpdate after the native specialization
            -- updates. Do not overwrite Mud's current-frame pressure result;
            -- only move its pressure baseline for the following frame.
            if eventName == "onUpdate" and owner.finalOwnerInProgress ~= true then
                owner.finalOwnerInProgress = true
                pcall(owner.finalOwnerCommit, owner, object)
                owner.finalOwnerInProgress = false
            end
        end
    )
    self.finalOwnerHookInstalled = true
end

function D:loadMap()
    self.finalOwnerFallbackMs = 0
    self.finalOwnerInProgress = false
    self:installFinalOwnerHook()
end

function D:deleteMap()
end

addModEventListener(D)
