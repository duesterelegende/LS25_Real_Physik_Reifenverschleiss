-- FS25_Reifenverschleiss - Visual Wear
-- TEST0.2.0.1
--
-- Visual tire wear uses the RP shader interface implemented in this mod.
-- The wear source is ReifenVerschleissCore per-wheel TOTAL-WEAR.
-- The shader receives reference radius, tire width, current target radius
-- and tread reserve and performs radial tread deformation independently.
-- GIANTS physics radius remains synchronized with the visual tread loss.

ReifenVerschleissVisual = {}
local RVV = ReifenVerschleissVisual
RVV.trackProfileBodyY = {}

-- TEST2.3.00: Prinoth Raptor metal-crawler profile wear reference.
-- Decoded FS25-v10 raptor300Crawler.i3d.shapes: the actual crawler pad
-- profile is on negative local Y. The dominant body plane is -0.0562997 m
-- and the outermost profile plane is -0.0879690 m for both LOD0 and LOD1.
-- These values are read from the supplied Raptor mesh decode and are used
-- only for the Raptor crawler profile shader path.
RVV.RAPTOR_PROFILE_BODY_Y = -0.0562997
RVV.RAPTOR_PROFILE_OUTER_Y = -0.0879690
-- Only the 100% wear endpoint is intentionally changed for this test.
-- At 0% the original mesh limits above remain unchanged.
RVV.RAPTOR_PROFILE_WORN_Y = -0.0300000
RVV.RAPTOR_PROFILE_SHADER_VARIATION = "motionPath_vmaskUV2"
RVV.raptorTrackMaterialCache = {}
RVV.raptorTrackWearMaterialSlots = setmetatable({}, {__mode = "k"})
RVV.raptorProfileVehicleCache = setmetatable({}, {__mode = "k"})

-- TEST2.3.113: A8800MR/Hover steel runtime bridge test; profile cluster remains unchanged from 112.
-- Hover Shape 1 decode: 48 pads x 544 vertices; exactly 50 elevated profile
-- vertices per pad begin at local Y=0.03105038 m.  The test mask therefore
-- now starts at the NEXT decoded height cluster Y>=0.040366 m and collapses
-- only the upper profile crown toward the preserved first profile level 0.031050 m.  Rubber crawlers and Raptor remain untouched.
RVV.A8800_PROFILE_TEST_WEAR = 1.0
RVV.A8800_PROFILE_START_Y = -0.0700000
RVV.A8800_PROFILE_WORN_Y = -0.0524670
RVV.a8800TrackMaterialCache = {}
RVV.a8800TrackWearMaterialSlots = setmetatable({}, {__mode = "k"})
-- TEST2_4_0_23: dedicated runtime material state for the two confirmed
-- original GIANTS steel-crawler families (IMPEX Hannibal T50 / Volvo EC380DL).
-- Kept separate from rubber-track and A8800/Hover caches so existing visuals cannot be disturbed.
RVV.specialSteelTrackWearMaterialSlots = setmetatable({}, {__mode = "k"})
-- TEST2_4_0_43: runtime state table was referenced by the deferred Volvo
-- safety path but never initialized. Keep weak vehicle keys so returned/sold
-- vehicles cannot leave stale state behind. This does not alter crawler physics.
RVV.volvoSteelRuntimeState = setmetatable({}, {__mode = "k"})
-- TEST2.3.01: cache generic crawler render-shape discovery per vehicle/crawler.
-- The expensive I3D traversal must never run every mission frame.
RVV.genericCrawlerVehicleCache = setmetatable({}, {__mode = "k"})
-- TEST2.3.02: cache the crawler classification itself. Vehicles without
-- spec_crawlers must never enter any crawler traversal/update path.
RVV.crawlerVehicleTypeCache = setmetatable({}, {__mode = "k"})

RVV.VERSION = "RELEASE_1_2_2_51_PERFORMANCE_CADENCE_TEST"
RVV.MOD_DIRECTORY = g_currentModDirectory
RVV.MATERIAL_HOLDER_PATH = "material/rpTireMaterialHolder.i3d"
RVV.MATERIAL_VARIATION = "tirePressureDeformation"
RVV.SHADER_PARAMETER = "rpTireWearData"
RVV.MAX_USAGE_FACTOR = 0.75
RVV.UPDATE_INTERVAL_SEC = 0.20

-- RELEASE PERFORMANCE CADENCE TEST:
-- Crawler/track profile wear is visual-only and changes slowly. Keep the
-- proven 5 Hz cadence while the vehicle is active/near the camera, but lower
-- stationary vehicles that are well outside the useful camera range to 1 Hz.
-- Runtime wear calculation itself is NOT throttled by these values.
RVV.CRAWLER_ACTIVE_UPDATE_INTERVAL_SEC = 0.20
RVV.CRAWLER_IDLE_FAR_UPDATE_INTERVAL_SEC = 1.00
RVV.OUT_OF_SIGHT_DISTANCE_M = 200.0
RVV.t9CrawlerVehicleCache = setmetatable({}, {__mode = "k"})

-- TEST0.2.0.50:
-- A workshop vehicle is not the currently controlled vehicle while the player
-- is standing at the workshop trigger. Therefore the normal Wheel.update /
-- clientUpdate hooks are not guaranteed to run for the vehicle immediately
-- after the reset. Keep a very short, frame-driven refresh queue so the
-- already loaded visual parts are refreshed independently of controlledVehicle.
RVV._pendingVisualResets = setmetatable({}, {__mode = "k"})
RVV._pendingVisualResetLifetime = 1.0
RVV._pendingVisualResetStep = 0.05

-- TEST2.3.92: load-time visual settling queue. This is intentionally
-- separate from the workshop RESET queue: it never changes OWN-WEAR and only
-- asks the existing tire/rubber-crawler/metal-crawler visual workers to
-- consume the already restored state while GIANTS finishes its render setup.
RVV._pendingVisualLoadRefreshes = setmetatable({}, {__mode = "k"})
RVV._pendingVisualLoadRefreshLifetime = 1.0
RVV._pendingVisualLoadRefreshStep = 0.05

RVV.materialId = nil
RVV.materialNode = nil
RVV.materialLoadRequestId = nil
RVV.materialLoaded = false

local function clampWear(value)
    if type(value) ~= "number" or value ~= value then
        return 0
    end
    return math.max(0, math.min(1, value))
end

local function rvGetVisualVehicleSpeedKmh(vehicle)
    if vehicle == nil then return 0 end

    local speedReal = math.abs(tonumber(vehicle.lastSpeedReal) or 0)
    if speedReal > 0.000001 then
        return speedReal * 1000 * 3.6
    end

    if vehicle.getLastSpeed ~= nil then
        local ok, speedKmh = pcall(vehicle.getLastSpeed, vehicle, false)
        if ok and type(speedKmh) == "number" then
            return math.abs(speedKmh)
        end
    end
    return 0
end

local function rvIsStationaryAndFarFromCamera(vehicle)
    if vehicle == nil then return false end
    if rvGetVisualVehicleSpeedKmh(vehicle) > 0.05 then return false end

    -- lastDistanceToCamera is maintained by GIANTS. If it is unavailable,
    -- stay conservative and keep the normal 5 Hz visual cadence.
    local distance = tonumber(vehicle.lastDistanceToCamera)
    return distance ~= nil and distance >= RVV.OUT_OF_SIGHT_DISTANCE_M
end

local function rvGetCrawlerVisualInterval(vehicle)
    if rvIsStationaryAndFarFromCamera(vehicle) then
        return RVV.CRAWLER_IDLE_FAR_UPDATE_INTERVAL_SEC
    end
    return RVV.CRAWLER_ACTIVE_UPDATE_INTERVAL_SEC
end

local function rvCrawlerImmediateRefreshRequested()
    return RVV._forceCrawlerVisualRefresh == true or RVV._inImmediateLoadRefresh == true
end

local function isRelevantVehicle(vehicle)
    if vehicle == nil or ReifenVerschleissCore == nil then
        return false
    end

    if ReifenVerschleissCore.isRelevantPlayerVehicle == nil then
        return true
    end

    local ok, result = pcall(
        ReifenVerschleissCore.isRelevantPlayerVehicle,
        vehicle
    )

    if ok and result == true then
        return true
    end

    -- Passive trailers/implements are not player vehicles themselves, but
    -- their wheel visuals belong to the currently relevant player vehicle.
    if vehicle.getAttacherVehicle ~= nil then
        local okParent, parent = pcall(vehicle.getAttacherVehicle, vehicle)
        if okParent and parent ~= nil then
            local okRoot, rootRelevant = pcall(
                ReifenVerschleissCore.isRelevantPlayerVehicle,
                parent
            )
            if okRoot and rootRelevant == true then
                return true
            end
        end
    end

    return false
end

-- Load the RP tire-wear material holder.
local function loadTireMaterial()
    if RVV.materialLoaded then
        return RVV.materialId ~= nil
    end

    local materialPath = Utils.getFilename(
        RVV.MATERIAL_HOLDER_PATH,
        RVV.MOD_DIRECTORY
    )

    local nodeId, sharedLoadRequestId = g_i3DManager:loadSharedI3DFile(
        materialPath,
        false,
        false
    )

    if nodeId == nil or nodeId <= 0 then
        return false
    end

    RVV.materialLoadRequestId = sharedLoadRequestId
    RVV.materialNode = I3DUtil.indexToObject(nodeId, "0|0")

    if RVV.materialNode == nil then
        return false
    end

    RVV.materialId = getMaterial(RVV.materialNode, 0)

    if RVV.materialId == nil then
        return false
    end

    RVV.materialLoaded = true

    return true
end

local function copyTextureMaps(previousMaterialId, newMaterialId)
    if previousMaterialId == nil or newMaterialId == nil then
        return newMaterialId
    end

    local texturePath = getMaterialCustomMapFilename(
        previousMaterialId,
        "detailDiffuse"
    )
    if texturePath ~= nil and (string.findLast(texturePath, ".dds") > 0 or string.findLast(texturePath, ".png") > 0) then
        newMaterialId = setMaterialCustomMapFromFile(
            newMaterialId,
            "detailDiffuse",
            texturePath,
            false,
            true,
            false
        )
    end

    texturePath = getMaterialCustomMapFilename(
        previousMaterialId,
        "detailNormal"
    )
    if texturePath ~= nil and (string.findLast(texturePath, ".dds") > 0 or string.findLast(texturePath, ".png") > 0) then
        newMaterialId = setMaterialCustomMapFromFile(
            newMaterialId,
            "detailNormal",
            texturePath,
            false,
            false,
            false
        )
    end

    texturePath = getMaterialCustomMapFilename(
        previousMaterialId,
        "detailSpecular"
    )
    if texturePath ~= nil and (string.findLast(texturePath, ".dds") > 0 or string.findLast(texturePath, ".png") > 0) then
        newMaterialId = setMaterialCustomMapFromFile(
            newMaterialId,
            "detailSpecular",
            texturePath,
            false,
            false,
            false
        )
    end

    texturePath = getMaterialDiffuseMapFilename(previousMaterialId)
    if texturePath ~= nil and (string.findLast(texturePath, ".dds") > 0 or string.findLast(texturePath, ".png") > 0) then
        newMaterialId = setMaterialDiffuseMapFromFile(
            newMaterialId,
            texturePath,
            false,
            true,
            false
        )
    end

    texturePath = getMaterialNormalMapFilename(previousMaterialId)
    if texturePath ~= nil and (string.findLast(texturePath, ".dds") > 0 or string.findLast(texturePath, ".png") > 0) then
        newMaterialId = setMaterialNormalMapFromFile(
            newMaterialId,
            texturePath,
            false,
            false,
            false
        )
    end

    texturePath = getMaterialGlossMapFilename(previousMaterialId)
    if texturePath ~= nil and (string.findLast(texturePath, ".dds") > 0 or string.findLast(texturePath, ".png") > 0) then
        newMaterialId = setMaterialGlossMapFromFile(
            newMaterialId,
            texturePath,
            false,
            false,
            false
        )
    end

    return newMaterialId
end

-- ReifenVerschleiss visual traversal. No alternative tire detection is used here:
-- the requested model is the reference model itself.
local function initializeWheelVisuals(wheel)
    if wheel == nil or wheel.visualWheels == nil then
        return
    end

    local hasAnyTire = false

    for visualWheelIndex, visualWheel in ipairs(wheel.visualWheels) do
        for visualPartIndex, visualPart in ipairs(visualWheel.visualParts) do
            if visualPart:isa(WheelVisualPartTire) then
                local materialId = nil
                if loadTireMaterial() then
                    materialId = RVV.materialId
                end

                if materialId ~= nil then
                    for tireNodeIndex, tireNode in ipairs(visualPart.tireNodes) do
                        local previousMaterialId = getMaterial(tireNode, 0)
                        local previousVariation = getMaterialCustomShaderVariation(previousMaterialId)

                        local isPassiveObject = wheel.vehicle ~= nil
                            and wheel.vehicle.getAttacherVehicle ~= nil
                            and pcall(wheel.vehicle.getAttacherVehicle, wheel.vehicle)
                        local hasUsedTireParameter = false
                        if tireNode ~= nil then
                            local okParam, valueParam = pcall(getHasShaderParameter, tireNode, RVV.SHADER_PARAMETER)
                            hasUsedTireParameter = okParam and valueParam == true
                        end

                        -- Normal vehicles keep the proven ReifenVerschleiss material-variation gate.
                        -- Passive implements/trailers get one additional compatible
                        -- entry path: if the actual TireNode already exposes the
                        -- `rpTireWearData` shader parameter, it is a valid visual tire even
                        -- when the source material variation is not named
                        -- `tirePressureDeformation`.
                        local visualTargetValid = previousMaterialId ~= nil and
                            (previousVariation == RVV.MATERIAL_VARIATION or
                             (isPassiveObject and hasUsedTireParameter))

                        if visualTargetValid then
                            local scratches1, scratches2, scratches3, scratches4 =
                                getShaderParameter(tireNode, "scratches_dirt_snow_wetness")
                            local porosity1 = getShaderParameter(tireNode, "porosity")
                            local morph1, morph2, morph3, morph4 =
                                getShaderParameter(tireNode, "morphPos")

                            local replacementMaterialId = copyTextureMaps(
                                previousMaterialId,
                                materialId
                            )

                            setMaterial(tireNode, replacementMaterialId, 0)

                            setShaderParameter(
                                tireNode,
                                "scratches_dirt_snow_wetness",
                                scratches1,
                                scratches2,
                                scratches3,
                                scratches4,
                                false
                            )
                            setShaderParameter(
                                tireNode,
                                "porosity",
                                porosity1,
                                nil,
                                nil,
                                nil,
                                false
                            )
                            setShaderParameter(
                                tireNode,
                                "morphPos",
                                morph1,
                                morph2,
                                morph3,
                                morph4,
                                false
                            )

                            -- ReifenVerschleiss initialization call.
                            setShaderParameter(
                                tireNode,
                                RVV.SHADER_PARAMETER,
                                2.0,
                                2.0,
                                2.0,
                                0.001,
                                false
                            )

                            visualPart.rvEnabled = true
                            hasAnyTire = true

                        end
                    end
                end
            end
        end
    end

    wheel.vehicle.rvHasVisualTyres = wheel.vehicle.rvHasVisualTyres or hasAnyTire
end

Wheel.postLoad = Utils.appendedFunction(
    Wheel.postLoad,
    initializeWheelVisuals
)

-- TEST0.2.2.25: passive implement visual refresh.
-- The wear state already updates per wheel. This function deliberately reuses
-- the established normal ReifenVerschleiss visual worker instead of introducing a second shader path.
-- It is called from the passive wear update after the wheel's own wear state has
-- changed, so implements are not dependent on being the controlled vehicle.
local updateWheelVisuals

function RVV.refreshAttachedImplementVisuals(implement)
    if implement == nil or implement.spec_wheels == nil or implement.spec_wheels.wheels == nil then
        return 0
    end

    local refreshed = 0
    for _, wheel in ipairs(implement.spec_wheels.wheels) do
        if wheel ~= nil then
            if wheel.visualWheels ~= nil then
                local needsInitialization = false
                for _, visualWheel in ipairs(wheel.visualWheels) do
                    for _, visualPart in ipairs(visualWheel.visualParts or {}) do
                        if visualPart:isa(WheelVisualPartTire) and visualPart.rvEnabled ~= true then
                            needsInitialization = true
                            break
                        end
                    end
                    if needsInitialization then break end
                end

                if needsInitialization then
                    initializeWheelVisuals(wheel)
                end

                local hadEnabled = false
                for _, visualWheel in ipairs(wheel.visualWheels) do
                    for _, visualPart in ipairs(visualWheel.visualParts or {}) do
                        if visualPart:isa(WheelVisualPartTire) and visualPart.rvEnabled == true then
                            hadEnabled = true
                        end
                    end
                end

                if hadEnabled then
                    wheel.rvVisualImmediateRefresh = true
                    updateWheelVisuals(wheel)
                    refreshed = refreshed + 1
                end
            end
        end
    end

    return refreshed
end

-- ReifenVerschleiss wear source:
-- use the persistent own TOTAL-WEAR for this exact wheel.
local function getOwnWheelWear(wheel)
    if ReifenVerschleissCore == nil or
       ReifenVerschleissCore.getWheelWearValue == nil then
        return 0
    end

    local ok, value = pcall(
        ReifenVerschleissCore.getWheelWearValue,
        wheel.vehicle,
        wheel
    )

    if not ok then
        return 0
    end

    return clampWear(value)
end

local function updateWheelVisualRadius(visualPart, isClientOnly, vehicle)
    if visualPart.rvMaxUsage == nil or
       visualPart.rvMaxRadius == nil or
       visualPart.rvMaxPhysRadius == nil then
        return
    end

    local wheel = visualPart.visualWheel.wheel
    local wheelWear = getOwnWheelWear(wheel)
    local tireRadiusDifference = wheelWear * visualPart.rvMaxUsage
    local rpTargetRadius = visualPart.rvMaxRadius - tireRadiusDifference

    -- ReifenVerschleiss update threshold.
    if visualPart.rvCurrentRadius ~= nil and
       math.abs(visualPart.rvCurrentRadius - rpTargetRadius) < 0.001 then
        return
    end

    visualPart.rvCurrentRadius = rpTargetRadius

    -- TEST0.2.0.17: keep the physical rolling radius in step with the
    -- already proven visual tread-radius loss.  The visual shader removes
    -- exactly (wear * rvMaxUsage) from the tire radius; using the same
    -- delta for the GIANTS wheel physics removes the remaining small
    -- "floating" effect without inventing a second wear scale.
    -- Only the server changes the authoritative wheel shape.
    if wheel ~= nil and vehicle ~= nil and vehicle.isServer == true and
       wheel.physics ~= nil and wheel.physics.radiusOriginal ~= nil then
        local originalPhysicsRadius = tonumber(wheel.physics.radiusOriginal)
        if originalPhysicsRadius ~= nil and originalPhysicsRadius > 0 then
            -- TEST2_4_0_49: round tires only. Mirror the *actual* current
            -- rpVisualTreadCenterRadius() shader curve instead of using the
            -- older raw tread loss + 15 mm approximation. The shader has used
            -- a stronger progressive high-wear deformation since TEST2_4_0_9;
            -- keeping physics on the old curve leaves a visible fly-over gap.
            --
            -- Shader equivalent:
            --   wearT      = saturate(rawDepth / reserve)
            --   highWearT  = smoothstep(0.75, 1.00, wearT)
            --   baseDepth  = rawDepth * 1.35
            --   endDepth   = reserve * 1.85
            --   visualDepth= lerp(baseDepth, endDepth, highWearT)
            --   clamp      = reserve * 1.90
            local reserve = math.max(math.abs(tonumber(visualPart.rvMaxUsage) or 0), 0.001)
            local rawDepth = math.max(0, tireRadiusDifference)
            local wearT = math.max(0, math.min(1, rawDepth / reserve))
            local highWearT = math.max(0, math.min(1, (wearT - 0.75) / 0.25))
            highWearT = highWearT * highWearT * (3 - 2 * highWearT)

            local baseDepth = rawDepth * 1.35
            local endDepth = reserve * 1.85
            local visualDepth = baseDepth + (endDepth - baseDepth) * highWearT
            visualDepth = math.min(visualDepth, reserve * 1.90)

            local physicsWearDelta = math.max(0, visualDepth)

            -- TEST2_4_0_50: the wear shader is calibrated against rvMaxRadius,
            -- not directly against GIANTS radiusOriginal.  On some tires those
            -- two baselines differ by roughly 10-20 mm.  Subtracting the shader
            -- depth only from radiusOriginal therefore leaves exactly that
            -- constant fly-over gap at high wear.
            --
            -- Keep a new tire 100% GIANTS-original and blend this baseline
            -- correction in with actual wear.  At 100% wear the physical contact
            -- radius therefore reaches the same calibrated radius basis used by
            -- the shader, while 0% wear is completely unchanged.
            local visualBaseRadius = tonumber(visualPart.rvMaxRadius) or originalPhysicsRadius
            local baselineOffset = math.max(0, originalPhysicsRadius - visualBaseRadius)
            local baselineCorrection = baselineOffset * wheelWear
            local targetPhysicsRadius = math.max(0.05, originalPhysicsRadius - physicsWearDelta - baselineCorrection)
            local currentPhysicsRadius = tonumber(wheel.physics.radius) or tonumber(wheel.radius) or originalPhysicsRadius

            wheel.rvRoundOriginalPhysicsRadius = originalPhysicsRadius
            wheel.rvRoundPhysicalWear = wheelWear
            wheel.rvRoundPhysicalRadius = targetPhysicsRadius

            if math.abs(currentPhysicsRadius - targetPhysicsRadius) > 0.0005 then
                wheel.physics.radius = targetPhysicsRadius
                wheel.radius = targetPhysicsRadius

                if vehicle.updateWheelBase ~= nil then
                    vehicle:updateWheelBase(wheel)
                elseif vehicle.setWheelPositionDirty ~= nil then
                    vehicle:setWheelPositionDirty(wheel)
                end

            end
        end
    end

    -- The shader receives the ReifenVerschleiss visual values below.

    for tireNodeIndex, tireNode in ipairs(visualPart.tireNodes) do
        -- ReifenVerschleiss update signature and value order.
        setShaderParameter(
            tireNode,
            RVV.SHADER_PARAMETER,
            visualPart.rvMaxRadius,
            visualPart.rvWidth,
            visualPart.rvCurrentRadius,
            visualPart.rvMaxUsage,
            nil,
            false
        )

    end
end

-- Reset the visual state immediately after a native GIANTS workshop repair/
-- repaint. This prevents the old own wear from remaining visible for the next
-- four-second normal update interval. The function deliberately restores only
-- our wear-related values; original materials, MotionPath and TrackArray stay
-- untouched.
-- Immediate client-side visual reset for RP Reifen wechseln.
-- The authoritative wear reset is executed on the server. Custom wheel-wear
-- state is not a GIANTS network field, so clients must explicitly repaint the
-- already initialized shader values instead of waiting for Wheel.update() or
-- re-entering the vehicle.
function RVV.queueImmediateVisualReset(vehicle)
    if ReifenVerschleissCore ~= nil
        and ReifenVerschleissCore.isVehicleExcluded ~= nil
        and ReifenVerschleissCore.isVehicleExcluded(vehicle) then
        return
    end
    if vehicle == nil then
        return
    end

    RVV._pendingVisualResets[vehicle] = {
        remaining = RVV._pendingVisualResetLifetime,
        accumulator = 0
    }
end

function RVV.updatePendingVisualResets(dt)
    if dt == nil then
        return
    end

    for vehicle, state in pairs(RVV._pendingVisualResets) do
        if vehicle == nil or state == nil then
            RVV._pendingVisualResets[vehicle] = nil
        else
            state.remaining = state.remaining - dt
            state.accumulator = state.accumulator + dt

            -- First refresh is performed by the caller immediately. Retry at
            -- 50 ms boundaries for only one second. This is deliberately not
            -- a multi-second timer; it bridges the workshop/non-controlled
            -- vehicle update gap while the GIANTS render state catches up.
            if state.accumulator >= RVV._pendingVisualResetStep then
                state.accumulator = 0
                local ok, err = pcall(
                    RVV.resetVehicleWearVisualsImmediate,
                    vehicle
                )
            end

            if state.remaining <= 0 then
                RVV._pendingVisualResets[vehicle] = nil
            end
        end
    end
end


-- Queue only the concrete vehicle whose persistent OWN-WEAR has just been
-- restored. No mission-wide scan and no controlledVehicle dependency.
function RVV.queueLoadVisualRefresh(vehicle)
    if ReifenVerschleissCore ~= nil
        and ReifenVerschleissCore.isVehicleExcluded ~= nil
        and ReifenVerschleissCore.isVehicleExcluded(vehicle) then
        return
    end
    if vehicle == nil then
        return
    end

    RVV._pendingVisualLoadRefreshes[vehicle] = {
        remaining = RVV._pendingVisualLoadRefreshLifetime,
        accumulator = 0
    }
end

function RVV.updatePendingLoadVisualRefreshes(dt)
    if dt == nil then
        return
    end

    for vehicle, state in pairs(RVV._pendingVisualLoadRefreshes) do
        if vehicle == nil or state == nil then
            RVV._pendingVisualLoadRefreshes[vehicle] = nil
        else
            state.remaining = state.remaining - dt
            state.accumulator = state.accumulator + dt

            -- Vehicle:onFinishedLoading already performed the first immediate
            -- refresh. These short retries bridge late wheel/crawler material
            -- finalisation, analogous to the proven workshop visual settling
            -- path, but they never reset or recalculate wear.
            if state.accumulator >= RVV._pendingVisualLoadRefreshStep then
                state.accumulator = 0
                local ok, err = pcall(RVV.refreshVehicleWearVisualsImmediate, vehicle)
            end

            if state.remaining <= 0 then
                RVV._pendingVisualLoadRefreshes[vehicle] = nil
            end
        end
    end
end


local function RP_applyDirectTireVisualReset(vehicle)
    if vehicle == nil or vehicle.spec_wheels == nil or vehicle.spec_wheels.wheels == nil then
        return
    end

    for _, wheel in ipairs(vehicle.spec_wheels.wheels) do
        if wheel.visualWheels ~= nil then
            for _, visualWheel in ipairs(wheel.visualWheels) do
                if visualWheel.visualParts ~= nil then
                    for _, visualPart in ipairs(visualWheel.visualParts) do
                        if visualPart ~= nil and visualPart:isa(WheelVisualPartTire) and visualPart.node ~= nil then
                            local currentRadius = visualPart.rvCurrentRadius or visualPart.currentRadius
                            local maxRadius = visualPart.rvMaxRadius or visualPart.maxRadius

                            if maxRadius ~= nil then
                                if currentRadius == nil then
                                    currentRadius = maxRadius
                                end

                                if visualPart.tireNodes ~= nil then
                                    for _, tireNode in ipairs(visualPart.tireNodes) do
                                        if tireNode ~= nil and tireNode ~= 0 then
                                            setShaderParameter(
                                                tireNode,
                                                "rpTireWearData",
                                                maxRadius,
                                                visualPart.rvWidth or visualPart.width or 0,
                                                currentRadius,
                                                visualPart.rvMaxUsage or visualPart.maxUsage or 0,
                                                nil,
                                                false
                                            )
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

function RVV.resetVehicleWearVisualsImmediate(vehicle)
    if ReifenVerschleissCore ~= nil
        and ReifenVerschleissCore.isVehicleExcluded ~= nil
        and ReifenVerschleissCore.isVehicleExcluded(vehicle) then
        return
    end
    RP_applyDirectTireVisualReset(vehicle)
    if vehicle == nil then
        return
    end

    local restoredNormal = 0

    local wheels = nil
    if vehicle.spec_wheels ~= nil then
        wheels = vehicle.spec_wheels.wheels
    end
    if wheels == nil then
        wheels = vehicle.wheels
    end

    for _, wheel in ipairs(wheels or {}) do
        if wheel ~= nil and wheel.visualWheels ~= nil then
            for _, visualWheel in ipairs(wheel.visualWheels) do
                for _, visualPart in ipairs(visualWheel.visualParts or {}) do
                    if visualPart:isa(WheelVisualPartTire) and visualPart.rvEnabled == true then
                        if visualPart.rvMaxRadius ~= nil and visualPart.rvWidth ~= nil and
                           visualPart.rvMaxUsage ~= nil then
                            -- Restore the physical rolling/contact radius immediately.
                            -- The normal wear update reduces it by the same visual tread
                            -- loss. A tire replacement must therefore restore the original
                            -- unworn boundary before the visual repaint.
                            local wheel = visualPart.visualWheel ~= nil and visualPart.visualWheel.wheel or nil
                            local originalPhysicsRadius = tonumber(visualPart.rvMaxPhysRadius)
                                or (wheel ~= nil and wheel.physics ~= nil and tonumber(wheel.physics.radiusOriginal) or nil)
                            if wheel ~= nil and vehicle.isServer == true and originalPhysicsRadius ~= nil and originalPhysicsRadius > 0 then
                                local targetPhysicsRadius = originalPhysicsRadius
                                if math.abs((tonumber(wheel.radius) or originalPhysicsRadius) - targetPhysicsRadius) > 0.0005 then
                                    wheel.physics.radius = targetPhysicsRadius
                                    wheel.radius = targetPhysicsRadius
                                    if vehicle.updateWheelBase ~= nil then
                                        vehicle:updateWheelBase(wheel)
                                    elseif vehicle.setWheelPositionDirty ~= nil then
                                        vehicle:setWheelPositionDirty(wheel)
                                    end
                                end
                                wheel.rvRoundPhysicalWear = 0
                                wheel.rvRoundPhysicalRadius = targetPhysicsRadius
                                wheel.rvRoundOriginalPhysicsRadius = originalPhysicsRadius
                            end

                                            -- TEST0.2.0.50: call the exact same visual worker that the normal
                            -- Wheel.update/clientUpdate hooks call during driving. The hook itself
                            -- is only the scheduler; updateWheelVisualRadius() is the actual worker
                            -- that calculates the current tread radius, synchronizes physics on the
                            -- server and writes the RP tire-wear shader parameter. Invalidate the cached
                            -- radius first so the worker cannot return early after a 100% -> 0% reset.
                            visualPart.rvCurrentRadius = nil
                            local okWorker, workerErr = pcall(
                                updateWheelVisualRadius,
                                visualPart,
                                vehicle.isClient == true and vehicle.isServer ~= true,
                                vehicle
                            )
                            visualPart.rvCurrentRadius = visualPart.rvMaxRadius
                            visualPart.rvServerLastUpdate = nil
                            visualPart.rvClientLastUpdate = nil
                            for _, tireNode in ipairs(visualPart.tireNodes or {}) do
                                setShaderParameter(
                                    tireNode,
                                    RVV.SHADER_PARAMETER,
                                    visualPart.rvMaxRadius,
                                    visualPart.rvWidth,
                                    visualPart.rvMaxRadius,
                                    visualPart.rvMaxUsage,
                                    nil,
                                    false
                                )
                            end
                            restoredNormal = restoredNormal + 1
                        end
                    end
                end
            end
        end
    end

    -- T9/crawler branch: use the same direct visual-refresh principle as the
    -- proven normal-tire path, adapted to the crawler scroller/material path.
    -- The target vehicle may be outside the controlled vehicle, so do not wait
    -- for Wheel.update() to perform the material swap and shader refresh.
    if vehicle.spec_crawlers ~= nil and vehicle.spec_crawlers.crawlers ~= nil then
        -- Crawler physics stays entirely GIANTS-owned. Only reset the visual
        -- wear parameter; do not touch wheel.radius, physics.radius or wheelShape.
        for _, crawler in ipairs(vehicle.spec_crawlers.crawlers) do
            for _, entry in ipairs(crawler.scrollerNodes or {}) do
                local node = entry ~= nil and entry.node or nil
                if node ~= nil and node ~= 0 and
                   getHasShaderParameter(node, "trackProfileWear") then
                    setShaderParameter(node, "trackProfileWear", 0, nil, nil, nil, false)
                end
            end
        end

        -- Crawler equivalent of directly invoking the proven visual worker.
        -- This also initializes the T9 wear material on a non-controlled
        -- workshop vehicle before writing trackProfileWear=0.
        if RVV.updateT9TrackWear ~= nil then
            RVV._forceCrawlerVisualRefresh = true
            local okTrack, trackErr = pcall(
                RVV.updateT9TrackWear,
                vehicle
            )
            RVV._forceCrawlerVisualRefresh = false
        end
    end

    if RPMudOverlayCompatibility ~= nil and
       RPMudOverlayCompatibility.refreshVehicleImmediate ~= nil then
        pcall(RPMudOverlayCompatibility.refreshVehicleImmediate, RPMudOverlayCompatibility, vehicle)
    end
end

function RVV.resetVehicleWearVisuals(vehicle)
    if ReifenVerschleissCore ~= nil
        and ReifenVerschleissCore.isVehicleExcluded ~= nil
        and ReifenVerschleissCore.isVehicleExcluded(vehicle) then
        return
    end
    if vehicle == nil then
        return
    end

    local restoredNormal = 0
    if vehicle.wheels ~= nil then
        for _, wheel in ipairs(vehicle.wheels) do
            if wheel ~= nil and wheel.visualWheels ~= nil then
                for _, visualWheel in ipairs(wheel.visualWheels) do
                    for _, visualPart in ipairs(visualWheel.visualParts or {}) do
                        if visualPart:isa(WheelVisualPartTire) and visualPart.rvEnabled == true then
                            local originalRadius = tonumber(visualPart.rvMaxPhysRadius)
                                or (wheel.physics ~= nil and tonumber(wheel.physics.radiusOriginal) or nil)
                            if originalRadius ~= nil and originalRadius > 0 and
                               wheel.physics ~= nil and vehicle.isServer == true then
                                wheel.physics.radius = originalRadius
                                wheel.radius = originalRadius
                                if vehicle.updateWheelBase ~= nil then
                                    vehicle:updateWheelBase(wheel)
                                elseif vehicle.setWheelPositionDirty ~= nil then
                                    vehicle:setWheelPositionDirty(wheel)
                                end
                            end

                            visualPart.rvCurrentRadius = nil
                            visualPart.rvServerLastUpdate = nil
                            visualPart.rvClientLastUpdate = nil
                            updateWheelVisualRadius(visualPart, true, vehicle)
                            restoredNormal = restoredNormal + 1
                        end
                    end
                end
            end
        end
    end

    -- T9 track branch: reset only the shader wear parameter.  Crawler physics,
    -- TrackArray and MotionPath remain untouched.
    if vehicle.spec_crawlers ~= nil and vehicle.spec_crawlers.crawlers ~= nil then
        for _, crawler in ipairs(vehicle.spec_crawlers.crawlers) do
            for _, entry in ipairs(crawler.scrollerNodes or {}) do
                local node = entry ~= nil and entry.node or nil
                if node ~= nil and node ~= 0 and getHasShaderParameter(node, "trackProfileWear") then
                    setShaderParameter(node, "trackProfileWear", 0, nil, nil, nil, false)
                end
            end
        end
    end

end

-- ReifenVerschleiss initialization/calibration model, with rv* variable names and
-- without changing the physical wheel radius.
updateWheelVisuals = function(wheel)
    if RVV._forcingNativeWheelUpdate then
        return false
    end

    if wheel == nil or wheel.vehicle == nil or not isRelevantVehicle(wheel.vehicle) then
        return
    end

    local updateFriction = false

    for visualWheelIndex, visualWheel in ipairs(wheel.visualWheels) do
        for visualPartIndex, visualPart in ipairs(visualWheel.visualParts) do
            if visualPart:isa(WheelVisualPartTire) and
               visualPart.node ~= nil and
               visualPart.rvEnabled == true then

                local timeNow = getTimeSec()

                local forceImmediate = wheel.rvVisualImmediateRefresh == true
                if forceImmediate then
                    visualPart.rvServerLastUpdate = nil
                end

                if forceImmediate or visualPart.rvServerLastUpdate == nil or
                   timeNow - visualPart.rvServerLastUpdate > RVV.UPDATE_INTERVAL_SEC then

                    if wheel.vehicle.isServer then
                        for tireNodeIndex, tireNode in ipairs(visualPart.tireNodes) do
                            local previousMaterialId = getMaterial(tireNode, 0)
                            local previousVariation = getMaterialCustomShaderVariation(previousMaterialId)

                            if previousMaterialId ~= nil and previousVariation == RVV.MATERIAL_VARIATION then
                                if visualPart.rvMaxUsage == nil then
                                    local _, _, _ = getScale(tireNode)
                                    local tireClone = clone(tireNode, false, false, false)
                                    setScale(tireClone, 0, 1, 1)
                                    link(getRootNode(), tireClone)
                                    local _, _, _, radius = getShapeWorldBoundingSphere(tireClone)
                                    unlink(tireClone)
                                    delete(tireClone)

                                    visualPart.rvMaxRadius =
                                        (radius + wheel.physics.radiusOriginal) * 0.5
                                    visualPart.rvWidth = wheel.physics.width
                                    visualPart.rvMaxPhysRadius = wheel.physics.radiusOriginal
                                    visualPart.rvMaxUsage =
                                        visualPart.maxDeformation * RVV.MAX_USAGE_FACTOR

                                    -- Protection against invalid/fake wheel geometry.
                                    local radiusRatio = wheel.physics.radiusOriginal / radius
                                    if radiusRatio < 0.85 then
                                        visualPart.rvMaxRadius = nil
                                        visualPart.rvWidth = nil
                                        visualPart.rvMaxPhysRadius = nil
                                        visualPart.rvMaxUsage = nil
                                        visualPart.rvEnabled = false
                                        wheel.vehicle.rvHasVisualTyres = false
                                        wheel.vehicle.rvUnsupported = true
                                    end
                                end
                            end
                        end
                    end

                    updateWheelVisualRadius(
                        visualPart,
                        not wheel.vehicle.isServer,
                        wheel.vehicle
                    )

                    visualPart.rvServerLastUpdate = timeNow
                end
            end
        end
    end

    -- Friction is not marked dirty here because the physical radius remains unchanged.
    -- We deliberately do NOT do this because our physical radius remains unchanged.
    wheel.rvVisualImmediateRefresh = nil
    return updateFriction
end

Wheel.update = Utils.appendedFunction(
    Wheel.update,
    updateWheelVisuals
)

-- ReifenVerschleiss client-update cadence and traversal. The visual shader receives
-- the same per-wheel wear source on clients.
local function updateWheelVisualsClient(wheel)
    if wheel == nil or wheel.visualWheels == nil then
        return
    end

    local timeNow = getTimeSec()

    for _, visualWheel in ipairs(wheel.visualWheels) do
        for _, visualPart in ipairs(visualWheel.visualParts) do
            if visualPart:isa(WheelVisualPartTire) then
                if visualPart.rvClientLastUpdate == nil or
                   timeNow - visualPart.rvClientLastUpdate > RVV.UPDATE_INTERVAL_SEC then
                    updateWheelVisualRadius(
                        visualPart,
                        true,
                        wheel.vehicle
                    )
                    visualPart.rvClientLastUpdate = timeNow
                end
            end
        end
    end
end

Wheel.clientUpdate = Utils.appendedFunction(
    Wheel.clientUpdate,
    updateWheelVisualsClient
)


-- TEST0.2.0.1: Band-/Crawler-Wear branch.
-- This branch is deliberately separate from the proven normal-tire ReifenVerschleiss path above.
-- The original T9 crawler node/material/trackArray/scrollPos path is preserved.
RVV.TRACK_MATERIAL_HOLDER_PATH = "material/trackMaterialHolder.i3d"
RVV.TRACK_PROFILE_MAX_DEPTH = 0.062878668
RVV.TRACK_PROFILE_BASE_Y = 0.0
-- T9 outer tread was identified on the negative local-Y side. The T9 track
-- node has Y scale 0.95, therefore the maximum physical tread-depth loss
-- corresponding to the current geometry test is 0.087339 * 0.95 meters.
RVV.T9_OUTER_TREAD_DEPTH_M = 0.08297205
-- Small additional cover margin to eliminate the remaining isolated inner-wheel
-- bleed-through at very high track wear. This is intentionally only 5 mm.
RVV.T9_INNER_WHEEL_COVER_MARGIN_M = 0.010
RVV.T9_MIN_CRAWLER_RADIUS_M = 0.001
RVV.trackMaterialId = nil
RVV.trackMaterialNode = nil
RVV.trackMaterialLoaded = false
RVV.trackMaterialCache = {}
RVV.trackWearNodes = setmetatable({}, {__mode = "k"})

local function rvIsTargetT9(vehicle)
    if vehicle == nil then return false end
    local path = string.lower(tostring(vehicle.configFileName or vehicle.xmlFileName or ""))
    return string.find(path, "fs25_new_holland_t9_series", 1, true) ~= nil
       and string.find(path, "t9tracks.xml", 1, true) ~= nil
end

local function rvLoadTrackMaterial()
    if RVV.trackMaterialLoaded then
        return RVV.trackMaterialId ~= nil
    end
    local path = Utils.getFilename(RVV.TRACK_MATERIAL_HOLDER_PATH, RVV.MOD_DIRECTORY)
    local nodeId = g_i3DManager:loadSharedI3DFile(path, false, false)
    if nodeId == nil or nodeId <= 0 then
        RVV.trackMaterialLoaded = true
        return false
    end
    RVV.trackMaterialNode = I3DUtil.indexToObject(nodeId, "0|0")
    if RVV.trackMaterialNode == nil then
        RVV.trackMaterialLoaded = true
        return false
    end
    RVV.trackMaterialId = getMaterial(RVV.trackMaterialNode, 0)
    RVV.trackMaterialLoaded = true
    return RVV.trackMaterialId ~= nil
end

local function rvCopyMap(materialId, originalMaterialId, mapName, srgb)
    local filename = getMaterialCustomMapFilename(originalMaterialId, mapName)
    if filename ~= nil and filename ~= "" then
        local ok, newId = pcall(setMaterialCustomMapFromFile, materialId, mapName, filename, false, srgb, false)
        if ok and newId ~= nil then
            materialId = newId
        end
    end
    return materialId
end

local function rvBuildTrackMaterial(originalMaterialId)
    if originalMaterialId == nil or not rvLoadTrackMaterial() then
        return nil
    end
    local cached = RVV.trackMaterialCache[originalMaterialId]
    if cached ~= nil then return cached end

    local materialId = RVV.trackMaterialId
    local diffuse = getMaterialDiffuseMapFilename(originalMaterialId)
    if diffuse ~= nil and diffuse ~= "" then
        local ok, newId = pcall(setMaterialDiffuseMapFromFile, materialId, diffuse, false, true, false)
        if ok and newId ~= nil then materialId = newId end
    end
    local normal = getMaterialNormalMapFilename(originalMaterialId)
    if normal ~= nil and normal ~= "" then
        local ok, newId = pcall(setMaterialNormalMapFromFile, materialId, normal, false, false, false)
        if ok and newId ~= nil then materialId = newId end
    end
    local gloss = getMaterialGlossMapFilename(originalMaterialId)
    if gloss ~= nil and gloss ~= "" then
        local ok, newId = pcall(setMaterialGlossMapFromFile, materialId, gloss, false, false, false)
        if ok and newId ~= nil then materialId = newId end
    end
    materialId = rvCopyMap(materialId, originalMaterialId, "detailDiffuse", true)
    materialId = rvCopyMap(materialId, originalMaterialId, "detailNormal", false)
    materialId = rvCopyMap(materialId, originalMaterialId, "detailSpecular", false)
    -- T9 uses the original crawler trackArray from the original material.
    materialId = rvCopyMap(materialId, originalMaterialId, "trackArray", false)
    RVV.trackMaterialCache[originalMaterialId] = materialId
    return materialId
end

local function rvGetCrawlerWear(crawler, vehicle)
    if ReifenVerschleissCore ~= nil and ReifenVerschleissCore.getCrawlerWearValue ~= nil then
        local ok, value = pcall(ReifenVerschleissCore.getCrawlerWearValue, vehicle, crawler)
        if ok then return clampWear(value) end
    end
    return 0
end

local function rvIsRaptorCrawler(crawler)
    if crawler == nil then return false end
    local filename = string.lower(tostring(crawler.filename or ""))
    -- The supplied pack uses raptor300Crawler.i3d. Keep the family check
    -- deliberately narrow so unrelated crawler mods are not changed.
    return string.find(filename, "raptor300crawler.i3d", 1, true) ~= nil
        or string.find(filename, "raptor200crawler.i3d", 1, true) ~= nil
end

local function rvCopyRaptorMaterialParameters(node, materialIndex)
    local result = {}
    local names = {
        "scratches_dirt_snow_wetness",
        "colorScale", "smoothnessScale", "metalnessScale",
        "clearCoatIntensity", "clearCoatSmoothness", "porosity",
        "dirtColor", "scrollPos", "prevScrollPos", "lengthAndRadius"
    }
    for _, name in ipairs(names) do
        local okHas, has = pcall(getHasShaderParameter, node, name, materialIndex)
        if okHas and has then
            local okGet, x, y, z, w = pcall(getShaderParameter, node, name, materialIndex)
            if okGet then
                result[name] = {x, y, z, w}
            end
        end
    end
    return result
end

local function rvRestoreRaptorMaterialParameters(node, params, materialIndex)
    for name, v in pairs(params or {}) do
        pcall(setShaderParameter, node, name, v[1], v[2], v[3], v[4], false, materialIndex)
    end
end

local function rvBuildRaptorTrackMaterial(originalMaterialId)
    if originalMaterialId == nil then return nil end
    local cached = RVV.raptorTrackMaterialCache[originalMaterialId]
    if cached ~= nil then return cached end

    -- Reuse the already proven holder/material construction. It copies the
    -- Raptor's base/normal/gloss/detail maps and its trackArray. We then only
    -- switch the custom variation from MOTION_PATH_RUBBER to MOTION_PATH.
    local materialId = rvBuildTrackMaterial(originalMaterialId)
    if materialId == nil then return nil end

    local ok, newMaterial = pcall(
        setMaterialCustomShaderVariation, materialId,
        RVV.RAPTOR_PROFILE_SHADER_VARIATION, false
    )
    if ok and newMaterial ~= nil then
        materialId = newMaterial
    end

    RVV.raptorTrackMaterialCache[originalMaterialId] = materialId
    return materialId
end

local function rvGetVisibleRaptorCrawlerTrackShapes(crawler)
    local result = {}
    local seen = {}
    local root = crawler ~= nil and crawler.loadedCrawler or nil
    if root == nil or root == 0 then return result end

    local function addNode(node)
        if node == nil or node == 0 or seen[node] then return end
        seen[node] = true

        local okShape, isShape = pcall(getHasClassId, node, ClassIds.SHAPE)
        if not okShape or not isShape then return end

        local okEff, effective = pcall(getEffectiveVisibility, node)
        if not okEff or not effective then return end

        local okName, name = pcall(getName, node)
        name = okName and name or ""
        local lowerName = string.lower(tostring(name))
        if string.find(lowerName, "lod", 1, true) == nil then return end

        local count = 1
        local okCount, n = pcall(getNumOfMaterials, node)
        if okCount and tonumber(n) and n > 0 then count = n end

        for materialIndex = 0, count - 1 do
            local okMat, materialId = pcall(getMaterial, node, materialIndex)
            if okMat and materialId ~= nil and materialId ~= 0 then
                local okVar, variation = pcall(getMaterialCustomShaderVariation, materialId)
                if okVar and (variation == "motionPath" or variation == "motionPath_vmaskUV2") then
                    local okScroll, hasScroll = pcall(getHasShaderParameter, node, "scrollPos", materialIndex)
                    if okScroll and hasScroll then
                        result[#result + 1] = {
                            node = node, materialIndex = materialIndex,
                            name = name, variation = variation
                        }
                        break
                    end
                end
            end
        end
    end

    I3DUtil.iterateRecursively(root, addNode)
    return result
end

local function rvDetectCrawlerMotionPathKind(crawler)
    if crawler == nil then return nil end
    RVV.crawlerMotionPathKindCache = RVV.crawlerMotionPathKindCache or setmetatable({}, {__mode = "k"})
    local cached = RVV.crawlerMotionPathKindCache[crawler]
    if cached ~= nil then return cached ~= false and cached or nil end

    local root = crawler.loadedCrawler
    if root == nil or root == 0 then
        RVV.crawlerMotionPathKindCache[crawler] = false
        return nil
    end

    local kind = nil
    I3DUtil.iterateRecursively(root, function(node)
        if kind == "STEEL" or node == nil or node == 0 then return end
        local okShape, isShape = pcall(getHasClassId, node, ClassIds.SHAPE)
        if not okShape or not isShape then return end
        local count = 1
        local okCount, n = pcall(getNumOfMaterials, node)
        if okCount and tonumber(n) and n > 0 then count = n end
        for materialIndex = 0, count - 1 do
            local okMat, materialId = pcall(getMaterial, node, materialIndex)
            if okMat and materialId ~= nil and materialId ~= 0 then
                local okVar, variation = pcall(getMaterialCustomShaderVariation, materialId)
                if okVar then
                    if variation == "motionPath" or variation == "motionPath_vmaskUV2" then
                        kind = "STEEL"
                        return
                    elseif kind == nil and (variation == "motionPathRubber" or variation == "motionPathRubber_vmaskUV2") then
                        kind = "RUBBER"
                    end
                end
            end
        end
    end)

    RVV.crawlerMotionPathKindCache[crawler] = kind or false
    return kind
end

local function rvGetCrawlerVehicleType(vehicle)
    if vehicle == nil then return 0 end
    local cached = RVV.crawlerVehicleTypeCache[vehicle]
    if cached ~= nil then return cached end

    local result = 0 -- 0 = no crawler, 1 = generic rubber crawler, 2 = Raptor crawler, 3 = generic steel crawler
    local crawlers = vehicle.spec_crawlers ~= nil and vehicle.spec_crawlers.crawlers or nil
    if crawlers ~= nil then
        for _, crawler in ipairs(crawlers) do
            if rvIsRaptorCrawler(crawler) then
                result = 2
                break
            else
                local kind = rvDetectCrawlerMotionPathKind(crawler)
                if kind == "STEEL" then
                    result = 3
                elseif result == 0 then
                    result = 1
                end
            end
        end
    end

    RVV.crawlerVehicleTypeCache[vehicle] = result
    return result
end

local function rvIsRaptorVehicle(vehicle)
    return rvGetCrawlerVehicleType(vehicle) == 2
end

local function rvInitRaptorCrawlerProfileWear(vehicle)
    local cached = RVV.raptorProfileVehicleCache[vehicle]
    if cached ~= nil then return cached end

    local state = {refs = {}, lastWear = -1, lastUpdateTime = -math.huge}
    if vehicle == nil or vehicle.spec_crawlers == nil or vehicle.spec_crawlers.crawlers == nil then
        RVV.raptorProfileVehicleCache[vehicle] = state
        return state
    end

    -- EXPENSIVE PART: crawler-tree/material discovery is performed once per vehicle.
    for crawlerIndex, crawler in ipairs(vehicle.spec_crawlers.crawlers) do
        if rvIsRaptorCrawler(crawler) then
            local refs = rvGetVisibleRaptorCrawlerTrackShapes(crawler)
            for targetIndex, ref in ipairs(refs) do
                local node = ref.node
                local materialIndex = ref.materialIndex
                local slots = RVV.raptorTrackWearMaterialSlots[node]
                if slots == nil then
                    slots = {}
                    RVV.raptorTrackWearMaterialSlots[node] = slots
                end

                if slots[materialIndex] == nil then
                    local originalMaterial = getMaterial(node, materialIndex)
                    local params = rvCopyRaptorMaterialParameters(node, materialIndex)
                    local wearMaterial = rvBuildRaptorTrackMaterial(originalMaterial)
                    local replaced = false
                    if wearMaterial ~= nil and wearMaterial ~= originalMaterial then
                        local okSet = pcall(setMaterial, node, wearMaterial, materialIndex)
                        if okSet then
                            rvRestoreRaptorMaterialParameters(node, params, materialIndex)
                            replaced = true
                        end
                    end
                    slots[materialIndex] = {originalMaterial = originalMaterial, replaced = replaced}
                end

                local okHas, hasWear = pcall(getHasShaderParameter, node, "crawlerProfileWear", materialIndex)
                if okHas and hasWear then
                    state.refs[#state.refs + 1] = {
                        node = node, materialIndex = materialIndex
                    }
                end
            end
        end
    end

    RVV.raptorProfileVehicleCache[vehicle] = state
    return state
end

local function rvUpdateRaptorCrawlerProfileWear(vehicle)
    if not rvIsRaptorVehicle(vehicle) then return end

    local state = rvInitRaptorCrawlerProfileWear(vehicle)
    if state == nil or #state.refs == 0 then return end

    local now = getTimeSec()
    local interval = rvGetCrawlerVisualInterval(vehicle)
    -- Wear itself changes slowly. Keep 5 Hz while active/near and lower only
    -- stationary far-away vehicles to 1 Hz. Immediate load/tab/workshop
    -- refreshes bypass this cadence.
    if not rvCrawlerImmediateRefreshRequested() and
       now - state.lastUpdateTime < interval then return end

    local wear = 0
    for _, crawler in ipairs(vehicle.spec_crawlers.crawlers) do
        if rvIsRaptorCrawler(crawler) then
            wear = math.max(wear, rvGetCrawlerWear(crawler, vehicle))
        end
    end

    if math.abs(wear - state.lastWear) < 0.00001 then
        state.lastUpdateTime = now
        return
    end

    for _, ref in ipairs(state.refs) do
        pcall(setShaderParameter, ref.node, "crawlerProfileBodyY",
            RVV.RAPTOR_PROFILE_BODY_Y, nil, nil, nil, false, ref.materialIndex)
        pcall(setShaderParameter, ref.node, "crawlerProfileOuterY",
            RVV.RAPTOR_PROFILE_OUTER_Y, nil, nil, nil, false, ref.materialIndex)
        pcall(setShaderParameter, ref.node, "crawlerProfileWornY",
            RVV.RAPTOR_PROFILE_WORN_Y, nil, nil, nil, false, ref.materialIndex)
        pcall(setShaderParameter, ref.node, "crawlerProfileWear",
            wear, nil, nil, nil, false, ref.materialIndex)
    end

    state.lastWear = wear
    state.lastUpdateTime = now
end

local function rvCopyMotionPathParameters(node)
    local result = {}
    for _, name in ipairs({"scrollPos", "prevScrollPos", "lengthAndRadius"}) do
        if getHasShaderParameter(node, name) then
            local x, y, z, w = getShaderParameter(node, name)
            result[name] = {x, y, z, w}
        end
    end
    return result
end

local function rvRestoreMotionPathParameters(node, params)
    for name, v in pairs(params) do
        setShaderParameter(node, name, v[1], v[2], v[3], v[4], false)
    end
end

local function rvUpdateT9CrawlerPhysicsRadius(vehicle, crawler, wear, crawlerIndex)
    -- TEST2_4_0_42: visual crawler wear must never rewrite GIANTS crawler-wheel
    -- physics.  The motionPathRubber shader flattens only the visible tread;
    -- wheelShape/radius/contact stay fully owned by GIANTS.  Rebuilding the wheel
    -- base here invalidated wheelShape indices ("Wheel shape not found for getSlip")
    -- and lowered the T9 until the running rollers visually became the ground
    -- contact.  Keep this worker as an intentional no-op so callers stay stable.
    return
end


RVV.trackWearMaterialSlots = setmetatable({}, {__mode = "k"})

local function rvCopyMotionPathParameters(node, materialIndex)
    local result = {}
    for _, name in ipairs({"scrollPos", "prevScrollPos", "lengthAndRadius"}) do
        local hasParam = false
        local okHas, valueHas = pcall(getHasShaderParameter, node, name, materialIndex)
        if okHas then hasParam = valueHas end
        if hasParam then
            local okGet, x, y, z, w = pcall(getShaderParameter, node, name, materialIndex)
            if okGet then
                result[name] = {x, y, z, w}
            end
        end
    end
    return result
end

local function rvRestoreMotionPathParameters(node, params, materialIndex)
    for name, v in pairs(params) do
        pcall(setShaderParameter, node, name, v[1], v[2], v[3], v[4], false, materialIndex)
    end
end

local function rvGetTrackMaterialCandidates(node)
    local candidates = {}
    local count = 0
    local okCount, numMaterials = pcall(getNumOfMaterials, node)
    if okCount then
        count = tonumber(numMaterials) or 0
    end

    -- Some engine objects expose at least one material through slot 0 even when
    -- getNumOfMaterials is unavailable/returns 0. Keep the old fallback alive.
    if count <= 0 then count = 1 end

    for materialIndex = 0, count - 1 do
        local okMat, materialId = pcall(getMaterial, node, materialIndex)
        if okMat and materialId ~= nil and materialId ~= 0 then
            local variation = nil
            local okVariation, valueVariation = pcall(
                getMaterialCustomShaderVariation, materialId
            )
            if okVariation then variation = valueVariation end

            local hasWearParam = false
            local okWear, valueWear = pcall(
                getHasShaderParameter, node, "trackProfileWear", materialIndex
            )
            if okWear then hasWearParam = valueWear end

            local isRubberMotionPath =
                variation == "motionPathRubber"
                or variation == "motionPathRubber_vmaskUV2"

            if hasWearParam or isRubberMotionPath then
                candidates[#candidates + 1] = {
                    materialIndex = materialIndex,
                    materialId = materialId,
                    variation = variation,
                    hasWearParam = hasWearParam,
                    isRubberMotionPath = isRubberMotionPath
                }
            end
        end
    end

    return candidates
end

local function rvGetVisibleCrawlerTrackShapes(crawler)
    local result = {}
    local seen = {}
    local root = crawler ~= nil and crawler.loadedCrawler or nil
    if root == nil or root == 0 then
        return result
    end

    local function addNode(node)
        if node == nil or node == 0 or seen[node] then return end
        seen[node] = true

        local okShape, isShape = pcall(getHasClassId, node, ClassIds.SHAPE)
        if not okShape or not isShape then return end

        local okName, name = pcall(getName, node)
        name = okName and name or ""
        local lower = string.lower(tostring(name))
        if string.find(lower, "track", 1, true) == nil then return end

        local okEff, effective = pcall(getEffectiveVisibility, node)
        if not okEff or not effective then return end

        local num = 1
        local okNum, n = pcall(getNumOfMaterials, node)
        if okNum and tonumber(n) and n > 0 then num = n end

        for materialIndex = 0, num - 1 do
            local okMat, mat = pcall(getMaterial, node, materialIndex)
            if okMat and mat ~= nil and mat ~= 0 then
                local okVar, variation = pcall(getMaterialCustomShaderVariation, mat)
                if okVar and (variation == "motionPathRubber" or variation == "motionPathRubber_vmaskUV2") then
                    result[#result + 1] = {node=node, materialIndex=materialIndex, name=name, variation=variation}
                    break
                end
            end
        end
    end

    I3DUtil.iterateRecursively(root, addNode)
    return result
end



-- TEST2.3.110: local visual wear for the A8800MR-family steel motionPath track.
-- This deliberately does NOT touch trackArray, scrollPos, crawler geometry,
-- dirt/snow/wetness, or the proven rubber-track path.
local function rvIsA8800FamilySteelTrackVehicle(vehicle)
    if vehicle == nil then return false end
    local name = string.lower(tostring(
        vehicle.configFileName or vehicle.xmlFileName or vehicle.typeName or ""
    ))
    return string.find(name, "a8800mr", 1, true) ~= nil
        or string.find(name, "jacto_hover_500", 1, true) ~= nil
        or string.find(name, "hover_500", 1, true) ~= nil
        or string.find(name, "hover500", 1, true) ~= nil
end

local function rvBuildA8800TrackMaterial(originalMaterialId)
    if originalMaterialId == nil or not rvLoadTrackMaterial() then
        return nil
    end

    -- TEST2.3.118 LIFECYCLE FIX:
    -- Never reuse a raw GIANTS material entity across vehicle lifetimes here.
    -- Returned/rented vehicles destroy their live material entities; the old
    -- global A8800/track caches could then hand a dead entity id to a newly
    -- spawned IH8800/Hover.  Build a fresh custom material for every live
    -- A8800 crawler node/slot instead.  The per-node weak slot table below
    -- guarantees that this happens only once for the lifetime of that node.
    local materialId = RVV.trackMaterialId
    if materialId == nil then return nil end

    local diffuse = getMaterialDiffuseMapFilename(originalMaterialId)
    if diffuse ~= nil and diffuse ~= "" then
        local ok, newId = pcall(setMaterialDiffuseMapFromFile, materialId, diffuse, false, true, false)
        if ok and newId ~= nil then materialId = newId end
    end

    local normal = getMaterialNormalMapFilename(originalMaterialId)
    if normal ~= nil and normal ~= "" then
        local ok, newId = pcall(setMaterialNormalMapFromFile, materialId, normal, false, false, false)
        if ok and newId ~= nil then materialId = newId end
    end

    local gloss = getMaterialGlossMapFilename(originalMaterialId)
    if gloss ~= nil and gloss ~= "" then
        local ok, newId = pcall(setMaterialGlossMapFromFile, materialId, gloss, false, false, false)
        if ok and newId ~= nil then materialId = newId end
    end

    materialId = rvCopyMap(materialId, originalMaterialId, "detailDiffuse", true)
    materialId = rvCopyMap(materialId, originalMaterialId, "detailNormal", false)
    materialId = rvCopyMap(materialId, originalMaterialId, "detailSpecular", false)
    materialId = rvCopyMap(materialId, originalMaterialId, "trackArray", false)

    local ok, newMaterial = pcall(
        setMaterialCustomShaderVariation, materialId,
        "motionPath_vmaskUV2", false
    )
    if ok and newMaterial ~= nil then
        materialId = newMaterial
    end

    return materialId
end

local function rvTryA8800FamilyLocalSteelWear(vehicle, node, wear, crawlerIndex, nodeIndex, targetIndex)
    if not rvIsA8800FamilySteelTrackVehicle(vehicle) or node == nil or node == 0 then
        return false
    end

    local materialCount = 0
    local okCount, count = pcall(getNumOfMaterials, node)
    if okCount then materialCount = tonumber(count) or 0 end
    if materialCount <= 0 then materialCount = 1 end

    local handled = false
    for materialIndex = 0, materialCount - 1 do
        local materialId = nil
        local okMat, mat = pcall(getMaterial, node, materialIndex)
        if okMat then materialId = mat end

        -- Install the custom MOTION_PATH shader exactly once for this explicitly
        -- gated A8800MR/Hover test family. Runtime motion-path values and the
        -- original trackArray are copied/restored; scrollPos is never modified.
        local slots = RVV.a8800TrackWearMaterialSlots[node]
        if slots == nil then
            slots = {}
            RVV.a8800TrackWearMaterialSlots[node] = slots
        end
        if slots[materialIndex] == nil and materialId ~= nil and materialId ~= 0 then
            local originalVariation = nil
            if getMaterialCustomShaderVariation ~= nil then
                local okOrigVar, valueOrigVar = pcall(getMaterialCustomShaderVariation, materialId)
                if okOrigVar then originalVariation = valueOrigVar end
            end
            if originalVariation == "motionPath_vmaskUV2" then
                local params = rvCopyRaptorMaterialParameters(node, materialIndex)
                local wearMaterial = rvBuildA8800TrackMaterial(materialId)
                local replaced = false
                if wearMaterial ~= nil and wearMaterial ~= materialId then
                    local okSet = pcall(setMaterial, node, wearMaterial, materialIndex)
                    if okSet then
                        rvRestoreRaptorMaterialParameters(node, params, materialIndex)
                        replaced = true
                    end
                end
                slots[materialIndex] = {originalMaterial=mat, replaced=replaced}
            else
                slots[materialIndex] = {originalMaterial=mat, replaced=false}
            end
        end

        -- Re-query after a possible material replacement. 112 only reached the
        -- special path while no generic candidate existed; after replacement the
        -- node became a generic candidate and therefore stopped receiving steel
        -- runtime updates. 113 explicitly keeps this family on this path.
        local okNewMat, newMat = pcall(getMaterial, node, materialIndex)
        if okNewMat then materialId = newMat end
        local variation = nil
        if materialId ~= nil and materialId ~= 0 and getMaterialCustomShaderVariation ~= nil then
            local okVar, valueVar = pcall(getMaterialCustomShaderVariation, materialId)
            if okVar then variation = valueVar end
        end

        if variation == "motionPath_vmaskUV2" then
            local wearClamped = math.max(0, math.min(1, tonumber(wear) or 0))

            -- PROFILE: write/readback unconditionally; pcall itself tells us if
            -- the parameter is really exposed on the active material instance.
            local okSetProfile = pcall(
                setShaderParameter, node, "a8800ProfileTestWear",
                wearClamped, nil, nil, nil, false, materialIndex
            )

            -- SCRATCHES: use OWN-WEAR as scratches only; preserve GIANTS dirt,
            -- snow and wetness values byte-for-byte as runtime values.
            local okHasScratches, hasScratches = pcall(
                getHasShaderParameter, node, "scratches_dirt_snow_wetness", materialIndex
            )
            local scratches, dirt, snow, wetness = nil, nil, nil, nil
            local okGetScratches, sx, sy, sz, sw = pcall(
                getShaderParameter, node, "scratches_dirt_snow_wetness", materialIndex
            )
            if okGetScratches then
                scratches, dirt, snow, wetness = sx, sy, sz, sw
            end
            local localScratches = math.max(tonumber(scratches) or 0, wearClamped)
            local okSetScratches = false
            if okGetScratches then
                okSetScratches = pcall(
                    setShaderParameter, node, "scratches_dirt_snow_wetness",
                    localScratches, dirt, snow, wetness, false, materialIndex
                )
            end

            if okSetProfile or okSetScratches then
                handled = true
            end
        end
    end
    return handled
end


-- TEST2_4_0_31: Hannibal/Volvo are explicit steel-track special paths.
-- TEST .030 showed that the positive-Y selection does not affect the visible tread.
-- .031 therefore uses a broad NEGATIVE-Y outer-profile collapse, matching the
-- proven Raptor coordinate orientation. The special
-- path still uses the proven TEST2.3.118 live-node/live-slot lifecycle, but
-- surface scratches are deliberately untouched. Volvo installation is gated to
-- the actually controlled vehicle and split across frames to avoid native load crashes.
local function rvGetSpecialSteelFamily(vehicle)
    if vehicle == nil then return nil end
    local name = string.lower(tostring(
        vehicle.configFileName or vehicle.xmlFileName or vehicle.typeName or ""
    ))
    if string.find(name, "impex/hannibalt50", 1, true) ~= nil
        or string.find(name, "hannibalt50", 1, true) ~= nil then
        return "HANNIBAL"
    end
    if string.find(name, "volvo/ec380dl", 1, true) ~= nil
        or string.find(name, "ec380dl", 1, true) ~= nil then
        return "VOLVO"
    end
    return nil
end

local function rvTrySpecialSteelCrawlerWear027(vehicle, node, wear, crawlerIndex, nodeIndex, targetIndex)
    local family = rvGetSpecialSteelFamily(vehicle)
    if family == nil or node == nil or node == 0 then return false end

    -- TEST2_4_0_29: Volvo EC380DL is an explicit special path. Its original
    -- motionPath_vmaskUV2 material must never be replaced during the vehicle
    -- onFinishedLoading/immediate refresh phase; .027 showed a native engine
    -- crash directly after that operation. Defer installation until the normal
    -- mission update path has seen the selected Volvo for a short settling time.
    -- Also stagger fresh material installation to one live crawler node at a
    -- time, avoiding two motion-path material swaps in one render update.
    if family == "VOLVO" then
        if RVV._inImmediateLoadRefresh == true then
            if RVV.volvoSteelLoadGuardSeen ~= vehicle then
                RVV.volvoSteelLoadGuardSeen = vehicle
            end
            return false
        end

        -- Native safety gate: do not touch the Volvo MotionPath material merely
        -- because the vehicle exists in the mission. Only initialize after the
        -- player actually controls this Volvo, then allow the renderer to settle.
        local controlled = g_currentMission ~= nil and g_currentMission.controlledVehicle or nil
        if controlled ~= vehicle then
            RVV.volvoSteelRuntimeState[vehicle] = nil
            return false
        end

        local now = getTimeSec()
        local state = RVV.volvoSteelRuntimeState[vehicle]
        if state == nil then
            state = {firstRuntimeSeen=now, nextReplaceTime=now + 1.50}
            RVV.volvoSteelRuntimeState[vehicle] = state
            return false
        end
        if now < (state.firstRuntimeSeen + 1.50) then
            return false
        end
    end

    local materialCount = 0
    local okCount, count = pcall(getNumOfMaterials, node)
    if okCount then materialCount = tonumber(count) or 0 end
    if materialCount <= 0 then materialCount = 1 end

    local handled = false
    for materialIndex = 0, materialCount - 1 do
        local materialId = nil
        local okMat, mat = pcall(getMaterial, node, materialIndex)
        if okMat then materialId = mat end

        local slots = RVV.specialSteelTrackWearMaterialSlots[node]
        if slots == nil then
            slots = {}
            RVV.specialSteelTrackWearMaterialSlots[node] = slots
        end

        -- Identical lifecycle rule to the confirmed TEST2.3.118 path:
        -- create/attach one fresh custom material for each live node/slot and
        -- never reuse a dead material entity from a returned/rented vehicle.
        if slots[materialIndex] == nil and materialId ~= nil and materialId ~= 0 then
            local originalVariation = nil
            if getMaterialCustomShaderVariation ~= nil then
                local okVar, valueVar = pcall(getMaterialCustomShaderVariation, materialId)
                if okVar then originalVariation = valueVar end
            end

            if originalVariation == "motionPath_vmaskUV2" then
                local params = rvCopyRaptorMaterialParameters(node, materialIndex)
                local wearMaterial = rvBuildA8800TrackMaterial(materialId)
                local replaced = false
                if wearMaterial ~= nil and wearMaterial ~= materialId then
                    if family == "VOLVO" then
                        local state = RVV.volvoSteelRuntimeState[vehicle]
                        local now = getTimeSec()
                        if state ~= nil and now < (state.nextReplaceTime or 0) then
                            return false
                        end
                    end

                    local okSet = pcall(setMaterial, node, wearMaterial, materialIndex)
                    if okSet then
                        rvRestoreRaptorMaterialParameters(node, params, materialIndex)
                        replaced = true
                        if family == "VOLVO" then
                            local state = RVV.volvoSteelRuntimeState[vehicle]
                            if state ~= nil then
                                state.nextReplaceTime = getTimeSec() + 0.25
                            end
                        end
                    end
                end
                slots[materialIndex] = {originalMaterial=mat, replaced=replaced, installedAt=getTimeSec()}
            else
                slots[materialIndex] = {originalMaterial=mat, replaced=false}
            end
        end

        local okNewMat, newMat = pcall(getMaterial, node, materialIndex)
        if okNewMat then materialId = newMat end
        local variation = nil
        if materialId ~= nil and materialId ~= 0 and getMaterialCustomShaderVariation ~= nil then
            local okVar, valueVar = pcall(getMaterialCustomShaderVariation, materialId)
            if okVar then variation = valueVar end
        end

        if variation == "motionPath_vmaskUV2" then
            -- Volvo: never set the deformation parameter in the same render
            -- update in which its material was installed. .027 showed that the
            -- native engine is sensitive in exactly this area.
            if family == "VOLVO" then
                local slotState = RVV.specialSteelTrackWearMaterialSlots[node]
                slotState = slotState ~= nil and slotState[materialIndex] or nil
                if slotState ~= nil and slotState.installedAt ~= nil and (getTimeSec() - slotState.installedAt) < 0.10 then
                    return false
                end
            end

            local wearClamped = math.max(0, math.min(1, tonumber(wear) or 0))
            local parameterName = family == "HANNIBAL" and "hannibalProfileWear" or "volvoProfileWear"
            local okSet = pcall(
                setShaderParameter, node, parameterName,
                wearClamped, nil, nil, nil, false, materialIndex
            )

            -- TEST2_4_0_30: DO NOT alter scratches/dirt/snow/wetness here.
            -- .029 proved that doing so turns the Hannibal plates bright/white
            -- instead of representing profile loss. Geometry-only steel wear.
            if okSet then handled = true end

        end
    end

    return handled
end

RVV.updateGenericCrawlerTrackWear = function(vehicle)
    -- TEST2.3.02: hard gate before any generic crawler work. A normal wheel
    -- vehicle/harvester must leave this function immediately.
    local crawlerVehicleType = rvGetCrawlerVehicleType(vehicle)
    if crawlerVehicleType ~= 1 and crawlerVehicleType ~= 3 then return end

    local now = getTimeSec()
    local vehicleCache = RVV.genericCrawlerVehicleCache[vehicle]
    if vehicleCache == nil then
        vehicleCache = {
            lastUpdateTime = -math.huge,
            visibleByCrawler = setmetatable({}, {__mode = "k"})
        }
        RVV.genericCrawlerVehicleCache[vehicle] = vehicleCache
    end

    -- Wear/shader updates remain 5 Hz while active/near. Stationary vehicles
    -- farther than the camera relevance range use 1 Hz. Node/material discovery
    -- stays cached and immediate load/tab/workshop refreshes bypass the timer.
    local interval = rvGetCrawlerVisualInterval(vehicle)
    if not rvCrawlerImmediateRefreshRequested() and
       now - vehicleCache.lastUpdateTime < interval then
        return
    end
    vehicleCache.lastUpdateTime = now

    for crawlerIndex, crawler in ipairs(vehicle.spec_crawlers.crawlers) do
        local wear = rvGetCrawlerWear(crawler, vehicle)
        local runtimeKind = rvDetectCrawlerMotionPathKind(crawler)
        local existingA8800SteelSpecial = rvIsA8800FamilySteelTrackVehicle(vehicle)
        local specialSteelFamily = rvGetSpecialSteelFamily(vehicle)
        if runtimeKind == "STEEL" and not existingA8800SteelSpecial and specialSteelFamily == nil then
            -- Unknown steel crawler: keep diagnostic detection but preserve its
            -- original visual until a safe decoded profile mask is available.
        else

        for nodeIndex, entry in ipairs(crawler.scrollerNodes or {}) do
            local targets = entry.nodes
            local targetCount = targets ~= nil and #targets or 0

            if targetCount == 0 and entry.node ~= nil and entry.node ~= 0 then
                targets = {entry.node}
                entry.nodes = targets
                targetCount = 1
            elseif targets == nil then
                targets = {}
                entry.nodes = targets
            end

            -- EXPENSIVE: recursively resolve visible crawler render shapes only
            -- once per crawler. Subsequent updates reuse the exact node/material
            -- references and only refresh the wear parameter.
            local visibleTrackTargets = vehicleCache.visibleByCrawler[crawler]
            if visibleTrackTargets == nil then
                visibleTrackTargets = rvGetVisibleCrawlerTrackShapes(crawler)
                vehicleCache.visibleByCrawler[crawler] = visibleTrackTargets
            end
            local existing = {}
            for _, n in ipairs(targets or {}) do existing[n] = true end
            for _, ref in ipairs(visibleTrackTargets) do
                if not existing[ref.node] then
                    targets[#targets + 1] = ref.node
                    targetCount = targetCount + 1
                    existing[ref.node] = true
                end
                -- TEST2.3.01: only the visible TRION track is classified as CLAAS_SPECIAL; all other tracks are NORMAL.
                -- 20 mm band-body reserve; the TRION-only 2% profile-travel reserve is applied separately. Generic/T9/OXBO tracks retain 20 mm.
                local refNameLower = string.lower(tostring(ref.name or ""))
                local isClaasSpecialTrack = string.find(refNameLower, "trion", 1, true) ~= nil
                -- TEST2.3.01: exactly one exclusive track type is assigned.
                -- CLAAS_SPECIAL is selected only for the concrete visible TRION track shape.
                -- Every other visible rubber track is explicitly NORMAL.
                RVV.trackProfileBodyY[ref.node] = 0.020
                pcall(
                    setShaderParameter, ref.node, "trackProfileClaasSpecial",
                    isClaasSpecialTrack and 1.0 or 0.0, nil, nil, nil, false, ref.materialIndex
                )
                RVV.trackProfileClaasSpecial = RVV.trackProfileClaasSpecial or setmetatable({}, {__mode = "k"})
                RVV.trackProfileClaasSpecial[ref.node] = isClaasSpecialTrack
            end

            for targetIndex, node in ipairs(targets or {}) do
                if node ~= nil and node ~= 0 then
                    local isA8800Special = rvIsA8800FamilySteelTrackVehicle(vehicle)
                    local isDecodedSteelSpecial = rvGetSpecialSteelFamily(vehicle) ~= nil
                    local steelLocalHandled = false
                    if isA8800Special then
                        steelLocalHandled = rvTryA8800FamilyLocalSteelWear(
                            vehicle, node, wear, crawlerIndex, nodeIndex, targetIndex
                        )
                    elseif isDecodedSteelSpecial then
                        steelLocalHandled = rvTrySpecialSteelCrawlerWear027(
                            vehicle, node, wear, crawlerIndex, nodeIndex, targetIndex
                        )
                    end
                    local candidates = (isA8800Special or isDecodedSteelSpecial)
                        and {} or rvGetTrackMaterialCandidates(node)

                    if #candidates > 0 then
                        local resolvedSlots = RVV.trackWearMaterialSlots[node]
                        if resolvedSlots == nil then
                            resolvedSlots = {}
                            RVV.trackWearMaterialSlots[node] = resolvedSlots
                        end

                        for _, candidate in ipairs(candidates) do
                            local materialIndex = candidate.materialIndex
                            local slotState = resolvedSlots[materialIndex]

                            if slotState == nil then
                                slotState = {
                                    originalMaterial = candidate.materialId,
                                    originalVariation = candidate.variation,
                                    replaced = false
                                }

                                -- Existing wear-capable material: leave it untouched.
                                -- Otherwise clone our proven rubber-track material into
                                -- exactly this material slot, never an arbitrary slot 0.
                                if not candidate.hasWearParam and candidate.isRubberMotionPath then
                                    local params = rvCopyMotionPathParameters(node, materialIndex)
                                    local wearMaterial = rvBuildTrackMaterial(candidate.materialId)

                                    if wearMaterial ~= nil and wearMaterial ~= candidate.materialId then
                                        local setOk = pcall(
                                            setMaterial, node, wearMaterial, materialIndex
                                        )
                                        if setOk then
                                            rvRestoreMotionPathParameters(node, params, materialIndex)
                                            slotState.replaced = true
                                        end
                                    end
                                end

                                resolvedSlots[materialIndex] = slotState
                            end
                            local finalHasParam = false
                            local okFinal, valueFinal = pcall(
                                getHasShaderParameter, node, "trackProfileWear", materialIndex
                            )
                            if okFinal then finalHasParam = valueFinal end

                            if finalHasParam then
                                local bodyY = RVV.trackProfileBodyY[node] or 0.020
                                pcall(setShaderParameter, node, "trackProfileBodyY", bodyY, nil, nil, nil, false, materialIndex)

                                -- TEST2.3.01: TEST0.2.0.88 proved that the clean final
                                -- TRION visual endpoint is the former 98% point. Keep logical
                                -- wear at 1.000 and reserve the final 2% of profile travel
                                -- inside the TRION visual path. The band-body reserve itself
                                -- is back to the proven generic value of 20 mm.
                                local isClaasSpecial = RVV.trackProfileClaasSpecial ~= nil
                                    and RVV.trackProfileClaasSpecial[node] == true
                                local visualWear = isClaasSpecial and (wear * 0.98) or wear

                                local setOk = pcall(
                                    setShaderParameter, node, "trackProfileWear",
                                    visualWear, nil, nil, nil, false, materialIndex
                                )
                            end
                        end
                    else
                        if not isA8800Special and not isDecodedSteelSpecial then
                            steelLocalHandled = rvTryA8800FamilyLocalSteelWear(
                                vehicle, node, wear, crawlerIndex, nodeIndex, targetIndex
                            )
                        end
                    end
                end
            end
        end
        end -- runtimeKind ~= STEEL
    end
end

RVV.updateT9TrackWear = function(vehicle)
    if not rvIsTargetT9(vehicle) then return end
    local spec = vehicle.spec_crawlers
    if spec == nil or spec.crawlers == nil then return end

    local now = getTimeSec()
    local state = RVV.t9CrawlerVehicleCache[vehicle]
    if state == nil then
        state = {lastUpdateTime = -math.huge}
        RVV.t9CrawlerVehicleCache[vehicle] = state
    end
    local interval = rvGetCrawlerVisualInterval(vehicle)
    if not rvCrawlerImmediateRefreshRequested() and
       now - state.lastUpdateTime < interval then
        return
    end
    state.lastUpdateTime = now

    for crawlerIndex, crawler in ipairs(spec.crawlers) do
        local wear = rvGetCrawlerWear(crawler, vehicle)
        rvUpdateT9CrawlerPhysicsRadius(vehicle, crawler, wear, crawlerIndex)
        if crawler.scrollerNodes ~= nil then
            for nodeIndex, entry in ipairs(crawler.scrollerNodes) do
                -- CRITICAL: GIANTS exposes the actual scroller shape as entry.node.
                -- The failed 0.1.x attempts incorrectly used entry.nodes here.
                local node = entry ~= nil and entry.node or nil
                if node ~= nil and node ~= 0 then
                    local originalMaterial = getMaterial(node, 0)
                    local variation = originalMaterial ~= nil and getMaterialCustomShaderVariation(originalMaterial) or nil
                    if variation == "motionPathRubber_vmaskUV2" then
                        if not RVV.trackWearNodes[node] then
                            local params = rvCopyMotionPathParameters(node)
                            local wearMaterial = rvBuildTrackMaterial(originalMaterial)
                            if wearMaterial ~= nil and wearMaterial ~= originalMaterial then
                                setMaterial(node, wearMaterial, 0)
                                rvRestoreMotionPathParameters(node, params)
                                RVV.trackWearNodes[node] = true
                            end
                        end

                        if RVV.trackWearNodes[node] and getHasShaderParameter(node, "trackProfileWear") then
                            setShaderParameter(node, "trackProfileWear", wear, nil, nil, nil, false)
                        end
                    end
                end
            end
        end
    end
end

FSBaseMission.update = Utils.appendedFunction(
    FSBaseMission.update,
    function(_, _)
        local vehicle = ReifenVerschleissCore ~= nil and ReifenVerschleissCore.currentVehicle or nil
        if vehicle ~= nil then
            -- TEST2.3.02: classify once per vehicle, then enter exactly one
            -- crawler branch. No crawler tree/material scan is possible for
            -- ordinary harvesters or other wheel-only vehicles.
            if rvIsTargetT9(vehicle) then
                RVV.updateT9TrackWear(vehicle)
            else
                local crawlerType = rvGetCrawlerVehicleType(vehicle)
                if crawlerType == 2 then
                    rvUpdateRaptorCrawlerProfileWear(vehicle)
                elseif crawlerType == 1 or crawlerType == 3 then
                    RVV.updateGenericCrawlerTrackWear(vehicle)
                end
            end
        end

        -- Passive trailer/implement visual wear uses the same ReifenVerschleiss wheel ->
        -- WheelVisualPartTire -> tireNodes worker as normal vehicle wheels.
        -- Use the same native attachment discovery as the passive wear path,
        -- so visual updates are not lost because of the old movement-cache path.
        if ReifenVerschleissCore ~= nil and
           ReifenVerschleissCore.getAttachedImplementsForDisplay ~= nil then
            for _, entry in ipairs(ReifenVerschleissCore.getAttachedImplementsForDisplay()) do
                local implement = entry.object
                if implement ~= nil and entry.root ~= nil and entry.speedKmh > 0.05 and
                   implement.spec_wheels ~= nil and implement.spec_wheels.wheels ~= nil then
                    for _, wheel in ipairs(implement.spec_wheels.wheels) do
                        updateWheelVisuals(wheel)
                    end
                end
            end
        end
    end
)


-- TEST0.2.0.72: immediate visual synchronization after a vehicle has been
-- restored from savegame. The persistent wear state is authoritative already;
-- this function only forces the existing visual workers to consume that state
-- immediately instead of waiting for the next vehicle enter/exit cycle.
function RVV.refreshVehicleWearVisualsImmediate(vehicle)
    if ReifenVerschleissCore ~= nil
        and ReifenVerschleissCore.isVehicleExcluded ~= nil
        and ReifenVerschleissCore.isVehicleExcluded(vehicle) then
        return
    end
    if vehicle == nil then
        return
    end

    local wheels = nil
    if vehicle.spec_wheels ~= nil and vehicle.spec_wheels.wheels ~= nil then
        wheels = vehicle.spec_wheels.wheels
    elseif vehicle.wheels ~= nil then
        wheels = vehicle.wheels
    end

    local normalCount = 0
    if wheels ~= nil then
        for _, wheel in ipairs(wheels) do
            if wheel ~= nil then
                -- Bypass the normal visual cadence only for this one load-time
                -- refresh. The actual worker and wear source remain unchanged.
                wheel.rvVisualImmediateRefresh = true
                wheel.rvVisualImmediateRefreshTime = getTimeSec()
                if vehicle.isServer then
                    updateWheelVisuals(wheel)
                else
                    updateWheelVisualsClient(wheel)
                end
                normalCount = normalCount + 1
            end
        end
    end

    -- The crawler branch has its own actual render-node worker and must receive
    -- the same restored wear state in the same load pass.
    local ok, err
    RVV._forceCrawlerVisualRefresh = true
    if rvIsTargetT9(vehicle) then
        ok, err = pcall(RVV.updateT9TrackWear, vehicle)
    else
        local crawlerType = rvGetCrawlerVehicleType(vehicle)
        if crawlerType == 2 then
            ok, err = pcall(rvUpdateRaptorCrawlerProfileWear, vehicle)
        elseif crawlerType == 1 or crawlerType == 3 then
            ok, err = pcall(RVV.updateGenericCrawlerTrackWear, vehicle)
        else
            ok, err = true, nil
        end
    end
    RVV._forceCrawlerVisualRefresh = false

    -- Mud overlay uses its own fleet scheduler. Force the same concrete vehicle
    -- now so load/tab/workshop changes are visible immediately even when its
    -- normal idle/far cadence is currently 1 Hz.
    if RPMudOverlayCompatibility ~= nil and
       RPMudOverlayCompatibility.refreshVehicleImmediate ~= nil then
        pcall(RPMudOverlayCompatibility.refreshVehicleImmediate, RPMudOverlayCompatibility, vehicle)
    end
end

