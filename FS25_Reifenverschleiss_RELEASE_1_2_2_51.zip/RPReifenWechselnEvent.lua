-- Real Physics - Reifenverschleiß
-- TEST0.2.0.98
-- Server-authoritative tire / running-gear replacement purchase.

RPReifenWechselnEvent = {}
local RPReifenWechselnEvent_mt = Class(RPReifenWechselnEvent, Event)

InitEventClass(RPReifenWechselnEvent, "RPReifenWechselnEvent")

function RPReifenWechselnEvent.emptyNew()
    local self = Event.new(RPReifenWechselnEvent_mt)
    return self
end

function RPReifenWechselnEvent.new(vehicle, mode)
    local self = RPReifenWechselnEvent.emptyNew()
    self.vehicle = vehicle
    self.mode = tostring(mode or "ALL")
    return self
end

function RPReifenWechselnEvent:writeStream(streamId, connection)
    NetworkUtil.writeNodeObject(streamId, self.vehicle)
    streamWriteString(streamId, tostring(self.mode or "ALL"))
end

function RPReifenWechselnEvent:readStream(streamId, connection)
    self.vehicle = NetworkUtil.readNodeObject(streamId)
    self.mode = streamReadString(streamId)
    self:run(connection)
end

local function getFarmId(vehicle)
    if vehicle ~= nil and vehicle.getOwnerFarmId ~= nil then
        local ok, value = pcall(vehicle.getOwnerFarmId, vehicle)
        if ok and type(value) == "number" then
            return value
        end
    end
    if vehicle ~= nil and type(vehicle.ownerFarmId) == "number" then
        return vehicle.ownerFarmId
    end
    if g_currentMission ~= nil and g_currentMission.player ~= nil then
        return g_currentMission.player.farmId
    end
    return nil
end

local function executeAuthoritativePurchase(vehicle, mode)
    if vehicle == nil then
        return false
    end

    if RPWorkshopButton == nil or RPWorkshopButton.getPurchaseInfo == nil then
        return false
    end

    local info = RPWorkshopButton.getPurchaseInfo(vehicle)
    mode = tostring(mode or "ALL")
    local price = info ~= nil and info.totalPrice or 0
    if info ~= nil and mode == "WHEELS" then
        price = info.tireOnlyPrice or 0
    elseif info ~= nil and mode == "TRACKS" then
        price = info.trackOnlyPrice or 0
    elseif info ~= nil and mode == "ROLLERS" then
        price = info.rollerOnlyPrice or 0
    end
    if type(price) ~= "number" or price <= 0 then
        return false
    end

    local farmId = getFarmId(vehicle)
    if farmId == nil or FarmManager ~= nil and FarmManager.SPECTATOR_FARM_ID ~= nil and farmId == FarmManager.SPECTATOR_FARM_ID then
        return false
    end

    -- TEST build: deliberately NO balance/affordability check.
    -- First perform the actual wear replacement. Money is only debited after
    -- the reset succeeded, so a failed reset can never consume the test price.
    if ReifenVerschleissDiagnostic == nil then
        return false
    end

    local ok, result
    if mode == "ALL" then
        local resetFn = ReifenVerschleissDiagnostic.resetRunningGearWorkshop
            or ReifenVerschleissDiagnostic.resetVehicleWear
        if resetFn == ReifenVerschleissDiagnostic.resetRunningGearWorkshop then
            ok, result = pcall(resetFn, vehicle, "ALL", "RP-FAHRZEUG-WECHSEL-ALL")
        else
            ok, result = pcall(resetFn, vehicle, "RP-FAHRZEUG-WECHSEL-ALL")
        end
    else
        local resetFn = ReifenVerschleissDiagnostic.resetRunningGearWorkshop
        if resetFn == nil then
            return false
        end
        ok, result = pcall(resetFn, vehicle, mode, "RP-FAHRZEUG-WECHSEL-" .. mode)
    end
    if not ok or result ~= true then
        return false
    end

    if g_currentMission == nil or g_currentMission.addMoney == nil then
        return false
    end

    g_currentMission:addMoney(-price, farmId, MoneyType.OTHER, true, true)

    if mode == "ALL" and ReifenVerschleissVisual ~= nil and ReifenVerschleissVisual.resetVehicleWearVisualsImmediate ~= nil then
        local visualFn = ReifenVerschleissVisual.resetVehicleWearVisualsImmediate
        local visualOk, visualErr = pcall(visualFn, vehicle)
        if ReifenVerschleissVisual.queueImmediateVisualReset ~= nil then
            ReifenVerschleissVisual.queueImmediateVisualReset(vehicle)
        end
    end


    return true
end

function RPReifenWechselnEvent.executePurchase(vehicle, mode)
    if vehicle == nil then
        return false
    end

    if g_server ~= nil then
        local result = executeAuthoritativePurchase(vehicle, mode)
        if result and g_server.broadcastEvent ~= nil then
            -- The server has already reset its state. Clients need only mirror
            -- the custom wear reset/visual refresh; the event is intentionally
            -- reused as the synchronization message below.
            local event = RPReifenWechselnEvent.new(vehicle, mode)
            g_server:broadcastEvent(event, nil, nil, vehicle)
        end
        return result
    end

    if RPReifenWechselnEvent.sendEvent ~= nil and g_client ~= nil and g_client:getServerConnection() ~= nil then
        RPReifenWechselnEvent.sendEvent(vehicle, mode)
        return true
    end

    return false
end

function RPReifenWechselnEvent:run(connection)
    if g_server ~= nil then
        -- Client request: the server recalculates the complete purchase price
        -- from the actual vehicle and performs the debit/reset authoritatively.
        if self.vehicle == nil or not self.vehicle:getIsSynchronized() then
            return
        end
        if connection == nil then
            return
        end

        local result = executeAuthoritativePurchase(self.vehicle, self.mode)
        if result and g_server.broadcastEvent ~= nil then
            g_server:broadcastEvent(self, false, connection, self.vehicle)
        end
        return
    end

    -- Client: mirror custom wear state and refresh already-created visuals.
    if self.vehicle ~= nil and ReifenVerschleissDiagnostic ~= nil then
        local stateOk, stateErr
        if tostring(self.mode or "ALL") == "ALL" and ReifenVerschleissDiagnostic.resetVehicleCustomWearState ~= nil then
            stateOk, stateErr = pcall(
                ReifenVerschleissDiagnostic.resetVehicleCustomWearState,
                self.vehicle, "RP-FAHRZEUG-WECHSEL-NETWORK-CLIENT"
            )
        elseif ReifenVerschleissDiagnostic.resetRunningGearWorkshop ~= nil then
            stateOk, stateErr = pcall(
                ReifenVerschleissDiagnostic.resetRunningGearWorkshop,
                self.vehicle, tostring(self.mode or "ALL"),
                "RP-FAHRZEUG-WECHSEL-NETWORK-CLIENT-" .. tostring(self.mode or "ALL")
            )
        end
    end

    if self.vehicle ~= nil and tostring(self.mode or "ALL") == "ALL" and ReifenVerschleissVisual ~= nil and
       ReifenVerschleissVisual.resetVehicleWearVisualsImmediate ~= nil then
        local visualFn = ReifenVerschleissVisual.resetVehicleWearVisualsImmediate
        local ok, err = pcall(visualFn, self.vehicle)
        if ReifenVerschleissVisual.queueImmediateVisualReset ~= nil then
            ReifenVerschleissVisual.queueImmediateVisualReset(self.vehicle)
        end
    end
end

function RPReifenWechselnEvent.sendEvent(vehicle, mode)
    if vehicle == nil then
        return
    end
    local event = RPReifenWechselnEvent.new(vehicle, mode)
    if g_client ~= nil and g_client:getServerConnection() ~= nil then
        g_client:getServerConnection():sendEvent(event)
    end
end
